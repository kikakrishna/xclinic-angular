import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'clina-2.0';
  result
  // constructor(private readonly swUpdate: SwUpdate) {
    // constructor(private swUpdate: SwUpdate) {
      constructor(){
  }

  ngOnInit() {
    // var r = confirm("New version available. Load New Version?");
    // if (r == true) {
    //  console.log(r);
    //  this.doAppUpdate();
    // } else {
    //   console.log(r);
    // }

      // if (this.swUpdate.isEnabled) {

      //     this.swUpdate.available.subscribe((event) => {

      //         if(confirm("New version available. Load New Version?")) {

      //             window.location.reload();
      //         }
      //     });
      // }        
  }
  // doAppUpdate() {
  //   this.swUpdate.activateUpdate().then(() => document.location.reload());
  // }
}

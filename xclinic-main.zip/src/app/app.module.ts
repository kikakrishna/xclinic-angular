import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { RouterModule } from '@angular/router';
import { JwtInterceptor } from './_helpers/jwt.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MainLayoutComponent } from './_components/layout/main-layout/main-layout.component';
import { ContentComponent } from './_components/layout/page-layout/content/content.component';
import { FooterModule } from './_components/layout/page-layout/footer/footer.module';
import { HeaderModule } from './_components/layout/page-layout/header/header.module';
import { PatientheaderModule } from './_components/layout/page-layout/patientheader/patientheader.module';
import { SidemenuModule } from './_components/layout/page-layout/sidemenu/sidemenu.module';
import { PatientmainmenuModule } from './_components/layout/page-layout/patientmainmenu/patientmainmenu.module';
import { ShareDataService } from './_services/sharedata.service';
import { VideocontentComponent } from './_components/layout/page-layout/videocontent/videocontent.component';
import { ToastModule } from 'ng-uikit-pro-standard';
import { LandingcontentComponent } from './_components/layout/page-layout/landingcontent/landingcontent.component';
import { LOCALE_ID } from '@angular/core';
import { PatientvideocomponentComponent } from './_components/layout/page-layout/patientvideocomponent/patientvideocomponent.component';
import { MatSelectModule } from '@angular/material/select';
import { LandingServicesModule } from './_components/pages/landing-services/landing-services.module';
// export function initializeApp1(appInitService: ChatbotService) {
//   // appInitService.getChatbot();
//   return () => appInitService.getChatbot();

//   // return (): Promise<any> => { 
//     // return appInitService.getChatbot();
//   // }
// }
// import { AppInitService } from './_services/app-init.service';

import { PatientService } from './_services/patient.service';
export function initializeApp2(PatientService: PatientService) {
  console.log("PatientService.init() called");
  return () =>
  new Promise((resolve) => {
    PatientService.domaindetail().subscribe().add(resolve);
    console.log('PatientService Finished');
  });
}

@NgModule({
  declarations: [
    AppComponent,
    MainLayoutComponent,
    ContentComponent,
    VideocontentComponent,
    LandingcontentComponent,
    PatientvideocomponentComponent,
  ],
  entryComponents: [
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FooterModule,
    HeaderModule,
    PatientheaderModule,
    SidemenuModule,
    PatientmainmenuModule,
    MatSelectModule,
    ToastModule.forRoot({ timeOut: 2000, enableHtml: true }),
    RouterModule.forRoot([

      {
        path: '',
        component: LandingcontentComponent,
        loadChildren: () => import('./_components/pages/landing-home/landing-home.module').then(m => m.LandingHomeModule)
      },
      {
        path: 'doctor',
        loadChildren: () => import('./_components/auth/login/login.module').then(m => m.LoginModule)
      },
      {
        path: 'resetpassword',
        loadChildren: () => import('./_components/pages/forgotpasswordnew/forgotpasswordnew.module').then(m => m.ForgotpasswordnewModule)
      },
      {
        path: 'consultationcall',
        component: PatientvideocomponentComponent,
        children:
          [
            {
              path: ':roomId/:roomDetails',
              loadChildren: () => import('./_components/pages/patient-appointmentcall/patient-appointmentcall.module').then(m => m.PatientAppointmentcallModule)
            },
          ]
      },
      {
        path: 'patient-call',
        component: PatientvideocomponentComponent,
        children:
          [
            {
              path: ':roomDetails',
              loadChildren: () => import('./_components/pages/patient-appointmentcall/patient-appointmentcall.module').then(m => m.PatientAppointmentcallModule)
            },
          ]
      },

      {
        path: 'thealth',
        component: ContentComponent,
        children:
          [
            // {
            //   path: 'appointment-booking',
            //   loadChildren: () => import('./_components/pages/bookappointment/bookappointment.module').then(m => m.BookappointmentModule)
            // },
            {
              path: 'appointments/:tId',
              loadChildren: () => import('./_components/pages/appointments/appointments.module').then(m => m.AppointmentsModule)
            },
            {
              path: 'payments',
              loadChildren: () => import('./_components/pages/payments/payments.module').then(m => m.PaymentsModule)
            },
            {
              path: 'dashboard',
              loadChildren: () => import('./_components/pages/dashboard/dashboard.module').then(m => m.DashboardModule)
            },
            {
              path: 'admin-dashboard',
              loadChildren: () => import('./_components/pages/dashboard/dashboard.module').then(m => m.DashboardModule)
            },
            {
              path: 'doctor/dashboard',
              loadChildren: () => import('./_components/pages/doctor-dashboard/doctor-dashboard.module').then(m => m.DoctorDashboardModule)
            },
            // {
            //   path: 'doctors',
            //   loadChildren: () => import('./_components/pages/doctors/doctors.module').then(m => m.DoctorsModule)
            // },
            {
              path: 'medicalhistory',
              loadChildren: () => import('./_components/pages/medicalhistory/medicalhistory.module').then(m => m.MedicalhistoryModule)
            },         
            {
              path: 'myprofile/edit',
              loadChildren: () => import('./_components/pages/patienteditprofile/patienteditprofile.module').then(m => m.PatienteditprofileModule)
            },
            {
              path: 'myprofile',
              loadChildren: () => import('./_components/pages/patientprofile/patientprofile.module').then(m => m.PatientprofileModule)
            },
            {
              path: 'medicalrecords',
              loadChildren: () => import('./_components/pages/medicalrecords/medicalrecords.module').then(m => m.MedicalrecordsModule)
            },
            {
              path: 'payments/invoice/:aptId',
              loadChildren: () => import('./_components/pages/paymentinvoice/paymentinvoice.module').then(m => m.PaymentinvoiceModule)
            },
            {
              path: 'appointments/:tId/:aptId',
              loadChildren: () => import('./_components/pages/appointmentview/appointmentview.module').then(m => m.AppointmentviewModule)
            },
            {
              path: 'treatments/:appointmentId',
              loadChildren: () => import('./_components/pages/patienttreatments/patienttreatments.module').then(m => m.PatienttreatmentsModule)
            },
            {
              path: 'doctor/profile',
              loadChildren: () => import('./_components/pages/doctor-myprofile/doctor-myprofile.module').then(m => m.DoctorMyprofileModule)
            },
            {
              path: 'doctor/appointments/:appointmentId',
              loadChildren: () => import('./_components/pages/doctor-appointmentview/doctor-appointmentview.module').then(m => m.DoctorAppointmentviewModule)
            },
            {
              path: 'doctor/invoice',
              loadChildren: () => import('./_components/pages/doctor-invoice/doctor-invoice.module').then(m => m.DoctorInvoiceModule)
            },
            {
              path: 'doctor/invoice/:serviceTransactionId',
              loadChildren: () => import('./_components/pages/doctor-invoice-detail/doctor-invoice-detail.module').then(m => m.DoctorInvoiceDetailModule)
            },
            {
              path: 'doctor/mypatients',
              loadChildren: () => import('./_components/pages/doctor-mypatients/doctor-mypatients.module').then(m => m.DoctorMypatientsModule)
            },
            {
              path: 'doctor/profile/edit',
              loadChildren: () => import('./_components/pages/doctor-editprofile/doctor-editprofile.module').then(m => m.DoctorEditprofileModule)
            },
            {
              path: 'doctor/mypatients/:patientid',
              loadChildren: () => import('./_components/pages/doctor-mypatientview/doctor-mypatientview.module').then(m => m.DoctorMypatientviewModule)
            },
            {
              path: 'doctor/manageslots',
              loadChildren: () => import('./_components/pages/doctor-manageslots/doctor-manageslots.module').then(m => m.DoctorManageslotsModule)
            },
            {
              path: 'doctor/unavailableslots',
              loadChildren: () => import('./_components/pages/doctor-unavailableslots/doctor-unavailableslots.module').then(m => m.DoctorUnavailableslotsModule)
            },
            {
              path: 'clinicadmin/medicalhistory/:patientid',
              loadChildren: () => import('./_components/pages/clinicadmin-medicalhistory/clinicadmin-medicalhistory.module').then(m => m.ClinicadminMedicalhistoryModule)
            },
            {
              path: 'clinicadmin/unavailableslots/:doctorid',
              loadChildren: () => import('./_components/pages/clinicadmin-unavailableslots/clinicadmin-unavailableslots..module').then(m => m.ClinicadminUnavailableslotsModule)
            },
            {
              path: 'clinicadmin/manageslots/:doctorid',
              loadChildren: () => import('./_components/pages/clinicadmin-manageslots/clinicadmin-manageslots.module').then(m => m.ClinicadminManageslotsModule)
            },
            {
              path: 'clinicadmin/dashboard',
              loadChildren: () => import('./_components/pages/clinicadmin-dashboard/clinicadmin-dashboard.module').then(m => m.ClinicadminDashboardModule)
            },
            {
              path: 'clinicadmin/patients',
              loadChildren: () => import('./_components/pages/clinicadmin-patients/clinicadmin-patients.module').then(m => m.ClinicadminPatientsModule)
            },
            {
              path: 'clinicadmin/bookingdetail',
              loadChildren: () => import('./_components/pages/clinic-admin-bookingdetail/clinic-admin-bookingdetail.module').then(m => m.ClinicadminBookingModule)
            },
            {
              path: 'clinicadmin/patients/bookappointment/:patientId',
              loadChildren: () => import('./_components/pages/clinicadmin-bookappointment/clinicadmin-bookappointment.module').then(m => m.ClinicadminBookappointmentModule)
            },
            // { new change
            //   path: 'clinicadmin-patients/view',
            //   loadChildren: () => import('./_components/pages/clinicadmin-patientview/clinicadmin-patientview.module').then(m => m.ClinicadminPatientviewModule)
            // },
            // {
            //   path: 'clinicadmin-doctors/profile',
            //   loadChildren: () => import('./_components/pages/clinicadmin-doctorprofile/clinicadmin-doctorprofile.module').then(m => m.ClinicadminDoctorprofileModule)
            // },

            {
              path: 'clinicadmin/patients/view/:patientid',
              loadChildren: () => import('./_components/pages/clinicadmin-patientview/clinicadmin-patientview.module').then(m => m.ClinicadminPatientviewModule)
            },
            {
              path: 'clinicadmin/doctors/profile/:doctorid',
              loadChildren: () => import('./_components/pages/clinicadmin-doctorprofile/clinicadmin-doctorprofile.module').then(m => m.ClinicadminDoctorprofileModule)
            },
            // { old change
            //   path: 'clinicadmin-patientview/:patientid',
            //   loadChildren: () => import('./_components/pages/clinicadmin-patientview/clinicadmin-patientview.module').then(m => m.ClinicadminPatientviewModule)
            // },
            // {
            //   path: 'clinicadmin-doctorprofile/:doctorid',
            //   loadChildren: () => import('./_components/pages/clinicadmin-doctorprofile/clinicadmin-doctorprofile.module').then(m => m.ClinicadminDoctorprofileModule)
            // },
            {
              path: 'clinicadmin/appointments/:tId',
              loadChildren: () => import('./_components/pages/clinicadmin-appointments/clinicadmin-appointments.module').then(m => m.ClinicAdminAppointmentsModule)
            },
            {
              path: 'clinicadmin/appointments/:tId/:appointmentId',
              loadChildren: () => import('./_components/pages/clinicadmin-appointmentview/clinicadmin-appointmentview.module').then(m => m.ClinicAdminAppointmentviewModule)
            },
            {
              path: 'clinicadmin/services/edit/:clinicserviceid',
              loadChildren: () => import('./_components/pages/clinicadmin-serviceedit/clinicadmin-serviceedit.module').then(m => m.ClinicAdminServiceeditModule)
            },
            {
              path: 'clinicadmin/services/add',
              loadChildren: () => import('./_components/pages/clinicadmin-serviceedit/clinicadmin-serviceedit.module').then(m => m.ClinicAdminServiceeditModule)
            },
            {
              path: 'clinicadmin/services',
              loadChildren: () => import('./_components/pages/clinicadmin-serviceview/clinicadmin-serviceview.module').then(m => m.ClinicAdminServiceviewModule)
            },
            {
              path: 'clinicadmin/slider',
              loadChildren: () => import('./_components/pages/clinicadmin-slider/clinicadmin-slider.module').then(m => m.ClinicAdminSliderModule)
            },
            {
              path: 'clinicadmin/product',
              loadChildren: () => import('./_components/pages/clinicadmin-product/clinicadmin-product.module').then(m => m.ClinicAdminProductModule)
            },
            {
              path:'clinicadmin/supplier/add',
              loadChildren: ()=> import('./_components/pages/clinicadmin-supplier/clinicadmin-supplier.module').then(m =>m.ClinicAdminSupplierModule)
            },
            {
              path:'clinicadmin/supplier/edit/:supplierId',
              loadChildren: ()=> import('./_components/pages/clinicadmin-supplier/clinicadmin-supplier.module').then(m =>m.ClinicAdminSupplierModule)
            },
            {
              path:'clinicadmin/supplier',
              loadChildren: ()=> import('./_components/pages/clinicadmin-supplierlist/clinicadmin-supplierlist.module').then(m => m.ClinicAdminSupplierlistModule)
            },
            {
             path:'clinicadmin/stockin',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockin/clinicadmin-stockin.module').then(m => m.ClinicAdminStockinModule)
            },
            {
             path:'clinicadmin/stockin/view/:stockinwardId',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockin/clinicadmin-stockin.module').then(m => m.ClinicAdminStockinModule)
            },
            {
              path:'clinicadmin/stockinview',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockinview/clinicadmin-stockinview.module').then(m =>m.ClinicAdminStockinviewModule)
            },
            {
              path:'clinicadmin/stockinlist',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockinlist/clinicadmin-stockinlist.module').then(m => m.ClinicAdminStockinlistModule)
            },
            {
              path:'clinicadmin/stockissueview',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockissueview/clinicadmin-stockissueview.module').then(m =>m.ClinicAdminStockissueviewModule)
            },
            {
              path:'clinicadmin/stockadjustmentview',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockadjustmentview/clinicadmin-stockadjustmentview.module').then(m =>m.ClinicAdminStockadjustmentviewModule)
            },
               {
               path:'clinicadmin/stockissue/add',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockissue/clinicadmin-stockissue.module').then(m => m.ClinicAdminStockissueModule)
            },{
               path:'clinicadmin/stockissue/edit/:clinicissueid',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockissue/clinicadmin-stockissue.module').then(m => m.ClinicAdminStockissueModule)
            },
            {
              path: 'clinicadmin/stockadjustmentlist',
              loadChildren: () => import('./_components/pages/clinicadmin-stockadjustmentlist/clinicadmin-stockadjustmentlist.module').then(m => m.ClinicAdminStockadjustmentlistModule)
            }, 
            {
              path:'clinicadmin/stockadjustment/add',
             loadChildren: ()=> import('./_components/pages/clinicadmin-stockadjustment/clinicadmin-stockadjustment.module').then(m => m.ClinicAdminStockadjustmentModule)
            },
            {
              path:'clinicadmin/stockadjustment/edit/:stockadjustmentid',
             loadChildren: ()=> import('./_components/pages/clinicadmin-stockadjustment/clinicadmin-stockadjustment.module').then(m => m.ClinicAdminStockadjustmentModule)
            },
            {
              path:'clinicadmin/productstock',
              loadChildren: ()=> import('./_components/pages/clinicadmin-productstock/clinicadmin-productstock.module').then(m =>m.ClinicAdminProductstockModule)
            },
            {
              path:'clinicadmin/producttransactions/:productid',
              loadChildren: ()=> import('./_components/pages/clinicadmin-producttransactions/clinicadmin-producttransactions.module').then(m =>m.ClinicAdminProducttransactionsModule)
            },
            {
              path:'clinicadmin/stockissuelist',
              loadChildren: ()=> import('./_components/pages/clinicadmin-stockissuelist/clinicadmin-stockissuelist.module').then(m =>m.ClinicAdminStockissuelistModule)
            },
            {
              path: 'clinicadmin/testimonial',
              loadChildren: () => import('./_components/pages/clinicadmin-testimonial/clinicadmin-testimonial.module').then(m => m.ClinicAdminTestimonialModule)
            }, 
            {
              path: 'clinicadmin/testimonial/add',
              loadChildren: () => import('./_components/pages/clinicadmin-testimonialedit/clinicadmin-testimonialedit.module').then(m => m.ClinicAdminTestimonialeditModule)
            },
            {
              path: 'clinicadmin/testimonial/edit/:testimonialId',
              loadChildren: () => import('./_components/pages/clinicadmin-testimonialedit/clinicadmin-testimonialedit.module').then(m => m.ClinicAdminTestimonialeditModule)
            },
            {
              path: 'clinicadmin/headerbanner',
              loadChildren: () => import('./_components/pages/clinicadmin-headerbanner/clinicadmin-headerbanner.module').then(m => m.ClinicAdminHeaderbannerModule)
            },
            {
              path: 'clinicadmin/view',
              loadChildren: () => import('./_components/pages/clinicadmin-view/clinicadmin-view.module').then(m => m.ClinicAdminViewModule)
            },
            {
              path: 'clinicadmin/edit/:clinicid',
              loadChildren: () => import('./_components/pages/clinicadmin-edit/clinicadmin-edit.module').then(m => m.ClinicAdminEditModule)
            },
            {
              path: 'clinicadmin/doctors',
              loadChildren: () => import('./_components/pages/clinicadmin-doctors/clinicadmin-doctors.module').then(m => m.ClinicAdminDoctorsModule)
            },
            {
              path: 'clinicadmin/transaction',
              loadChildren: () => import('./_components/pages/clinicadmin-transaction/clinicadmin-transaction.module').then(m => m.ClinicadminTransactionModule)
            },
            {
              path: 'clinicadmin/createtransaction',
              loadChildren: () => import('./_components/pages/clinicadmin-createtransaction/clinicadmin-createtransaction.module').then(m => m.ClinicadminCreateTransactionModule)
            },
            {
              path: 'clinicadmin/createtransaction/:bill_appointment_map_id',
              loadChildren: () => import('./_components/pages/clinicadmin-createtransaction/clinicadmin-createtransaction.module').then(m => m.ClinicadminCreateTransactionModule)
            },
            {
              path: 'clinicadmin/transactioninvoice/:bill_appointment_map_id',
              loadChildren: () => import('./_components/pages/clinicadmin-transactioninvoice/clinicadmin-transactioninvoice.module').then(m => m.ClinicadminTransactionInvoiceModule)
            },
            {
              path: 'clinicadmin/administration',
              loadChildren: () => import('./_components/pages/clinicadmin-administration/clinicadmin-administration.module').then(m => m.ClinicadminAdministrationModule)
            },
            {
              path: 'clinicadmin/vitalgroup',
              loadChildren: () => import('./_components/pages/clinicadmin-createvitalgroup/clinicadmin-createvitalgroup.module').then(m => m.ClinicadminCreatevitalgroupModule)
            },
            {
              path: 'doctor/vitalgroup',
              loadChildren: () => import('./_components/pages/doctor-vitalgroup/doctor-vitalgroup.module').then(m => m.DoctorVitalgroupModule)
            },
            {
              path: 'clinicadmin/galleryimages/:id',
              loadChildren: () => import('./_components/pages/clinicadmin-galleryimage/clinicadmin-galleryimage.module').then(m => m.ClinicAdminGalleryimageModule)
            },
            {
              path: 'clinicadmin/gallerygroup',
              loadChildren: () => import('./_components/pages/clinicadmin-gallerygroup/clinicadmin-gallerygroup.module').then(m => m. ClinicadminGallerygroupModule)
            },
            {
              path: 'clinicadmin/packagetreatmentplan',
              loadChildren: () => import('./_components/pages/clinicadmin-packagetreatmentplan/clinicadmin-packagetreatmentplan.module').then(m => m.ClinicadminPackagetreatmentplanModule)
            },
            {
              path: 'clinicadmin/packagetreatmentlist',
              loadChildren: () => import('./_components/pages/clinicadmin-packagetreatmentlist/clinicadmin-packagetreatmentlist.module').then(m => m.ClinicadminpackagetreatmentlistModule)
            },
            {
              path: 'clinicadmin/plantreatmentschedule/:id',
              loadChildren: () => import('./_components/pages/clinicadmin-plantreatmentschedule/clinicadmin-plantreatmentschedule.module').then(m => m.ClinicAdminplantreatmentscheduleModule)
            },
            {
              path: 'clinicadmin/packagetreatmentsummary/:patienttrpackagemapid',
              loadChildren: () => import('./_components/pages/clinicadmin-packagetreatmentsummary/clinicadmin-packagetreatmentsummary.module').then(m => m.ClinicadminPackagetreatmentsummaryModule)
            },
          ]
      },

      {
        path: 'thealth',
        component: VideocontentComponent,
        children:
          [
            {
              path: 'doctor/appointmentcall/:appointmentId',
              loadChildren: () => import('./_components/pages/doctor-appointmentcall/doctor-appointmentcall.module').then(m => m.DoctorAppointmentcallModule)
            },
          ]
      },
      {
        path: 'thealth',
        component: PatientvideocomponentComponent,
        children:
          [
            {
              path: 'patient/appointmentcall/:appointmentId',
              loadChildren: () => import('./_components/pages/patient-appointmentcall/patient-appointmentcall.module').then(m => m.PatientAppointmentcallModule)
            },
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'home',
              loadChildren: () => import('./_components/pages/landing-home/landing-home.module').then(m => m.LandingHomeModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'login',
              loadChildren: () => import('./_components/auth/patient-login/patient-login.module').then(m => m.PatientLoginModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'appointment',
              loadChildren: () => import('./_components/pages/landing-booking/landing-booking.module').then(m => m.LandingBookingModule)
            }
          ]
      }, {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'payment',
              loadChildren: () => import('./_components/pages/landing-bookingdetail/landing-bookingdetail.module').then(m => m.LandingBookingdetailModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'faq',
              loadChildren: () => import('./_components/pages/faq/faq.module').then(m => m.FaqModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'contact',
              loadChildren: () => import('./_components/pages/contact/contact.module').then(m => m.ContactModule)
            }
          ]
      },
      // {
      //   path: 'thealth',
      //   component: LandingcontentComponent,
      //   children:
      //     [
      //       {
      //         path: 'blog/doublemasking',
      //         loadChildren: () => import('./_components/pages/landing-blog1/landing-blog1.module').then(m => m.LandingBlog1Module)
      //       }
      //     ]
      // },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'blog/medicaltests',
              loadChildren: () => import('./_components/pages/landing-blog1/landing-blog1.module').then(m => m.LandingBlog1Module)
            }
          ]
      },
      // {
      //   path: 'thealth',
      //   component: LandingcontentComponent,
      //   children:
      //     [
      //       {
      //         path: 'blog/dietplan',
      //         loadChildren: () => import('./_components/pages/landing-blog2/landing-blog2.module').then(m => m.LandingBlog2Module)
      //       }
      //     ]
      // },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'blog/stayinghealthy',
              loadChildren: () => import('./_components/pages/landing-blog2/landing-blog2.module').then(m => m.LandingBlog2Module)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'blog/managingstress',
              loadChildren: () => import('./_components/pages/landing-blog3/landing-blog3.module').then(m => m.LandingBlog3Module)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'services',
              loadChildren: () => import('./_components/pages/landing-services/landing-services.module').then(m => m.LandingServicesModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'facilities',
              loadChildren: () => import('./_components/pages/landing-facilities/landing-facilities.module').then(m => m.LandingFacilitiesModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'news',
              loadChildren: () => import('./_components/pages/landing-events/landing-events.module').then(m => m.LandingEventsModule)
            }
          ]
      },
      {
        path: 'thealth',
        component: LandingcontentComponent,
        children:
          [
            {
              path: 'paymentlinkverify',
              loadChildren: () => import('./_components/pages/paymentlinkverification/paymentlinkverification.module').then(m => m.PaymentlinkverificationModule)
            }
          ]
      }

    ],
      {
        useHash: true,
        scrollPositionRestoration: 'top',
      })
  ],
  providers: [
    // ChatbotService,    
    // { provide: APP_INITIALIZER,useFactory: initializeApp1, deps: [ChatbotService], multi: true},
    ShareDataService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    { provide: LOCALE_ID, useValue: "en-US" },
    { provide: APP_INITIALIZER,useFactory: initializeApp2, deps: [PatientService], multi: true }
  ],
  exports: [

  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  //   constructor(public chatservice:ChatbotService){
  //  this.chatservice.getChatbot();
  //   }
}
     // {
      //   path: 'ClinaNg',
      //   component: DoctorAppointmentcallComponent,
      //   children:
      //     [
      //       {
      //         path: 'doctor-appointmentcall/:id',
      //         loadChildren: () => import('./_components/pages/doctor-appointmentcall/doctor-appointmentcall.module').then(m => m.DoctorAppointmentcallModule)
      //       },
      //     ]
      // },

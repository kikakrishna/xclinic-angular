import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormGroupDirective, NgForm} from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService } from '../../../_services/authentication.service';
import { Router, ActivatedRoute } from "@angular/router";
import { MatDialog } from '@angular/material/dialog';
import { LoginFamilymemberListComponent } from '../../pages/login-familymember-list/login-familymember-list.component';
import { ToastService } from 'ng-uikit-pro-standard';
import { DoctorService } from 'src/app/_services/doctor.service';
import { ForgotpasswordComponent } from '../../pages/forgotpassword/forgotpassword.component';
import { PatientService } from 'src/app/_services/patient.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  hide = true;
  RegisterForm = true;
  LoginForm = false;
  patientLogin: FormGroup;
  doctorLogin: FormGroup;
  returndoctorUrl: string;
  returnclinicadminUrl: string;
  returnadminUrl: string;
  userrole: any;
  returnpatientUrl: string;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  patloginerror: boolean;
  docloginerror: boolean;
  registererror: boolean;
  registererrorMsg: any;
  patloginerrorMsg: any;
  docloginerrorMsg: any;
  messagebox: boolean;
  errormessagebox: boolean;
  loading: boolean;
  patientRegister: FormGroup;
  patlogindisable: boolean;
  error : any;
  langurl: string = "";
  siteLanguage: string;
  disableBtn: boolean;
  validatemyemail: boolean;
  validatemyemail2: boolean = true;
  languageList = [
    { code: 'en', label: 'English' },
    { code: 'ta', label: 'தமிழ்' },
    { code: 'mal', label: 'മലയാളം' },
    { code: 'vie', label: 'Tiếng Việt' },
    { code: 'ar', label: 'عربى' }
  ];
  siteLocale: string;
  constructor(
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private toastrService: ToastService,
    private _DoctorService: DoctorService,
    public _patientservice:PatientService
  ) {
    if (this.authenticationService.currentUserValue) {
      this.userrole = sessionStorage.getItem('Role');
      if (this.userrole === 'patient') {
        this.router.navigate(['/thealth/dashboard']);
      } if (this.userrole === 'clinicadmin') {
        this.router.navigate(['/thealth/clinicadmin/dashboard']);
      }
      else if (this.userrole === 'Doctor') {
        this.router.navigate(['/thealth/doctor/dashboard']);
      } else if (this.userrole === 'Admin' || this.userrole === 'ClinicAdmin') {
        this.router.navigate(['/thealth/admin-dashboard']);
      }
    }
    this.loading = false;
    this.patlogindisable = false;
    this.disableBtn = false;
    sessionStorage.setItem('familyMemberGuid', "");
  }

  @ViewChild('formDirective') private formDirective: NgForm;
  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;

  ngOnInit(): void {    
     if(window.location.pathname.split('/')[1] != ""){
      this.siteLanguage = window.location.pathname.split('/')[1]
     }
    if(sessionStorage.getItem("currentLang")){
      this.siteLanguage = this.languageList.find(f => f.code === sessionStorage.getItem("currentLang")).label;
    }
    else{
      this.siteLanguage = this.languageList[0].label;
    }
    this.toastrService.clear();
    this.patientLogin = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', Validators.required],
      clinicid: ['', Validators.required]
    });
    this.doctorLogin = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required,Validators.required, Validators.pattern(/^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/)])],
      password: ['' , Validators.required]
    });
    this.patientRegister = this.formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required,Validators.minLength(4),Validators.pattern('^.{4,}$')]]
    });

    this._patientservice.domaindetail()
    .pipe(first())
    .subscribe((res:any) => {
      if(!res.isError){        
        console.log(res)
      }
    });

    this.returnpatientUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/dashboard';
    this.returnadminUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/admin-dashboard';
    this.returndoctorUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/doctor/dashboard';
    this.returnclinicadminUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/clinicadmin/dashboard';
    
    this.siteLanguage = this.languageList[0].label;
    this.siteLocale = window.location.pathname.split('/')[1];
    if (this.siteLocale && this.siteLocale != "#") {
      this.siteLanguage = this.languageList.find(f => f.code === this.siteLocale)?.label;
      console.log(this.siteLanguage);
    }
    console.log(this.siteLanguage);
    this.changeLang(this.siteLanguage)
  }

  changeLang(lang: string) {
    this.langurl = this.route.snapshot['_routerState'].url
    if (lang === 'mal') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'mal')
    }
    else if (lang === 'ta') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'ta')
    }
    else if (lang === 'vie') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'vie')
    }
    else if (lang === 'ar') {
      alert();
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'ar')
    }
    else {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'en')
    }
    sessionStorage.setItem('sitelanguage',lang);
    }

  get f() { return this.patientLogin.controls; }

  // Chatbot(){
  //   this.authenticationService.getChatbot() 
  //   .subscribe((res: any) => {
  //     if (!res.isError) {
  //       console.log(res)
  //       sessionStorage.setItem('hasChatBot',res.responseMessage.hasChatBot);
  //     }
  //     else {
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', res.errorMessage, options);
  //       setTimeout(() => {
  //         this.toastrService.clear(),2000
  //       }, 2000);
  //     }
  //   },
  //     err => {
  //       const options = { opacity: 1, timeOut: 2000,tapToDismiss: true };                
  //       this.toastrService.warning('', err?.error, options);
  //       setTimeout(() => {
  //         this.toastrService.clear(),2000
  //       }, 2000);
  //     });    
  // }
  patSubmit(formData: any, formDirective: FormGroupDirective) {
    
    if(this.validatemyemail == false){
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Invalid Email Address', options);
      setTimeout(() => {
        this.toastrService.clear(),2000
      }, 2000);
      return;
    }

    this.toastrService.clear();
    this.loading = true;
    this.patlogindisable = true;
    this.error = false;
    this.disableBtn = true;
    if(this.patientLogin.value.email == '' && this.patientLogin.value.password =='') {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Specify Username and Password', options);
      setTimeout(() => {
        this.toastrService.clear(),2000
      }, 2000);
      this.error = true;
    }
    if(!this.error) {      
    this.authenticationService.loginpat(this.patientLogin.value)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.toastrService.clear();
          this.loading = false;
          if (res.responseMessage.role === 'patient') {                 
            // this.Chatbot();
            this._DoctorService.familylist(res.responseMessage.userid)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  if (res.responseMessage.length === 0) {
                    this.router.navigate([this.returnpatientUrl]);
                  }
                  else {
                    const dialogRef = this.dialog.open(LoginFamilymemberListComponent, {
                      maxWidth: '100vw',
                      maxHeight: '100vh',
                      height: '100%',
                      width: '100%',
                      panelClass: 'loginfamily-dialog'
                    });
                    dialogRef.afterClosed().subscribe(result => {
                      this.disableBtn = false;
                      this.router.navigate([this.returnpatientUrl]);
                    });
                  }
                }
                else {
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                  setTimeout(() => {
                    this.toastrService.clear(),2000
                  }, 2000);

                }
              },
                err => {
                  const options = { opacity: 1, timeOut: 2000,tapToDismiss: true };
                  console.log(err);
                  for (var prop in err.error) {
                    this.toastrService.warning('', err?.error[prop], options);
                  }
                  formDirective.resetForm();
                  this.patientRegister.reset();
                  setTimeout(() => {
                    this.toastrService.clear(),2000
                  }, 2000);
                });
          } else {        
            this.disableBtn = false;    
            formDirective.resetForm();
            this.patientLogin.reset();
            this.patloginerror = true;
            this.patloginerrorMsg = "User not registered as Patient";
            setTimeout(() => {
              this.patloginerror = false;
            }, 3000);
          }
        }
        else {
          this.disableBtn = false;
          const options = { opacity: 1,timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }

      },
        err => {
          this.disableBtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          if(err?.error.Username) {
            this.toastrService.warning('', err?.error.Username[0], options);
          }
          if(err?.error.Password) {
            this.toastrService.warning('', err?.error.Password[0], options);
          }
          
          this.loading = false;
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });
      }
      else {
        this.loading = false;
        this.disableBtn = false;
      }
  }

  forgotpassword(){
    const dialogRef = this.dialog.open(ForgotpasswordComponent, {
      panelClass: 'forgotpassword-dialog'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
        } else {
        }
      }
    });
  }
  
  tabClick(tab) {
    console.log(tab.tab.textLabel)
    if(tab.tab.textLabel == "doctor"){
      this.doctorLogin = this.formBuilder.group({
        email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
        password: ['' , Validators.required]
      });
    }
  }
  save(event) {    
    const regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;   
    if(regularExpression.test(String(event.target.value).toLowerCase()))     
    {
      this.validatemyemail = true    
    }
    else{
      this.validatemyemail = false;      
    }  
  }

  save2() {  
    if(isNaN(Number(this.doctorLogin.value.email)) == true){

    const regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;   
    if(this.doctorLogin.value.email.trim() != ""){
    if(regularExpression.test(String(this.doctorLogin.value.email.trim()).toLowerCase()))     
    {
      this.validatemyemail2 = true    
    }
    else{
      this.validatemyemail2 = false;      
    }  
   }
  }
  }

  docSubmit(formData: any, formDirective: FormGroupDirective) {        
    this.save2();
    this.toastrService.clear();    
    this.loading = true;
    this.error = false;
    if(this.doctorLogin.value.email == '' && this.doctorLogin.value.password ==''){
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please specify username and password', options);
      setTimeout(() => {
        this.toastrService.clear(),2000
      }, 2000);
      this.error = true;
    }
    if (this.doctorLogin?.value.email !== '' && this.doctorLogin?.value.password == '') {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('','Please specify password', options);
      this.loading = false;
      return;

    }
    if(!this.error){
      let payload:any = {}      
      if(isNaN(Number(this.doctorLogin.value.email)) == true){
        // email id  login
        if(this.validatemyemail2 == false){
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Invalid email address', options);
      setTimeout(() => {
        this.toastrService.clear(),2000
      }, 2000);
this.loading = false;
      return;
    }
        payload ={
          "Username": this.doctorLogin.value.email,
          "Password": this.doctorLogin.value.password
        }
        this.authenticationService.login2(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {          
            this.loading = false;
            // this.Chatbot();
            if (res.responseMessage.role === 'doctor') {
              this.router.navigate([this.returndoctorUrl]);
            }
            if (res.responseMessage.role === 'clinicadmin') {
              this.router.navigate([this.returnclinicadminUrl]);
            }
            else if (res.responseMessage.role === 'Admin' || res.responseMessage.role === 'ClinicAdmin') {
              this.router.navigate([this.returnadminUrl]);
            }
            formDirective.resetForm();
          } else {
            this.loading = false;          
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {          
            formDirective.resetForm();
            this.doctorLogin.reset();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            if(err?.error.Username) {
              this.toastrService.warning('', err?.error.Username[0], options);
            }
            if(err?.error.Password) {
              this.toastrService.warning('', err?.error.Password[0], options);
            }
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });        
      }else{
        // phone number login
        this.validatemyemail2=true;        
        payload ={
          "PhoneNumber": this.doctorLogin.value.email,
          "Password": this.doctorLogin.value.password
        }
        this.authenticationService.login2(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {          
            this.loading = false;
            // this.Chatbot();
            if (res.responseMessage.role === 'doctor') {
              this.router.navigate([this.returndoctorUrl]);
            }
            if (res.responseMessage.role === 'clinicadmin') {
              this.router.navigate([this.returnclinicadminUrl]);
            }
            else if (res.responseMessage.role === 'Admin' || res.responseMessage.role === 'ClinicAdmin') {
              this.router.navigate([this.returnadminUrl]);
            }
            formDirective.resetForm();
          } else {
            this.loading = false;          
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {          
            formDirective.resetForm();
            this.doctorLogin.reset();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            if(err?.error.Username) {
              this.toastrService.warning('', err?.error.Username[0], options);
            }
            if(err?.error.Password) {
              this.toastrService.warning('', err?.error.Password[0], options);
            }
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
      }
      }
      else {
        this.loading = false;
      }
  }

  patregSubmit(formData: any, formDirective: FormGroupDirective) {
    if(this.validatemyemail == false){
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Invalid Email Address', options);
      setTimeout(() => {
        this.toastrService.clear(),2000
      }, 2000);

      return;
    }else{
      this.loading = true;
      this.toastrService.clear();
      const roleid = 3;
      if(this.patientRegister.value.firstname == '' || this.patientRegister.value.firstname == null &&
        this.patientRegister.value.lastname =='' || this.patientRegister.value.lastname == null && 
        this.patientRegister.value.email =='' || this.patientRegister.value.email == null && 
        this.patientRegister.value.password == '' || this.patientRegister.value.password == null || this.patientRegister.value.password.trim() =="" ||
        this.patientRegister.value.password.trim().length < 4) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Enter Valid Details', options);
        setTimeout(() => {
          this.toastrService.clear(),2000
        }, 2000);
        this.loading = false;
        console.log(this.error)
        return;
      }else{

      this.authenticationService.register(this.patientRegister.value, roleid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.showLogin();
            this.ngOnInit();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.loading = false;
            formDirective.resetForm();
            this.patientRegister.reset();
            this.ngOnInit();
            
          }
          else {
            this.loading = false;
            formDirective.resetForm();
            this.patientRegister.reset();
            this.registererror = true;
            this.registererrorMsg = res.errorMessage;
            setTimeout(() => {
              this.registererror = false;
            }, 3000);
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err);
            const options = { opacity: 1,timeOut: 2000, tapToDismiss: true };
            for(var prop in err.error){
              this.toastrService.warning('', err?.error[prop], options);
            }
            formDirective.resetForm();
            this.patientRegister.reset();
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
        }
    }
  }

  closemessagebox() {
    this.forbiddenmessagebox = false;
    this.messagebox = false;
    this.errormessagebox = false;
  }

  showRegister() {
    this.LoginForm = !this.LoginForm;
    this.RegisterForm = !this.RegisterForm;
  }

  showLogin() {
    this.RegisterForm = !this.RegisterForm;
    this.LoginForm = !this.LoginForm;
  }

test(){
  alert();
}

}

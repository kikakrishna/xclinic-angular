import { RouterModule } from '@angular/router';
import { PatientLoginComponent } from './patient-login.component';
export const PatientLoginRoutes: RouterModule[] = [
    {
        path: '',
        component: PatientLoginComponent,
    }
]

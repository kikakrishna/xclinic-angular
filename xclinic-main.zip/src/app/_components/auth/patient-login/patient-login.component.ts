import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService } from '../../../_services/authentication.service';
import { Router, ActivatedRoute } from "@angular/router";
import { MatDialog } from '@angular/material/dialog';
import { LoginFamilymemberListComponent } from '../../pages/login-familymember-list/login-familymember-list.component';
import { ToastService } from 'ng-uikit-pro-standard';
import { DoctorService } from 'src/app/_services/doctor.service';
import { MatDialogRef } from '@angular/material/dialog';
import { ForgotpasswordTwoComponent } from '../../pages/forgotpassword-two/forgotpassword-two.component';

@Component({
  selector: 'app-patient-login',
  templateUrl: './patient-login.component.html',
  styleUrls: ['./patient-login.component.css']
})
export class PatientLoginComponent implements OnInit, OnDestroy {
  hide = true;
  hide1 = true;
  hide2 = true;
  selectedItem: any;
  emailsignin: boolean;
  patientLogin: FormGroup;
  patientotpLogin: FormGroup
  otpsignin: boolean;
  patientRegister: FormGroup;
  validatemyemail: boolean;
  userrole: any;
  patloginerror: boolean;
  registererror: boolean;
  registererrorMsg: any;
  returnpatientUrl: string;
  returnadminUrl: string;
  returndoctorUrl: string;
  returnclinicadminUrl: string;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  patlogindisable: boolean;
  error: any;
  disableBtn: boolean;
  loading: boolean;
  curLang: any;
  isotpReceived: boolean;
  public signintype: any[] = [
    { "type": "email", "name": "Existing User" },
    { "type": "otp", "name": "Sign In with OTP" },
  ];
  patloginerrorMsg: string;
  minlen: any = 1;
  maxlen: any = 1;
  returnpatientDashboardUrl: any;
  previousUrl: string = null;
  currentUrl: string = null;
  selectedti: any = 0

  constructor(private formBuilder: FormBuilder,
    public authenticationService: AuthenticationService,
    public router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    public toastrService: ToastService,
    public _DoctorService: DoctorService,
    public dialogRef: MatDialogRef<PatientLoginComponent>
  ) {
    this.minlen = sessionStorage.getItem("minlen");
    this.maxlen = sessionStorage.getItem("maxlen");
    if (this.authenticationService.currentUserValue) {
      this.userrole = sessionStorage.getItem('Role');
      if (this.userrole === 'patient') {
        this.router.navigate(['/thealth/appointment']);
      } else if (this.userrole === 'clinicadmin') {
        this.router.navigate(['/thealth/clinicadmin/dashboard']);
      }
      else if (this.userrole === 'Doctor') {
        this.router.navigate(['/thealth/doctor/dashboard']);
      } else if (this.userrole === 'Admin' || this.userrole === 'ClinicAdmin') {
        this.router.navigate(['/thealth/admin-dashboard']);
      }
    }
    sessionStorage.setItem('familyMemberGuid', "");
  }

  @ViewChild('formDirective') private formDirective: NgForm;
  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;

  ngOnInit(): void {
    this.curLang = window.location.pathname.split('/')[1]
    let currentURL = window.location.pathname.split('/')[1]
    let langg = sessionStorage.getItem('currentLang')
    
    if (langg === 'ta' || currentURL === 'ta') {
      this.signintype = [
        { "type": "otp", "name": "OTP உடன் உள்நுழைக" },
        { "type": "email", "name": "மின்னஞ்சல்/மொபைல் எண்" },
      ];
      this.selectedItem = "OTP உடன் உள்நுழைக";
    }
    else if (langg === 'mal' || currentURL === 'mal') {
      this.signintype = [
        { "type": "otp", "name": "OTP ഉപയോഗിച്ച്" },
        { "type": "email", "name": "ഇമെയിൽ/മൊബൈൽ നമ്പർ" },
      ];
      this.selectedItem = "OTP ഉപയോഗിച്ച്";
    }
    else if (langg === 'vie' || currentURL === 'vie') {
      this.signintype = [
        { "type": "otp", "name": "Đăng nhập bằng OTP" },
        { "type": "email", "name": "email / số điện thoại di động" },
      ];
      this.selectedItem = "Đăng nhập bằng OTP";
    }
    else if (langg === 'ar' || currentURL === 'ar') {
      this.signintype = [
        { "type": "otp", "name": "تسجيل الدخول باستخدام OTP" },
        { "type": "email", "name": "البريد الإلكتروني / رقم الهاتف المحمول" },
      ];
      this.selectedItem = "تسجيل الدخول باستخدام OTP";
    }
    else if (langg === 'hi' || currentURL === 'hi') {
      this.signintype = [
        { "type": "otp", "name": "मोबाइल ओटीपी" },
        { "type": "email", "name": "ईमेल / मोबाइल नंबर" },
      ];
      this.selectedItem = "मोबाइल ओटीपी";
    }
    else {
      this.signintype = [
        { "type": "otp", "name": "Mobile OTP" },
        { "type": "email", "name": "Email / Mobile number" },
      ];
      // this.selectedItem = "Email / Mobile number";
      this.selectedItem = "Mobile OTP";
    }
    this.otpsignin = true;
    this.emailsignin = false;

    this.patientLogin = this.formBuilder.group({      
      email: ['', Validators.compose([Validators.required, Validators.pattern(/^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/)])],
      password: ['', Validators.required]
    });

    this.patientotpLogin = this.formBuilder.group({
      phoneno: ['', Validators.required],
      otp: ['']
    });

    if(sessionStorage.getItem("clinicCountryName") == "india"){
      // for indian country emaild is optional
      this.patientRegister = this.formBuilder.group({
        firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
        lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
        email: ['', [Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
        password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
        phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
        aadharno: ['', [Validators.minLength(12),Validators.maxLength(12), Validators.pattern(/^[1-9]\d*$/)]],
        age: ['',[Validators.pattern('^[0-9]*$')]],
        gender: ['']
      });
    }else{
      // other countries emaild is manditory
      this.patientRegister = this.formBuilder.group({
        firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
        lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
        email: ['', [Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
        // email: ['', [Validators.required,Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
        password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
        phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
        aadharno: ['', [Validators.minLength(12),Validators.maxLength(12), Validators.pattern(/^[1-9]\d*$/)]],
        age: ['',[Validators.pattern('^[0-9]*$')]],
        gender: ['']
      });
    }

    this.returnpatientUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/appointment';
    this.returnadminUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/admin-dashboard';
    this.returndoctorUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/doctor/dashboard';
    this.returnclinicadminUrl = this.route.snapshot.queryParams['returnUrl'] || '/thealth/clinicadmin/dashboard';
    this.returnpatientDashboardUrl = this.route.snapshot.queryParams['returnUrl'] || 'thealth/dashboard/';
  }

  listClick(event, newValue) {
    this.selectedItem = newValue.name;
    if (newValue.type === "email") {
      this.emailsignin = true;
      this.otpsignin = false;
    }
    else {
      this.otpsignin = true;
      this.emailsignin = false;
    }
  }
  save(event) {
    const regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (regularExpression.test(String(event.target.value).toLowerCase())) {
      this.validatemyemail = true
    }
    else {
      this.validatemyemail = false;
    }
  }
  forgotpassword() {
    const dialogRef = this.dialog.open(ForgotpasswordTwoComponent, {
      panelClass: 'forgotpassword-dialog'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
        } else {
        }
      }
    });
  }
  closedia(){
    this.dialogRef.close();
  }
  initformgroup(){
    this.patientRegister.reset();
    this.patientRegister.controls.firstname.setErrors(null);
    this.patientRegister.controls.lastname.setErrors(null);
    this.patientRegister.controls.email.setErrors(null);
    this.patientRegister.controls.password.setErrors(null);
    this.patientRegister.controls.phoneno.setErrors(null);
  }
  patregSubmit(formData: any, formDirective: FormGroupDirective) {
    console.log(this.patientRegister.value.email)
      this.loading = true;
      this.toastrService.clear();
      const roleid = 3;
      if (this.patientRegister.value.firstname == '' || this.patientRegister.value.firstname == null &&
        // this.patientRegister.value.lastname == '' || this.patientRegister.value.lastname == null &&
        // this.patientRegister.value.email == '' || this.patientRegister.value.email == null &&
        this.patientRegister.value.phoneno == '' || this.patientRegister.value.phoneno == null &&
        // this.patientRegister.value.password == '' || this.patientRegister.value.password == null || this.patientRegister.value.password.trim() == "" ||
        this.patientRegister.value.password.trim().length < 4) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Enter Valid Details', options);
        setTimeout(() => {
          this.toastrService.clear(), 2000
        }, 2000);
        this.loading = false;
        return;
      } else {
        if(this.patientRegister.value.email == '' || this.patientRegister.value.email == null && this.patientRegister.value.phoneno){
             let payload = {
              "FirstName":this.patientRegister.value.firstname,
              "LastName": this.patientRegister.value.lastname,
              "Password": this.patientRegister.value.password,
              "MobileNumber": this.patientRegister.value.phoneno,
              "RoleId": roleid,
              "Age": this.patientRegister.value.age,
              "Gender": this.patientRegister.value.gender,
              "Aadhaarnumber": this.patientRegister.value.aadharno,

            }
             this.authenticationService.RegisterWithMobileNumber(payload)
             .pipe(first())
             .subscribe((res: any) => {
               if (!res.isError) {
                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                 this.toastrService.success('', res.responseMessage, options);
                 this.loading = false;
                 this.initformgroup();
                 this.selectedti = 0
               }
               else {
                 this.loading = false;
                 this.registererror = true;
                 this.registererrorMsg = res.errorMessage;
                 setTimeout(() => {
                   this.registererror = false;
                 }, 3000);
                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                 this.toastrService.warning('', res.errorMessage, options);
               }
             },
               err => {
                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                 this.loading = false;
                 this.forbiddenmessagebox = true;
                 this.messagecontent = err.error;
               });
              return   
        }else{
              if (this.validatemyemail == false && this.patientRegister.value.email != "") {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', 'Invalid Email Address', options);
          setTimeout(() => {
            this.toastrService.clear(), 2000
          }, 2000);
          return;
        }
          this.authenticationService.register(this.patientRegister.value, roleid)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res.responseMessage, options);
                this.loading = false;
                this.initformgroup();
                this.selectedti = 0
              }
              else {
                this.loading = false;
                this.registererror = true;
                this.registererrorMsg = res.errorMessage;
                setTimeout(() => {
                  this.registererror = false;
                }, 3000);
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                for (var prop in err.error) {
                  this.toastrService.warning('', err?.error[prop], options);
                }
                this.loading = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
              });
        }
      }
  }

  patSubmit(formData: any, formDirective: FormGroupDirective) {
    if (this.patientLogin?.value.email == '' || this.patientLogin?.value.email == null){
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Specify Email/Mobile number', options);
        this.loading = false;
        return;
      }
      let payloadformobilelogin:any={}
    if(isNaN(Number(this.patientLogin.value.email)) == false){
     payloadformobilelogin={
        "PhoneNumber": this.patientLogin.value.email,
        "Password": this.patientLogin.value.password,
        "Rememberme": true,
        "Username":"",
        "clinicguid": sessionStorage.getItem("clinicCode")
      }
    }else{
      payloadformobilelogin={
        "Username": this.patientLogin.value.email,
        "Password": this.patientLogin.value.password,
        "Rememberme": true,
        "PhoneNumber":"",
        "clinicguid": sessionStorage.getItem("clinicCode")
      }
    }
    if(payloadformobilelogin['PhoneNumber'] == ""){
      // "email vai"
      this.loading = true;   
      if (this.validatemyemail == false && this.patientLogin?.value.email != '' ) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Invalid Email Address', options);
        this.loading = false;
        return;
      }  
      if (this.patientLogin?.value.email == '' || this.patientLogin?.value.email == null &&
         this.patientLogin?.value.password == '' || this.patientLogin?.value.password == null) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Specify Username and Password', options);
        this.loading = false;
        return;
  
      }
      if (this.patientLogin?.value.email && this.patientLogin?.value.password == '' ||
        this.patientLogin?.value.password == null) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('','Please Specify Password', options);
        this.loading = false;
        return;  
      }      
      this.authenticationService.loginpat(payloadformobilelogin)  
        .pipe(first())
        .subscribe((loginres: any) => {
          if (!loginres.isError) {
            // this.Chatbot()
            this.loading = false;
            // doctor
            if (loginres.responseMessage.role === 'doctor') {
              this.dialogRef.close()
              this.router.navigate([this.returndoctorUrl]);
              return;
            }
            // clinicadmin
            if (loginres.responseMessage.role === 'clinicadmin') {
              this.dialogRef.close()
              this.router.navigate([this.returnclinicadminUrl]);
              return;
            }
            // admin / clinic admin
            else if (loginres.responseMessage.role === 'Admin' || loginres.responseMessage.role === 'ClinicAdmin') {
              this.dialogRef.close()
              this.router.navigate([this.returnadminUrl]);
              return;
            }
            // patient
            if (loginres.responseMessage.role === 'patient') {
              this._DoctorService.familylist(loginres?.responseMessage?.userid)
                .pipe(first())
                .subscribe(
                  (res: any) => {
                    if (!res.isError) {
                      console.log(res)
                      console.log(res.responseMessage.length)
                      if (res.responseMessage.length === 0) {
                        if(sessionStorage.getItem('appointmentUrl') === '/thealth/appointment') {
                          this.router.navigate([this.returnpatientUrl]);
                          sessionStorage.removeItem('appointmentUrl');
                        } 
                        else {
                          this.router.navigate([this.returnpatientDashboardUrl]);
                        }
                        this.dialogRef.close();
                      }
                      else {
                        const dialogRef = this.dialog.open(LoginFamilymemberListComponent, {
                          maxWidth: '100vw',
                          maxHeight: '100vh',
                          height: '100%',
                          width: '100%',
                          panelClass: 'loginfamily-dialog'
                        });
                        dialogRef.afterClosed().subscribe(result => {             
                          this.disableBtn = false;
                          if(sessionStorage.getItem('appointmentUrl') === '/thealth/appointment') {
                            this.router.navigate([this.returnpatientUrl]);
                            sessionStorage.removeItem('appointmentUrl');
                          } 
                          else {
                            this.router.navigate([this.returnpatientDashboardUrl]);
                          }
                          this.dialogRef.close()
  
                        });
                      }
                    }
                    else {
                      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      this.toastrService.warning('', res.errorMessage, options);
                    }
                  },
                  err => {
                    console.log(err);
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.warning('', err.error, options);
  
                  });
              return;
            }
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', loginres.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            formDirective.resetForm();
            this.patientLogin.reset();
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            if (err?.error.Username) {
              this.toastrService.warning('', err?.error.Username[0], options);
            }
            if (err?.error.Password) {
              this.toastrService.warning('', err?.error.Password[0], options);
            }
          });
    }else{
      this.loading = true;  
      if (this.patientLogin?.value.email == '' || this.patientLogin?.value.email == null &&
         this.patientLogin?.value.password == '' || this.patientLogin?.value.password == null) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Specify Mobilenumber and Password', options);
        this.loading = false;
        return;
      }
      if (this.patientLogin?.value.email && this.patientLogin?.value.password == '' ||
        this.patientLogin?.value.password == null) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('','Please Specify Password', options);
        this.loading = false;
        return;  
      }
      this.authenticationService.loginpat(payloadformobilelogin)
        .pipe(first())
        .subscribe((loginres: any) => {
          if (!loginres.isError) {
            // this.Chatbot()
            this.loading = false;
            // doctor
            if (loginres.responseMessage.role === 'doctor') {
              this.dialogRef.close()
              this.router.navigate([this.returndoctorUrl]);
              return;
            }
            // clinicadmin
            if (loginres.responseMessage.role === 'clinicadmin') {
              this.dialogRef.close()
              this.router.navigate([this.returnclinicadminUrl]);
              return;
            }
            // admin / clinic admin
            else if (loginres.responseMessage.role === 'Admin' || loginres.responseMessage.role === 'ClinicAdmin') {
              this.dialogRef.close()
              this.router.navigate([this.returnadminUrl]);
              return;
            }
            // patient
            if (loginres.responseMessage.role === 'patient') {
              this._DoctorService.familylist(loginres?.responseMessage?.userid)
                .pipe(first())
                .subscribe(
                  (res: any) => {
                    if (!res.isError) {
                      console.log(res)
                      console.log(res.responseMessage.length)
                      if (res.responseMessage.length === 0) {
                        if(sessionStorage.getItem('appointmentUrl') === '/thealth/appointment') {
                          this.router.navigate([this.returnpatientUrl]);
                          sessionStorage.removeItem('appointmentUrl');
                        } 
                        else {
                          this.router.navigate([this.returnpatientDashboardUrl]);
                        }
                        this.dialogRef.close();
                      }
                      else {
                        const dialogRef = this.dialog.open(LoginFamilymemberListComponent, {
                          maxWidth: '100vw',
                          maxHeight: '100vh',
                          height: '100%',
                          width: '100%',
                          panelClass: 'loginfamily-dialog'
                        });
                        dialogRef.afterClosed().subscribe(result => {             
                          this.disableBtn = false;
                          if(sessionStorage.getItem('appointmentUrl') === '/thealth/appointment') {
                            this.router.navigate([this.returnpatientUrl]);
                            sessionStorage.removeItem('appointmentUrl');
                          } 
                          else {
                            this.router.navigate([this.returnpatientDashboardUrl]);
                          }
                          this.dialogRef.close()
                        });
                      }
                    }
                    else {
                      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                      this.toastrService.warning('', res.errorMessage, options);
                    }
                  },
                  err => {
                    console.log(err);
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.warning('', err.error, options);
                  });
              return;
            }
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', loginres.errorMessage, options);
          }
        },
          err => {
            formDirective.resetForm();
            this.patientLogin.reset();
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            if (err?.error.Username) {
              this.toastrService.warning('', err?.error.Username[0], options);
            }
            if (err?.error.Password) {
              this.toastrService.warning('', err?.error.Password[0], options);
            }
          });
    }
   
  }

  patotpSubmit(formData: any, formDirective: FormGroupDirective) {
    this.loading = true;
    if (this.patientotpLogin.value.phoneno.trim() == "") {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter Mobilenumber", options);
      return;
    }
    if (this.patientotpLogin.value.otp.trim() == "") {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter OTP", options);
      return;
    }

    this.authenticationService.loginpatwithotp(this.patientotpLogin.value)
      .pipe(first())
      .subscribe((submitotpres: any) => {
        // this.Chatbot()
        if (!submitotpres.isError) {
          this.loading = false;
          let subotpresdata = submitotpres.responseMessage;
          console.log(subotpresdata)
          this._DoctorService.familylist(subotpresdata.userid)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                if (res.responseMessage.length === 0) {
                  this.loading = false;
                  if(sessionStorage.getItem('appointmentUrl') === '/thealth/appointment') {
                    this.router.navigate([this.returnpatientUrl]);
                    sessionStorage.removeItem('appointmentUrl');
                  } 
                  else {
                    this.router.navigate([this.returnpatientDashboardUrl]);
                  }
                  this.dialogRef.close();
                }
                else {
                  this.loading = false;
                  const dialogRef = this.dialog.open(LoginFamilymemberListComponent, {
                    maxWidth: '100vw',
                    maxHeight: '100vh',
                    height: '100%',
                    width: '100%',
                    panelClass: 'loginfamily-dialog'
                  });
                  dialogRef.afterClosed().subscribe(result => {
                    this.disableBtn = false;
                    this.dialogRef.close()
                    if(sessionStorage.getItem('appointmentUrl') === '/thealth/appointment') {
                      this.router.navigate([this.returnpatientUrl]);
                      sessionStorage.removeItem('appointmentUrl');
                    } 
                    else {
                      this.router.navigate([this.returnpatientDashboardUrl]);
                    }
                  });
                }
              }
              else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                setTimeout(() => {
                  this.toastrService.clear(), 2000
                }, 2000);

              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);

              });
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', submitotpres.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        });
  }

  // Chatbot(){
  //   this.authenticationService.getChatbot() 
  //   .subscribe((res: any) => {
  //     if (!res.isError) {
  //       console.log(res)
  //       sessionStorage.setItem('hasChatBot',res.responseMessage.hasChatBot);
  //     }
  //     else {
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', res.errorMessage, options);
  //       setTimeout(() => {
  //         this.toastrService.clear(),2000
  //       }, 2000);
  //     }
  //   },
  //     err => {
  //       const options = { opacity: 1, timeOut: 2000,tapToDismiss: true };                
  //       this.toastrService.warning('', err?.error, options);
  //       setTimeout(() => {
  //         this.toastrService.clear(),2000
  //       }, 2000);
  //     });    
  // }
  otpmobile(patientotpLogin) {
    this.loading = true;
    this.isotpReceived = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    if (!patientotpLogin.value.phoneno) {
      this.toastrService.warning('', "Please Enter your Mobile Number", options);
      this.isotpReceived = false;
      this.loading = false;
      return;
    } else {
      this.authenticationService.otpmobile(patientotpLogin.value.phoneno)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.isotpReceived = true;
            this.toastrService.success('', res.responseMessage, options);

          } else {
            this.loading = false;
            this.isotpReceived = false;
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            this.isotpReceived = false;
            this.toastrService.warning('', err?.error, options);
          });
    }
  }
  onNoClick() {
    this.dialogRef.close();
  }

  ngOnDestroy() {
  }
}

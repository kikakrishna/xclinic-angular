import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ClinicadminPatientsComponent } from './clinicadmin-patients.component';
import { ClinicadminPatientsRoutes } from './clinicadmin-patients.routes';
import { ClinicadminCreatepatientComponent } from '../clinicadmin-createpatient/clinicadmin-createpatient.component';
import { ClinicAdminPipeModule } from './clinicadmin-patientPipeModule';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatStepperModule } from '@angular/material/stepper';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSliderModule }  from '@angular/material/slider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatSelectModule} from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
@NgModule({
  declarations: [ClinicAdminPipeModule,ClinicadminPatientsComponent,ClinicadminCreatepatientComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(ClinicadminPatientsRoutes),
    FormsModule, 
    ReactiveFormsModule, 
    MatCardModule,    
    MatButtonModule,
    MatDividerModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatInputModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatIconModule,
    MatStepperModule,
    MatExpansionModule,
    MatSidenavModule,
    MatSliderModule,
    MatCheckboxModule,
    MatSelectModule,
    MatTableModule
  ],
  entryComponents: [ClinicadminCreatepatientComponent],
  exports: [ClinicadminPatientsComponent]
})
export class ClinicadminPatientsModule { }

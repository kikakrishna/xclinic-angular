import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'patientFilter'
})
export class ClinicAdminPipeModule implements PipeTransform {
    transform(value: any, args?: any): any {
        value = value.filter(function (search) {
            return search.name.toLowerCase().indexOf(args.toLowerCase()) > -1 ||
            String(search.patientId).toLowerCase().indexOf(args.toLowerCase()) > -1 ||
               String(search.bloodGroup).toLowerCase().indexOf(args.toLowerCase()) > -1;
        });
        return value;
    }
}
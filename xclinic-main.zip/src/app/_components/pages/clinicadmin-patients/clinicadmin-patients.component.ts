import { Component, OnInit, ViewChild, ChangeDetectorRef, OnDestroy, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ClinicadminCreatepatientComponent } from '../clinicadmin-createpatient/clinicadmin-createpatient.component';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MediaMatcher } from '@angular/cdk/layout';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { MatSidenav } from '@angular/material/sidenav';
import { saveAs } from 'file-saver';


interface Gender {
  value: string;
}

@Component({
  selector: 'app-clinicadmin-patients',
  templateUrl: './clinicadmin-patients.component.html',
  styleUrls: ['./clinicadmin-patients.component.css'],
  host: {
    class: 'clinicadminPatients'
  }
})
export class ClinicadminPatientsComponent implements OnInit {
  displayedColumns2: string[] = ['name', 'patientid', 'relationtype'];
  dataSource2;
  doctorfilerform: FormGroup;

  public patientlist: any = [];
  public filter: string = "";
  profileImage: any;
  listdata: boolean;
  initialgetnext: boolean;
  searchlistdata: boolean;
  Ishide: boolean = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  obs: Observable<any>;
  loading: boolean;
  filterData: boolean;
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  public doctorlist_arraycount: any;
  opened: boolean;
  createpatProfile: FormGroup
  minlen: any = sessionStorage.getItem('minlen');
  maxlen: any = sessionStorage.getItem('maxlen');
  mandatorymobEmailfields: boolean = false;
  passwordLenght: any = 8;
  passwordPattern: any;
  hide = true;
  public searchinput = "";
  Fsearchstring: string;
  applyfilterData: boolean = false;
  pageindex: any = 0;
  pagesize: any = 6;
  totalSize: any;
  totallength: any;
  constains: any;
  filterpatients: any;
  resp: any;
  addmember: boolean = false;
  regbtn: boolean = true;
  relationshiptype: any;
  familytype: boolean = false;
  alreadymemb: boolean = false;
  createfamiltype: FormGroup
  patid: any;
  patientsearchgroup: FormGroup;

  listdata2: boolean;

  @ViewChild('txpaginator', { read: MatPaginator }) txpaginator: MatPaginator;
  @ViewChild('uploadResultPaginator', { read: MatPaginator }) uploadResultPaginator: MatPaginator;
  @ViewChild('patientResultPaginator', { read: MatPaginator }) patientResultPaginator: MatPaginator;
  constructor(public dialog: MatDialog,
    private router: Router,
    private _DoctorService: DoctorService,
    private _PatientService: PatientService,
    public toastrService: ToastService, private _formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,) {

  }

  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;

  @ViewChild('sidenav') public sidenav: MatSidenav;
  @ViewChild('privatUserCheckbox') privatUserCheckbox: ElementRef;

  genderlist: Gender[] = [
    { value: 'Male' },
    { value: 'Female' }
  ];

  ngOnInit(): void {
    this.initialgetnext = true;
    this.dataSource.paginator = this.patientResultPaginator;
    this.obs = this.dataSource.connect();
    this.mypatientlist()
    this._PatientService.domaindetail()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
        }
      });



    // if (sessionStorage.getItem("clinicCountryName") == "india") {
    //   this.mandatorymobEmailfields = false;
    //   this.createpatProfile = this._formBuilder.group({
    //     firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
    //     lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
    //     email: ['', [Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
    //     password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    //     phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]]
    //   });
    // }
    // else {
    //   this.mandatorymobEmailfields = true;
    //   this.createpatProfile = this._formBuilder.group({
    //     firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
    //     lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
    //     email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
    //     password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    //     phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]]
    //   });
    // }


    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: ['', [Validators.pattern(/^[1-9]\d*$/)]],
      // aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      patientclinicidentifier: ['', Validators.required],
      aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(12), Validators.maxLength(12)]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });

    this.createfamiltype = this._formBuilder.group({
      relationtype: ['', [Validators.required]],
    });
    this.patientsearchgroup = this._formBuilder.group({
      patientfilter: ['',],
      patientsearchstring: ['',]
    });

    this._DoctorService.getrelation()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.relationshiptype = res.responseMessage;
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });


    this._DoctorService.DropDownSearchpatient()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.loading = false;
          this.filterpatients = res.responseMessage;
          // console.log(this.clinicLocations)
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })

  }

  mypatientlist() {
    this.loading = true;
    this._DoctorService.mypatientlist('withprofile', this.pageindex, this.pagesize)
      .pipe(first())
      .subscribe((res: any) => {
        this.Ishide = false;
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          this.patientlist = res?.responseMessage;
          this.dataSource = new MatTableDataSource<any>(res?.responseMessage);
          this.totalSize = res?.pagination?.total;
          this.totallength = res?.pagination?.total;
          this.doctorlist_arraycount = res?.pagination?.total;
          this.pageindex = 0;
          this.dataSource.paginator = this.patientResultPaginator;
          this.obs = this.dataSource.connect();
          if (this.dataSource?.data?.length === 0) {
            this.initialgetnext = false;
          }
          else {
            // this.initialgetnext = true;
          }
          setTimeout(() => {
            this.paginator.pageSize=0;
            this.paginator.pageIndex=0;
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        this.Ishide = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
       
      })
  }
  PaginationgetNextdoctorlist(event: PageEvent) {
    this.loading = true;
    console.log('event', event);
    console.log(this.doctorlist_arraycount);

    let a = {
      "pageNumber": event?.pageIndex,
      "pageSize": event?.pageSize,
      "totalSize": this.doctorlist_arraycount,
    }

    let navinfo = {
      paginationClicked: "clicked",
      paginatorinfo: a,
    }

    // this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    // this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    // this.txpaginator.length = navinfo.paginatorinfo.totalSize;

    this._DoctorService.mypatientlist('withprofile', event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        this.Ishide = false;
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          this.patientlist = res?.responseMessage;
          this.dataSource = new MatTableDataSource<any>(res?.responseMessage);
          this.obs = this.dataSource.connect();
          if (this.dataSource?.data?.length === 0) {
            this.initialgetnext = false;
          }
          else {
            this.initialgetnext = true;
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        this.Ishide = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })

  }

  
  PaginationgetNextlist(event) {
    this.loading = true;
    this._DoctorService.PaginationgetNextlist(encodeURIComponent(this.Fsearchstring), this.patientsearchgroup.value.patientfilter, event.pageIndex, event.pageSize).pipe(first()).subscribe((res: any) => {
      this.Ishide = false;
      if (!res.isError) {
        this.loading = false;
        this.patientlist = res?.responseMessage;
        this.totalSize = res?.pagination?.total;
        this.totallength = res?.pagination?.total;
        this.pageindex = 0;
        this.doctorlist_arraycount = res?.pagination?.total;
        this.dataSource = new MatTableDataSource<any>(res?.responseMessage);
        console.log(this.dataSource)
        this.obs = this.dataSource.connect();
        if (res?.pagination?.total == 0) {
          this.searchlistdata = false;

        }
        else {
          this.searchlistdata = true;


        }

         setTimeout(() => {
            this.paginator.pageSize=0;
            this.paginator.pageIndex=0;
          }); 
      }
      else {
        this.Ishide = false;
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    }, err => {

    });
  }

  clearSearch() {
    this.initialgetnext = true;
    this.searchlistdata = false;
    this.searchinput = ""
    this.mypatientlist();
    this.patientsearchgroup.reset();
  }

  docSearch() {
    if (this.patientsearchgroup.value.patientfilter != "" && this.patientsearchgroup.value.patientfilter != undefined) {
      if (this.patientsearchgroup.value.patientsearchstring.trim() != "" && this.patientsearchgroup.value.patientsearchstring.trim() != undefined) {
        this.loading = true;
        this.Fsearchstring = this.patientsearchgroup.value.patientsearchstring;
        this._DoctorService.doctorsearch1(encodeURIComponent(this.searchinput), this.patientsearchgroup.value.patientfilter).pipe(first()).subscribe((res: any) => {
          this.searchlistdata = true
          this.initialgetnext = false
          this.Ishide = false;
          if (!res.isError) {
            this.loading = false;
            setTimeout(() => {
              this.totalSize = res?.pagination?.total;
              this.paginator.pageIndex = 0;
              this.paginator.pageSize = 0;
              // this.totalSize = res?.pagination?.total;
              // this.totallength = res?.pagination?.total;
              // this.pageindex = 0;
              // this.dataSource.paginator = this.stockinlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
            });
            this.patientlist = res?.responseMessage;
          
            this.doctorlist_arraycount = res?.pagination?.total;
            this.dataSource = new MatTableDataSource<any>(res?.responseMessage);
            this.obs = this.dataSource.connect();
            if (res?.pagination?.total == 0) {
              this.searchlistdata = false;
            }
            else {
              this.searchlistdata = true;
            }
          }
          else {
            this.Ishide = false;
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        }, err => {

        });
      }
      // else {
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', "Please enter search input", options);
      // }

    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select the type", options);
    }

  }
  statchanged(pId, state) {
    this._PatientService.statechanged(pId, state)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.mypatientlist();
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  applyFilterMypatient(event) {
    this.dataSource.filter = event.target.value;
    let filteredArray = this.patientlist.filter(data => {
      if (event.target.value.endsWith("+") || event.target.value.endsWith("-")) {
        event.target.value = event.target.value.toUpperCase();
      }
      if (data.patientOfficialId == event.target.value.trim()) {
        return true;
      } else if (data.bloodGroup.startsWith(event.target.value.trim())) {
        return true;
      } else if (data.name.toLowerCase().trim().startsWith(event.target.value.toLowerCase().trim())) {
        return true;
      } else {
        return false;
      }
    })
    this.dataSource = new MatTableDataSource<any>(filteredArray);
    this.dataSource.paginator = this.patientResultPaginator;
    this.obs = this.dataSource.connect();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  openDialog() {
    const dialogRef = this.dialog.open(ClinicadminCreatepatientComponent, {
      width: '40%',
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
          this.mypatientlist();
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', result.data.responseMessage, options);

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', result.data.errorMessage, options);
        }
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
      });

  }

  public calculateAge(birthdate: any): number {
    if (birthdate == null) {
      return 0;
    }
    return moment().diff(birthdate, 'years');
  }

  applyFilter(filterValue) {
    this.dataSource.filter = filterValue;
    if (this.dataSource.filteredData.length === 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
      setTimeout(() => this.dataSource.paginator = this.patientResultPaginator);
    }
    let filteredArray = this.patientlist.filter(data => {
      if (filterValue.endsWith("+") || filterValue.endsWith("-")) {
        filterValue = filterValue.toUpperCase();
      }
      if (data.patientOfficialId == filterValue.trim()) {
        return true;
      } else if (data.bloodGroup.startsWith(filterValue.trim())) {
        return true;
      } else if (data.name.toLowerCase().trim().startsWith(filterValue.toLowerCase().trim())) {
        return true;
      } else {
        return false;
      }
    })
    this.dataSource = new MatTableDataSource<any>(filteredArray);
    this.dataSource.paginator = this.patientResultPaginator;
    this.obs = this.dataSource.connect();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  nextRoute(item) {
    console.log(item)
    sessionStorage.setItem('temppatientid', item?.patientId)
    this.router.navigate(['/thealth/clinicadmin/patients/view', item?.patientId]);
    // this.router.navigate(['/thealth/clinicadmin/patients/view', item?.patientId]);
  }
  // generatePassword(){
  //   var newPassword = "";
  //   for (var i = 0; i < this.passwordLenght; i++) {
  //     newPassword += [Math.floor(Math.random() * this.dictionary.length)];
  //   }
  //   this.newPassword = newPassword;
  // }

  generatePassword(e) {
    console.log(e)
    if (e.checked == true) {
      this.passwordPattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,./;'[]\=-)(*&^%$#@!~`";
      this.passwordLenght = 8;
      let text = "";
      for (let i = 0; i < this.passwordLenght; i++) {
        text += this.passwordPattern.charAt(Math.floor(Math.random() * this.passwordPattern.length));
      }
      let Password = text;
      console.log(Password)
      this.createpatProfile.get('password').setValue(Password);
    } else if (e.checked == false) {
      this.createpatProfile.get('password').setValue('');
    }
  }

  // generatePassword(passwordLength){
  //   var numberChars = "0123456789";
  // var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  // var lowerChars = "abcdefghijklmnopqrstuvwxyz";
  // var allChars = numberChars + upperChars + lowerChars;
  // var randPasswordArray = Array(passwordLength);
  // randPasswordArray[0] = numberChars;
  // randPasswordArray[1] = upperChars;
  // randPasswordArray[2] = lowerChars;
  // randPasswordArray = randPasswordArray.fill(allChars, 3);
  // return shuffleArray(randPasswordArray.map(function(x) { return x[Math.floor(Math.random() * x.length)] })).join('');
  // }

  // shuffleArray(array) {
  //   for (var i = array.length - 1; i > 0; i--) {
  //     var j = Math.floor(Math.random() * (i + 1));
  //     var temp = array[i];
  //     array[i] = array[j];
  //     array[j] = temp;
  //   }
  //   return array;
  // }

  reset() {
    this.createpatProfile.reset();
    this.alreadymemb = false;
    this.familytype = false;
    this.regbtn = true;
    this.privatUserCheckbox['checked'] = false;
  }

  createpatient(){
    this.privatUserCheckbox['checked'] = false;
  }
  // patregister() {
  //   if (this.createpatProfile.value.email == "" || this.createpatProfile.value.email == null && this.createpatProfile.value.phoneno) {
  //     if (this.createpatProfile.value.password == '' || this.createpatProfile.value.password == null || this.createpatProfile.value.password.trim() == "") {
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', 'Please Enter valid the Password', options);
  //       setTimeout(() => {
  //         this.toastrService.clear(), 2000
  //       }, 2000);
  //       return;
  //     }
  //     this.loading = true;
  //     const roleid = 3;
  //     let payload = {
  //       "FirstName": this.createpatProfile.value.firstname,
  //       "LastName": this.createpatProfile.value.lastname,
  //       "Password": this.createpatProfile.value.password,
  //       "MobileNumber": this.createpatProfile.value.phoneno,
  //       "RoleId": roleid
  //     }
  //     this.authenticationService.RegisterWithMobileNumber(payload)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         console.log(res)
  //         if (!res.isError) {
  //           this.loading = false;
  //           this.createpatProfile.reset();
  //           // this.dialogRef.close({ data: res });
  //         }
  //         else {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //         }
  //       },
  //         err => {
  //           console.log(err)
  //           this.loading = false;
  //           // this.dialogRef.close({ data: err });
  //         });
  //   } else {
  //     if (this.createpatProfile.value.password == '' || this.createpatProfile.value.password == null || this.createpatProfile.value.password.trim() == "") {
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', 'Please Enter valid the Password', options);
  //       setTimeout(() => {
  //         this.toastrService.clear(), 2000
  //       }, 2000);
  //       return;
  //     }
  //     this.loading = true;
  //     const roleid = 3;
  //     this.authenticationService.register(this.createpatProfile.value, roleid)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         console.log(res)
  //         if (!res.isError) {
  //           this.loading = false;
  //           this.createpatProfile.reset();
  //           // this.dialogRef.close({ data: res });
  //         }
  //         else {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //         }
  //       },
  //         err => {
  //           console.log(err)
  //           this.loading = false;
  //           // this.dialogRef.close({ data: err });
  //         });
  //   }
  // }

  onFocusOutEvent(event: any) {
    if (event.target.value == '') {
      // alert('empty');
      console.log(event.target.value);
    }
    else {
      this.loading = true;
      this.dataSource2 = new MatTableDataSource([]);
      console.log(event.target.value);
      this.authenticationService.patdetailsbymobno(event.target.value)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          console.log(res)
          if (!res.isError) {
            if (res.responseMessage == null) {
              console.log(res.responseMessage)
              this.familytype = false;
              this.alreadymemb = false
              this.regbtn = true;
            }
            else {
              this.resp = res.responseMessage;
              console.log(this.resp.mobile, this.createpatProfile?.value.phoneno);
              if (this.resp.mobile == this.createpatProfile?.value.phoneno) {
                this.familytype = true;
                this.regbtn = false;
                this.patid = this.resp.patientId;
                setTimeout(() => {
                  document.getElementById("checkscroll").scrollIntoView({ behavior: 'smooth', block: "end" });
                })
                this.dataSource2 = new MatTableDataSource(res.responseMessage.patientFamilyMemberDetails);
                setTimeout(() => {
                  this.dataSource2.paginator = this.uploadResultPaginator;
                });
                if (res.responseMessage.patientFamilyMemberDetails === null || res.responseMessage.patientFamilyMemberDetails.length === 0) {
                  this.alreadymemb = false;
                }
                else {
                  this.alreadymemb = true;
                }
              }
            }


            // if (this.resp.mobile == this.createpatProfile?.value.phoneno) {
            //   this.addmember = true;
            //   this.regbtn = false;
            //   this.dataSource2 = new MatTableDataSource(res.responseMessage.patientFamilyMemberDetails);
            //   console.log(this.dataSource2);

            //   if (this.dataSource2.data === null || this.dataSource2.data.length === 0) {
            //     this.listdata = true;
            //   }
            //   else {
            //     this.listdata = false;
            //   }
            // }
            // else {
            //   this.addmember = false;
            //   this.regbtn = true;
            // }
            this.loading = false;
          } else {
            this.loading = false;
            this.familytype = false;
            this.alreadymemb = false
            this.regbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.responseData, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  patregister(formDirective: FormGroupDirective) {
    console.log(this.createpatProfile?.value)
    this.loading = true;
    if (this.createpatProfile?.value.firstname.trim() == '' || this.createpatProfile?.value.firstname.trim() == null ||
      this.createpatProfile?.value.phoneno.trim() == '' || this.createpatProfile?.value.phoneno.trim() == null ||
      this.createpatProfile?.value.password.trim() == '' || this.createpatProfile?.value.password.trim() == null ||
      this.createpatProfile?.value.patientclinicidentifier.trim() == '' || this.createpatProfile?.value.patientclinicidentifier.trim() == null) {

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
      return;
    }
    else {

      if (this.createpatProfile?.value?.email && this.createpatProfile?.value?.email != "") {
        this.loading = true;
        const roleid = 3;
        console.log(this.createpatProfile.value)
        this.authenticationService.register(this.createpatProfile.value, roleid)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              this.mypatientlist()
              this.loading = false;
              setTimeout(() => this.formGroupDirective.resetForm(), 0);
              this.createpatProfile.reset();
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              this.sidenav.close();
              this.clearSearch();
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              console.log(err)
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            })

      }
      else {
        this.loading = true;
        const roleid = 3;
        let payload = {
          "FirstName": this.createpatProfile.value.firstname,
          "LastName": this.createpatProfile.value.lastname,
          "Aadhaarnumber": this.createpatProfile.value.aadharno,
          "Password": this.createpatProfile.value.password,
          "MobileNumber": this.createpatProfile.value.phoneno,
          "RoleId": roleid,
          "ClinicPatientId": this.createpatProfile.value.patientclinicidentifier,
          "Age": this.createpatProfile.value.age
        }
        console.log(payload)
        this.authenticationService.RegisterWithMobileNumber(payload)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res)
            if (!res.isError) {
              this.loading = false;
              setTimeout(() => this.formGroupDirective.resetForm(), 0);
              this.createpatProfile.reset();
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              this.sidenav.close();
              this.clearSearch();
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              console.log(err)
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            })
      }
    }
  }

  patfamtype() {
    console.log(this.createpatProfile?.value.firstname)
    console.log(this.createpatProfile?.value.lastname)
    console.log(this.createfamiltype?.value.relationtype)
    console.log(this.patid)

    this.loading = true;
    if (this.createpatProfile?.value.firstname == '' || this.createpatProfile?.value.firstname == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill First name', options);
      this.loading = false;
      return;
    }
    if (this.createfamiltype?.value.relationtype == '' || this.createfamiltype?.value.relationtype == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill Relation Type', options);
      this.loading = false;
      return;
    }
    if (this.createpatProfile?.value.patientclinicidentifier == '' || this.createpatProfile?.value.patientclinicidentifier == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill Clinic Patient ID', options);
      this.loading = false;
      return;
    }
    else {
      this.loading = true;
      let payload = {
        "FirstName": this.createpatProfile?.value.firstname,
        "LastName": this.createpatProfile?.value.lastname,
        "RelationType": this.createfamiltype?.value.relationtype,
        "Profile": null,
        "PatientId": this.patid,
        "GenderName": this.createpatProfile?.value.gender,
        "Age": this.createpatProfile?.value.age,
        "Aadhaarnumber": this.createpatProfile?.value.aadharno,
        "ClinicPatientId": this.createpatProfile?.value.patientclinicidentifier
      }
      console.log(payload)
      const roleid = 3;
      this._DoctorService.famtype(payload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.alreadymemberslist(payload.PatientId);
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.sidenav.close();
            this.mypatientlist();
            this.ngOnInit()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            for (var prop in err.error) {
              this.toastrService.warning('', err?.error[prop], options);
            }
          })
    }
  }
  downloadname: any;
  downloadpatient(){
    this.loading = true;
    this.downloadname = "Patient details";
    console.log("downloadclick")
    this._DoctorService.downloadpatient()
    .pipe(first())
    .subscribe((res: any) => {
      console.log(res);
      if (!res.isError) {
        this.loading = false;
        const data: Blob = new Blob([res], {
          type: 'text/csv'
        });
        saveAs(data, this.downloadname);
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
      err => {
        console.log(err)
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        // this.toastrService.warning('', res.errorMessage, options);
      })
  }

  alreadymemberslist(pid) {
    this.loading = true;
    this.dataSource2 = new MatTableDataSource([]);
    this.loading = true;
    this._DoctorService.alreadymemlist(pid)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.dataSource2 = new MatTableDataSource(res.responseMessage);
          setTimeout(() => {
            this.dataSource2.paginator = this.uploadResultPaginator;
          });
          if (res.responseMessage === null || res.responseMessage.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }


  booksideopen() {
    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: ['', [Validators.pattern(/^[1-9]\d*$/)]],
      patientclinicidentifier: ['', Validators.required],
      aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(12), Validators.maxLength(12)]],
      // aadharno: ['', [Validators.maxLength(12), Validators.pattern(/^[1-9]\d*$/)]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });
  }
  booksideclose() {
    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: ['', [Validators.pattern(/^[1-9]\d*$/)]],
      patientclinicidentifier: ['', Validators.required],
      aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(12), Validators.maxLength(12)]],
      // aadharno: ['', [Validators.maxLength(12), Validators.pattern(/^[1-9]\d*$/)]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });
    this.familytype = false;
    this.alreadymemb = false;
    this.regbtn = true;

  }
  Changepatients(){
    console.log("")
    this.searchinput="";
    this.patientsearchgroup.value.patientsearchstring="";
  }
}

export interface PeriodicElement2 {
  name: any;
  patientid: any;
  relationtype: any;
}

const ELEMENT_DATA2: PeriodicElement2[] = [
  { name: 'Sreeram', patientid: '52485245454', relationtype: 'son' },
  { name: 'Sreeram', patientid: '52485245454', relationtype: 'son' },
  { name: 'Sreeram', patientid: '52485245454', relationtype: 'son' },
  { name: 'Sreeram', patientid: '52485245454', relationtype: 'son' },
];

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminPatientsComponent } from './clinicadmin-patients.component';

describe('ClinicadminPatientsComponent', () => {
  let component: ClinicadminPatientsComponent;
  let fixture: ComponentFixture<ClinicadminPatientsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminPatientsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminPatientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { RouterModule } from '@angular/router';
import { ClinicadminPatientsComponent } from './clinicadmin-patients.component';
export const ClinicadminPatientsRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminPatientsComponent,
    }
]
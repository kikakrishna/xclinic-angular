import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-clinicadmin-dialogconformmanageslsot',
  templateUrl: './clinicadmin-dialogconformmanageslsot.component.html',
  styleUrls: ['./clinicadmin-dialogconformmanageslsot.component.css']
})
export class ClinicadminDialogconformmanageslsotComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ClinicadminDialogconformmanageslsotComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
  }

  onNoClick(): void {
    this.dialogRef.close({data:"no"});
  }
  conform(){
    this.dialogRef.close({data:"conform"});

  }
}


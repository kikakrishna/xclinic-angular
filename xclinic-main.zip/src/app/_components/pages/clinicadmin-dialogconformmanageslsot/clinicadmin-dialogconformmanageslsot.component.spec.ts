import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDialogconformmanageslsotComponent } from './clinicadmin-dialogconformmanageslsot.component';

describe('ClinicadminDialogconformmanageslsotComponent', () => {
  let component: ClinicadminDialogconformmanageslsotComponent;
  let fixture: ComponentFixture<ClinicadminDialogconformmanageslsotComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDialogconformmanageslsotComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDialogconformmanageslsotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

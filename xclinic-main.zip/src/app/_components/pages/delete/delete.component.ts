import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  Appointmentcancel: FormGroup;
  constructor(private _formBuilder: FormBuilder,
    private _patientservice: PatientService,
    public dialogRef: MatDialogRef<DeleteComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  ngOnInit(): void {
    this.Appointmentcancel = this._formBuilder.group({
    });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  deletefile() {
    this._patientservice.deletefiles(this.data.patientId, this.data.recordGUID)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.dialogRef.close({ data: res });
        } else {
          this.dialogRef.close({ data: res });
        }
      },
        err => {
          this.dialogRef.close({ data: err });
        });
  }
}

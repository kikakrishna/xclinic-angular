import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminAppointmentviewComponent } from './clinicadmin-appointmentview.component';

describe('ClinicadminAppointmentviewComponent', () => {
  let component: ClinicadminAppointmentviewComponent;
  let fixture: ComponentFixture<ClinicadminAppointmentviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminAppointmentviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminAppointmentviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

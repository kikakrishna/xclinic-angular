import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';

import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter';
import { MatDialogModule } from '@angular/material/dialog';
import { LOCALE_ID } from '@angular/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ClinicAdminAppointmentviewRoutes } from './clinicadmin-appointmentview.routes';
import { ClinicadminAppointmentviewComponent } from './clinicadmin-appointmentview.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MY_DATE_FORMATS } from '../appointments/my-date-formats';
import { ClinicadminCancelComponent } from '../clinicadmin-cancel/clinicadmin-cancel.component';
import { ClinicadminDialogVisitCompletedComponent } from '../clinicadmin-dialog-visit-completed/clinicadmin-dialog-visit-completed.component';
import { ClinicadminCreatepaymentlinkComponent } from '../clinicadmin-createpaymentlink/clinicadmin-createpaymentlink.component';

@NgModule({
  declarations: [ClinicadminDialogVisitCompletedComponent,
    ClinicadminAppointmentviewComponent,ClinicadminCancelComponent, ClinicadminCreatepaymentlinkComponent],
  imports: [
    MatDialogModule,
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    MatSelectModule,
    MatDatepickerModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatTabsModule,
    MatDatepickerModule,
    RouterModule.forChild(ClinicAdminAppointmentviewRoutes),
    MatSidenavModule,
    MatCheckboxModule
  ],
  entryComponents: [
    ClinicadminDialogVisitCompletedComponent,
    ClinicadminCancelComponent,
    ClinicadminCreatepaymentlinkComponent
  ],
  exports: [ClinicadminAppointmentviewComponent],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    { provide: LOCALE_ID, useValue: "en-US" },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },

  ]
})
export class ClinicAdminAppointmentviewModule { }

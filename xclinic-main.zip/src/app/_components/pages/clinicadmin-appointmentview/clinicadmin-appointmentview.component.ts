import { Component, NgZone, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators, NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';
import { MatSidenav } from '@angular/material/sidenav';
import { ClinicadminCancelComponent } from '../clinicadmin-cancel/clinicadmin-cancel.component';
import { ClinicadminDialogVisitCompletedComponent } from '../clinicadmin-dialog-visit-completed/clinicadmin-dialog-visit-completed.component';
import { ClinicadminTreatmentComponent } from '../clinicadmin-treatment/clinicadmin-treatment.component';
import { DeletemrDoctorappointmentComponent } from '../deletemr-doctorappointment/deletemr-doctorappointment.component';
import { ClinicadminCreatepaymentlinkComponent } from '../clinicadmin-createpaymentlink/clinicadmin-createpaymentlink.component';
import { ShareDataService } from '../../../_services/sharedata.service';
import { WindowRefService } from 'src/app/_services/window-ref.service';
declare var $;

@Component({
  selector: 'app-clinicadmin-appointmentview',
  templateUrl: './clinicadmin-appointmentview.component.html',
  styleUrls: ['./clinicadmin-appointmentview.component.css']
})
export class ClinicadminAppointmentviewComponent implements OnInit {
  // private key = CryptoJS.enc.Utf8.parse('lat-086648a8-cbd2-4d81-b3ab-905647a8282b-lon');
  // private iv = CryptoJS.enc.Utf8.parse('lat-086648a8-cbd2-4d81-b3ab-905647a8282b-lon');
  MedicalRecordListdisplayedColumnsbyDoctor: string[] = [
    'file',
    'action',
  ];
  public medicalRecordListdataSource: any = new MatTableDataSource<object>([]);
  public medicalRecordListdataSourcebydoctor: any = new MatTableDataSource<object>([]);
  MedicalRecordListdisplayedColumns: string[] = ['file', 'reporttype', 'action'];
  Apptid: any;
  resbutton: boolean;
  status: any;
  package: any;
  currency: any;
  locationmapid: any;
  mapping: any;
  disableUploadbtn: boolean;
  messagecontent: any;
  appointmentarray: any = [];
  appointment_view_id: any = [];
  fileToUpload: File[] = [];
  isShownFollowup: boolean = false;
  enablefollow: any;
  errormessagebox: boolean;
  followbtn: boolean;
  maxdate: any;
  maxdate1 = new Date();
  isShownReshedule: boolean = false;
  updateAppointment: FormGroup;
  BookFollowAppointment: FormGroup;
  addfollowupForm: FormGroup;
  slotimeid: any;
  timeslots: any = [];
  sloterrormsg: boolean;
  stdate: any;
  loading: boolean;
  noslotmsg: boolean;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  filter: string;
  myHolidayFilter
  shareUrl;
  type: any;
  consultationtype: any;
  public myarraystate: any = [];
  public myHolidayDates: any = [];
  public payload: any = {};
  Ispatregscreen: boolean = false;
  Isbookingscreen: boolean = true;
  Ispaymentscreen: boolean = false;
  createTreatmentForm: FormGroup;
  @ViewChild('sidenav') public sidenav: MatSidenav;
  @ViewChild('privatUserCheckbox') privatUserCheckbox: ElementRef;
  treatmentsList: any = [];
  treatmentData: any;
  treatmentPayload: any
  enableCreateTreatment: boolean = true;
  IsBookFollowup: boolean = false;
  parentGroup: FormGroup;
  confirmPayment: boolean = false;
  SelectedSlotDet: any;
  razorinfo: any;
  forbiddenmessagebox: boolean;
  blckbtn: boolean = false;
  successection: boolean;
  paymentsection: boolean;
  consultationType_walkin = "";
  Insuranceform: FormGroup;
  Book_SelectedDocInfo: any = "";
  userSelectedconsultationType: any;
  consultationType: any;
  freeapptform: boolean;
  insuranceform: boolean;

  // Payments section
  paymethodlist: any = [];
  cardpaymentform: boolean;

  user_id: string;
  pat_id: string;
  ord_id: any;
  sign: any;
  parentaId: any;
  pAId: number;

  pay_id: any;
  consFess: number;
  checkproerror: boolean;
  messagecontentflag: any;
  navigateflag: any;

  mobilenumber: any;

  checkpro: any;
  masteruser_id: string;
  docdetails: any;
  docdClinicVisit: any;
  followupdetails = null;
  myfollowupdetails: any = ""
  apptdetails: any = "";
  patdetails: any;
  patLocaDetail: any;
  clinicID: any;
  doctorimage: any;
  docimage: any;
  cashpaymentform: boolean;
  docid: any;
  cliname: any;
  specid: any;
  odId: any;
  skey: any;
  paymentId: any;
  orderId: any;
  signature: any;
  razorpaymentform: boolean;
  activepaymethod: any;
  availablepaymethods: any;

  newArray: any = [];
  apptid: any;

  resposnsedata: any;
  methodtype: any;
  searchspecial: any;
  searchdoc: any;
  searchdocspecial: any;
  searchddates: any;
  searchdoctordates: any;

  pageCheck: any;

  walkin_appoinmentDate;
  selectedconsultationtype;
  disabledIswalkin: boolean = false;
  IspressedNextperviouscalenderbtn: boolean = false;
  showmsg: boolean;
  Medihistory_array: any;
  finalFee: any;
  selectedLocation: any;
  locationDate: any;
  searchDoctorItem: any;
  patid: number;
  doctorlist: any;


  constructor(private _formBuilder: FormBuilder, private _patientservice: PatientService,
    private _activatedRoute: ActivatedRoute, public dialog: MatDialog, private router: Router,
    private _DoctorService: DoctorService,
    private sharedataService: ShareDataService,
    private winRef: WindowRefService,
    private ngZone: NgZone,
    private toastrService: ToastService) {
    this.filter = this._activatedRoute.snapshot.params.tId;
  }
  shareClick(type: string = '') {
    if (!this.shareUrl || this.shareUrl == '') {
      this._DoctorService.consultationInvite(this.Apptid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.shareUrl = res.responseMessage;
            this.copyCliboard();
          }
        });
    } else {
      this.copyCliboard();
    }
    // if (type == 'self') {
    //   // let parameterJson = JSON.stringify(this.Apptid + '||' + this.appointmentarray.patientId + '||' + this.appointmentarray.patient + '||' + this.appointmentarray.doctorId + '||' + this.appointmentarray.doctor);
    //   // let encrypted: string = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(parameterJson), this.key, {
    //   //   keySize: 128 / 8,
    //   //   iv: this.iv,
    //   //   mode: CryptoJS.mode.CBC,
    //   //   padding: CryptoJS.pad.Pkcs7
    //   // });
    //   // shareUrl =
    //   //   window.location.origin +
    //   //   '/#/consultationcall/' +
    //   //   this.appointmentarray.appointmentRoomId +
    //   //   '/' +
    //   //   encodeURIComponent(encrypted + '');
    // }

  }

  copyCliboard = () => {
    let selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = this.shareUrl;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true }
    this.toastrService.success(
      'The link is copied to the clipboard.',
      'Appointment Invite',
      options,
    )
  }

  clinicadminTreament(selectedData) {
    const dialogRef = this.dialog.open(ClinicadminTreatmentComponent, {
      width: '70%',
      data: selectedData

    });
    dialogRef.afterClosed().subscribe(result => {

    });
  }

  public Isapp_reschebtn: boolean = false;
  public Isapp_cancelbtn: boolean = false;
  public appointmentstatus_text: string = "";

  ngOnInit(): void {
    this.loading = true;
    this.maxdate = new Date();
    this.parentGroup = this._formBuilder.group({
      'radio-group1': [''],
    });
    this.medicalRecordListdataSource.paginator = this.paginator;
    this.updateAppointment = this._formBuilder.group({
      dateofappointment: ['', Validators.required],
      timeslot: [''],
    });
    this.BookFollowAppointment = this._formBuilder.group({
      dateofappointment: ['', Validators.required],
      timeslot: [''],
    });


    this.addfollowupForm = this._formBuilder.group({
      followupfee: [
        '',
        [
          Validators.required,
          /// Validators.min(1),
          // Validators.pattern(/^-?(0|[1-9]\d*)?$/)
          // Validators.pattern('^[0-9]\.?$'),
        ],
      ],
      comment: ['', Validators.required],
    });

    this.createTreatmentForm = this._formBuilder.group({
      amount: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noofvisits: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      treatment: ['', [Validators.required]],
      appointmentTreatment: ['']
    });

    this._activatedRoute.paramMap.subscribe(params => {
      this.Apptid = +params.get('appointmentId');
    });

    this._patientservice.appointmentdetail(this.Apptid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res?.responseMessage)
          this.loading = false;
          this.appointmentarray = res?.responseMessage;
          this.appointment_view_id = res.responseMessage;
          this.enableCreateTreatment = this.appointmentarray?.treatmentPackage;
          this.enablefollow = res.responseMessage.followUp.followUpStatus;
          this.myfollowupdetails = res.responseMessage;
          setTimeout(() => {
            this.recordlist();
            this.locationmapid = res?.responseMessage?.clinicLocationMapId;
            res?.responseMessage?.doctorConsultationType.map((data) => {
              if (data.consultationType == this.appointment_view_id?.typeDisplayName) {
                data.loccm.map((locdata) => {
                  if (locdata.clinicLocationMapId == this.locationmapid) {
                    this.mapping = locdata.isFollowupCodeMapped;
                  }
                })
              }
            })

          }, 3000)

          this.enablefollow = res.responseMessage.followUp.followUpStatus;
          this.currency = res.responseMessage.currencyDetails.preferedCurrencyDisplay
          this.package = res.responseMessage.package;
          this.status = res.responseMessage.status;
          this.type = res.responseMessage.type;
          const currentdate = moment(this.maxdate).format('L');
          const apptdate = moment(res.responseMessage.appointmentDate).format('L');
          if (Date.parse(apptdate) > Date.parse(currentdate)) {
            // upcoming
            // alert("upcoming")
            this.appointmentstatus_text = "upcoming"

          } else if (Date.parse(apptdate) < Date.parse(currentdate)) {
            // past
            // alert("past")
            this.appointmentstatus_text = "past"
          } else {
            if (Date.parse(apptdate) == Date.parse(currentdate)) {
              // alert("today")
              this.appointmentstatus_text = "today"

            }
            // today
            // alert("none")
          }
          // debugger;
          if (res.responseMessage.type == "walk_in") {

            // debugger
            if ((res?.responseMessage?.status == 'cancelled') || (res?.responseMessage?.status == 'past') ||
              this.appointmentstatus_text == "past" && res?.responseMessage?.status !== "completed") {
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            } else {
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = true;
            }

            if (res?.responseMessage?.status == "completed") {
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            }
          }
          // debugger
          if ((res?.responseMessage?.type == "visit_to_clinic" || res?.responseMessage?.type == "online")) {

            if ((res?.responseMessage?.type == "visit_to_clinic" || res?.responseMessage?.type == "online") &&
              (this.appointmentstatus_text == "today" && res?.responseMessage?.status == "completed")) {
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
              // alert(1);
            }

            // only for cancelled            
            if (res?.responseMessage?.status == "cancelled" &&
              res?.responseMessage?.typeDisplayName == "Video Consultation" ||
              res?.responseMessage?.typeDisplayName == "Clinic Visit") {
              // alert("tet" + " " + this.appointmentstatus_text)
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            }

            if (
              (res?.responseMessage?.status !== "cancelled") &&
              (res?.responseMessage?.status !== "completed") &&
              (res?.responseMessage?.type == "visit_to_clinic" || res?.responseMessage?.type == "online") &&
              (this.appointmentstatus_text == "upcoming" || this.appointmentstatus_text == "today")
            ) {

              this.Isapp_reschebtn = true;
              this.Isapp_cancelbtn = true;
              // alert(2);
            } else {
              // alert(3);
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            }

          }
          if (Date.parse(apptdate) >= Date.parse(currentdate)) {
            this.resbutton = true;
          } else {
            this.resbutton = false;
          }

          if (Date.parse(apptdate) <= Date.parse(currentdate)) {
            this.followbtn = true;
          } else {
            this.followbtn = false;
          }

          if (this.type == 'online') {
            this.consultationtype = 1;
          } else {
            this.consultationtype = 2;
          }
          this.dateSlots();
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  toggleFollowup() {
    this.isShownFollowup = !this.isShownFollowup;
    console.log(this.appointment_view_id)
    let followupfee;
    if (this.appointment_view_id?.type == "online") {
      followupfee = this.appointment_view_id?.fees?.domesticFollowUpFee
    }
    if (this.appointment_view_id?.type == "visit_to_clinic") {
      followupfee = this.appointment_view_id?.fees?.clinicVisitFollowUp
    }

    this.addfollowupForm
      .get('followupfee')
      .setValue(followupfee);
    this.addfollowupForm
      .get('comment')
      .setValue(this.appointment_view_id?.followUp?.comments);
    this.isShownReshedule = false;
  }

  recordlist() {
    let filetype;
    let myfilename;
    let myfilename2;
    this.loading = true;
    let array = [];
    let array2 = [];
    console.log('patient id', this.Apptid, this.appointment_view_id)

    this.medicalRecordListdataSourcebydoctor.length = 0;
    this.medicalRecordListdataSource.length = 0;
    // this._patientservice.viewpatientuploads2(this.Apptid)

    this._DoctorService.viewapptuploadsbypatientanddoctor(this.Apptid, this.appointment_view_id.patientId)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          setTimeout(() => this.medicalRecordListdataSource.paginator = this.paginator);
          for (let item of res?.responseMessage[0].medicalRecordsByPatient) {
            myfilename = item.displayName.split(".").pop();
            if (myfilename == 'jpg' || myfilename == 'jpeg' || myfilename == 'png' ||
              myfilename == 'gif' || myfilename == 'bmp' || myfilename == 'tif' ||
              myfilename == 'eps' || myfilename == 'tiff') {

              item.filetype = "imageformat";

            } else if (myfilename == 'docx' || myfilename == 'doc' || myfilename == 'pdf' ||
              myfilename == 'xls' || myfilename == 'txt' || myfilename == 'xlsx') {

              item.filetype = "textformat";

            } else if (myfilename == 'mp4' || myfilename == 'wmv' || myfilename == 'avi' ||
              myfilename == 'mkv' || myfilename == '3gp' || myfilename == 'mov' ||
              myfilename == 'mxf' || myfilename == 'mts/m2ts' || myfilename == 'asf') {

              item.filetype = "videoformat"
            } else {
              item.filetype = "fileformat"
            }
            array.push(item)
          }

          for (let item of res?.responseMessage[0].medicalRecordsByDoctor) {
            myfilename2 = item.displayName.split(".").pop();
            if (myfilename2 == 'jpg' || myfilename2 == 'jpeg' || myfilename2 == 'png' ||
              myfilename2 == 'gif' || myfilename2 == 'bmp' || myfilename2 == 'tif' ||
              myfilename2 == 'eps' || myfilename2 == 'tiff') {

              item.filetype2 = "imageformat";

            } else if (myfilename2 == 'docx' || myfilename2 == 'doc' || myfilename2 == 'pdf' ||
              myfilename2 == 'xls' || myfilename2 == 'txt' || myfilename2 == 'xlsx') {

              item.filetype2 = "textformat";

            } else if (myfilename2 == 'mp4' || myfilename2 == 'wmv' || myfilename2 == 'avi' ||
              myfilename2 == 'mkv' || myfilename2 == '3gp' || myfilename2 == 'mov' ||
              myfilename2 == 'mxf' || myfilename2 == 'mts/m2ts' || myfilename2 == 'asf') {

              item.filetype2 = "videoformat"
            } else {
              item.filetype2 = "fileformat"
            }
            array2.push(item);
          }

          this.medicalRecordListdataSource = new MatTableDataSource(array);
          this.medicalRecordListdataSourcebydoctor = new MatTableDataSource(array2);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  cancleopenDialog(cancelappid) {
    const dialogRef = this.dialog.open(ClinicadminCancelComponent, {
      // width: '60%',
      data: cancelappid
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', result.data.responseMessage, options);
          this.router.navigate(['/thealth/clinicadmin/appointments/cancelled'])

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', result.data.errorMessage, options);
        }
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
      });
  }
  toggleReshedule() {
    this.isShownReshedule = true;
    this.IsBookFollowup = false
    this.timeslots = []
    this.updateAppointment.reset()
  }

  togglereschedule(formData: any, formDirective: FormGroupDirective) {
    this.updateAppointment.reset();
    this.timeslots = [];
    this.isShownReshedule = false;

  }

  slotid(sltId, data) {
    this.slotimeid = sltId;
    console.log(data)
    this.SelectedSlotDet = data
  }
  isActive(sltId) {
    return this.slotimeid === sltId;
  };
  getslot() {
    this.loading = true;
    console.log(this.slotimeid)
    this.slotimeid = ""
    this.SelectedSlotDet = ""
    this.confirmPayment = false
    this.timeslots.length = 0
    this.sloterrormsg = false;
    if (this.IsBookFollowup) {
      const sdate = this.BookFollowAppointment.value.dateofappointment;
      const dobdate = moment(sdate).format();
      this.stdate = dobdate.substr(0, 19);
    } else {
      const sdate = this.updateAppointment.value.dateofappointment;
      const dobdate = moment(sdate).format();
      this.stdate = dobdate.substr(0, 19);
    }


    this._patientservice.timeslotres(this.appointment_view_id.appointmentId, this.appointment_view_id.doctorId, this.stdate, this.consultationtype, this.appointment_view_id.clinicLocationMapId)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          if (res.responseMessage.length === 0) {
            this.noslotmsg = true;
          } else {
            this.noslotmsg = false;
            this.timeslots = res.responseMessage;
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  reinitupdateappoint() {
    this.updateAppointment = this._formBuilder.group({
      dateofappointment: ['', Validators.required],
      timeslot: [''],
      comment: ['', Validators.required],
    });
  }

  updateappoint(formData: any, formDirective: FormGroupDirective) {
    this.loading = true;
    if (!this.slotimeid || this.slotimeid === 'undefined') {
      this.sloterrormsg = true;
      this.loading = false;
    } else {
      this.sloterrormsg = false;
      this._patientservice.upappointment(this.updateAppointment.value, this.stdate, this.slotimeid, this.appointment_view_id.appointmentId)
        .pipe(first())
        .subscribe((res: any) => {
          if (res) {
            if (!res.isError) {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const dt = this.maxdate1.toISOString();
              if (this.stdate > dt) {
                this.router.navigate(['/thealth/clinicadmin/appointments/upcoming'])
              } else {
                this.router.navigate(['/thealth/clinicadmin/appointments/today'])
              }
              this.reinitupdateappoint();
              this.timeslots.length = 0;
              this.toggleReshedule();
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.reinitupdateappoint()
            }
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.reinitupdateappoint()
          });
    }
  }
  downloadfile(data) {
    this.loading = true;
    this._DoctorService.getfiledownload(data?.recordGUID, data?.patientId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          const file_path = window.URL.createObjectURL(res);
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = data?.displayName;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  isOpenDatepicker: boolean;
  // please dont remove this function
  OpenDatepicker() {
    // if(this.isOpenDatepicker == false){
    //   this.dateSlots();
    // }
    // this.updateAppointment.get('dateofappointment').setValue(null);
    // this.timeslots.length = 0;
    // if(this.timeslots.length == 0){
    //   this.dateSlots()
    //   this.slotimeid = ""
    // }
    // setTimeout(() => {

    //   const prev = document.querySelector(".mat-calendar-previous-button");
    //   const next = document.querySelector(".mat-calendar-next-button");    


    //   prev.addEventListener("click", () => {  
    //    this.loading = true;
    //     this.myarraystate.length =0;
    //     // Previous Button      
    //     this.myHolidayFilter = (d: Date): any => {
    //       this.myarraystate.push(moment(d).format('YYYY-MM-DD'))
    //     }  
    //     setTimeout(()=>{          
    //       this.payload = {
    //         StartDate:moment(this.myarraystate[0]).format('YYYY-MM-DD'),
    //         EndDate:moment(this.myarraystate[this.myarraystate.length -1]).format('YYYY-MM-DD'),
    //         ClinicId:this.appointment_view_id.clinicId,
    //         DoctorId:this.appointment_view_id.doctorId
    //       }
    //       this.myHolidayDates.length = 0;
    //       this._patientservice.getdateslot(this.payload)
    //       .pipe(first())
    //       .subscribe((res: any) => {                     
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.myHolidayDates = res?.responseMessage[0]?.slotDates;                
    //         this.myHolidayFilter = (d: Date): any => {
    //           return this.myHolidayDates.find(x=>moment(x).format('MM/DD/YYYY')==moment(d).format('MM/DD/YYYY'));  
    //         }
    //         }
    //         else {
    //           this.loading = false;
    //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //           this.toastrService.warning('', res.errorMessage, options);
    //         }
    //       },
    //         err =>{
    //           this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err.error, options);      
    //           })
    //     });
    //   });


    //   next.addEventListener("click", () => {
    //     this.loading = true;
    //     this.myarraystate.length =0;
    //     // Previous Button      
    //     this.myHolidayFilter = (d: Date): any => {
    //       this.myarraystate.push(moment(d).format('YYYY-MM-DD'))
    //     }  
    //     setTimeout(()=>{          
    //       this.payload = {
    //         StartDate:moment(this.myarraystate[0]).format('YYYY-MM-DD'),
    //         EndDate:moment(this.myarraystate[this.myarraystate.length -1]).format('YYYY-MM-DD'),
    //         ClinicId:this.appointment_view_id.clinicId,
    //         DoctorId:this.appointment_view_id.doctorId
    //       }
    //       this.myHolidayDates.length = 0;
    //       this._patientservice.getdateslot(this.payload)
    //       .pipe(first())
    //       .subscribe((res: any) => {                     
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.myHolidayDates = res?.responseMessage[0]?.slotDates;                
    //         this.myHolidayFilter = (d: Date): any => {
    //           return this.myHolidayDates.find(x=>moment(x).format('MM/DD/YYYY')==moment(d).format('MM/DD/YYYY'));  
    //         }
    //         }
    //         else {
    //           this.loading = false;
    //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //           this.toastrService.warning('', res.errorMessage, options);
    //         }
    //       },
    //         err =>{
    //           this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err.error, options);      
    //           })
    //     });
    //   });
    // }); 
  }

  CloseDatepicker() {
    this.isOpenDatepicker = false;
  }
  dateSlots() {
    this.loading = true;
    this.payload = {
      StartDate: moment(this.maxdate).format('YYYY-MM-DD'),
      EndDate: moment(this.maxdate).add(365, 'days').format('YYYY-MM-DD'),
      ClinicId: this.appointment_view_id.clinicId,
      DoctorId: this.appointment_view_id.doctorId,
      CliniclocMapid: this.appointment_view_id.clinicLocationMapId,
      ConsultationType: this.consultationtype
    }
    this.myHolidayDates.length = 0;
    this._patientservice.getdateslot(this.payload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.myHolidayDates = res?.responseMessage[0]?.slotDates;
          if (res?.responseMessage[0]?.slotDates.length == 0) {
            this.noslotmsg = true;
          } else {
            this.noslotmsg = false;
          }
          this.isOpenDatepicker = true;
          this.myHolidayFilter = (d: Date): any => {
            return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        })
  }
  consultationStatus() {
    const dialogRef = this.dialog.open(ClinicadminDialogVisitCompletedComponent, {
    });
    dialogRef.afterClosed().subscribe(
      (result) => {
        if (result) {
          console.log(result)
          if (result.data == "conform") {
            this.loading = true;
            this._DoctorService.consultationStatusUpdate(this.Apptid)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  this.loading = false;
                  this.ngOnInit();
                } else {
                  this.loading = false;
                }
              })
          }
        }
      })
  }

  handleFileInput(event) {
    console.log(event)
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(event.target.files[0].size)
      if (event.target.files[0].size > 5242880) {
        this.disableUploadbtn = true;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "This file exceeds the maximum size limit of 5MB", options);
        return;
      } else {
        this.disableUploadbtn = false;
        this.fileToUpload = file;
      }
    }
  }

  downloadMedicalRecordfile(SelectedRecord) {
    this.toastrService.clear();
    this.loading = true;
    this._DoctorService
      .getfiledownload(SelectedRecord?.recordGUID, SelectedRecord?.patientId)
      .pipe(first())
      .subscribe(
        (res: any) => {
          if (!res.isError) {
            this.loading = false;
            const newBlob = new Blob([res], { type: 'application/pdf' });
            const file_path = window.URL.createObjectURL(res);
            const down = document.createElement('A') as HTMLAnchorElement;
            down.href = file_path;
            down.download = SelectedRecord?.displayName;
            document.body.appendChild(down);
            down.click();
            document.body.removeChild(down);
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
        (err) => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        }
      );
  }

  deleteMedicalRecordfile(SelectedRecord) {
    const dialogRef = this.dialog.open(DeletemrDoctorappointmentComponent, {
      // width: '60%',
      data: SelectedRecord,
    });
    dialogRef.afterClosed().subscribe(
      (result) => {
        if (result) {
          if (!result.data.isError) {
            this.ngOnInit();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success(
              '',
              result.data.responseMessage,
              options
            );
            this.messagecontent = result.data.responseMessage;
            this.recordlist()
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', result.data.errorMessage, options);
            this.errormessagebox = true;
            this.messagecontent = result.data.errorMessage;
          }
        }
      },
      (err) => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
        this.messagecontent = err.error;
      }
    );
  }

  SelecttabClick(event) {
    console.log(event)
    this.recordlist()
  }

  submitUploadfile() {
    this.loading = true;
    let listsdate = new Date();
    let getstdate = moment(listsdate).format();
    let recdate = getstdate.substr(0, 19);
    if (this.fileToUpload.length == 0) {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select file", options);
      return;
    } else {
      this._DoctorService.apptdetfile2(recdate, this.fileToUpload, this.Apptid, this.appointment_view_id?.patientId)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.recordlist();
            this.fileToUpload.length = 0;
            (document.getElementById("medicalrecordsUpload") as HTMLInputElement).value = ""
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
          }
          else {
            console.log(res)
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            console.log(err)
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.loading = false;
          });
    }
  }

  addfollowup() {
    this.loading = true;
    this.toastrService.clear();
    if (this.addfollowupForm.value.followupfee != null && this.addfollowupForm.value.comment !== null && this.addfollowupForm.value.comment.trim() !== "") {
      this._DoctorService
        .createfollowup(this.addfollowupForm.value, this.Apptid)
        .pipe(first())
        .subscribe(
          (res: any) => {
            if (!res.isError) {
              this.loading = false;
              this.ngOnInit();
              this.Clearaddfollowup();
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
          (err) => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          }
        );
    } else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the required field', options);
    }

  }

  Clearaddfollowup() {
    this.addfollowupForm.reset();
    this.isShownFollowup = false;
  }

  // Create Treatments
  treatmentplan() {
    this.Ispatregscreen = false;
    this.Isbookingscreen = true;
    this.createTreatmentForm.reset();
    this.privatUserCheckbox['checked'] = false;
    this.getTreatmentsdropdown();
  }
  getTreatmentsdropdown() {
    this.loading = true;
    this._DoctorService.getTreatmentsDropdown().pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.treatmentsList = res?.responseMessage;
          console.log(this.treatmentsList)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      )
  }
  changetreatment(event) {
    console.log(event.value)
    this.loading = true;
    this._DoctorService.getTreatmentsById(event.value).pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.treatmentData = res?.responseMessage[0];
          console.log(this.treatmentData)
          this.createTreatmentForm.get('noofvisits').setValue(this.treatmentData?.visits)
          this.createTreatmentForm.get('amount').setValue(this.treatmentData?.amount)
          // this.createTreatmentForm.get('noofvisits').setValue(this.treatmentData.visits)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      )
  }

  create_treatment(form, formDirective: FormGroupDirective) {
    console.log(form.value)
    this.loading = true;
    if (form.valid) {
      if (form.value.appointmentTreatment == true) {
        this.treatmentPayload = {
          'Noofvisits': form.value.noofvisits,
          "Amount": form.value.amount,
          "patientid": this.appointmentarray.patientId,
          "treatmentpackageId": form.value.treatment,
          "Appointmentid": this.appointmentarray.appointmentId
        }
      } else {
        this.treatmentPayload = {
          'Noofvisits': form.value.noofvisits,
          "Amount": form.value.amount,
          "patientid": this.appointmentarray.patientId,
          "treatmentpackageId": form.value.treatment,
        }
      }
      console.log(this.treatmentPayload)
      this._DoctorService.createTreatmentPlanner(this.treatmentPayload).pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.router.navigate(['/thealth/clinicadmin/packagetreatmentlist']);
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          (err) => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          }
        )
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
    }
  }

  clearTreatmentForm() {
    this.createTreatmentForm.reset()
  }

  createpaymentlink(paymentdata) {
    const dialogRef = this.dialog.open(ClinicadminCreatepaymentlinkComponent, {
      width: '18%',
      data: this.Apptid
    });
    console.log("sfefff------->" + paymentdata)
  }
  BookFollowUp() {
    this.isShownReshedule = false;
    this.confirmPayment = false;
    this.BookFollowAppointment.reset()
    this.SelectedSlotDet = ""
    this.timeslots = [];
    if (this.appointmentarray.isDoctorActive == true) {
      this.IsBookFollowup = !this.IsBookFollowup;
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Followup can't be created. Please enable the doctor status", options);
    }
  }

  CancelBookfollowup(formData: any, formDirective: FormGroupDirective) {
    // this.IsBookFollowup = false;
    this.BookFollowAppointment.reset()
    this.timeslots = [];
    this.SelectedSlotDet = ""
    this.confirmPayment = false;
    // this.myHolidayFilter = [];
  }
  confirmSubmit(e) {
    console.log("e----------------------------" + e);

    this.methodtype = ''
    console.log(this.Book_SelectedDocInfo)
    if (this.consultationtype == 1) {
      this.finalFee = this.appointmentarray.followUp.followUpFee;
    }
    else if (this.consultationtype == 102) {
      // this.Book_SelectedDocInfo?.fees?.wfList.map((cwdata) =>{
      // if(cwdata.cliniclocationmapId == this.selectedLocation){
      // this.finalFee = cwdata.walkinfee;
      // }
      // })
      this.finalFee = this.appointmentarray.followUp.followUpFee;
    } else if (this.consultationtype == 2) {
      // this.Book_SelectedDocInfo?.fees?.cvfList.map((cvdata) =>{
      // if(cvdata.cliniclocationmapId == this.selectedLocation){
      // this.finalFee = cvdata.clinicVisitFee;
      // }
      // })
      this.finalFee = this.appointmentarray.followUp.followUpFee;
    }
    if (this.userSelectedconsultationType == 102) {
      if (this.userSelectedconsultationType == 102 && this.slotimeid == "" || this.userSelectedconsultationType == 102 && this.slotimeid == undefined) {
        let payl = {
          "consultationtype": 102,
          "slotTime": this.locationDate,
          "IsWalkselectedtype": "no_slot_walkin",
          "userSelectedconsultationType": this.userSelectedconsultationType
        }
        this.SelectedSlotDet = payl;
        this.showmsg = false;
        this.sharedataService.doctordetails(e);
        this.sharedataService.appointmentdetails(this.SelectedSlotDet);
        this.sharedataService.searchdoc(this.searchDoctorItem);
        // this.Medihistory_array["patient_params"] = this.patid;
        // this.sharedataService.clinicadminPatientdetails = this.Medihistory_array;
        // this.sharedataService.clinicadminDoctordetails = this.Book_SelectedDocInfo;
        // this.sharedataService.clinicadminAppointmentdetails = this.SelectedSlotDet;
        // this.sharedataService.locMapid = this.selectedLocation;
        // this.sharedataService.finalFee = this.finalFee;
        // this.sharedataService.docdetails = this.Book_SelectedDocInfo;
        // this.router.navigate(['/thealth/clinicadmin/bookingdetail']);
        this.docdetails = e;
        console.log(e)
        this.loadPaymentDetail();
        this.confirmPayment = true;
      } else {
        this.SelectedSlotDet.IsWalkselectedtype = "slot_walkin"
        this.showmsg = false;
        this.sharedataService.doctordetails(e);
        this.sharedataService.appointmentdetails(this.SelectedSlotDet);
        this.sharedataService.searchdoc(this.searchDoctorItem);
        // this.Medihistory_array["patient_params"] = this.patid;
        // this.sharedataService.clinicadminPatientdetails = this.Medihistory_array;
        // this.sharedataService.clinicadminDoctordetails = this.Book_SelectedDocInfo;
        // this.sharedataService.clinicadminAppointmentdetails = this.SelectedSlotDet;
        // this.sharedataService.locMapid = this.selectedLocation;
        // this.sharedataService.finalFee = this.finalFee;
        // this.sharedataService.docdetails = this.Book_SelectedDocInfo;
        // this.router.navigate(['/thealth/clinicadmin/bookingdetail']);
        this.docdetails = e;
        this.loadPaymentDetail();
        this.confirmPayment = true;
      }
    } else if (this.userSelectedconsultationType != 102 && this.slotimeid && this.slotimeid != "") {
      this.showmsg = false;
      this.sharedataService.doctordetails(e);
      this.sharedataService.appointmentdetails(this.SelectedSlotDet);
      this.sharedataService.searchdoc(this.searchDoctorItem);
      // this.Medihistory_array["patient_params"] = this.patid;
      // this.sharedataService.clinicadminPatientdetails = this.Medihistory_array;
      // this.sharedataService.clinicadminDoctordetails = this.Book_SelectedDocInfo;
      // this.sharedataService.clinicadminAppointmentdetails = this.SelectedSlotDet;
      // this.sharedataService.locMapid = this.selectedLocation;
      // this.sharedataService.finalFee = this.finalFee;
      // this.sharedataService.docdetails = this.Book_SelectedDocInfo;
      this.docdetails = e;
      this.loadPaymentDetail();
      this.confirmPayment = true;
      // patLocaDetail

      // this.router.navigate(['/thealth/clinicadmin/bookingdetail']);
    } else {
      this.showmsg = true;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Select Slots", options);
      return;
    }
  }

  loadPaymentDetail() {
    // payments methods
    this.parentGroup = this._formBuilder.group({
      'radio-group1': [''],
    });

    this.successection = false;
    this.paymentsection = true;
    this.loadScript();
    this.Insuranceform = this._formBuilder.group({
      appointtype: ['online'],
      insuranceNumber: ['', [Validators.required]],
      insuranceProvider: ['', [Validators.required]],
      validity: ['', [Validators.required]],
      insurarname: ['', [Validators.required]],
    });

    this.apptdetails = this.SelectedSlotDet;
    console.log(this.apptdetails)
    this.docdClinicVisit = this.Book_SelectedDocInfo?.fees?.cvfList;

    this.patdetails = this.Medihistory_array;
    this.patLocaDetail = this.selectedLocation;
    this.finalFee = this.finalFee;

    this.clinicID = this.docdetails?.clinicId;
    this.stdate = this.apptdetails?.slotTime;
    this.slotimeid = this.apptdetails?.appointmentslotId;
    // this.consFess = this.docdetails?.doctorFee;
    this.docid = this.appointmentarray.doctorId;
    this.cliname = this.appointmentarray.clinic;
    this.specid = this.docdetails?.specialityId;
    this.doctorimage = this.docdetails?.doctorProfileURL;
    if (this.doctorimage != 'null' || this.doctorimage != '') {
      this.docimage = this.doctorimage;
    }
    else {
      this.docimage = "./assets/images/noimage.webp"
    }
    this.cardpaymentform = false;
    this.cashpaymentform = false;
    this.freeapptform = false;
    this.insuranceform = false;
    this.user_id = sessionStorage.getItem('userId');
    this.masteruser_id = sessionStorage.getItem('masteruserId');

    $('.payment-methods input:radio').change(function () {
      // Only remove the class in the specific `box` that contains the radio
      $('label.highlight').removeClass('highlight');
      $(this).closest('.row').addClass('highlight');
    });

    // if (this.apptdetails?.userSelectedconsultationType == 1) {
    //   this.selectedconsultationtype = 'online';
    //   this.consFess = this.docdetails.fees.domesticConsultation;
    // }
    // if (this.apptdetails?.userSelectedconsultationType == 102) {
    //   this.docdetails?.fees?.wfList.map((cwdata) => {
    //     if (cwdata.cliniclocationmapId == this.patLocaDetail) {
    //       this.selectedconsultationtype = 'walk_in';
    //       this.consFess = cwdata.walkinfee;
    //       this.consultationType_walkin = this.apptdetails?.consultationtype;
    //     }
    //   })
    // }
    // if (this.apptdetails?.userSelectedconsultationType == 2) {
    //   this.docdetails?.fees?.cvfList.map((cvdata) => {
    //     if (cvdata.cliniclocationmapId == this.patLocaDetail) {
    //       this.selectedconsultationtype = 'visit_to_clinic';
    //       this.consFess = cvdata.clinicVisitFee;
    //     }
    //   })
    // }
    // else {

    // }

    // if (this.apptdetails?.userSelectedconsultationType == 102) {
    //   this.disabledIswalkin = false;
    // } else {
    //   this.disabledIswalkin = true;
    // }
    this.loadpaymentmethods()
    console.log("ghfg")
    this._patientservice.checkprofile2(this.appointmentarray.patientId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.checkpro = res.responseMessage;
          this.loading = true;

          this._patientservice.patientdetail(this.appointmentarray.patientId)
            .pipe(first())
            .subscribe((res: any) => {
              console.log('Raor response..... ', res)
              if (!res.isError) {
                this.loading = false;
                this.razorinfo = res.responseMessage;
                // this.mobilenumber = res?.responseMessage?.mobileNumber
                this.mobilenumber = sessionStorage.getItem("mobilenumber")

              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
        } else {
          this.checkproerror = true;
          this.messagecontentflag = res.errorMessage;
          this.navigateflag = res.responseMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });

    this.listInsuranceProvider();
  }
  // payment methods

  // load checkout script
  public loadScript() {
    var isFound = false;
    var scripts = document.getElementsByTagName("script")
    for (var i = 0; i < scripts.length; ++i) {
      if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
        isFound = true;
      }
    }

    if (!isFound) {
      var dynamicScripts = ["https://checkout.razorpay.com/v1/checkout.js"];
      for (var i = 0; i < dynamicScripts.length; i++) {
        let node = document.createElement('script');
        node.src = dynamicScripts[i];
        node.type = 'text/javascript';
        node.async = false;
        node.charset = 'utf-8';
        document.getElementsByTagName('head')[0].appendChild(node);
      }
    }
  }

  loadpaymentmethods() {
    this.paymethodlist.length = 0;
    this.newArray = []
    this._patientservice.loadpaymentmethods()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res);
        if (!res.isError) {
          this.loading = false;
          this.paymethodlist = res.responseMessage;
          console.log(res.responseMessage)
          this._patientservice.activeclinicpayment(this.appointmentarray.clinicId)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                console.log(res);
                if (this.apptdetails.consultationtype == 2) {
                  this.availablepaymethods = res.responseMessage.clinicVisitPaymentDetails;
                } else {
                  this.availablepaymethods = res.responseMessage.onlinePaymentDetails;
                }
                console.log(this.availablepaymethods);
                // this.availablepaymethods = res.responseMessage.paymentDetails;
                for (let i = 0; i < this.paymethodlist.length; i++) {
                  var ismatch = false;
                  for (let j = 0; j < this.availablepaymethods.length; j++) {
                    if (this.paymethodlist[i].paymentMethodId == this.availablepaymethods[j].paymentMethodId) {
                      ismatch = true;
                      this.paymethodlist[i].showDateInput = false;
                      this.newArray.push(this.paymethodlist[i]);
                      break;
                    }
                  }
                  if (!ismatch) {
                    this.paymethodlist[i].showDateInput = true;
                    this.paymethodlist[i].mychecked2 = false;
                    this.newArray.push(this.paymethodlist[i]);
                  }

                  //End if
                }
                console.log(this.newArray)
              } else {
                console.log('error');
              }
            },
              err => {
                console.log('error2');
              });
        } else {
          console.log('error');
        }
      },
        err => {
          console.log('error2');
        });
  }


  onItemChange(paymethod) {
    console.log(paymethod)
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.methodtype = paymethod.paymentMethodReferenceName;

    if (paymethod.paymentMethodReferenceName === 'razorpay') {
      this.cashpaymentform = false;
      this.cardpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'cash') {
      this.cardpaymentform = false;
      this.cashpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'free_service') {
      this.freeapptform = true;
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.insuranceform = false;
    }
    else {
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.freeapptform = false;
      this.insuranceform = true;
    }
  }


  ispaymentActive(item) {
    return this.methodtype === item.paymentMethodReferenceName;
  }

  imgfile: any;
  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    console.log(file)
    this.imgfile = event.target.files[0];
    console.log(this.imgfile)
    this.filevalidation = false;
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
      }
    }
  }
  clearfreeapptform() {
    this.blckbtn = false;
    this.freeapptform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcashpayment() {
    this.blckbtn = false;
    this.cashpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearinsurance() {
    this.blckbtn = false;
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.insuranceform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcardpayment() {
    this.blckbtn = false;
    this.cardpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    let item = [];
    this.isActive(item);
  }
  filevalidation: boolean;
  consultationTypeText

  submitappointment(paytype) {
    this.blckbtn = true;

    if (this.consultationtype == 1) {
      this.consFess = this.appointmentarray.followUp.followUpFee;
    }
    else if (this.consultationtype == 102) {
      // this.Book_SelectedDocInfo?.fees?.wfList.map((cwdata) =>{
      // if(cwdata.cliniclocationmapId == this.selectedLocation){
      // this.finalFee = cwdata.walkinfee;
      // }
      // })
      this.consFess = this.appointmentarray.followUp.followUpFee;
    } else if (this.consultationtype == 2) {
      // this.Book_SelectedDocInfo?.fees?.cvfList.map((cvdata) =>{
      // if(cvdata.cliniclocationmapId == this.selectedLocation){
      // this.finalFee = cvdata.clinicVisitFee;
      // }
      // })
      this.consFess = this.appointmentarray.followUp.followUpFee;
    }

    //  else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 1) {
    //  this.consultationTypeText = 'walk_in';
    //this.consFess = this.docdetails?.fees?.wfList[0].walkinfee;
    //} else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 2) {
    //this.consultationTypeText = 'walk_in';
    //this.consFess = this.docdetails?.fees?.wfList[1].walkinfee;
    //} else if (this.apptdetails?.userSelectedconsultationType == 2 && this.patLocaDetail == 1) {
    //this.consultationTypeText = 'visit_to_clinic';
    //this.consFess = this.docdetails?.fees?.cvfList[0].clinicVisitFee;
    // }
    // else {
    //this.consultationTypeText = 'visit_to_clinic';
    //this.consFess = this.docdetails?.fees?.cvfList[1].clinicVisitFee;
    //}

    this.docid = this.appointmentarray.doctorId;
    this.cliname = this.appointmentarray.clinic;
    this.specid = this.docdetails?.specialityId;
    this.mobilenumber = this.appointmentarray.mobile;
    console.log(this.apptdetails)
    this.slotimeid = this.apptdetails?.appointmentslotId;
    this.stdate = this.apptdetails?.slotTime;
    let meta = this

    if (this.apptdetails?.userSelectedconsultationType == 102 && this.consultationTypeText == "walk_in" && this.apptdetails?.IsWalkselectedtype == "no_slot_walkin") {
      if (paytype == "insurance") {
        // alert("walkin ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined ||
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.appointmentarray.patientId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.appointmentarray.type);
        formDataInsuranceinsurance.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.appointmentarray.specialityId);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.mobilenumber);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('CliniclocMapid', this.appointmentarray.clinicLocationMapId);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        if (this.myfollowupdetails &&
          this.myfollowupdetails.followUp.parentAppointmentId) {
          formDataInsuranceinsurance.append('followUp.ParentAppointmentId', this.myfollowupdetails.followUp.parentAppointmentId);
        }
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.paymentsection = false;

                this.blckbtn = false;
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        let insurancedoctorfee
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.appointmentarray.type);
        formDataPaymentWalkin.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataPaymentWalkin.append('PatientId', this.patdetails?.userId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.appointmentarray.specialityId);
        formDataPaymentWalkin.append('Mobile', this.mobilenumber);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);
        formDataPaymentWalkin.append('CliniclocMapid', this.appointmentarray.clinicLocationMapId);
        if (this.myfollowupdetails &&
          this.myfollowupdetails.followUp.parentAppointmentId) {
          formDataPaymentWalkin.append('followUp.ParentAppointmentId', this.myfollowupdetails.followUp.parentAppointmentId);
        }
        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              // this.SelectedSlotDet = "";
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.successection = true;
              this.paymentsection = false;

              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const slotDate = moment(this.stdate).format('MM/DD/YYYY');
              const dt = moment(this.maxdate).format('MM/DD/YYYY');
              this.blckbtn = false;
              setTimeout(() => {
                if (slotDate > dt) {
                  this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                } else {
                  this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                }
              }, 2000);
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    } else if (this.apptdetails?.userSelectedconsultationType == 102 && this.consultationTypeText == "walk_in" && this.apptdetails?.IsWalkselectedtype == "slot_walkin") {
      if (paytype == "insurance") {
        // alert("walkin  slot ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined ||
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.appointmentarray.patientId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.appointmentarray.type);
        formDataInsuranceinsurance.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.appointmentarray.specialityId);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.mobilenumber);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('CliniclocMapid', this.appointmentarray.clinicLocationMapId);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        // formDataInsuranceinsurance.append('PatientId', this.pat_id);
        if (this.myfollowupdetails &&
          this.myfollowupdetails.followUp.parentAppointmentId) {
          formDataInsuranceinsurance.append('followUp.ParentAppointmentId', this.myfollowupdetails.followUp.parentAppointmentId);
        }
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              this.successection = true;
              this.paymentsection = false;

              this.blckbtn = false;
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.appointmentarray.type);
        formDataPaymentWalkin.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataPaymentWalkin.append('PatientId', this.patdetails?.userId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.appointmentarray.specialityId);
        formDataPaymentWalkin.append('Mobile', this.mobilenumber);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('AppoinmentSlotid', this.apptdetails?.appointmentslotId);
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);
        formDataPaymentWalkin.append('CliniclocMapid', this.appointmentarray.clinicLocationMapId);
        if (this.myfollowupdetails &&
          this.myfollowupdetails.followUp.parentAppointmentId) {
          formDataPaymentWalkin.append('followUp.ParentAppointmentId', this.myfollowupdetails.followUp.parentAppointmentId);
        }
        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              // this.SelectedSlotDet = "";   
              this.resposnsedata = res;
              this.apptid = res.responseData;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const slotDate = moment(this.stdate).format('MM/DD/YYYY');
              const dt = moment(this.maxdate).format('MM/DD/YYYY');;
              this.successection = true;
              this.paymentsection = false;

              this.blckbtn = false;
              console.log(this.stdate)
              console.log(dt)
              setTimeout(() => {
                if (slotDate > dt) {
                  this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                } else {
                  this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                }
              }, 2000);
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    }
    else {
      if (paytype == "insurance") {
        // alert(" online offline , insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined ||
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.appointmentarray.patientId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsurance: FormData = new FormData();
        formDataInsurance.append('AppointmentType', this.appointmentarray.type);
        formDataInsurance.append('AppointmentDate', this.stdate);
        formDataInsurance.append('Comments', "Regularcheckup");
        formDataInsurance.append('Firstname', "");
        formDataInsurance.append('Lastname', "");
        formDataInsurance.append('DoctorId', this.docid);
        formDataInsurance.append('SpecilalityId', this.appointmentarray.specialityId);
        formDataInsurance.append('Email', "");
        formDataInsurance.append('Mobile', this.mobilenumber);
        formDataInsurance.append('PaymentMethod', "Insurance");
        formDataInsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsurance.append('BookingType', "regular");
        formDataInsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsurance.append('CliniclocMapid', this.appointmentarray.clinicLocationMapId,);
        formDataInsurance.append('OrderId', this.ord_id);
        formDataInsurance.append('PaymentId', this.pay_id);
        formDataInsurance.append('Signature', this.sign);
        formDataInsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsurance.append('Cardimagepath', this.imgfile);
        formDataInsurance.append('PatientId', this.pat_id);
        if (this.myfollowupdetails &&
          this.myfollowupdetails.followUp.parentAppointmentId) {
          formDataInsurance.append('followUp.ParentAppointmentId', this.myfollowupdetails.followUp.parentAppointmentId);
        }
        this._patientservice.paymentsubmitForInsurance(formDataInsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.paymentsection = false;

                this.blckbtn = false;
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        // alert("online offline , cash and free")
        this.loading = true;
        this.pat_id = this.appointmentarray.patientId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        const payment = paytype;
        const aptmnt = {
          appointtype: this.appointmentarray.type,
          comment: "",
          fname: "",
          lname: "",
          doctor: this.appointmentarray.doctorId,
          clinic: this.cliname,
          speciality: this.appointmentarray.specialityId,
          email: "",
          mobile: "",
          dateofappointment: "",
          timeslot: "",
          paymentid: ""
        }
        let parentappid = "";
        if (this.myfollowupdetails &&
          this.myfollowupdetails.followUp.parentAppointmentId) {
          parentappid = this.myfollowupdetails.followUp.parentAppointmentId
        }
        console.log()
        this._patientservice.paymentsubmitBookFollowup(aptmnt, this.stdate, this.appointmentarray.patientId, this.slotimeid, this.pay_id, this.ord_id, this.sign, this.consFess, payment, this.mobilenumber, parentappid, this.appointmentarray.clinicLocationMapId, this.appointmentarray.appointmentId)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                this.successection = true;
                this.paymentsection = false;

                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                // const dt = moment(this.maxdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');
                console.log(slotDate > dt)
                this.blckbtn = false;
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);
              });
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      }
    }
  }

  listinsuranceproviderArray: any = [];
  listInsuranceProvider() {
    this._patientservice.getInsturanceProvider()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        this.listinsuranceproviderArray = res.responseMessage
      }, err => {
      })
  }

  initPay() {
    this.blckbtn = true;
    if (this.consultationType_walkin == "102") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.blckbtn = false;
      this.toastrService.warning('', "Rayzor Not Applicable for Walk-In", options);
      return;
    }
    // if (this.apptdetails?.userSelectedconsultationType == 1) {
    //   this.consultationTypeText = 'online';
    //   this.consFess = this.appointmentarray.followUp.followUpFee;
    // }
    // if (this.apptdetails?.userSelectedconsultationType == 102) {
    //   this.consultationTypeText = 'walk_in';
    //   this.consFess = this.appointmentarray.followUp.followUpFee;
    // }
    // if (this.apptdetails?.userSelectedconsultationType == 2) {
    //   this.consultationTypeText = 'visit_to_clinic';
    //   this.consFess = this.appointmentarray.followUp.followUpFee;
    // }
    this.consFess = this.appointmentarray.followUp.followUpFee;
    this.user_id = sessionStorage.getItem('userId');
    console.log('pay details... ', this.finalFee, this.docid, this.clinicID, this.user_id, "*******", this.slotimeid)
    if (!this.slotimeid || this.slotimeid === 'undefined') {
      this.sloterrormsg = true;
      this.loading = false;
    } else {
      this.sloterrormsg = false;
      this._patientservice.emailinitpay(this.finalFee, this.docid, this.appointmentarray.clinicId, this.user_id)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.odId = res.responseMessage;
            this.skey = res.responseData
            this.blckbtn = false;
            console.log(this.odId, this.skey)
            this.payWithRazor(this.odId, this.skey);
          }
          else {
            this.errormessagebox = true;
            this.blckbtn = false;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.blckbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }
  cleardata() {
    this.apptdetails = ""
    this.consultationType_walkin = ""
  }
  // for testing
  payWithRazor(oid, sk) {
    console.log(this.consultationTypeText);
    let razorpaydescription = ""
    this.pat_id = this.appointmentarray.patientId;
    console.log(this.pat_id);
    let meta = this
    if (this.myfollowupdetails &&
      this.myfollowupdetails.followUp.parentAppointmentId) {
      razorpaydescription = "Followup Fee";
    } else {
      razorpaydescription = "Consultation Fee";
    }
    const options: any = {
      key: sk,
      amount: this.consFess * 100, // amount should be in paise format to display Rs 1255 without decimal point
      currency: 'INR',
      name: 'ClinaNG', // company name or product name
      description: razorpaydescription,  // product description
      // description: 'Consultation Fee',  // product description
      image: './assets/images/clina-blue.webp', // company logo or product image
      order_id: oid, // order_id created by you in backend
      modal: {
        // We should prevent closing of the form when esc key is pressed.
        escape: false,
      },
      notes: {
        // include notes if any
      },
      theme: {
        color: '#0c238a'
      }
    };
    console.log(options)
    options.handler = ((response, error) => {
      options.response = response;
      this.paymentId = response.razorpay_payment_id;
      this.orderId = response.razorpay_order_id;
      this.signature = response.razorpay_signature;

      if (response.razorpay_payment_id && response.razorpay_order_id && response.razorpay_signature) {
        this.loading = true;
        if (!this.slotimeid || this.slotimeid === 'undefined') {
          this.sloterrormsg = true;
          this.loading = false;
        }
        else {
          const payment = 'RazorPay';
          if (this.parentaId != 0) {
            this.pAId = this.parentaId;
          } else {
            this.pAId = 0;
          }
          const aptmnt = {
            appointtype: this.appointmentarray.type,
            comment: "",
            fname: "",
            lname: "",
            doctor: this.appointmentarray.doctorId,
            clinic: this.cliname,
            speciality: this.appointmentarray.specialityId,
            email: "",
            mobile: "",
            dateofappointment: "",
            timeslot: "",
            paymentid: ""
          }
          let parentappid = "";
          if (this.myfollowupdetails &&
            this.myfollowupdetails.followUp.parentAppointmentId) {
            parentappid = this.myfollowupdetails.followUp.parentAppointmentId
          }
          this._patientservice.paymentsubmitBookFollowup(aptmnt, this.stdate, this.appointmentarray.patientId, this.slotimeid, this.paymentId, this.orderId, this.signature, this.consFess, payment, this.mobilenumber, parentappid, this.appointmentarray.clinicLocationMapId, this.appointmentarray.appointmentId)
            .pipe(first())
            .subscribe((res: any) => {
              console.log(res);
              if (res && !res.isError) {
                this.resposnsedata = res;
                this.apptid = res.responseData;
                this.loading = false;
                this.sloterrormsg = false;
                this.followupdetails = "";
                this.sharedataService.reschefollowdetails = "";
                this.sharedataService.followupdet = "";
                this._patientservice.Followupdoctordetails = "";
                this.myfollowupdetails = ""
                sessionStorage.removeItem("followupdetails");
                this.sharedataService.rescheduledocdetails('');
                this.sharedataService.searchdats = "";
                this.sharedataService.searchdates('');
                this.sharedataService.searchspeciality = '';
                this.sharedataService.searchspecial('');
                this.sharedataService.searchdoctor = '';
                this.sharedataService.searchdoc('');
                this.sharedataService.docspeciality = "";
                this.sharedataService.searchdocspeciality('');
                this.sharedataService.docdate = "";
                this.sharedataService.searchdocdate('');
                this.sharedataService.docspecdate = "";
                this.sharedataService.searchdocspecdate('');
                this.sharedataService.specdate = '';
                this.sharedataService.searchspecdate('');
                this.sharedataService.ResheclinicadminAppointmentdetails = ""
                this.sharedataService.ResheclinicadminDoctordetails = ""
                this.sharedataService.ResheclinicadminPatientdetails = ""
                this.sharedataService.clinicadminconsulatationType = "";
                this.consultationType_walkin = "";
                sessionStorage.removeItem("specialityId")
                // meta.ngZone.run(() => {
                //   this.successection = true;
                //   this.paymentsection = false;
                // });

                meta.ngZone.run(() => {
                  this.successection = true;
                  this.paymentsection = false;

                  const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                  const dt = moment(this.maxdate).format('MM/DD/YYYY');
                  this.blckbtn = false;
                  setTimeout(() => {
                    if (slotDate > dt) {
                      meta.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                    } else {
                      meta.router.navigate(['/thealth/clinicadmin/appointments/today'])
                    }
                  }, 3000);
                });

                this.sharedataService.setSuccessmsg(res.responseMessage);
              }
              else {
                this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res?.errorMessage, options);
                this.sloterrormsg = false;
                if (this.errormessagebox) {
                  this.loading = false;
                }
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            },
              err => {
                this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
                this.sloterrormsg = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
                if (this.forbiddenmessagebox) {
                  this.loading = false;
                }
              });
        }
      }
      // call your backend api to verify payment signature & capture transaction
    });
    console.log(this.razorinfo)
    options.prefill = {
      name: this.razorinfo.firstName,
      email: this.razorinfo.eMail,
      contact: this.razorinfo.mobileNumber
    },
      options.modal.ondismiss = (() => {
        // handle the case when user closes the form while transaction is in progress
      });
    const rzp = new this.winRef.nativeWindow.Razorpay(options);
    rzp.open();
  }
  Closestepper(data) {
    this.consultationType = ""
    this.myHolidayFilter = [];
    this.IspressedNextperviouscalenderbtn = false;
    this.confirmPayment = false;
    this.timeslots = []
    this.IsBookFollowup = false
    this.ngOnInit();
  }
}

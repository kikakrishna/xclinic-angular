import { RouterModule } from '@angular/router';
import { ClinicadminAppointmentviewComponent } from './clinicadmin-appointmentview.component';
export const ClinicAdminAppointmentviewRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminAppointmentviewComponent,
    }
]
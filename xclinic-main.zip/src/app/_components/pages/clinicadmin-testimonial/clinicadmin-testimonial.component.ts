import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDeletetestimonialComponent } from '../clinicadmin-deletetestimonial/clinicadmin-deletetestimonial.component';
import { MatDialog } from '@angular/material/dialog';
import {MatSelectModule} from '@angular/material/select';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-clinicadmin-testimonial',
  templateUrl: './clinicadmin-testimonial.component.html',
  styleUrls: ['./clinicadmin-testimonial.component.css']
})
export class ClinicadminTestimonialComponent implements OnInit {
  clinicId:any;
  displayedColumns: string[] = ['title', 'publish', 'action'];
  public ClnicArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  addressmodel: any;
  rating:any;
  positionselect:any;

   foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'},
  ];

  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    private router: Router,
    public dialog: MatDialog,
    ) { }

  ngOnInit(): void {
   this.rating = [
    {value: '1', viewValue: '1'},
    {value: '2', viewValue: '2'},
    {value: '3', viewValue: '3'},
    {value: '4', viewValue: '4'},
    {value: '5', viewValue: '5'},
    ]; 

    this.loading = true;
    this.clinicId = sessionStorage.getItem('clinicId');
     this.ClnicArraydataSource.paginator = this.paginator;
     this._DoctorService.getTestimoniallist()
      .pipe(first())
      .subscribe((res: any) => {
      console.log('tetsti response... ', res);
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.ClnicArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  createclick(){
      this.router.navigate([`/thealth/clinicadmin/testimonial/add`], { state: { testitatus: 'create', btnAction:true } });
  }

  editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/testimonial/edit/${ele.testimonialId}`], { state: { testitatus: ele, btnAction:false } });
      }
  
  statchanged(dId, state) {
    this.loading = true;
    this._DoctorService.publishTestimonial(dId, state)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.serviceslist();
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.serviceslist()
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);          
        });
  }

  Changeposition(){ 
  }

  deleteclick(deldata) {
  console.log(deldata)
  this.loading = false;
  const dialogRef = this.dialog.open(ClinicadminDeletetestimonialComponent, {
  panelClass: 'deletewrapper',
  data: deldata.testimonialId
  });
  dialogRef.afterClosed().subscribe(res => {
  if (res) {
  console.log(res)
  if (!res.data.isError) {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.success('', res.data.responseMessage, options);
    this.serviceslist();
  } else {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', res.data.errorMessage, options);
  }
  }
  },
  err => {
  this.loading = false;
  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  this.toastrService.warning('', err?.error, options);
  });
  }

  serviceslist() {
    this._DoctorService.getTestimoniallist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.ClnicArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

}

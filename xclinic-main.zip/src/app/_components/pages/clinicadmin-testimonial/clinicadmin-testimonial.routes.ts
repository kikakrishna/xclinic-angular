import { RouterModule } from '@angular/router';
import { ClinicadminTestimonialComponent } from './clinicadmin-testimonial.component';
export const ClinicadminTestimonialRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminTestimonialComponent,
    }
]
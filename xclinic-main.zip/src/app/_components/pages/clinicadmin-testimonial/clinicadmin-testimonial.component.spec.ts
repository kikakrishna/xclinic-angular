import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminTestimonialComponent } from './clinicadmin-testimonial.component';

describe('ClinicadminTestimonialComponent', () => {
  let component: ClinicadminTestimonialComponent;
  let fixture: ComponentFixture<ClinicadminTestimonialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminTestimonialComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminTestimonialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

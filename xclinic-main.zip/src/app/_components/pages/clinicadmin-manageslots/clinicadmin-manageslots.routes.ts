import { RouterModule } from '@angular/router';
import { ClinicadminManageslotsComponent } from './clinicadmin-manageslots.component';
export const ClinicadminManageslotsRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminManageslotsComponent,
    }
]
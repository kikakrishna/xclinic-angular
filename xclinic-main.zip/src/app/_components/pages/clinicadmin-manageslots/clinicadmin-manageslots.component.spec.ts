import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminManageslotsComponent } from './clinicadmin-manageslots.component';

describe('ClinicadminManageslotsComponent', () => {
  let component: ClinicadminManageslotsComponent;
  let fixture: ComponentFixture<ClinicadminManageslotsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminManageslotsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminManageslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { DoctorService } from 'src/app/_services/doctor.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { first } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { SlotdeletionDialogComponent } from '../slotdeletion-dialog/slotdeletion-dialog.component';
import { ActivatedRoute } from '@angular/router';
import { ClinicadminAddslotsComponent } from '../clinicadmin-addslots/clinicadmin-addslots.component';
import { PatientService } from 'src/app/_services/patient.service';
var ELEMENT_DATA = [];
@Component({
  selector: 'app-clinicadmin-manageslots',
  templateUrl: './clinicadmin-manageslots.component.html',
  styleUrls: ['./clinicadmin-manageslots.component.css']
})
export class ClinicadminManageslotsComponent implements OnInit, OnDestroy {
  public selectedDoctor;
  chgconsultantiontypevar = 0;
  public avaliableDateslots_displayedColumns: string[] = ['date', 'days', 'clinic'];
  public avaliableTimeslots_displayedColumns: string[] = ['slot', 'consultancystatus', 'status', 'action'];
  public avaliableDateslots_dataSource: any = new MatTableDataSource<object>([]);
  public avaliableTimeslots_dataSource: any = new MatTableDataSource<object>([]);
  clinicnameArray: any = [];
  viewSlot: FormGroup;
  messagebox: boolean;
  errormessagebox: boolean;
  messagecontent: any;
  lstsdate: any;
  lstedate: any;
  myStartDate: any;
  myEndDate: any;
  temp_getslotlistData: any = {};
  temp_selectedslotData: any;
  filtcontent: string;
  listdata: boolean;
  selecteddate: any;
  loading: boolean;
  Doctorid: any;
  appoinmenttype: any = [];
  language: any;
  public cct;
  public Istypesingle: boolean;
  public IstypesingleArray: any = [];
  clinicLocations: any = [];
  clinicId: any;
  videostatus: any;
  @ViewChild('paginator', { read: MatPaginator }) paginator: MatPaginator;
  @ViewChild('paginator2', { read: MatPaginator }) paginator2: MatPaginator;
  constructor(public _activatedRoute: ActivatedRoute,
    public _patientservice: PatientService,
    public dialog: MatDialog, private toastrService: ToastService, private _formBuilder: FormBuilder, private _DoctorService: DoctorService) {
    this.avaliableDateslots_dataSource = new MatTableDataSource
    this.avaliableTimeslots_dataSource = new MatTableDataSource
    this.listdata = false;
    this.viewSlot = this._formBuilder.group({
      clinicname: [''],
      startdate: ['', Validators.required],
      enddate: ['', Validators.required],
      location: ['']
    });
  }
  activeconType: any = [];
  ngOnInit(): void {
    this.selectedDoctor = JSON.parse(sessionStorage.getItem("selecteddoctor"));
    this.loading = true;
    this.videostatus = sessionStorage.getItem('videostatus');
    this._activatedRoute.paramMap.subscribe(params => {
      this.Doctorid = +params.get('doctorid');
    });
    this.myStartDate = new Date();
    this.viewSlot.controls.enddate.disable();
    this.avaliableDateslots_dataSource.paginator = this.paginator;
    this.avaliableTimeslots_dataSource.paginator = this.paginator2;
    this.listdata = true;
    this._DoctorService.getcliniclist()
      .pipe(first())
      .subscribe((res: any) => {
        this.clinicnameArray.length = 0;
        if (!res.isError) {
          this.loading = false;
          this.clinicnameArray = res.responseMessage;
          this.viewSlot.get('clinicname').setValue(res.responseMessage[0].clinicId);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.messagecontent = res.errorMessage;
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
    this.language = sessionStorage.getItem('currentLang');
    if (this.language == "ta") {
      this.filtcontent = "கிடைக்கக்கூடிய இடங்களைக் காண தேதிகளை வடிகட்டவும்";
    } else if (this.language == "mal") {
      this.filtcontent = "ലഭ്യമായ സ്ലോട്ടുകൾ കാണാൻ തീയതികൾ ഫിൽട്ടർ ചെയ്യുക";
    } else if (this.language == "ar") {
      this.filtcontent = "قم بتصفية التواريخ لمعرفة الخانات المتاحة";
    }
    else {
      this.filtcontent = "Filter the dates to see the available slots";
    }


    // this._DoctorService.getappoinmenttype()
    this._patientservice.getpaymentType_Notwalkin()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appoinmenttype.length = 0;
          this.loading = false;
          res.responseMessage.push({ appointmentTypeId: 0, appointmentTypeName: "Both", appoinmentlabel: "Both" });
          for (let i of res.responseMessage) {
            if (i.appointmentTypeName == "Video Consultation") {
              i.appoinmentlabel = "Video"
            }
            if (i.appointmentTypeName == "Clinic Visit") {
              i.appoinmentlabel = "Clinic Visit"
            }
          }
          this.appoinmenttype = res?.responseMessage
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });

    this._DoctorService.viewprofile(this.Doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let i of res.responseMessage.doctorConsultationType) {
            if (i.status == 1) {
              this.IstypesingleArray.push(i);
            }
            if (i.status == 1 && i.typeId != "102") {
              this.activeconType.push(i);
            }
          }
          console.log(this.activeconType)
          if (this.activeconType.length == 2) {
            this.Istypesingle = false;
            if (this.IstypesingleArray.length == 1) {
              this.Istypesingle = true;
            } else {
              this.Istypesingle = false;
            }
          } else {
            this.Istypesingle = true;
          }
        } else {
          this.loading = false;

        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      this.getClinicLocations();
  }

  getClinicLocations(){      
    // Get clinic locations
    this.clinicId = sessionStorage.getItem('clinicId');
    this._DoctorService.getclinicLocations(this.clinicId)
    .pipe(first())
    .subscribe((res: any) => {
      if(!res.isError){
        console.log(res)
        this.clinicLocations = res.responseMessage;
        console.log(this.clinicLocations)
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    }, err => {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', err?.error, options);
    })
}

  Changeconsultationtype() {
    this.cct = "";
    if (!this.temp_getslotlistData.startdate || !this.temp_getslotlistData.enddate || !this.temp_getslotlistData.clinicname || !this.temp_selectedslotData) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Select Date", options);
      return;
    }
    this.loading = true;
    this._DoctorService.unavailslotlistConsultationType2(this.selecteddate, this.selecteddate, this.temp_getslotlistData.clinicname, this.chgconsultantiontypevar, this.Doctorid)
      // this._DoctorService.unavailslotlistConsultationType2(this.temp_getslotlistData.startdate, this.temp_getslotlistData.enddate, this.temp_getslotlistData.clinicname,this.chgconsultantiontypevar,this.Doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.avaliableTimeslots_dataSource = new MatTableDataSource(res?.responseMessage[0]?.byDate)
          this.cct = res?.responseMessage[0]?.byDate?.length;
          for (let items of res?.responseMessage[0]?.byDate) {
            items.formatedDate = moment(items?.date).format('ll');
            if (items?.date === this.temp_selectedslotData?.date) {
              if (items?.slots?.length != 0) {
                this.selectedSlot(items);
              }
            }
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.avaliableDateslots_dataSource.paginator = this.paginator);
      })
  }
  addslots() {
    const dialogRef = this.dialog.open(ClinicadminAddslotsComponent, {
      width: '65%',
      data: this.Doctorid
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result == "slotcreated" && this.avaliableTimeslots_dataSource.data.length != 0) {
        this.chgconsultantiontypevar = 0
        this.Changeconsultationtype();

      }
    });
  }
  setchoosedoc: boolean;
  setchoosendoctor() {
    this.setchoosedoc = true;
  }
  selectedSlot(sdata) {
    var array = [];
    this.temp_selectedslotData = sdata;
    for (let item of sdata?.slots) {
      item.clinicName = sdata.clinicName;
      item.clinicId = sdata.clinicId;
      array.push(item);
    }
    this.avaliableTimeslots_dataSource = new MatTableDataSource(array);
    setTimeout(() => this.avaliableTimeslots_dataSource.paginator = this.paginator2);
    this.selecteddate = sdata.date;
  }
  selectedSlot2(sdata) {
    this.chgconsultantiontypevar = 0
    console.log(sdata)
    this.temp_selectedslotData = sdata;
    var array = [];
    for (let item of sdata?.slots) {
      item.clinicName = sdata.clinicName;
      item.clinicId = sdata.clinicId;
      // if(item?.consultationtype == "1"){
      //   item.consultationtype ="Active";
      // }
      // if(item?.consultationtype == "2"){
      //   item.consultationtype ="InActive";
      // }            
      array.push(item);
    }
    this.avaliableTimeslots_dataSource = new MatTableDataSource(array);
    this.selecteddate = sdata.date;
    console.log(this.selecteddate)

    setTimeout(() => {
      this.avaliableTimeslots_dataSource.paginator = this.paginator2
      if (this.avaliableTimeslots_dataSource.paginator) {
        this.avaliableTimeslots_dataSource.paginator.firstPage();
      }
    });


  }
  getRecord(sdata) {
    return this.selecteddate === sdata;
  }
  dateenabled() {
    this.viewSlot.controls.enddate.reset();
    if (this.viewSlot.value.startdate != "") {
      this.viewSlot.controls.enddate.enable();
    }
    this.avaliableTimeslots_dataSource = new MatTableDataSource();
    this.avaliableDateslots_dataSource = new MatTableDataSource();
  }
  datevalidation() {
    if (this.viewSlot.value.startdate == "") {
      this.viewSlot.controls.enddate.disable();
      return;
    }
    this.myEndDate = this.viewSlot.value.startdate;
  }
  getslotlist() {
    this.chgconsultantiontypevar = 0;
    this.loading = true;
    let array = [];
    this.avaliableTimeslots_dataSource = new MatTableDataSource();
    const listsdate = this.viewSlot.value.startdate;
    const getstdate = moment(listsdate).format();
    this.lstsdate = getstdate.substr(0, 19);
    const listedate = this.viewSlot.value.enddate;
    const getedate = moment(listedate).format();
    this.lstedate = getedate.substr(0, 19);
    this.temp_getslotlistData.startdate = this.lstsdate;
    this.temp_getslotlistData.enddate = this.lstedate;
    this.temp_getslotlistData.clinicname = this.viewSlot.value;
    this._DoctorService.unavailslotlist2(this.lstsdate, this.lstedate, this.viewSlot.value, this.Doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let item of res?.responseMessage[0]?.byDate) {
            item.formatedDate = moment(item?.date).format('ll');
            array.push(item)
          }
          this.avaliableDateslots_dataSource = new MatTableDataSource(array)
          if (this.avaliableDateslots_dataSource.data.length === 0) {
            this.listdata = true;
            this.filtcontent = "No Record Found";
          }
          else {
            this.listdata = false;
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.avaliableDateslots_dataSource.paginator = this.paginator);
      })
  }
  getslotlist2() {
    this.loading = true;
    let array = [];
    this.avaliableTimeslots_dataSource = new MatTableDataSource();
    const listsdate = this.viewSlot.value.startdate;
    const getstdate = moment(listsdate).format();
    this.lstsdate = getstdate.substr(0, 19);
    const listedate = this.viewSlot.value.enddate;
    const getedate = moment(listedate).format();
    this.lstedate = getedate.substr(0, 19);
    this.temp_getslotlistData.startdate = this.lstsdate;
    this.temp_getslotlistData.enddate = this.lstedate;
    this.temp_getslotlistData.clinicname = this.viewSlot.value;
    this._DoctorService.unavailslotlist2(this.lstsdate, this.lstedate, this.viewSlot.value, this.Doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let item of res?.responseMessage[0]?.byDate) {
            item.formatedDate = moment(item?.date).format('ll');
            array.push(item)
          }
          this.avaliableDateslots_dataSource = new MatTableDataSource(array)
          if (this.avaliableDateslots_dataSource.data.length === 0) {
            this.listdata = true;
            this.filtcontent = "No Record Found";
          }
          else {
            this.listdata = false;
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.avaliableDateslots_dataSource.paginator = this.paginator);
      })
  }
  getslotlist_Bytempdata() {
    this.loading = true;
    this._DoctorService.unavailslotlist2(this.lstsdate, this.lstedate, this.viewSlot.value, this.Doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res?.responseMessage[0]?.byDate)
          this.avaliableDateslots_dataSource = new MatTableDataSource(res?.responseMessage[0]?.byDate)
          for (let items of res?.responseMessage[0]?.byDate) {
            items.formatedDate = moment(items?.date).format('ll');
            if (items?.date === this.temp_selectedslotData?.date) {
              if (items?.slots?.length != 0) {
                this.selectedSlot(items);
              }
            }
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.avaliableDateslots_dataSource.paginator = this.paginator);
      })
  }
  statchanged(sId, slotstate) {
    this.loading = true;
    this.toastrService.clear();
    this._DoctorService.slotchangestate(sId, slotstate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.messagecontent = res.responseMessage;
          // this.getslotlist_Bytempdata();
          // this.Changeconsultationtype()

        } else {
          this.loading = false;
          this.messagecontent = res.errorMessage;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // this.getslotlist_Bytempdata();
          // this.Changeconsultationtype()

        }
        this.getslotlist2();
        this.Changeconsultationtype()
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          this.messagecontent = err.error;
        });
  }
  deleteConformation(element) {
    const dialogRef = this.dialog.open(SlotdeletionDialogComponent, {
      // width: '35%',
      panelClass: 'deletewrapper',
      data: element
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // this.Changeconsultationtype(); 
        if (!result.data.isError) {
          // this.getslotlist();
          // this.getslotlist_Bytempdata();
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', result.data.responseMessage, options);
          this.messagecontent = result.data.responseMessage;
          this.getslotlist2();
          this.Changeconsultationtype()
          setTimeout(() => {
            console.log(this.cct)
            if (this.cct == 0) {
              this.getslotlist();
            }
          }, 1000);
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', result.data.errorMessage, options);
          this.errormessagebox = true;
          this.messagecontent = result.data.errorMessage;
        }
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
        this.messagecontent = err.error;
      });
  }

  Toggleconsultationtype(event, element) {
    if (element.isAppointmentBooked == true) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Cannot Update This slot is booked already", options);
      if (event.checked) {
        return element.consultationtype = 1;
      } else {

        return element.consultationtype = 2;
      }
    } else {
      let checkedvalue = 0;
      console.log(element)
      console.log(event.checked)
      console.log(checkedvalue)
      if (event.checked) {
        this.UpdateconsultationtypeChange(element.slotId, 1)
        return element.consultationtype = 1;
      } else {
        this.UpdateconsultationtypeChange(element.slotId, 2)
        return element.consultationtype = 2;
      }
    }
  }

  UpdateconsultationtypeChange(slotid, consultationtypeid) {
    this.loading = true;
    this._DoctorService.consultationtypeChange2(slotid, consultationtypeid, this.Doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          // this.chgconsultantiontypevar=0
          console.log(this.chgconsultantiontypevar)
          const options = { opacity: 1, timeOut: 800, tapToDismiss: true };
          setTimeout(
            () => this.toastrService.success('', res.responseMessage, options)
          );
          // this.getslotlist_Bytempdata();     
          this.Changeconsultationtype();
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  ngOnDestroy() {
  }
}


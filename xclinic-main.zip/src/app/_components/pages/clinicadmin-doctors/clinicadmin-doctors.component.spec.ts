import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDoctorsComponent } from './clinicadmin-doctors.component';

describe('ClinicadminDoctorsComponent', () => {
  let component: ClinicadminDoctorsComponent;
  let fixture: ComponentFixture<ClinicadminDoctorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDoctorsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDoctorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

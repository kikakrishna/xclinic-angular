import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'doctorFilter'
})
export class ClinicAdminDoctorfilterPipe implements PipeTransform {

  transform(items: any[], filterdata: string): any[] {
    if (!items) return [];
    if (!filterdata) return items;
    filterdata = filterdata.toString().toLowerCase();
    return items.filter(it => {
      return it.doctorName.toLowerCase().includes(filterdata) ||
        it.speciality.toLowerCase().includes(filterdata);
    });    
  }
}
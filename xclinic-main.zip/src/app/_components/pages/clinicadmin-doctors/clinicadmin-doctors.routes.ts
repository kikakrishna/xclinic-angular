import { RouterModule } from '@angular/router';
import { ClinicadminDoctorsComponent } from './clinicadmin-doctors.component';
export const ClinicAdminDoctorsRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminDoctorsComponent,
    }
]
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { DoctorService } from '../../../_services/doctor.service';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import { ClinicadminCreatedoctorComponent } from '../clinicadmin-createdoctor/clinicadmin-createdoctor.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

import { ClinicadminDocotorlistfeeComponent } from '../clinicadmin-docotorlistfee/clinicadmin-docotorlistfee.component';
import { ShareDataService } from 'src/app/_services/sharedata.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-clinicadmin-doctors',
  templateUrl: './clinicadmin-doctors.component.html',
  styleUrls: ['./clinicadmin-doctors.component.css']
})
export class ClinicadminDoctorsComponent implements OnInit {
  public filterdata = null;
  displayedColumns: string[] = ['patientid', 'name', 'age', 'gender', 'bloodgroup', 'action'];
  public doctorlist_array: any = [];
  public doctorlist_arraycount: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('txpaginator', { read: MatPaginator }) txpaginator: MatPaginator;


  doctorfilerform: FormGroup;
  selected: any;  
  obs: Observable<any>;  
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  listdata: boolean;
  loading: boolean;
  constains:any;
  Ishide:boolean= true;
  totalSize:any = 0;
  totallength:any = 0;
  pageindex:any = 0;
  pagesize:any = 6;
  filterData: boolean;  
  mycurrencyDetails:any;
  constructor(public toastrService: ToastService,
    public _DoctorService: DoctorService,
    public dialog: MatDialog,
    public router: Router,
    public _formBuilder: FormBuilder,
    public sharedservice: ShareDataService) { }

  ngOnInit() {
    setTimeout(() => this.dataSource.paginator = this.txpaginator); 
    this.obs = this.dataSource.connect();
    this.doctorfilerform = this._formBuilder.group({
      doctorname: ['withprofile', Validators.required],
      search: ['']
    });

    if(sessionStorage.getItem("goback") == null){
      this.oninitdoctorlist();     
    }           
      if(sessionStorage.getItem("goback") == "doctorwithprofile"){
        this.doctorfilerform.get('doctorname').setValue("withprofile");
        this.Changedoctor()
        sessionStorage.removeItem("goback")
      }
      if(sessionStorage.getItem("goback") == "doctorwithoutprofile"){
        this.doctorfilerform.get('doctorname').setValue("withoutprofile");        
        this.Changedoctor()
        sessionStorage.removeItem("goback")
      }              
  }
  clearSearch() {
    this.doctorfilerform.get('search').setValue("");
    this.Changedoctor();
  }

  docSearch(){
    console.log(this.doctorfilerform.value)
     this.loading = true;
    this._DoctorService.doctorsearch(this.doctorfilerform.value.doctorname, this.doctorfilerform.value.search).pipe(first()).subscribe((res:any) =>{

    this.Ishide = false;      
        if(!res.isError) {
          this.loading = false;
          this.doctorlist_array = res?.responseMessage?.doctors;
          this.mycurrencyDetails = res?.responseMessage?.currencyDetails;
          this.constains = res?.pagination?.total;
          this.totalSize = res?.pagination?.total;
          this.totallength = res?.pagination?.total;
          //this.txpaginator.length = res?.pagination?.total;
          //this.txpaginator.pageIndex = res?.pagination?.pageNumber;
          //this.txpaginator.pageSize = res?.pagination?.pageSize;
          this.pageindex = 0;
          this.doctorlist_arraycount = res?.pagination?.total; 
          this.dataSource = new MatTableDataSource<any>(res?.responseMessage?.doctors);
          this.obs = this.dataSource.connect();
          if(res?.pagination?.total == 0){
            this.listdata = true;
          }
          else{
            this.listdata = false;
          }         
        }
        else{
          this.Ishide = false;        
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
    }, err =>{

    });
  }

  oninitdoctorlist(){
    this.Ishide = true;        
    this.loading = true;
    this._DoctorService.mydoctorlist('withprofile',this.pageindex,this.pagesize)
    .pipe(first())
    .subscribe((res: any) => {
      this.Ishide = false;      
      if (!res.isError) {
        this.loading = false;

         if (res?.pagination?.total == 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          } 

        if(res?.responseMessage == null){
        }else{
          this.doctorlist_array = res?.responseMessage?.doctors;
          this.mycurrencyDetails = res?.responseMessage.currencyDetails;
          this.totalSize = res?.pagination?.total;
          this.totallength = res?.pagination?.total;
          console.log('doctor total count ', res?.pagination?.total)
        //  this.txpaginator.length = res?.pagination?.total;
          this.pageindex = 0;
          this.doctorlist_arraycount = res?.pagination?.total; 
          this.dataSource = new MatTableDataSource<any>(res?.responseMessage?.doctors);  
//          setTimeout(() => this.dataSource.paginator = this.txpaginator);    
        }
        this.obs = this.dataSource.connect();
                   
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
      err => {
        this.Ishide = false;        
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }

  selectedDoctor(item) {
    this.sharedservice.setSelectedDoctor(item)
    this.router.navigate(['/thealth/clinicadmin/doctors/profile', item?.doctorId]);
  }

  Changedoctor() {    
    this.Ishide = true;        
    this.loading = true;
    this._DoctorService.mydoctorlist(this.doctorfilerform.value.doctorname,0,6)
    .pipe(first())
    .subscribe((res: any) => {
      if(res?.responseMessage == null){
        this.Ishide = false;  
        this.listdata = true;      
        this.loading = false;
        this.doctorlist_array = [];        
        this.dataSource = new MatTableDataSource([]);
       // setTimeout(() => this.dataSource.paginator = this.paginator);      
        this.obs = this.dataSource.connect();
        return;
      }else{
        this.listdata = false;
      }
      this.Ishide = false;      
      if (!res.isError) {
        this.Ishide = false;        
        this.loading = false;
        this.doctorlist_array = res?.responseMessage?.doctors;
        this.mycurrencyDetails = res?.responseMessage.currencyDetails;
        this.totalSize = res?.pagination?.total;
        this.doctorlist_arraycount = res?.pagination?.total;  
        //this.txpaginator.length = res?.pagination?.total;
        //this.txpaginator.pageIndex = res?.pagination?.pageNumber;
        //this.txpaginator.pageSize = res?.pagination?.pageSize;
        this.dataSource = new MatTableDataSource<any>(res?.responseMessage?.doctors);
        this.obs = this.dataSource.connect();
          if (res?.pagination?.total == 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }  
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
      err => {
        this.Ishide = false;        
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  DoctorsList() {
    this.Ishide = true;        
    this.loading = true;
    this._DoctorService.mydoctorlist(this.doctorfilerform.value.doctorname,this.pageindex,this.pagesize)
      .pipe(first())
      .subscribe((res: any) => {
        this.Ishide = false;      
        if(!res.isError) {
          this.loading = false;
          this.mycurrencyDetails = res?.responseMessage.currencyDetails
          this.doctorlist_array = res?.responseMessage?.doctors;   
          this.doctorlist_arraycount = res?.pagination?.total;  
          this.txpaginator.length = res?.pagination?.total;
          this.txpaginator.pageIndex = res?.pagination?.pageNumber;
          this.txpaginator.pageSize = res?.pagination?.pageSize;
          this.dataSource = new MatTableDataSource<any>(res?.responseMessage?.doctors);
          //setTimeout(() => this.dataSource.paginator = this.paginator);           
          this.obs = this.dataSource.connect();
          if(res?.pagination?.total == 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }         
        }
        else {
          this.Ishide = false;        
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.Ishide = false;        
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }


  PaginationgetNextdoctorlist(event: PageEvent){
  console.log('event', event);
  console.log(this.doctorlist_arraycount);

     let a = {
        "pageNumber": event?.pageIndex,
        "pageSize": event?.pageSize,
        "totalSize": this.doctorlist_arraycount,
      }
      
      let navinfo = {
        paginationClicked: "clicked",
        paginatorinfo: a,
      }

      this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
      this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
      this.txpaginator.length = navinfo.paginatorinfo.totalSize;

    this._DoctorService.mydoctorlist(this.doctorfilerform.value.doctorname,this.txpaginator.pageIndex, this.txpaginator.pageSize)
    .pipe(first())
    .subscribe((res: any) => {
      this.Ishide = false;      
      if (!res.isError) {
        this.loading = false;
        if(res?.pagination?.total == 0){
          this.listdata = true;
        }else{
          this.listdata = false;
          this.doctorlist_array = res?.responseMessage?.doctors;
          this.mycurrencyDetails = res?.responseMessage.currencyDetails;
          this.pageindex = this.txpaginator.pageIndex;
          this.totalSize = res?.pagination?.total;
          this.pagesize = this.txpaginator.pageSize;

          this.dataSource = new MatTableDataSource<any>(res?.responseMessage?.doctors);  
        }
        this.obs = this.dataSource.connect();
          if (res?.pagination?.total == 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }           
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
      err => {
        this.Ishide = false;        
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });

  }

  statchanged(dId, state) {
    this.loading = true;
    this._DoctorService.statechanged(dId, state)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.DoctorsList();
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.oninitdoctorlist()
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);          
        });
  }
  applyFilterMydoctor(event){ 
    this.dataSource.filter = event.target.value;    
    let filteredArray = this.doctorlist_array.filter(data => {
      if(data.doctorName.toLowerCase().trim().startsWith(event.target.value.toLowerCase().trim())) {    
        return true;
      }
      else if(data.speciality.toLowerCase().trim().startsWith(event.target.value.toLowerCase().trim())) {    
        return true;
      }else{
        return false;
      }
    })    
    this.dataSource = new MatTableDataSource<any>(filteredArray);
    this.dataSource.paginator = this.paginator;
    this.obs = this.dataSource.connect();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  editfeeDialog(selectedData) {    
    const dialogRef = this.dialog.open(ClinicadminDocotorlistfeeComponent, {
      width: '35%',
      panelClass: 'editfeewrapper',
      data: {"selectedData":selectedData,"currencyDetails":this.mycurrencyDetails}

    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
          this.DoctorsList();
        }
      }
    });
  }
  CreateDoctor() {
    let dialogRef = this.dialog.open(ClinicadminCreatedoctorComponent, {
      data: {"currencyDetails":this.mycurrencyDetails},
      panelClass: 'createdoctorwrapper',
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
          this.DoctorsList();
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', result.data.responseMessage, options);

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', result.data.errorMessage, options);
        }
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
      });
  }
  applyFilter(filterValue) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if(this.dataSource.filteredData.length === 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
    }
    //setTimeout(() => this.dataSource.paginator = this.paginator); 
    this.obs = this.dataSource.connect();
  }
  Setselecteddoctor(item){
    sessionStorage.setItem("selecteddoctor",JSON.stringify(item))
  }
}

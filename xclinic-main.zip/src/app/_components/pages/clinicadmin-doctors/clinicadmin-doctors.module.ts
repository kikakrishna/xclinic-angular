import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter';
import { MatDialogModule } from '@angular/material/dialog';


import {  ClinicAdminDoctorsRoutes } from './clinicadmin-doctors.routes';
import { ClinicadminDoctorsComponent } from './clinicadmin-doctors.component';
import { ClinicAdminDoctorfilterPipe} from './clinicadmin-doctorPipeModule';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ClinicadminCreatedoctorComponent } from '../clinicadmin-createdoctor/clinicadmin-createdoctor.component';
import { MatIconModule } from '@angular/material/icon';
import { ClinicadminDocotorlistfeeComponent } from '../clinicadmin-docotorlistfee/clinicadmin-docotorlistfee.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ClinicadminDialogSlotconformationComponent } from '../clinicadmin-dialog-slotconformation/clinicadmin-dialog-slotconformation.component';
@NgModule({
  declarations: [ClinicadminCreatedoctorComponent,ClinicadminDoctorsComponent,ClinicAdminDoctorfilterPipe,ClinicadminDocotorlistfeeComponent,ClinicadminDialogSlotconformationComponent],

  imports: [    
    MatDialogModule,
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    MatSelectModule,
    MatDatepickerModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    MatIconModule,
    MatDatepickerModule,
    MatPaginatorModule,    
    RouterModule.forChild(ClinicAdminDoctorsRoutes),
  ],
  entryComponents: [
    ClinicadminCreatedoctorComponent,
    ClinicadminDocotorlistfeeComponent,
    ClinicadminDialogSlotconformationComponent
  ],
  exports: [ClinicadminDoctorsComponent],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },

  ],
})
export class ClinicAdminDoctorsModule { }

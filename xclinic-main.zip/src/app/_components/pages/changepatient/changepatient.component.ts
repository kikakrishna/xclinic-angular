import { Component, OnInit } from '@angular/core';
import { DoctorService } from '../../../_services/doctor.service';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { MatDialogRef } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
@Component({
  selector: 'app-changepatient',
  templateUrl: './changepatient.component.html',
  styleUrls: ['./changepatient.component.css']
})
export class ChangepatientComponent implements OnInit {

  user_id: string;
  role: string;
  listfamily = [];
  errormessagebox: boolean;
  messagecontent: any;
  forbiddenmessagebox: boolean;
  family_pId: any;
  activeclass: any;
  familyselectlist: any;
  selectpatientmsg: boolean;
  masteruser_id: string;

 constructor(private toastrService: ToastService,private _DoctorService: DoctorService, private router: Router,
    private dialogRef: MatDialogRef<ChangepatientComponent>,) {
    this.user_id = sessionStorage.getItem('userId');
    this.masteruser_id = sessionStorage.getItem('masteruserId');
    this.role =  sessionStorage.getItem('Role');
    this.selectpatientmsg = false;
   }

  ngOnInit(): void {
      this.familymemberlist(); 
  }
  familymemberlist(){
    this._DoctorService.familylist(this.masteruser_id)  
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.listfamily = res.responseMessage;
        }else{
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
        }
      },
      err => {
        this.forbiddenmessagebox = true;
        this.messagecontent = err.error;
      });
    }
    familypatientid(famlist){
      this.familyselectlist = famlist;
      this.activeclass = famlist.patientId;
    }
    isActive(famlist){
      return this.familyselectlist === famlist;
    }
    familymember(){
      this.toastrService.clear();
      if(this.familyselectlist != undefined || this.familyselectlist != null)  {
        if(this.familyselectlist.familyMemberGuid != null){
          sessionStorage.setItem('familyMemberGuid',this.familyselectlist.familyMemberGuid);
        }else{
          sessionStorage.setItem('familyMemberGuid',"");
        }
      this.selectpatientmsg = false;
      sessionStorage.setItem('userId',this.familyselectlist.patientId);
      sessionStorage.setItem('clinicPatientId',this.familyselectlist.patientProfile.clinicPatientId);
      sessionStorage.setItem('userName',this.familyselectlist.firstName);
      sessionStorage.setItem('lastName',this.familyselectlist.lastName);
      sessionStorage.setItem('profile', this.familyselectlist.profileImage);
        this.dialogRef.close({ data: this.familyselectlist });
        this.router.navigate(['/thealth/dashboard'])
        .then(() => {
          window.location.reload();
        });
      }else{
        const options = { opacity: 1, timeOut: 2000};
        this.toastrService.warning('', "Please Choose the Patient", options);
      }
    }
    closematbox(){
        this.dialogRef.close({ });
    }
}


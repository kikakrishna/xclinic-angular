import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangepatientComponent } from './changepatient.component';

describe('ChangepatientComponent', () => {
  let component: ChangepatientComponent;
  let fixture: ComponentFixture<ChangepatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangepatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangepatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { ClinicadminPatientviewComponent } from '../clinicadmin-patientview/clinicadmin-patientview.component';

@Component({
  selector: 'app-clinicadmin-addfamilymember',
  templateUrl: './clinicadmin-addfamilymember.component.html',
  styleUrls: ['./clinicadmin-addfamilymember.component.css']
})
export class ClinicadminAddfamilymemberComponent implements OnInit {
  createFamily: FormGroup;
  imgfile: any;
  imageUrl: any = './assets/images/noimage.webp';
  loading: boolean = false;
  masteruser_id = ""
  relationshiptype: any = [];
  userId = "";
  responseuserId = "";
  constructor(
    private _DoctorService: DoctorService,
    public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private _activatedRoute: ActivatedRoute,
    public ot: ClinicadminPatientviewComponent,
    public dialog: MatDialog) {
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('patientid')) {
        this.userId = params?.get('patientid');

      }
    })
    this.masteruser_id = sessionStorage.getItem('masteruserId');

    this.createFamily = this._formBuilder.group({
      fname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      // lname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],

      relationtype: ['', Validators.required],
      patientclinicidentifier: ['', [Validators.required]],

    });
  }

  ngOnInit(): void {
    this.getRelationaltype();

    this._DoctorService.medihistory(this.userId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError && res.responseMessage != null) {

          console.log(res)
          this.responseuserId = res.responseMessage.userId

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }

  getRelationaltype() {
    this._DoctorService.getrelation()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.relationshiptype = res.responseMessage;
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  onNoClick() {
    this._DoctorService.Isaddfamliy = false;
    this.ot.familymemberlist();
  }
  add() {
  }
  clear() {
    this.createFamily = this._formBuilder.group({
      fname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      // lname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],

      relationtype: ['', Validators.required],
      patientclinicidentifier: ['', [Validators.required]],

    });
  }
  // createfamilymember(formData: any, formDirective: FormGroupDirective) {        
  createfamilymember() {
    console.log(this.responseuserId)
    this.loading = true;
    let firstname = this.createFamily.value.fname;
    // const newStr = `${firstname[0].toUpperCase()}${firstname.slice(1)}`;
    // this.createFamily.value.fname = newStr;
    this.imgfile = null
    console.log(this.imgfile)
    if (this.createFamily?.value.fname == '' || this.createFamily?.value.fname == null ||
      this.createFamily?.value.relationtype == '' || this.createFamily?.value.relationtype == null || 
      this.createFamily?.value.patientclinicidentifier == '' || this.createFamily?.value.patientclinicidentifier == null) {
      this.loading = false;
      return;
    }
    else {
      this._DoctorService.clinicadminAddFamilymember(this.createFamily.value, this.imgfile, this.responseuserId)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            // formDirective.resetForm();
            this.createFamily.reset();
            this.clear();
            this._DoctorService.Isaddfamliy = false;
            this.imageUrl = './assets/images/noimage.webp';
            this.ot.familymemberlist();
            // this._DoctorService.familylist(this.masteruser_id);
            this.imgfile = null;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', 'Member has been created successfully', options);
            // formDirective.resetForm();
            this.createFamily.reset();
            this.clear();
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            // formDirective.resetForm();
            this.createFamily.reset();
            this.clear();
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
  }
  // familymemberlist() {
  //   this.isImgcount = 0;
  //   this.isnotImgcount = 0;
  //   this.isImgcountevent = 0;
  //   this.isnotImgcountevent = 0;
  //   this._DoctorService.familylist(this.masteruser_id)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         for(let item of res?.responseMessage){
  //           if(item?.profileImage != null){
  //             this.isImgcount++;
  //           }
  //           if(item?.profileImage == null){                        
  //             this.isnotImgcount++;
  //           }
  //         }
  //         this.listfamily = res.responseMessage;
  //         if (this.listfamily != "") {
  //           this.familylist = this.listfamily;
  //           this.nofamilymembers =false;
  //           sessionStorage.setItem("changepatient","true")
  //         }
  //         else{
  //           if(this.listfamily.length === 0 || this.listfamily === ''){
  //             this.familylist = false;
  //             this.nofamilymembers =true;
  //             sessionStorage.setItem("changepatient","false")
  //           }
  //         }
  //         this.patmemberage = moment().diff(moment(res.responseMessage.dateofBirth, 'YYYYMMDD'), 'years')
  //       } else {
  //         this.loading = false;          
  //         this.errormessagebox = true;
  //         this.messagecontent = res.errorMessage;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //       }
  //     },
  //       err => {          
  //         this.loading = false;
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //       });
  // }
}

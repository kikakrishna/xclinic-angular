import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminAddfamilymemberComponent } from './clinicadmin-addfamilymember.component';

describe('ClinicadminAddfamilymemberComponent', () => {
  let component: ClinicadminAddfamilymemberComponent;
  let fixture: ComponentFixture<ClinicadminAddfamilymemberComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminAddfamilymemberComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminAddfamilymemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeletemapComponent } from './clinicadmin-deletemap.component';

describe('ClinicadminDeletemapComponent', () => {
  let component: ClinicadminDeletemapComponent;
  let fixture: ComponentFixture<ClinicadminDeletemapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeletemapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeletemapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

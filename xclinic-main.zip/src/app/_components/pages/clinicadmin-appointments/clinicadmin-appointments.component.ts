import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DoctorService } from 'src/app/_services/doctor.service';
@Component({
  selector: 'app-clinicadmin-appointments',
  templateUrl: './clinicadmin-appointments.component.html',
  styleUrls: ['./clinicadmin-appointments.component.css']
})
export class ClinicadminAppointmentsComponent implements OnInit {
  myStartDate: any;
  myEndDate: any;

  public filterpast_startdate: any;
  public filterpast_enddate: any;
  public filerpastform_pagination_show: boolean;
  displayedColumns: string[] = ['patient', 'appid', 'date', 'time', 'doctor', 'consultation', 'paymentstatus', 'action'];
  public dataSource: any = new MatTableDataSource<object>([]);
  public originalarray: any = [];
  @ViewChild(MatPaginator, { static: false }) appointmentspaginator: MatPaginator;
  getpendingstate: any;
  id: string;
  listdata: boolean;
  role: any;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  messagebox: boolean;
  errormessagebox: boolean;
  loading: boolean;
  filter: string;
  public totalSize = 0;
  public pageindex = 0;
  filterpast: FormGroup
  public fdate: Date;
  public tdate: Date;
  public clicadminsearchinput = "";
  constructor(private toastrService: ToastService, public _formBuilder: FormBuilder, private _DoctorService: DoctorService, private _Activatedroute: ActivatedRoute) {
    this.filter = this._Activatedroute.snapshot.params.tId;
    if (this.filter) {
      console.log(this.filter)
      this.appt(this.filter);
    }
    this.filterpast = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      todatepicker: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.myStartDate = new Date();
    this.filterpast.controls.todatepicker.disable();
    const today = new Date()
    this.myStartDate.setDate(today.getDate() - 1)
    this.dataSource.paginator = this.appointmentspaginator;
    this.role = sessionStorage.getItem("Role");
  }

  clearPastForm() {
    this.filterpast.reset();
    this.filterpast = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      todatepicker: ['', Validators.required]
    });
    this.filterpast.controls.todatepicker.disable();
  }
  dateenabled() {
    this.filterpast.controls.todatepicker.reset();
    if (this.filterpast.value.fromdatepicker != null) {
      this.filterpast.controls.todatepicker.enable();
    }
  }
  datevalidation() {
    if (this.filterpast.value.fromdatepicker == null) {
      this.filterpast.controls.todatepicker.disable();
      return;
    }
    this.myEndDate = this.filterpast.value.fromdatepicker;
  }
  clearfilterpastPagination() {
    this.filerpastform_pagination_show = false;
  }
  filterpastForm() {
    this.loading = true;
    let array = [];
    if (this.filterpast.value.fromdatepicker == null && this.filterpast.value.todatepicker == null ||
      this.filterpast.value.fromdatepicker == null && this.filterpast.value.todatepicker != null ||
      this.filterpast.value.fromdatepicker != null && this.filterpast.value.todatepicker == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Choose From Date and To Date", options);
      return;
    }
    const fdate = this.filterpast.value.fromdatepicker;
    const getFdate = moment(fdate).format();
    let startdate = getFdate.substr(0, 19);
    this.filterpast_startdate = startdate;

    const edate = this.filterpast.value.todatepicker;
    const getEdate = moment(edate).format();
    let enddate = getEdate.substr(0, 19);
    this.filterpast_enddate = enddate;
    this._DoctorService.Pastappointmentlist('Past', 0, 5, startdate, enddate)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.filerpastform_pagination_show = true;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
          }
          this.dataSource = new MatTableDataSource(array);
          this.originalarray = array
          this.totalSize = res?.responseMessage?.pagination.total;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  getNext2(event: PageEvent, filter) {
    this.loading = true;
    let array = [];
    this._DoctorService.Pastappointmentlist('Past', event.pageIndex, event.pageSize, this.filterpast_startdate, this.filterpast_enddate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.totalSize = res?.responseMessage?.pagination.total;
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

  }
  getNext(event: PageEvent, filter) {
    this.loading = true;
    let array = [];
    this.getpendingstate = filter;
    this._DoctorService.appointmentlist(filter, event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.totalSize = res?.responseMessage?.pagination.total;
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.originalarray = array
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

  }
  // applyFilter(filterValue: string, filterstate) {
  //   const filterstatevalue = filterstate.toLowerCase()
  //   let array = [];
  //   if(filterValue){
  //     if(filterstate != 'Past'){
  //       this._DoctorService.apponitmentfilter(filterValue, filterstate, 0 , 5)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         if (!res.isError) {
  //           this.totalSize = res.responseMessage.pagination.total;
  //           this.loading = false;
  //             for (let item of res?.responseMessage?.appointmentList) {
  //               item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
  //               array.push(item);
  //             }
  //             this.dataSource = new MatTableDataSource(array); 
  //             if (this.dataSource.data.length === 0) {
  //               this.listdata = true;
  //             }
  //             else {
  //               this.listdata = false;
  //             }
  //         }
  //         else {
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //           this.loading = false;
  //           this.errormessagebox = true;
  //           this.messagecontent = res.errorMessage;
  //         }
  //       },
  //       err => {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //         this.loading = false;
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //       });
  //     }else{
  //       if(this.filterpast_startdate === undefined){
  //         this.filterpast_startdate = '';
  //       }
  //       if(this.filterpast_enddate === undefined){
  //         this.filterpast_enddate = '';
  //       }
  //       this._DoctorService.apponitmentpastfilter(filterValue, filterstate, 0 , 5, this.filterpast_startdate, this.filterpast_enddate)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         if (!res.isError) {
  //           this.totalSize = res.responseMessage.pagination.total;
  //           this.loading = false;
  //             for (let item of res?.responseMessage?.appointmentList) {
  //               item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
  //               array.push(item);
  //             }
  //             this.dataSource = new MatTableDataSource(array); 
  //             if (this.dataSource.data.length === 0) {
  //               this.listdata = true;
  //             }
  //             else {
  //               this.listdata = false;
  //             }
  //         }
  //         else {
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //           this.loading = false;
  //           this.errormessagebox = true;
  //           this.messagecontent = res.errorMessage;
  //         }
  //       },
  //       err => {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //         this.loading = false;
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //       });
  //     }
  //   }else{
  //     this.getpendingstate = filterstate;
  //     let array =[];
  //     this._DoctorService.appointmentlist(filterstate, 0, 5)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         if (!res.isError) {
  //           this.totalSize = res.responseMessage.pagination.total;
  //           this.loading = false;
  //           for (let item of res?.responseMessage?.appointmentList) {
  //             item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
  //             array.push(item);
  //           }
  //           this.dataSource = new MatTableDataSource(array); 
  //           if (this.dataSource.data.length === 0) {
  //             this.listdata = true;
  //           }
  //           else {
  //             this.listdata = false;
  //           }

  //         } else {
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //           this.loading = false;
  //           this.errormessagebox = true;
  //           this.messagecontent = res.errorMessage;
  //         }
  //       },
  //         err => {
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //           this.loading = false;
  //           this.forbiddenmessagebox = true;
  //           this.messagecontent = err.error;
  //         });
  //   }
  // }
  appt(state: string) {
    this.clicadminsearchinput = "";
    this.applyfilterData = false;
    this.filterData = false;
    this.dataSource = new MatTableDataSource;
    this.getpendingstate = state;
    if (state == 'upcoming') {
      this.loading = true;
      this.getpendingstate = 'upcoming';
      let array = [];
      this._DoctorService.appointmentlist('Upcoming', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            this.originalarray = array
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentspaginator) {
                this.appointmentspaginator.pageIndex = 0;
              }
            }

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
    if (state == 'today') {
      this.loading = true;
      let array = []
      this.getpendingstate = 'today';
      this._DoctorService.appointmentlist('Today', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.totalSize = res?.responseMessage?.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            this.originalarray = array
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentspaginator) {
                this.appointmentspaginator.pageIndex = 0;
              }
            }

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);

          });
      return;
    }
    if (state == 'past') {
      this.loading = true;
      this.getpendingstate = 'past';
      let array = [];
      this._DoctorService.appointmentlist('Past', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.totalSize = res?.responseMessage?.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            this.originalarray = array
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentspaginator) {
                this.appointmentspaginator.pageIndex = 0;
              }
            }

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
    if (state == 'cancelled') {
      this.loading = true;
      this.getpendingstate = 'cancelled';
      let array = [];
      this._DoctorService.appointmentlist('Cancelled', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            this.totalSize = res?.responseMessage?.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.originalarray = array
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentspaginator) {
                this.appointmentspaginator.pageIndex = 0;
              }
            }

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
  }

  filterData: boolean;
  applyfilterData: boolean = false;
  clearFilter2() {
    // const filterValue = (event.target as HTMLInputElement).value;
    // let searchstring = filterValue.trim()
    // console.log(searchstring)
    console.log(this.clicadminsearchinput)
    this.clicadminsearchinput = ""
    let searchstring = this.clicadminsearchinput
    if (searchstring == "") {
      this.applyfilterData = false;
      if (this.getpendingstate == "today") {
        this.appt('today');
      }
      if (this.getpendingstate == "past") {
        this.appt('past');
      }
      if (this.getpendingstate == "upcoming") {
        this.appt('upcoming');
      }
      if (this.getpendingstate == "cancelled") {
        this.appt('cancelled');
      }
      return;
    }
  }
  Fsearchstring:string;
  applyFilter2() {
    const filterValue = this.clicadminsearchinput;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    if (searchstring) {
      this.applyfilterData = true;
    } else {
      this.applyfilterData = false;
      if (this.getpendingstate == "today") {
        this.appt('today');
      }
      if (this.getpendingstate == "past") {
        this.appt('past');
      }
      if (this.getpendingstate == "upcoming") {
        this.appt('upcoming');
      }
      if (this.getpendingstate == "cancelled") {
        this.appt('cancelled');
      }
      return;
    }
    
    // this.dataSource.filter = filterValue.trim().toLowerCase();
    // if(this.dataSource.filteredData.length === 0) {
    //   this.filterData = true;
    // } else {
    //   this.filterData = false;
    // }
    this.loading = true;
    this.Fsearchstring=searchstring;
    console.log(filterValue.trim().toLowerCase(), this.getpendingstate, 0, 5)
    // this._DoctorService.apponitmentfilterwithpageSize(searchstring, this.getpendingstate,0,5)
      this._DoctorService.apponitmentfilter(searchstring,this.getpendingstate,0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          let array = [];        
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
          // for (let item of res?.responseMessage?.appointmentList) {
          //   item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
          //   array.push(item);
          // }
          // this.dataSource = new MatTableDataSource(array);
          // if (this.dataSource.paginator) {
          //   this.dataSource.paginator.firstPage();
          // }
          // if (this.dataSource.data.length === 0) {
          //   this.listdata = true;
          //   this.filterData = true;

          // }
          // else {
          //   this.listdata = false;
          //   this.filterData = false;
          //   // this.appointmentspaginator.pageIndex = 0;

          // }
          setTimeout(() => {
            // this.totalSize = res?.responseMessage?.pagination.total;        
            //this.dataSource.paginator = this.appointmentspaginator
            this.totalSize = res?.responseMessage?.pagination?.total
            this.appointmentspaginator.pageIndex = 0;
            this.appointmentspaginator.pageSize = 0;

          });
        }
        else {
          this.loading = false;
          if(res.errorMessage === " No records found.") {       
            this.dataSource = new MatTableDataSource([]);
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
            return;
          }
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }
  sessionback() {
    sessionStorage.setItem('backpatadmin', 'false');
    sessionStorage.setItem('backdocadmin', 'false');
  }


  filterGetnext(event: PageEvent, timeframe) {    
    this.getpendingstate = timeframe;
    this.loading = true;
    this._DoctorService.apponitmentfilterwithpageSize(this.Fsearchstring, timeframe,event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {          
          let array = [];                    
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
            this.filterData = true;

          }
          else {
            this.listdata = false;
            this.filterData = false;
          }
         
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }
}

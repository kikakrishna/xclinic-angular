import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminAppointmentsComponent } from './clinicadmin-appointments.component';

describe('ClinicadminAppointmentsComponent', () => {
  let component: ClinicadminAppointmentsComponent;
  let fixture: ComponentFixture<ClinicadminAppointmentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminAppointmentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminAppointmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

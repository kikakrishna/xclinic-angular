import { RouterModule } from '@angular/router';
import { ClinicadminAppointmentsComponent } from './clinicadmin-appointments.component';
export const ClinicAdminAppointmentRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminAppointmentsComponent,
    }
]
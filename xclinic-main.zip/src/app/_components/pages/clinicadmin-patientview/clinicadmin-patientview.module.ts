import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { ClinicadminPatientviewComponent } from './clinicadmin-patientview.component';
import { ClinicadminPatientviewRoutes } from './clinicadmin-patientview.routes';
import { ClinicadminTreatmentComponent } from '../clinicadmin-treatment/clinicadmin-treatment.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ClinicadminAddfamilymemberComponent } from '../clinicadmin-addfamilymember/clinicadmin-addfamilymember.component';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';


@NgModule({
  declarations: [ClinicadminAddfamilymemberComponent,ClinicadminPatientviewComponent, ClinicadminTreatmentComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(ClinicadminPatientviewRoutes),
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    MatTabsModule,
    MatTableModule,    
    MatFormFieldModule,
    MatInputModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatIconModule,
    MatSelectModule,
    MatSidenavModule
  ],
  entryComponents: [ClinicadminTreatmentComponent],
  exports: [ClinicadminPatientviewComponent]
})
export class ClinicadminPatientviewModule { }

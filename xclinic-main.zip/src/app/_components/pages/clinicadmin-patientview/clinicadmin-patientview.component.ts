import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ClinicadminTreatmentComponent } from '../clinicadmin-treatment/clinicadmin-treatment.component';
import { ToastService } from 'ng-uikit-pro-standard';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from 'src/app/_services/doctor.service';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { MatSidenav } from '@angular/material/sidenav';

interface Gender {
  value: string;
}

@Component({
  selector: 'app-clinicadmin-patientview',
  templateUrl: './clinicadmin-patientview.component.html',
  styleUrls: ['./clinicadmin-patientview.component.css']
})
export class ClinicadminPatientviewComponent implements OnInit {
  public userId: any;
  public state: any;
  obsFamilymember: Observable<any>;
  public Medihistory_array: any = [];
  public Medihistory_array2: any = [];
  public ppId: any;
  displayedColumns: string[] = ['id', 'date', 'time', 'doctor', 'speciality', 'action'];
  public appointmentTodaydataSource: any = new MatTableDataSource<object>([]);
  public appointmentUpcomingdataSource: any = new MatTableDataSource<object>([]);
  public appointmentPastdataSource: any = new MatTableDataSource<object>([]);
  public appointmentCancelleddataSource: any = new MatTableDataSource<object>([]);
  public familymemberdataSource: any = new MatTableDataSource<object>([]);
  getpendingstate: any;
  public totalSize = 0;
  public pageindex = 0;
  loading: boolean;
  editmobile: boolean;
  listdata: boolean = false;
  upcominglistdata: boolean = false;
  messagecontent: any;
  messagebox: boolean;
  errormessagebox: boolean;
  forbiddenmessagebox: boolean;
  opened: boolean;
  profileImage: any;
  createpatProfile: FormGroup;
  minlen: any = sessionStorage.getItem('minlen');
  maxlen: any = sessionStorage.getItem('maxlen');
  mandatorymobEmailfields: boolean = false;
  language: any;
  @ViewChild('appointmentTodaypaginator', { read: MatPaginator }) appointmentTodaypaginator: MatPaginator;
  @ViewChild('appointmentUpcomingpaginator', { read: MatPaginator }) appointmentUpcomingpaginator: MatPaginator;
  @ViewChild('appointmentPastpaginator', { read: MatPaginator }) appointmentPastpaginator: MatPaginator;
  @ViewChild('appointmentCancelledpaginator', { read: MatPaginator }) appointmentCancelledpaginator: MatPaginator;
  @ViewChild('familymemberpaginator', { read: MatPaginator }) familymemberpaginator: MatPaginator;
  createfamiltype: FormGroup
  masteruser_id
  dataSource2;
  familytype: boolean = false;
  alreadymemb: boolean = false;
  regbtn: boolean = true;
  resp: any;
  patid: any;
  displayedColumns2: string[] = ['name', 'patientid', 'relationtype'];

  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;

  @ViewChild('uploadResultPaginator', { read: MatPaginator }) uploadResultPaginator: MatPaginator;
  @ViewChild('sidenav') public sidenav: MatSidenav;
  patoffid: any;
  isReadOnlyphone: boolean = false;
  isReadOnlyemail: boolean = false;
  CreateTreatmentsection: boolean = false;
  CreatePatientsection: boolean = true;
  createTreatmentForm: FormGroup;
  @ViewChild('privatUserCheckbox') privatUserCheckbox: ElementRef;
  treatmentsList: any = [];
  treatmentData: any;
  treatmentPayload: any;
  public searchinputToday = "";
  public searchinputPast = "";
  public searchinputUpcoming = "";
  public searchinputCancel = "";
  Fsearchstring: any;
  familymembersearch: any;
  count = [];
  countrymodel: any = [];
  constructor(private toastrService: ToastService,
    private _activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public _DoctorService: DoctorService,
    private router: Router, private _formBuilder: FormBuilder,
    private authenticationService: AuthenticationService) {
    this.appointmentTodaydataSource = new MatTableDataSource;
    this.appointmentUpcomingdataSource = new MatTableDataSource;
    this.appointmentPastdataSource = new MatTableDataSource;
    this.appointmentCancelleddataSource = new MatTableDataSource;
    this.familymemberdataSource = new MatTableDataSource<object>([]);

  }

  genderlist: Gender[] = [
    { value: 'Male' },
    { value: 'Female' }
  ];

  ngOnInit(): void {
    this.masteruser_id = sessionStorage.getItem('masteruserId');
    this.language = sessionStorage.getItem('sitelanguage');
    this.loading = true;
    this.toastrService.clear();
    this.appointmentTodaydataSource.paginator = this.appointmentTodaypaginator;
    this.appointmentUpcomingdataSource.paginator = this.appointmentUpcomingpaginator;
    this.appointmentPastdataSource.paginator = this.appointmentPastpaginator;
    this.appointmentCancelleddataSource.paginator = this.appointmentCancelledpaginator;
    this.familymemberdataSource.paginator = this.familymemberpaginator;

    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('patientid')) {
        this.userId = params?.get('patientid');
        console.log(this.userId)
      }
    })

    this.createpatProfile = this._formBuilder.group({
      address: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pincode: ['', Validators.required],
      country: ['', Validators.required],
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: ['', [Validators.pattern(/^[1-9]\d*$/)]],
      // aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      patientclinicidentifier: ['', Validators.required],
      aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(12), Validators.maxLength(12)]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      // password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],

    });

    this.createfamiltype = this._formBuilder.group({
      relationtype: ['', [Validators.required]],
    });

    this.createTreatmentForm = this._formBuilder.group({
      amount: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noofvisits: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      treatment: ['', [Validators.required]],
      appointmentTreatment: ['']
    });

    this._DoctorService.medihistory(this.userId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError && res.responseMessage != null) {
          this.loading = false;
          this.Medihistory_array = res?.responseMessage;
          this.ppId = res?.responseMessage?.patientProfileId;
          this.patoffid = res?.responseMessage?.userId
          this.familymemberlist();
          // if(this.Medihistory_array?.isFamilyMember == false){
          // }else{
          //   this.familymemberlistall();
          // }
          // console.log(this.Medihistory_array?.userId)
          // this._DoctorService.familylist(this.Medihistory_array?.userId)
          // .pipe(first())
          // .subscribe((res: any) => {
          //   if (!res.isError) {
          //     console.log(res)
          //   }
          // })

          if (res?.responseMessage.patientProfile != null) {
            this.profileImage = res.responseMessage.patientProfile;
          } else {
            this.profileImage = "./assets/images/noimage.webp";
          }
        } else {
          this.profileImage = "./assets/images/noimage.webp";

          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });

    this._DoctorService.Isaddfamliy = false;
    setTimeout(() => {
      this.list('Today');
    }, 2000);

    this._DoctorService.getcountry()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.count = res.responseMessage;
        } else {
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  viewFamilymemberdetail(item) {
    // this.router.navigate(['/thealth/clinicadmin/transaction/']); 
    this.router.navigate(['/thealth/clinicadmin/patients/view/', item?.patientProfile?.patientProfileId]);
    setTimeout(() => {
      this.ngOnInit();
    }, 2000);
  }
  listfamily: any = [];
  familymemberlist() {
    this.familymembersearch = ""
    this.familymemberfilterData = false;
    if (this.Medihistory_array?.isFamilyMember == false) {
      this.getfammemMASTER(this.Medihistory_array?.userId);
    } else {
      this.getfammem(this.Medihistory_array?.masterId, this.Medihistory_array?.patientGuid);
    }
  }
  getfammemMASTER(id) {
    this._DoctorService.clinicadminfamilylistMASTER(id)
      // this._DoctorService.familylist(this.masteruser_id)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          // alert("aaaa")
          console.log(res)
          this.listfamily = res.responseMessage;
          // this.patientlist = res?.responseMessage;
          this.familymemberdataSource = new MatTableDataSource<any>(res?.responseMessage);
          this.familymemberdataSource.paginator = this.familymemberpaginator;

          this.obsFamilymember = this.familymemberdataSource.connect();
          console.log(this.obsFamilymember)
          if (this.familymemberdataSource?.data?.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
        } else {
          // alert("bbbbbbbbb")
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          // alert("cccccccc")
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  getfammem(id, patientguid) {
    this._DoctorService.clinicadminfamilylist(id, patientguid)
      // this._DoctorService.familylist(this.masteruser_id)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          // alert("111111")
          console.log(res)
          this.listfamily = res.responseMessage;
          // this.patientlist = res?.responseMessage;
          this.familymemberdataSource = new MatTableDataSource<any>(res?.responseMessage);
          this.familymemberdataSource.paginator = this.familymemberpaginator;

          this.obsFamilymember = this.familymemberdataSource.connect();
          console.log(this.obsFamilymember)
          if (this.familymemberdataSource?.data?.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
        } else {
          // alert("222222222")
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          // alert("3333333333333")
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  familymemberfilterData: boolean = false;
  applyFilterfamilymember(filterValue) {
    console.log(filterValue)
    console.log(this.familymemberdataSource.filter)
    console.log(this.familymemberdataSource)
    this.familymemberdataSource.filter = filterValue;

    let filteredArray = this.listfamily.filter(data => {
      // console.log(data)
      // if (filterValue.endsWith("+") || filterValue.endsWith("-")) {
      //   filterValue = filterValue.toUpperCase();
      // }
      // if (data.patientOfficialId == filterValue.trim()) {
      //   return true;
      // } else if (data.bloodGroup.startsWith(filterValue.trim())) {
      // return true;
      if (data.firstName.toLowerCase().trim().startsWith(filterValue.toLowerCase().trim())) {
        return true;
      }
      else if (data.lastName.toLowerCase().trim().startsWith(filterValue.toLowerCase().trim())) {
        return true;
      } else if (data.relation.toLowerCase().trim().startsWith(filterValue.toLowerCase().trim())) {
        return true;
      }
      else {
        return false;
      }
    })
    this.familymemberdataSource = new MatTableDataSource<any>(filteredArray);
    this.familymemberdataSource.paginator = this.familymemberpaginator;
    this.obsFamilymember = this.familymemberdataSource.connect();
    if (this.familymemberdataSource.filteredData.length === 0) {
      this.familymemberfilterData = true;
    } else {
      this.familymemberfilterData = false;
      setTimeout(() => this.familymemberdataSource.paginator = this.familymemberpaginator);
    }
    if (this.familymemberdataSource.paginator) {
      this.familymemberdataSource.paginator.firstPage();
    }
  }
  applyFilterToday() {
    // this.appointmentTodaydataSource.filter = filterValuetoday.trim().toLowerCase();
    // if (this.appointmentTodaydataSource.filteredData.length === 0) {
    //   this.listdata = true;
    // }
    // else {
    //   this.listdata = false;
    // }


    const filterValue = this.searchinputToday;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    this.Fsearchstring = searchstring;
    if (searchstring != "") {
      this.loading = true;
      this._DoctorService.appointmentadminlistsearch('Today', this.ppId, 0, 5, searchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            let array = [];
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            console.log(this.appointmentTodaydataSource)
            this.appointmentTodaydataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
            if (this.appointmentTodaydataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
            setTimeout(() => {
              this.totalSize = res?.responseMessage?.pagination?.total;
              this.appointmentTodaypaginator.pageIndex = 0
              this.appointmentTodaypaginator.pageSize = 0
              // this.dataSource.paginator = this.stockinlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
            });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    } else {
      this.clearfilter()
    }
    // this.searchinput= "5726"


  }
  applyFilterUpcoming() {
    // this.appointmentUpcomingdataSource.filter = filterValueupcoming.trim().toLowerCase();
    // if (this.appointmentUpcomingdataSource.filteredData.length === 0) {
    //   this.listdata = true;
    // }
    // else {
    //   this.listdata = false;
    // }

    const filterValue = this.searchinputUpcoming;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    this.Fsearchstring = searchstring;
    if (searchstring != "") {
      this.loading = true;
      this._DoctorService.appointmentadminlistsearch('Upcoming', this.ppId, 0, 5, searchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            let array = [];
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            console.log(this.appointmentUpcomingdataSource)
            this.appointmentUpcomingdataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
            if (this.appointmentUpcomingdataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
            setTimeout(() => {
              this.totalSize = res?.responseMessage?.pagination?.total;
              this.appointmentUpcomingpaginator.pageIndex = 0
              this.appointmentUpcomingpaginator.pageSize = 0
              // this.dataSource.paginator = this.stockinlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
            });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    }
    else {
      this.clearfilter()
    }
    // this.searchinput= "5726"

  }
  applyFilterPast() {
    // this.appointmentPastdataSource.filter = filterValuepast.trim().toLowerCase();
    // if (this.appointmentPastdataSource.filteredData.length === 0) {
    //   this.listdata = true;
    // }
    // else {
    //   this.listdata = false;
    // }

    const filterValue = this.searchinputPast;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    this.Fsearchstring = searchstring;
    if (searchstring != "") {
      this.loading = true;
      this._DoctorService.appointmentadminlistsearch('Past', this.ppId, 0, 5, searchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            let array = [];
            this.loading = false;

            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            console.log(this.appointmentPastdataSource)
            this.appointmentPastdataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
            if (this.appointmentPastdataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
            setTimeout(() => {
              this.totalSize = res?.responseMessage?.pagination?.total;
              this.appointmentPastpaginator.pageIndex = 0;
              this.appointmentPastpaginator.pageSize = 0;
              // this.dataSource.paginator = this.stockinlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
            });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    } else {
      this.clearfilter()
    }
    console.log(this.state);

    // this.searchinput= "5726"

  }
  applyFilterCancel() {
    // this.appointmentCancelleddataSource.filter = filterValuecancel.trim().toLowerCase();
    // if (this.appointmentCancelleddataSource.filteredData.length === 0) {
    //   this.listdata = true;
    // }
    // else {
    //   this.listdata = false;
    // }

    const filterValue = this.searchinputCancel;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    this.Fsearchstring = searchstring;
    if (searchstring != "") {
      this.loading = true;
      this._DoctorService.appointmentadminlistsearch('Cancelled', this.ppId, 0, 5, searchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            let array = [];
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            console.log(this.appointmentCancelleddataSource)
            this.appointmentCancelleddataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
            if (this.appointmentCancelleddataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
            setTimeout(() => {
              this.totalSize = res?.responseMessage?.pagination?.total;
              this.appointmentCancelledpaginator.pageIndex = 0
              this.appointmentCancelledpaginator.pageSize = 0
              // this.dataSource.paginator = this.stockinlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
            });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    } else {
      this.clearfilter()
    }
    // this.searchinput= "5726"

  }

  clinicadminTreament(selectedData) {
    const dialogRef = this.dialog.open(ClinicadminTreatmentComponent, {
      width: '70%',
      data: selectedData

    });
    dialogRef.afterClosed().subscribe(result => {

    });
  }
  SelecttabClick(event) {
    console.log(event)
    this._DoctorService.Isaddfamliy = false;
    if (event.tab.textLabel == "Appointment Details") {
      // this.list('Today');
    }
  }
  openaddfamily() {
    this._DoctorService.Isaddfamliy = true;
  }
  list(tabname) {
    // debugger;
    this.listdata = false;
    this.Fsearchstring = "";
    this.searchinputToday = "";
    this.searchinputUpcoming = "";
    this.searchinputPast = "";
    this.searchinputCancel = "";
    // this.state = (tabname.tab.textLabel).toLowerCase();
    // console.log(tabname.index);
    if (tabname == "Today" || tabname.tab.textLabel == "Today") {
      this.state = 'today';
    }
    else if (tabname.tab.textLabel == "Upcoming") {
      this.state = 'upcoming';
    }
    else if (tabname.tab.textLabel == "Past") {
      this.state = 'past';
    }
    else {
      this.state = 'cancelled';
    }
    console.log(this.state);
    if (this.state === 'upcoming') {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentadminlist('Upcoming', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentUpcomingdataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.appointmentUpcomingdataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentUpcomingpaginator) {
                this.appointmentUpcomingpaginator.pageIndex = 0;
              }
            }
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.state === 'today') {
      let array = [];
      this.loading = true;
      this._DoctorService.appointmentadminlist('Today', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentTodaydataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.appointmentTodaydataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentTodaypaginator) {
                this.appointmentTodaypaginator.pageIndex = 0;
              }
            }
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.state === 'past') {
      let array = [];
      this.loading = true;
      this._DoctorService.appointmentadminlist('Past', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentPastdataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.appointmentPastdataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentPastpaginator) {
                this.appointmentPastpaginator.pageIndex = 0;
              }
            }
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentadminlist('Cancelled', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res?.responseMessage?.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentCancelleddataSource = new MatTableDataSource(array);
            if (this.appointmentCancelleddataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentCancelledpaginator) {
                this.appointmentCancelledpaginator.pageIndex = 0;
              }
            }
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
  }
  public calculateAge(birthdate: any): number {
    if (birthdate == null) {
      return 0;
    }
    return moment().diff(birthdate, 'years');
  }

  getNext(event: PageEvent) {
    // this.loading = true;
    console.log(event, this.state)
    this.getpendingstate = this.state;
    if (this.state === 'upcoming') {
      if (this.Fsearchstring == undefined || this.Fsearchstring == "") {
        let array = [];
        this._DoctorService.appointmentadminlist(this.state, this.ppId, event.pageIndex, event.pageSize)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              console.log(res)
              this.totalSize = res?.responseMessage?.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentUpcomingdataSource = new MatTableDataSource(array);
              if (this.appointmentUpcomingdataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }

            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.errormessagebox = true;
              this.messagecontent = res.errorMessage;
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      }
      else {
        this.loading = true;
        this._DoctorService.appointmentadminlistsearch('Upcoming', this.ppId, event.pageIndex, event.pageSize, this.Fsearchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              console.log(res)
              let array = [];
              this.loading = false;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              console.log(this.appointmentUpcomingdataSource)
              this.appointmentUpcomingdataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
              if (this.appointmentUpcomingdataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }
              setTimeout(() => {
                this.totalSize = res?.responseMessage?.pagination?.total;
                // this.dataSource.paginator = this.stockinlistpaginator
                //  this.totalSize = res?.responseMessage?.pagination?.total
              });
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.loading = false;
            });
      }
    }
    else if (this.state === 'today') {
      if (this.Fsearchstring == undefined || this.Fsearchstring == "") {
        this.loading = true;
        let array = []
        this._DoctorService.appointmentadminlist(this.state, this.ppId, event.pageIndex, event.pageSize)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              console.log(res)
              this.totalSize = res?.responseMessage?.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentTodaydataSource = new MatTableDataSource(array);
              if (this.appointmentTodaydataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }

            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.errormessagebox = true;
              this.messagecontent = res.errorMessage;
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      }
      else {
        this.loading = true;
        this._DoctorService.appointmentadminlistsearch('Today', this.ppId, event.pageIndex, event.pageSize, this.Fsearchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              console.log(res)
              let array = [];
              this.loading = false;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              console.log(this.appointmentTodaydataSource)
              this.appointmentTodaydataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
              if (this.appointmentTodaydataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }
              setTimeout(() => {
                this.totalSize = res?.responseMessage?.pagination?.total;
                // this.dataSource.paginator = this.stockinlistpaginator
                //  this.totalSize = res?.responseMessage?.pagination?.total
              });
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.loading = false;
            });
      }
    }

    else if (this.state === 'past') {
      console.log("rtr", this.Fsearchstring)
      if (this.Fsearchstring == undefined || this.Fsearchstring == "") {
        console.log("rtr")
        this.loading = true;
        let array = [];
        this._DoctorService.appointmentadminlist(this.state, this.ppId, event.pageIndex, event.pageSize)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              console.log(res)
              this.totalSize = res?.responseMessage?.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentPastdataSource = new MatTableDataSource(array);
              if (this.appointmentPastdataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.errormessagebox = true;
              this.messagecontent = res.errorMessage;
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else if (this.Fsearchstring) {
        this.loading = true;
        console.log("rtr")
        this._DoctorService.appointmentadminlistsearch('Past', this.ppId, event.pageIndex, event.pageSize, this.Fsearchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              console.log(res)
              let array = [];
              this.loading = false;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              console.log(this.appointmentPastdataSource)
              this.appointmentPastdataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
              if (this.appointmentPastdataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }
              setTimeout(() => {
                this.totalSize = res?.responseMessage?.pagination?.total;
                // this.dataSource.paginator = this.stockinlistpaginator
                //  this.totalSize = res?.responseMessage?.pagination?.total
              });
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.loading = false;
            });
      }

    }
    else {
      if (this.Fsearchstring == undefined || this.Fsearchstring == "") {
        this.loading = true;
        let array = [];
        this._DoctorService.appointmentadminlist(this.state, this.ppId, event.pageIndex, event.pageSize)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              console.log(res)
              this.totalSize = res?.responseMessage?.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentCancelleddataSource = new MatTableDataSource(array);
              if (this.appointmentCancelleddataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }

            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.errormessagebox = true;
              this.messagecontent = res.errorMessage;
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      }
      else {
        this.loading = true;
        this._DoctorService.appointmentadminlistsearch('Cancelled', this.ppId, event.pageIndex, event.pageSize, this.Fsearchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              console.log(res)
              let array = [];
              this.loading = false;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              console.log(this.appointmentCancelleddataSource)
              this.appointmentCancelleddataSource = new MatTableDataSource(res?.responseMessage?.appointmentList);
              if (this.appointmentCancelleddataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }
              setTimeout(() => {
                this.totalSize = res?.responseMessage?.pagination?.total;
                // this.dataSource.paginator = this.stockinlistpaginator
                //  this.totalSize = res?.responseMessage?.pagination?.total
              });
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.loading = false;
            });
      }

    }
  }

  booksideopen() {
    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: ['', [Validators.pattern(/^[1-9]\d*$/)]],
      // aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      patientclinicidentifier: ['', Validators.required],
      aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(12), Validators.maxLength(12)]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      // password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
      address: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pincode: ['', Validators.required],
      country: ['', Validators.required],
    });
  }

  booksideclose() {
    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: ['', [Validators.pattern(/^[1-9]\d*$/)]],
      // aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      patientclinicidentifier: ['', Validators.required],
      aadharno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(12), Validators.maxLength(12)]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      // password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
      address: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pincode: ['', Validators.required],
      country: ['', Validators.required],
    });
  }

  onFocusOutEvent(event: any) {
    if (event.target.value == '') {
      // alert('empty');
      console.log(event.target.value);
    }
    else {
      console.log(event.target.value)
      this.loading = true;
      this.dataSource2 = new MatTableDataSource([]);
      console.log(event.target.value);
      this.authenticationService.patdetailsbymobno(event.target.value)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          console.log(res)
          if (!res.isError) {
            if (res.responseMessage == null) {
              console.log(res.responseMessage)
              this.familytype = false;
              this.alreadymemb = false
              this.regbtn = true;
            }
            else {
              this.resp = res.responseMessage;
              console.log(this.resp.mobile, this.createpatProfile?.value.phoneno);
              if (this.resp.mobile == this.createpatProfile?.value.phoneno) {
                this.familytype = true;
                this.regbtn = false;
                this.patid = this.resp.patientId;
                setTimeout(() => {
                  document.getElementById("checkscroll").scrollIntoView({ behavior: 'smooth', block: "end" });
                })
                this.dataSource2 = new MatTableDataSource(res.responseMessage.patientFamilyMemberDetails);
                setTimeout(() => {
                  this.dataSource2.paginator = this.uploadResultPaginator;
                });
                if (res.responseMessage.patientFamilyMemberDetails === null || res.responseMessage.patientFamilyMemberDetails.length === 0) {
                  this.alreadymemb = false;
                }
                else {
                  this.alreadymemb = true;
                }
              }
            }


            // if (this.resp.mobile == this.createpatProfile?.value.phoneno) {
            //   this.addmember = true;
            //   this.regbtn = false;
            //   this.dataSource2 = new MatTableDataSource(res.responseMessage.patientFamilyMemberDetails);
            //   console.log(this.dataSource2);

            //   if (this.dataSource2.data === null || this.dataSource2.data.length === 0) {
            //     this.listdata = true;
            //   }
            //   else {
            //     this.listdata = false;
            //   }
            // }
            // else {
            //   this.addmember = false;
            //   this.regbtn = true;
            // }
            this.loading = false;
          } else {
            this.loading = false;
            this.familytype = false;
            this.alreadymemb = false
            this.regbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.responseData, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  patfamtype() {
    console.log(this.createpatProfile?.value.firstname)
    console.log(this.createpatProfile?.value.lastname)
    console.log(this.createfamiltype?.value.relationtype)
    console.log(this.patid)

    this.loading = true;
    if (this.createpatProfile?.value.firstname == '' || this.createpatProfile?.value.firstname == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill First name', options);
      this.loading = false;
      return;
    }
    if (this.createfamiltype?.value.relationtype == '' || this.createfamiltype?.value.relationtype == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill Relation Type', options);
      this.loading = false;
      return;
    }
    else {
      this.loading = true;
      let payload = {
        "FirstName": this.createpatProfile?.value.firstname,
        "LastName": this.createpatProfile?.value.lastname,
        "RelationType": this.createfamiltype?.value.relationtype,
        "Profile": null,
        "PatientId": this.patid,
        "GenderName": this.createpatProfile?.value.gender,
        "Age": this.createpatProfile?.value.age,
        "Aadhaarnumber": this.createpatProfile?.value.aadharno
      }
      const roleid = 3;
      this._DoctorService.famtype(payload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.alreadymemberslist(payload.PatientId);
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.sidenav.close();
            // this.mypatientlist();
            this.ngOnInit()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            for (var prop in err.error) {
              this.toastrService.warning('', err?.error[prop], options);
            }
          })
    }
  }

  alreadymemberslist(pid) {
    this.loading = true;
    this.dataSource2 = new MatTableDataSource([]);
    this.loading = true;
    this._DoctorService.alreadymemlist(pid)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          // alert("xxxxxxxxxx")
          this.loading = false;
          this.dataSource2 = new MatTableDataSource(res.responseMessage);
          setTimeout(() => {
            this.dataSource2.paginator = this.uploadResultPaginator;
          });
          if (res.responseMessage === null || res.responseMessage.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
          this.loading = false;
        }
        else {
          // alert("yyyyyyyyyyyyyyyy")
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          // alert("zzzzzzzzzzzzzz")
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  opensidenav() {
    this.loading = true;
    this.CreateTreatmentsection = false;
    this.CreatePatientsection = true;
    this.sidenav.open()
    console.log(this.userId)
    // alert(this.userId)
    setTimeout(() => {

      this._DoctorService.medihistory(this.userId)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          console.log(res)
          if (!res.isError && res.responseMessage != null) {
            this.loading = false;
            console.log(res?.responseMessage)
            this.Medihistory_array2 = res?.responseMessage;
            // this.parenteditaddress = this.Medihistory_array2?.isFamilyMember
            console.log("boolean------------", this.Medihistory_array2?.isFamilyMember);
            console.log("clinicPatientId------------", this.Medihistory_array2?.clinicPatientId);

            // this.parenteditaddress = this.Medihistory_array2?.isFamilyMember
            // this.parenteditaddress = false
            if (this.Medihistory_array2?.isFamilyMember == false) {
              console.log("logfalse");

              this.editmobile = true
            } else {
              console.log("logtrue");

              this.editmobile = false

            }
            this.createpatProfile.get('firstname').setValue(this.Medihistory_array2?.firstName);
            this.createpatProfile.get('lastname').setValue(this.Medihistory_array2?.lastName);
            if (this.Medihistory_array2?.gender != null) {
              this.createpatProfile.get('gender').setValue(this.Medihistory_array2?.gender);
            }
            if (this.Medihistory_array2?.age != 0) {
              this.createpatProfile.get('age').setValue(this.Medihistory_array2?.age);
            }
            this.createpatProfile.get('aadharno').setValue(this.Medihistory_array2?.aadhaarnumber);
            this.createpatProfile.get('phoneno').setValue(this.Medihistory_array2?.mobileNumber);
            if (this.Medihistory_array2?.email != null) {
              this.createpatProfile.get('email').setValue(this.Medihistory_array2?.email);
            }
            if (this.Medihistory_array2?.address != null) {
              this.createpatProfile.get('address').setValue(this.Medihistory_array2?.address);
            }
            if (this.Medihistory_array2?.street != null) {
              this.createpatProfile.get('street').setValue(this.Medihistory_array2?.street);
            }
            if (this.Medihistory_array2?.city != null) {
              this.createpatProfile.get('city').setValue(this.Medihistory_array2?.city);
            }
            if (this.Medihistory_array2?.state != null) {
              this.createpatProfile.get('state').setValue(this.Medihistory_array2?.state);
            }
            if (this.Medihistory_array2?.pincode != null) {
              this.createpatProfile.get('pincode').setValue(this.Medihistory_array2?.pincode);
            }
            if (this.Medihistory_array2?.clinicPatientId != null) {
              console.log("jijijijiji");

              this.createpatProfile.get('patientclinicidentifier').setValue(this.Medihistory_array2?.clinicPatientId);
            }
            // if (this.Medihistory_array2?.clinicPatientId != null) {
            //   this.countrymodel == this.Medihistory_array2?.countryid
            //   this.createpatProfile.get('country').setValue(this.Medihistory_array2?.country);
            // }
            if (this.Medihistory_array2?.country == null) {
              this.createpatProfile.get('country').setValue('');
            } else {
              this.createpatProfile.get('country').setValue(this.Medihistory_array2?.countryid);
            }
            // address: ['', Validators.required],
            // street: ['', Validators.required],
            // city: ['', Validators.required],
            // state: ['', Validators.required],
            // pincode: ['', Validators.required],
            // country: ['', Validators.required],
            if (res?.responseMessage?.isFamilyMember == true) {
              // alert("56565")
              this.isReadOnlyphone = true;
              this.isReadOnlyemail = true;
            }
            if (res?.responseMessage?.isFamilyMember == false) {
              // alert("00000000")
              this.isReadOnlyphone = false;
              this.isReadOnlyemail = false;
            }


          } else {

            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    }, 1000);

  }

  patregister(formDirective: FormGroupDirective) {
    console.log(this.createpatProfile?.value)

    // if (this.createpatProfile?.value.firstname.trim() == '' || this.createpatProfile?.value.firstname.trim() == null ||
    //   this.createpatProfile?.value.phoneno.trim() == '' || this.createpatProfile?.value.phoneno.trim() == null ||
    //   this.createpatProfile?.value.password.trim() == '' || this.createpatProfile?.value.password.trim() == null) {

    if (this.createpatProfile?.value.firstname.trim() == '' || this.createpatProfile?.value.firstname.trim() == null ||
      this.createpatProfile?.value.phoneno.trim() == '' || this.createpatProfile?.value.phoneno.trim() == null ||
      this.createpatProfile?.value.patientclinicidentifier.trim() == ''
      || this.createpatProfile?.value.patientclinicidentifier.trim() == "") {

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
      return;
    }

    if (this.createpatProfile.value.aadharno != null && this.createpatProfile.value.aadharno.length != 0 && this.createpatProfile.value.aadharno.length != 12) {

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill valid aadhar number', options);
      this.loading = false;
      return;
    }
    // if (!this.createpatProfile?.controls?.aadharno?.errors?.pattern) {

    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', 'Please fill valid aadhar number', options);
    //   this.loading = false;
    //   return;
    // }
    else {

      // if (this.createpatProfile?.value?.email && this.createpatProfile?.value?.email != "") {
      //   // alert("1111111")
      //   this.loading = true;
      //   const roleid = 3;
      //   this.authenticationService.register(this.createpatProfile.value, roleid)
      //     .pipe(first())
      //     .subscribe((res: any) => {
      //       console.log(res);
      //       if (!res.isError) {
      //         this.mypatientlist()
      //         this.loading = false;
      //         setTimeout(() => this.formGroupDirective.resetForm(), 0);
      //         this.createpatProfile.reset();
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.success('', res.responseMessage, options);
      //         this.sidenav.close();
      //       }
      //       else {
      //         // alert("UYUYU")
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', res.errorMessage, options);
      //       }
      //     },
      //       err => {
      //         console.log(err)
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', err?.error, options);
      //       })

      // }
      // else {
      this.loading = true;
      const roleid = 3;
      let payload = {
        "FirstName": this.createpatProfile.value.firstname,
        "LastName": this.createpatProfile.value.lastname,
        "MobileNo": this.createpatProfile.value.phoneno,
        "Gender": this.createpatProfile.value.gender,
        "Email": this.createpatProfile.value.email,
        "ClinicPatientId": this.createpatProfile.value.patientclinicidentifier,
        "age": this.createpatProfile.value.age,
        "Aadhaarnumber": this.createpatProfile.value.aadharno,
        "Address": this.createpatProfile.value.address,
        "City": this.createpatProfile.value.city,
        "countryid": this.createpatProfile.value.country,
        "Pincode": this.createpatProfile.value.pincode,
        "State": this.createpatProfile.value.state,
        "Street": this.createpatProfile.value.street
      }
      console.log(payload)
      this.authenticationService.updatepatientprofile(payload, this.patoffid)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            setTimeout(() => this.formGroupDirective.resetForm(), 0);
            this.createpatProfile.reset();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.sidenav.close();
            this.ngOnInit()
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
      // }
    }
  }

  changedateformat(date) {
    if (date != undefined) {
      return moment(date).format('ll');
    }
  }

  // Create Treatment Planner
  treatmentplan() {
    this.CreateTreatmentsection = true;
    this.CreatePatientsection = false;
    this.getTreatmentsdropdown();
    this.createTreatmentForm.reset();

  }

  getTreatmentsdropdown() {
    this.loading = true;
    this._DoctorService.getTreatmentsDropdown().pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.treatmentsList = res?.responseMessage;
          console.log(this.treatmentsList)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      )
  }
  changetreatment(event) {
    console.log(event.value)
    this.loading = true;
    this._DoctorService.getTreatmentsById(event.value).pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.treatmentData = res?.responseMessage[0];
          console.log(this.treatmentData)
          this.createTreatmentForm.get('noofvisits').setValue(this.treatmentData?.visits)
          this.createTreatmentForm.get('amount').setValue(this.treatmentData?.amount)
          // this.createTreatmentForm.get('noofvisits').setValue(this.treatmentData.visits)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      )
  }

  create_treatment(form, formDirective: FormGroupDirective) {
    console.log(form.value)
    this.loading = true;
    if (form.valid) {
      // if (form.value.appointmentTreatment == true) {
      //   this.treatmentPayload = {
      //     'Noofvisits': form.value.noofvisits,
      //     "Amount": form.value.amount,
      //     "patientid": this.appointmentarray.patientId,
      //     "Trpackageid": form.value.treatment,
      //     "Appointmentid": this.appointmentarray.appointmentId
      //   }
      // } else {
      this.treatmentPayload = {
        'Noofvisits': form.value.noofvisits,
        "Amount": form.value.amount,
        "patientid": this.patoffid,
        "treatmentpackageId": form.value.treatment,
      }
      // }
      // console.log(this.treatmentPayload)
      // this._DoctorService.createTreatmentPlanner(this.treatmentPayload).pipe(first())
      //   .subscribe((res: any) => {
      //     if (!res.isError) {
      //       this.loading = false;
      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //       this.toastrService.success('', res.responseMessage, options);
      //       this.router.navigate(['/thealth/clinicadmin/packagetreatmentlist']);
      //     } else {
      //       this.loading = false;
      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //       this.toastrService.warning('', res.errorMessage, options);
      //     }
      //   },
      //     (err) => {
      //       this.loading = false;
      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //       this.toastrService.warning('', err.error, options);
      //     }
      //   )
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
    }
  }

  clearTreatmentForm() {
    this.createTreatmentForm.reset()
  }
  clearfilter() {
    console.log(this.state);
    //this.appointmentTodaypaginator.pageSize = 0
    // this.appointmentCancelledpaginator.pageSize = 0
    //this.appointmentPastpaginator.pageSize = 0
    // this.appointmentUpcomingpaginator.pageSize = 0
    // this.list('Past');
    this.Fsearchstring = "";
    this.searchinputToday = "";
    this.searchinputUpcoming = "";
    this.searchinputPast = "";
    this.searchinputCancel = "";
    console.log(this.Fsearchstring);
    // if( this.state = 'today'){
    //   this.list('Today');
    // }
    // else if( this.state = 'upcoming'){
    //   this.list('Upcoming');
    // }
    // else if( this.state = 'past'){
    //   this.list('Past');
    // }
    // else if( this.state = 'cancelled'){
    //   this.list('Cancelled');
    // }
    if (this.state === 'upcoming') {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentadminlist('Upcoming', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentUpcomingdataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.appointmentUpcomingdataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentUpcomingpaginator) {
                this.appointmentUpcomingpaginator.pageIndex = 0;
              }
            }
            setTimeout(() => {
              this.appointmentUpcomingpaginator.pageIndex = 0
              this.appointmentUpcomingpaginator.pageSize = 0
            });
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.state === 'today') {
      let array = [];
      this.loading = true;
      this._DoctorService.appointmentadminlist('Today', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentTodaydataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.appointmentTodaydataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentTodaypaginator) {
                this.appointmentTodaypaginator.pageIndex = 0;
              }
            }
            setTimeout(() => {
              this.appointmentTodaypaginator.pageIndex = 0
              this.appointmentTodaypaginator.pageSize = 0
            });
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.state === 'past') {
      let array = [];
      this.loading = true;
      this._DoctorService.appointmentadminlist('Past', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentPastdataSource = new MatTableDataSource(array);
            this.totalSize = res?.responseMessage?.pagination.total;
            if (this.appointmentPastdataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentPastpaginator) {
                this.appointmentPastpaginator.pageIndex = 0;
              }
            }
            setTimeout(() => {
              this.appointmentPastpaginator.pageIndex = 0
              this.appointmentPastpaginator.pageSize = 0
            });
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentadminlist('Cancelled', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res?.responseMessage?.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentCancelleddataSource = new MatTableDataSource(array);
            if (this.appointmentCancelleddataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
              if (this.appointmentCancelledpaginator) {
                this.appointmentCancelledpaginator.pageIndex = 0;
              }
            }
            setTimeout(() => {
              this.appointmentCancelledpaginator.pageIndex = 0
              this.appointmentCancelledpaginator.pageSize = 0
            });
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
  }
}

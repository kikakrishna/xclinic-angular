import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminPatientviewComponent } from './clinicadmin-patientview.component';

describe('ClinicadminPatientviewComponent', () => {
  let component: ClinicadminPatientviewComponent;
  let fixture: ComponentFixture<ClinicadminPatientviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminPatientviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminPatientviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { RouterModule } from '@angular/router';
import { ClinicadminPatientviewComponent } from './clinicadmin-patientview.component';
export const ClinicadminPatientviewRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminPatientviewComponent,
    }
]
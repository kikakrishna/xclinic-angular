import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { BehaviorSubject } from 'rxjs';
import { first } from 'rxjs/operators';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';

@Component({
  selector: 'app-clinicadmin-createdoctor',
  templateUrl: './clinicadmin-createdoctor.component.html',
  styleUrls: ['./clinicadmin-createdoctor.component.css']
})
export class ClinicadminCreatedoctorComponent implements OnInit {
  public hide: boolean = true;
  doctorRegister: FormGroup;
  loading: boolean;
  validatemyemail: boolean;
  selectedInput: BehaviorSubject<number> = new BehaviorSubject<number>(1);
  public spcl: any = [];
  submitted: any;
  
  sessioncurrency: string;
  minlen: any = 1;
  maxlen: any = 1;
  Isonline: boolean = false;
  Isoffline: boolean = false;
  consultationtypetoppings = new FormControl();
  consultationtypearray: any = []
  salu: any =[]
  constructor(private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private router: Router,
    private route: ActivatedRoute,
    public toastrService: ToastService,
    private _patientservice: PatientService,
    private _DoctorService: DoctorService,
    private dialogRef: MatDialogRef<ClinicadminCreatedoctorComponent>,
    @Inject(MAT_DIALOG_DATA) public dataval: any) {
    console.log(this.dataval)
    this.minlen = sessionStorage.getItem("minlen");
    this.maxlen = sessionStorage.getItem("maxlen");
    console.log(this.minlen, this.maxlen)
  }

  ngOnInit(): void {
    this.Isonline = false;
    this.Isoffline = false;
    this.sessioncurrency = this.dataval?.currencyDetails?.currencySymbol
    this.doctorRegister = this.formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$')]],
      speciality: ['', Validators.required],
      salutation: ['', Validators.required],
      domesticfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      overseasfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // domesticfollowfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // overseasfollowfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      // clinicvisitconsultationfee: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // clinicvisitfollowupfee: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      consultationtype: ['', Validators.required]
    });


    this._patientservice.getspecial()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.spcl = res.responseMessage;
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    this._DoctorService.getappoinmenttype()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.consultationtypearray = res.responseMessage;
          // this.consultationtypetoppings.setValue([res.responseMessage[0].consultationTypeId]);
          // this.changeconsultation();
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
        this._DoctorService.getsalutation()
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            this.salu = res.responseMessage;
            // this.consultationtypetoppings.setValue([res.responseMessage[0].consultationTypeId]);
            // this.changeconsultation();
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
  }
  reset() {
    this.doctorRegister.reset();
    this.consultationtypetoppings.reset();
  }

  save(event) {
    const regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (regularExpression.test(String(event.target.value).toLowerCase())) {
      this.validatemyemail = true
    }
    else {
      this.validatemyemail = false;
    }
  }
  changeconsultation() {
    let array = [];
    this.consultationtypetoppings.value.forEach(element => {
      this.consultationtypearray.filter(x => {
        if (x.appointmentTypeId == element) {
          array.push(x)
        }
      })
    });
    // console.log(array)

    // if (array.length == 0) {
    //   this.Isonline = false;
    //   this.Isoffline = false;
    // }
    // if (array.length == 2) {
    //   this.Isonline = true;
    //   this.Isoffline = true;
    // } else {
    //   array.forEach(type => {    //   console.log(type)

    //     if (type.appointmentTypeName === "Clinic Visit") {
    //       this.Isonline = false;
    //       this.Isoffline = true;
    //       // this.doctorRegister.get('domesticfollowfees').setValue("");
    //       // this.doctorRegister.get('domesticfees').setValue("");
    //     }
    //     if (type.appointmentTypeName === "Online Consultation") {
    //       this.Isonline = true;
    //       this.Isoffline = false;
    //       // this.doctorRegister.get('clinicvisitconsultationfee').setValue("");
    //       // this.doctorRegister.get('clinicvisitfollowupfee').setValue("");
    //     }
    //   });
    // }
  }
  docSubmit() {
    if (this.consultationtypetoppings?.value?.length == 0 || this.consultationtypetoppings?.value == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select consultation type', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);

      return;
    }

    if (this.validatemyemail == false) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Invalid Email Address', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);

      return;
    }
    if (this.doctorRegister.value.firstname == "" || this.doctorRegister.value.lastname == "" ||
      this.doctorRegister.value.phoneno == "" || this.doctorRegister.value.password == "" ||this.doctorRegister.value.salutation == "" ||
      this.doctorRegister.value.speciality == "" || this.doctorRegister.value.email == "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Enter all the Mandatory Fields', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);
      return;
    }
    let ctype;
    let ctypename;
    console.log(this.consultationtypetoppings.value.length)
    // if (this.consultationtypetoppings.value.length == 2) {
    //   ctype = 0;
    // } else {
    //   this.consultationtypetoppings.value.forEach(element => {
    //     this.consultationtypearray.filter(x => {
    //       if (x.appointmentTypeId == element) {
    //         console.log(x)
    //         ctype = x.appointmentTypeId;
    //         ctypename = x.appointmentTypeName;
    //       }
    //     })
    //   });
    //   console.log(ctype)
    //   console.log(ctypename)
    //   // if(ctypename === "Online Consultation") {
    //   //   // this.doctorRegister.get('clinicvisitconsultationfee').setValue(null);
    //   //   // this.doctorRegister.get('clinicvisitfollowupfee').setValue(null);          
    //   //     this.doctorRegister.value.clinicvisitconsultationfee = "0"
    //   //     this.doctorRegister.value.clinicvisitfollowupfee = "0"
          
    //   // } else {
    //   //   // this.doctorRegister.get('domesticfollowfees').setValue(null);
    //   //   //   this.doctorRegister.get('domesticfees').setValue(null);
    //   //   this.doctorRegister.value.domesticfollowfees = "0"
    //   //   this.doctorRegister.value.domesticfees = "0"
        
    //   // }
    // }


// return;
    this._patientservice.domaindetail()
      .pipe(first())
      .subscribe((Domainres: any) => {
        if (!Domainres.isError) {
          console.log(Domainres)
          this.loading = true;
          const roleid = 2;

          // if(this.doctorRegister.value.domesticfees == "" && this.doctorRegister.value.domesticfollowfees == ""){
          //   this.doctorRegister.value.domesticfollowfees = null
          //   this.doctorRegister.value.domesticfees = null
          // }
          // if(this.doctorRegister.value.clinicvisitconsultationfee == "" && this.doctorRegister.value.clinicvisitfollowupfee == ""){
          //   this.doctorRegister.value.clinicvisitconsultationfee = null
          //   this.doctorRegister.value.clinicvisitfollowupfee = null
          // }

          let payload: any = {
            "Email": this.doctorRegister.value.email,
            "MobileNumber": this.doctorRegister.value.phoneno,
            "salutationId": this.doctorRegister.value.salutation,
            "FirstName": this.doctorRegister.value.firstname,
            "LastName": this.doctorRegister.value.lastname,
            "Password": this.doctorRegister.value.password,
            "RoleId": roleid,
            "ClinicId": Domainres.responseMessage.clinicId,
            "SpecalityId": this.doctorRegister.value.speciality,
            "ConsultationType": this.consultationtypetoppings.value,
            // "ConsultationType": ctype,
            // "Fees": {
            //   "DomesticConsultationFee": this.doctorRegister.value.domesticfees,
            //   "DomesticFollowUpFee": this.doctorRegister.value.domesticfollowfees,
            //   "OverseasConsultationFee": this.doctorRegister.value.domesticfees,
            //   "OverseasFollowUpFee": this.doctorRegister.value.domesticfollowfees,
            //   "ClinicVisitConsultation": this.doctorRegister.value.clinicvisitconsultationfee,
            //   "ClinicVisitFollowUp": this.doctorRegister.value.clinicvisitfollowupfee
            // }
          }
          console.log(payload)
          // return;
          this.authenticationService.register2(payload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                this.dialogRef.close({ data: res });
                this.doctorRegister.reset();
              }
              else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
        }
      });
    return;
  }
  validateAllFormFields(formGroup: FormGroup) {         //{1}  
    Object.keys(formGroup.controls).forEach(field => {  //{2}
      console.log(field)
      const control = formGroup.get(field);             //{3}
      if (control instanceof FormControl) {             //{4}
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {        //{5}
        this.validateAllFormFields(control);            //{6}
      }
    });
  }
}

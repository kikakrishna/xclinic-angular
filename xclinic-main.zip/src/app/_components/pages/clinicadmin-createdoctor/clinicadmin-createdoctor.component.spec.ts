import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminCreatedoctorComponent } from './clinicadmin-createdoctor.component';

describe('ClinicadminCreatedoctorComponent', () => {
  let component: ClinicadminCreatedoctorComponent;
  let fixture: ComponentFixture<ClinicadminCreatedoctorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminCreatedoctorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminCreatedoctorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

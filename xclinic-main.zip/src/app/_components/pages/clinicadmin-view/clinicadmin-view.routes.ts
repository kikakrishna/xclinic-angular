import { RouterModule } from '@angular/router';
import { ClinicadminViewComponent } from './clinicadmin-view.component';
export const ClinicAdminVieweRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminViewComponent,
    }
]
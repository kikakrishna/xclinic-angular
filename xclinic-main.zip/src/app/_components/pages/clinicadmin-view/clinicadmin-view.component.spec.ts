import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminViewComponent } from './clinicadmin-view.component';

describe('ClinicadminViewComponent', () => {
  let component: ClinicadminViewComponent;
  let fixture: ComponentFixture<ClinicadminViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

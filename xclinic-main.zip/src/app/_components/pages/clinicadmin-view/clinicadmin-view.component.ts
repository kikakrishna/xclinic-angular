import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';

@Component({
  selector: 'app-clinicadmin-view',
  templateUrl: './clinicadmin-view.component.html',
  styleUrls: ['./clinicadmin-view.component.css']
})
export class ClinicadminViewComponent implements OnInit {
  displayedColumns: string[] = ['clinicname', 'location', 'action'];
  public ClnicArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
 loading:boolean;
  addressmodel: any;
  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    private router: Router) { }

  ngOnInit(): void {
    this.loading = true;
    let array = []
    this._DoctorService.getcliniclist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage[0]?.clinicAddressModel;
          console.log(this.addressmodel)
          for (let item of this.addressmodel) {
            item.clinicId = res?.responseMessage[0]?.clinicId;
            item.clinicName = res?.responseMessage[0]?.clinicName;
            array.push(item);
          }
          console.log(array)
          this.ClnicArraydataSource = new MatTableDataSource(array);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  editclick(ele){
    console.log(ele)
    sessionStorage.setItem('defaultclinicstatus', ele)
    sessionStorage.setItem('eleclinicId', ele.clinicId)
    sessionStorage.setItem('eleloctionId', ele.clinicLocationMapId)
    this.router.navigate([`/thealth/clinicadmin/edit/${ele.clinicId}`], { state: { defaultclinicstatus: ele } });  }
}

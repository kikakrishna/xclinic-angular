import { RouterModule } from '@angular/router';
import { ClinicadminGallerygroupComponent } from './clinicadmin-gallerygroup.component';
export const ClinicadminGallerygroupRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminGallerygroupComponent,
    }
]

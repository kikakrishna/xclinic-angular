import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ToastService } from 'ng-uikit-pro-standard';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';

@Component({
  selector: 'app-clinicadmin-gallerygroup',
  templateUrl: './clinicadmin-gallerygroup.component.html',
  styleUrls: ['./clinicadmin-gallerygroup.component.css']
})
export class ClinicadminGallerygroupComponent implements OnInit {
  displayedColumns: string[] = [ 'gallerygroupname','gallerytype', 'status','action','upload' ];
  dataSource;
  galleryGroupForm: FormGroup;
  loading: boolean = false;
  galleryType: any;
  galleryGroupresult: any;
  gallerylists: any;
  totalSize: number;
  editGalleryId: any;
  disabled: boolean = false;


  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(
    private _formBuilder: FormBuilder,
    private doctorService: DoctorService, private toastrService: ToastService,
    private _patientservice: PatientService
  ) { 
    this.dataSource = new MatTableDataSource;
  }

  ngOnInit(): void {
    this.galleryGroupForm = this._formBuilder.group({
      gallerygroupType: ['',],
      gallerygroupname: [''],
    });
    // Domain details
    // console.log(this._patientservice.Domdetails)
    // this.menu = this._patientservice.Domdetails.responseMessage.clinicUiFeatureMap;
    
    // get gallery group type
    this.getGalleryType();
    this.gelGalleryList();
    this.getPageStatus();
  }
  getGalleryType() {
    this.loading = true;
    this.doctorService.getGallerygroupType()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.galleryType = res?.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  gelGalleryList() {
    this.loading = true;
    this.doctorService.getGallerylists()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.gallerylists = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.gallerylists);
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  submitgalleryGroup() {
    this.loading = true;
    console.log(this.galleryGroupForm.value)
    if(this.galleryGroupForm.value.gallerygroupType != '' && this.galleryGroupForm.value.gallerygroupname != '' &&
    this.galleryGroupForm.value.gallerygroupType != null && this.galleryGroupForm.value.gallerygroupname != null) {
      if(this.editGalleryId == undefined) {
        let payload = {
          'GalleryType' : this.galleryGroupForm.value.gallerygroupType,
          "GalleryGroupName": this.galleryGroupForm.value.gallerygroupname
        }
        this.doctorService.creategalleryGroup(payload)
          .pipe(first())
          .subscribe((res:any) => {
            if (!res.isError) {
              this.gelGalleryList();
              this.reset();
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res?.responseMessage, options);
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
      } else {
        let payload = {
          "GalleryGroupName": this.galleryGroupForm.value.gallerygroupname
        }
        this.doctorService.updategalleryGroup(payload, this.editGalleryId)
          .pipe(first())
          .subscribe((res:any) => {
            if (!res.isError) {
              this.loading = false;
              this.gelGalleryList();
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res?.responseMessage, options);   
              this.editGalleryId = undefined
              this.reset();
              this.disabled = false;
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
      }
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the mandatory fields', options);
    }
  }
  filterGetnext(){

  }
  reset() {
    this.galleryGroupForm.reset();
  }

  editGalleryGroup(id){
    this.loading = true;
    this.doctorService.editGalleryGroup(id)
      .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError){
          this.loading = false;
          this.galleryGroupresult = res?.responseMessage;
          console.log(this.galleryGroupresult)
          this.editGalleryId = id;
          this.disabled = true;
          this.galleryGroupForm.get('gallerygroupType').setValue(this.galleryGroupresult.galleryTypeid);
          this.galleryGroupForm.get('gallerygroupname').setValue(this.galleryGroupresult.galleryGroupName);
        }else{
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
 
  UpdateStausGallery(id, status) {
    let payload = {
      "GalleryGroupid": id,
      "Status": status,
    }
    this.doctorService.updateStatusGallery(id, status, payload)
        .pipe(first())
        .subscribe((res:any) => {
          if (!res.isError) {
            this.loading = false;
            this.gelGalleryList();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res?.responseMessage, options);
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.gelGalleryList();
          }
        },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.gelGalleryList();
        })
  }
  publish: any;
  getPageStatus() {
    this.doctorService.getGalleryPageStatus ()
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {
        this.loading = false;
        this.publish = res?.responseMessage;
        console.log(this.publish)
      } else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  UpdatePageStaus(event, statusId) {
    this.doctorService.updatePublishService(event, statusId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.getPageStatus()
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

}

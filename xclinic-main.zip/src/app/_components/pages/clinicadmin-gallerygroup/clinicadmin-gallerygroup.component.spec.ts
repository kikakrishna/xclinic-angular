import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminGallerygroupComponent } from './clinicadmin-gallerygroup.component';

describe('ClinicadminGallerygroupComponent', () => {
  let component: ClinicadminGallerygroupComponent;
  let fixture: ComponentFixture<ClinicadminGallerygroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminGallerygroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminGallerygroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

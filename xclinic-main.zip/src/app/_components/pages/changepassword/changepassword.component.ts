import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PatientService } from '../../../_services/patient.service';
import { first } from 'rxjs/operators';
import { MatDialogRef } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  secondFormGroup: FormGroup;
  confirmed: boolean;
  confirmpwd: string;
  cpwd: boolean;
  oldpass: boolean;
  oldnewpass: boolean;
  msg:string;
  show:boolean;
  errormsg: any;
  error: boolean;
  role:any;
  constructor(private toastrService: ToastService,private _formBuilder: FormBuilder,private _patientservice: PatientService, private dialogRef: MatDialogRef<ChangepasswordComponent>,) {  
    this.role = sessionStorage.getItem("Role");
    if(this.role == "patient"){
      this.secondFormGroup = this._formBuilder.group({
        oldpassword: ['', [Validators.required,Validators.minLength(4),Validators.pattern('^.{4,}$')]],
        newpassword: ['', [Validators.required,Validators.minLength(4),Validators.pattern('^.{4,}$')]],
        confirmpassword: [null, [Validators.required,Validators.minLength(4),Validators.pattern('^.{4,}$')]]
      });
    }
    if(this.role == "doctor"){
      this.secondFormGroup = this._formBuilder.group({
        oldpassword: ['', [Validators.required,Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]],
        newpassword: [null, [Validators.required,Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]],
        confirmpassword: [null, [Validators.required,Validators.minLength(4),Validators.pattern('^.{4,}$')]]
      });
    } 
    if(this.role == "clinicadmin"){
      this.secondFormGroup = this._formBuilder.group({
        oldpassword: ['', [Validators.required,Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]],
        newpassword: [null, [Validators.required,Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]],
        confirmpassword: [null, [Validators.required,Validators.minLength(4),Validators.pattern('^.{4,}$')]]
      });
    }       
    this.confirmed = false;
    this.cpwd = false;
  }
  ngOnInit(): void {
    this.toastrService.clear();
  }
  npassword(){
    const opwd = this.secondFormGroup.value.oldpassword;
    const cpwd  = this.secondFormGroup.value.confirmpassword;
    if(cpwd  !=null){
      this.confirmed = false;
      const npwd  = this.secondFormGroup.value.newpassword;
      if(cpwd === npwd){
        this.confirmed = false;
        this.cpwd = false;
      }else{
        this.confirmed = true;
        this.cpwd = true;
        if(sessionStorage.getItem("currentLang")=="ar"){
          this.confirmpwd = "يجب أن يتطابق تأكيد كلمة المرور مع كلمة المرور الجديدة";
        }else{
          this.confirmpwd = "Confirm Password should match with New Password";
        }
        
      }
    }
    if(this.secondFormGroup.value.oldpassword != null && this.secondFormGroup.value.newpassword  != null){
      if(this.secondFormGroup.value.oldpassword == this.secondFormGroup.value.newpassword){
        this.show = true;
        if(sessionStorage.getItem("currentLang")=="ar"){
          this.msg = "يجب ألا تكون كلمة المرور القديمة وكلمة المرور الجديدة متماثلتين";
        }else{
          this.msg = "Old Password and New Password should not be same";
        }        
      }else{
        this.show = false;
      }
    }
  }
  opassword(){
    const npwd  = this.secondFormGroup.value.newpassword;
    if(npwd === null){
      this.oldpass = false;
      const opwd = this.secondFormGroup.value.oldpassword;
      if(npwd != opwd){
        this.oldpass = false;
        this.oldnewpass = false;
      }else{
          this.oldpass = true;
          this.oldnewpass = true;
          if(sessionStorage.getItem("currentLang")=="ar"){
            this.confirmpwd = "يجب ألا تكون كلمة المرور الجديدة مماثلة لكلمة المرور القديمة";
          }else{
            this.confirmpwd = "New Password should not be same as Old Password";
          }
          
      }
    }
  }
  cpassword() {
    this.confirmed = false;
    const npwd  = this.secondFormGroup.value.newpassword;
    const cpwd  = this.secondFormGroup.value.confirmpassword;
    if(npwd != null && cpwd != null){
        if(npwd === cpwd){
          this.confirmed = false;
          this.cpwd = false;
        } else {
          if(this.secondFormGroup.value.confirmpassword){
            this.confirmed = true;
            this.cpwd = true;
            if(sessionStorage.getItem("currentLang")=="ar"){
              this.confirmpwd = "يجب أن يتطابق تأكيد كلمة المرور مع كلمة المرور الجديدة";
            }else{
              this.confirmpwd = "Confirm Password should be match with New Password";
            }
          }
          else{
            this.confirmed = false;
            this.cpwd = false;
          }
        }
      }
      else {
        this.confirmed = false;
        this.cpwd = false;
      }
  }
  submitpassword(){
    this.toastrService.clear();
      this._patientservice.changepassword(this.secondFormGroup.value)
      .pipe(first())
      .subscribe((res:any) => {
        if(!res.isError){
          this.dialogRef.close({ data: res });
          const options = { opacity: 1, timeOut: 2000};
          this.toastrService.success('',  res.responseMessage, options);
        }
        else{
          this.error = true;
          this.errormsg = res.errorMessage;
          const options = { opacity: 1, timeOut: 2000};
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
      err => {
          this.dialogRef.close({ data: err });
          const options = { opacity: 1, timeOut: 2000};
          this.toastrService.warning('', err?.error, options);
      });
  }
}

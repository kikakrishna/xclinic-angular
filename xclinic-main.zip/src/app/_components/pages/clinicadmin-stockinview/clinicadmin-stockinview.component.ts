import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, Validators } from '@angular/forms';
export interface PeriodicElement {
  productname: string;
  qty: number;
  unittype: string;
  unitcost: number;
  subtotal:number;

 
}

const ELEMENT_DATA: PeriodicElement[] = [
  { productname: 'product 1', qty: 2, unittype: 'Box', unitcost:100, subtotal: 200,  },
  { productname: 'product 2', qty: 3, unittype: 'piece', unitcost:50, subtotal: 150,  },
  { productname: 'product 3', qty: 4, unittype: 'Box', unitcost:10, subtotal: 40, },
  
];
@Component({
  selector: 'app-clinicadmin-stockinview',
  templateUrl: './clinicadmin-stockinview.component.html',
  styleUrls: ['./clinicadmin-stockinview.component.css']
})
export class ClinicadminStockinviewComponent implements OnInit {
  displayedColumns: string[] = ['productname', 'qty', 'unittype', 'unitcost','subtotal', ];
  dataSource = ELEMENT_DATA;
  
  // date = new FormControl(new Date());
  // serializedDate = new FormControl(new Date().toISOString());

  name = new FormControl('', [Validators.required,]);
  getErrorMessage() {
    if (this.name.hasError('required')) {
      return 'Please Enter Name';
    }
   return ;
  }
  alert = new FormControl('', [Validators.required,]);
  getErrorMessagealert() {
    if (this.alert.hasError('required')) {
      return 'Please Enter Alert';
    }
   
  }

  code = new FormControl('', [Validators.required, ]);
  getErrorMessagecode() {
    if (this.code.hasError('required')) {
      return 'Please Enter Code';
    }
   
  }

  constructor() { }

  ngOnInit(): void {
  }



  
}

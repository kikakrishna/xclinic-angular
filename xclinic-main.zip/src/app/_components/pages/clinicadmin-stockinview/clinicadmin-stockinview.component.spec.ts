import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockinviewComponent } from './clinicadmin-stockinview.component';

describe('ClinicadminStockinviewComponent', () => {
  let component: ClinicadminStockinviewComponent;
  let fixture: ComponentFixture<ClinicadminStockinviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockinviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockinviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { RouterModule } from '@angular/router';
import { ClinicadminStockinviewComponent } from './clinicadmin-stockinview.component';
export const ClinicadminStockinviewRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockinviewComponent,
    }
]
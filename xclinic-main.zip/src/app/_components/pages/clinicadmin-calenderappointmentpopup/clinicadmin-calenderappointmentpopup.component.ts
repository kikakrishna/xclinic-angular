import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DoctorService } from '../../../_services/doctor.service';

@Component({
  selector: 'app-clinicadmin-calenderappointmentpopup',
  templateUrl: './clinicadmin-calenderappointmentpopup.component.html',
  styleUrls: ['./clinicadmin-calenderappointmentpopup.component.css']
})
export class ClinicadminCalenderappointmentpopupComponent implements OnInit {
  loading: boolean;
  errormessagebox: boolean;
  messagecontent: any;
  doctorlistval: any;

  constructor(  private dialogRef: MatDialogRef<ClinicadminCalenderappointmentpopupComponent>,
    private _DoctorService: DoctorService,
    @Inject(MAT_DIALOG_DATA) public dataval: any) { 
    }
  ngOnInit(): void {
  }
}

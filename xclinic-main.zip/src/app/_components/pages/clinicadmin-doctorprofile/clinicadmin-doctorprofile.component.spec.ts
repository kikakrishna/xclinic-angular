import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDoctorprofileComponent } from './clinicadmin-doctorprofile.component';

describe('ClinicadminDoctorprofileComponent', () => {
  let component: ClinicadminDoctorprofileComponent;
  let fixture: ComponentFixture<ClinicadminDoctorprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDoctorprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDoctorprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

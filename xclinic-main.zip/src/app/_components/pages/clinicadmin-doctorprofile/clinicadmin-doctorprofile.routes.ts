import { RouterModule } from '@angular/router';
import { ClinicadminDoctorprofileComponent } from './clinicadmin-doctorprofile.component';
export const ClinicadminDoctorprofileRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminDoctorprofileComponent,
    }
]
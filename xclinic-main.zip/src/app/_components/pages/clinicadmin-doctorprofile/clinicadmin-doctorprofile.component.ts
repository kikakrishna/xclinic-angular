import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ClinicadminDoctoreditfeeComponent } from '../clinicadmin-doctoreditfee/clinicadmin-doctoreditfee.component';
import { ClinicadminDoctortreatmentComponent } from '../clinicadmin-doctortreatment/clinicadmin-doctortreatment.component';
import { ToastService } from 'ng-uikit-pro-standard';
import { DoctorService } from 'src/app/_services/doctor.service';
import { first } from 'rxjs/operators';
import { ShareDataService } from 'src/app/_services/sharedata.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'app-clinicadmin-doctorprofile',
  templateUrl: './clinicadmin-doctorprofile.component.html',
  styleUrls: ['./clinicadmin-doctorprofile.component.css']
})
export class ClinicadminDoctorprofileComponent implements OnInit {
  displayedColumns: string[] = ['feetype', 'fee', 'fromdate', 'todate'];
  public appointmentDataSource: any = new MatTableDataSource<object>([]);
  public FeeHistoryDataSource: any = new MatTableDataSource<object>([]);
  public filterpast_startdate: any;
  public filterpast_enddate: any;
  public filerpastform_pagination_show: boolean;
  public doctorProfileArray: any = [];
  public userId: any;
  public mycurrencyDetails: any;
  ppId: any;
  public activetab: string = ""
  filterpast: FormGroup;
  ssymbol: any;
  profileImage: any;
  displayedColumns1: string[] = ['patient', 'appid', 'date', 'time', 'action'];
  @ViewChild('appointmentpaginator', { read: MatPaginator }) appointmentpaginator: MatPaginator;
  @ViewChild('feehistorypaginator', { read: MatPaginator }) feehistorypaginator: MatPaginator;
  public totalSize = 0;
  public pageindex = 0;
  listdata: boolean;
  loading: boolean;
  showappointTab: boolean;
  paymentTypes: any;
  consultationType: any = 'all';
  videostatus: any;
  public searchinput = "";
  Fsearchstring: any;

  constructor(private toastrService: ToastService,
    private _activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private _DoctorService: DoctorService,
    public sharedservice: ShareDataService,
    public _formBuilder: FormBuilder) {
    this.appointmentDataSource = new MatTableDataSource;
  }

  ngOnInit(): void {
    this.loading = true;
    this.filterpast = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      todatepicker: ['', Validators.required],
    });

    this.appointmentDataSource.paginator = this.appointmentpaginator;
    this.FeeHistoryDataSource.paginator = this.feehistorypaginator;
    this.videostatus = sessionStorage.getItem('videostatus');

    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('doctorid')) {
        this.userId = params?.get('doctorid');
      }
    })
    this._DoctorService.viewprofile(this.userId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.mycurrencyDetails = res?.responseMessage?.currencyDetails
          // address, exp,linc,dob 
          this.doctorProfileArray = res?.responseMessage;
          if (res?.responseMessage?.doctorProfile != null) {
            this.profileImage = res.responseMessage.doctorProfile;
          } else {
            this.profileImage = "./assets/images/noimage.webp";
          }
          if (res?.responseMessage?.address != null && res?.responseMessage?.yearsExperience != null &&
            res?.responseMessage?.licenseNumber != null && res?.responseMessage?.dateofBirth != null) {
            this.showappointTab = true;
            console.log("doctor with profile ****")
            sessionStorage.setItem("goback", "doctorwithprofile");
          }
          else {
            console.log("doctor with out profile ****")
            sessionStorage.setItem("goback", "doctorwithoutprofile");
            this.showappointTab = false;
          }
          this.ppId = res?.responseMessage?.doctorprofileId;
          setTimeout(() => {
            this.list('today');
          }, 700);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

    // this._DoctorService.getpaymentType()
    // .subscribe((res: any) => {
    //   if(!res.isError) {
    //     this.loading = false;
    //     this.paymentTypes = res.responseMessage;
    //   }
    //   else {
    //     this.loading = false;
    //   }
    // }, err => {
    //   this.loading = false;
    // })
  }
  clearfilterpastPagination() {
    this.filerpastform_pagination_show = false;
  }
  getNext2(event: PageEvent) {
    this.loading = true;
    console.log(this.activetab)
    let array = [];
    this._DoctorService.Pastappointmentlist('Past', event.pageIndex, event.pageSize, this.filterpast_startdate, this.filterpast_enddate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          this.totalSize = res.responseMessage.pagination.total;
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.appointmentDataSource = new MatTableDataSource(array);
          if (this.appointmentDataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  filterpastForm() {
    this.loading = true;
    let array = [];
    const fdate = this.filterpast.value.fromdatepicker;
    const getFdate = moment(fdate).format();
    let startdate = getFdate.substr(0, 19);
    this.filterpast_startdate = startdate;


    const edate = this.filterpast.value.todatepicker;
    const getEdate = moment(edate).format();
    let enddate = getEdate.substr(0, 19);
    this.filterpast_enddate = enddate;

    this._DoctorService.Pastappointmentlist('Past', 0, 5, startdate, enddate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.filerpastform_pagination_show = true;
          this.totalSize = res.responseMessage.pagination.total;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.appointmentDataSource = new MatTableDataSource(array);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  applyFilter() {
    this.appointmentDataSource = []
    // const filterValue = (event.target as HTMLInputElement).value;
    // this.appointmentDataSource.filter = filterValue.trim().toLowerCase();

    // if (this.appointmentDataSource.paginator) {
    //   this.appointmentDataSource.paginator.firstPage();
    // }
    console.log(this.activetab)
    //this.loading = true;
    const filterValue = this.searchinput;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    this.Fsearchstring = searchstring;
    if (searchstring){
      if (this.activetab == "today") {
        this.loading = true;
        console.log("t")
        let array = [];
        this._DoctorService.appointmentdoctorlistsearch('Today', this.ppId, 0, 5, searchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              this.totalSize = res.responseMessage.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentDataSource = new MatTableDataSource(array);
              setTimeout(() => {
                this.appointmentpaginator.pageIndex = 0;
                this.appointmentpaginator.pageSize=0
               });
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }
      else if (this.activetab == "upcoming") {
        console.log("u")
        this.loading = true;
        let array = [];
        this._DoctorService.appointmentdoctorlistsearch('Upcoming', this.ppId, 0, 5, searchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              this.totalSize = res.responseMessage.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentDataSource = new MatTableDataSource(array);
              setTimeout(() => {
                this.appointmentpaginator.pageIndex = 0;
                this.appointmentpaginator.pageSize=0
               });
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }
      else if (this.activetab == "past") {
        console.log("p")
        this.loading = true;
        let array = [];
        this._DoctorService.appointmentdoctorlistsearch('Past', this.ppId, 0, 5, searchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              this.totalSize = res.responseMessage.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentDataSource = new MatTableDataSource(array);
              setTimeout(() => {
                this.appointmentpaginator.pageIndex = 0;
                this.appointmentpaginator.pageSize=0
               });
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }
      else if (this.activetab == "cancelled") {
        console.log("c")
        this.loading = true;
        let array = [];
        this._DoctorService.appointmentdoctorlistsearch('Cancelled', this.ppId, 0, 5, searchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              this.totalSize = res.responseMessage.pagination.total;
              for (let item of res?.responseMessage?.appointmentList) {
                item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
                array.push(item);
              }
              this.appointmentDataSource = new MatTableDataSource(array);
              setTimeout(() => {
                this.appointmentpaginator.pageIndex = 0;
                this.appointmentpaginator.pageSize=0
               });
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
      }
    }
    else{
      this.clearfilter();
    }
  


  }


  applyFilter2(event: Event) { 
    const filterValue = (event.target as HTMLInputElement).value;
    this.FeeHistoryDataSource.filter = filterValue.trim().toLowerCase();

    // if (this.FeeHistoryDataSource.paginator) {
    //   this.FeeHistoryDataSource.paginator.firstPage();
    // }
  }
  getNext(event: PageEvent) {
    this.loading = true;
    if(this.Fsearchstring){
      let array = [];
      this._DoctorService.appointmentdoctorlistsearch(this.activetab, this.ppId, event.pageIndex, event.pageSize,this.Fsearchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            this.totalSize = res.responseMessage.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
            if (this.appointmentDataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
  
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else{
      let array = [];
      this._DoctorService.appointmentdoctorlist(this.activetab, this.ppId, event.pageIndex, event.pageSize)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            this.totalSize = res.responseMessage.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
            if (this.appointmentDataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
  
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    
  }

  list(type) {
    this.appointmentDataSource = new MatTableDataSource;
    this.searchinput = "";
    this.Fsearchstring ="";
    if (type == "today") {
      this.loading = true;
      this.activetab = "today";
      console.log(this.activetab)
      let array = [];
      this._DoctorService.appointmentdoctorlist('Today', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
    if (type == "upcoming") {
      this.loading = true;
      this.activetab = "upcoming";
      console.log(this.activetab)
      let array = []
      this._DoctorService.appointmentdoctorlist('Upcoming', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            // moment().format('ll');   // Jan 21, 2021
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
    if (type == "past") {
      this.loading = true;
      this.activetab = "past";
      console.log(this.activetab)
      let array = [];
      this._DoctorService.appointmentdoctorlist('Past', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
    if (type == "cancelled") {
      this.loading = true;

      this.activetab = "cancelled";
      console.log(this.activetab)
      let array = []
      this._DoctorService.appointmentdoctorlist('Cancelled', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
  }
  list2(type) {
    this.FeeHistoryDataSource = new MatTableDataSource;
    console.log(type)
    if (type?.tab?.textLabel == "Fee History" || type?.tab?.textLabel == "கட்டணம் வரலாறு" || type?.tab?.textLabel == "ഫീസ് ചരിത്രം" || type?.tab?.textLabel == "Lịch sử phí" || type?.tab?.textLabel == "سجل الرسوم") {
      this.loading = true;
      let array = [];
      console.log(this.consultationType)
      this._DoctorService.feehistory(this.userId, this.consultationType)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let item of res?.responseMessage) {
              console.log(item?.feeType)
              // Overseas Consultation
              // Overseas Followup
              if (item?.fromDate != null) {
                item.formattedFromDate = moment(item?.fromDate).format('ll');
              } else {
                item.formattedFromDate = "";
              }
              if (item?.toDate != null) {
                item.formattedToDate = moment(item?.toDate).format('ll');
              } else {
                item.formattedToDate = "";
              }
              array.push(item);
            }
            console.log(array)
            this.FeeHistoryDataSource = new MatTableDataSource(array);
            setTimeout(() => this.FeeHistoryDataSource.paginator = this.feehistorypaginator);
            this.feehistory2();
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    }
    if (type?.tab?.textLabel == "About Me") {
      return;
    }
  }
  feehistory2() {
    this.loading = true;
    let array = [];
    this._DoctorService.feehistory(this.userId, this.consultationType)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let item of res?.responseMessage) {
            if (item?.fromDate != null) {
              item.formattedFromDate = moment(item?.fromDate).format('ll');
            } else {
              item.formattedFromDate = "";
            }
            if (item?.toDate != null) {
              item.formattedToDate = moment(item?.toDate).format('ll');
            } else {
              item.formattedToDate = "";
            }
            array.push(item);
          }
          console.log(array)
          this.FeeHistoryDataSource = new MatTableDataSource(array);
          setTimeout(() => this.FeeHistoryDataSource.paginator = this.feehistorypaginator);

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  consultationTypeChange(event) {
    this.consultationType = event;
    this.feehistory2();
  }
  editfeeDialog() {
    const dialogRef = this.dialog.open(ClinicadminDoctoreditfeeComponent, {
      width: '35%',
      panelClass: 'editfeewrapper',
      data: { "data": this.userId, "currencyDetails": this.mycurrencyDetails }
    });
    dialogRef.afterClosed().subscribe(result => {
      let arrayedit = [];
      this._DoctorService.feehistory(this.userId, this.consultationType)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            for (let item of res?.responseMessage) {
              if (item?.fromDate != null) {
                item.formattedFromDate = moment(item?.fromDate).format('ll');
              } else {
                item.formattedFromDate = "";
              }
              if (item?.toDate != null) {
                item.formattedToDate = moment(item?.toDate).format('ll');
              } else {
                item.formattedToDate = "";
              }
              arrayedit.push(item);
            }
            this.FeeHistoryDataSource = new MatTableDataSource(arrayedit);
            setTimeout(() => this.FeeHistoryDataSource.paginator = this.feehistorypaginator);

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
      return;
    });
  }
  clinicadminTreament(data) {
    const dialogRef = this.dialog.open(ClinicadminDoctortreatmentComponent, {
      width: '70%',
      data: data

    });
    dialogRef.afterClosed().subscribe(result => {

    });
  }
  clearfilter() {
    this.searchinput = "";
    this.Fsearchstring ="";
    // this.appointmentDataSource.paginator.pageSize = 0
    if (this.activetab == "today") {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentdoctorlist('Today', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
            setTimeout(() => {
             this.appointmentpaginator.pageIndex = 0;
             this.appointmentpaginator.pageSize=0
            });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.activetab == "upcoming") {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentdoctorlist('Upcoming', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
            setTimeout(() => {
              this.appointmentpaginator.pageIndex = 0;
              this.appointmentpaginator.pageSize=0
             });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.activetab == "past") {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentdoctorlist('Past', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
            setTimeout(() => {
              this.appointmentpaginator.pageIndex = 0;
              this.appointmentpaginator.pageSize=0
             });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (this.activetab == "cancelled") {
      this.loading = true;
      let array = [];
      this._DoctorService.appointmentdoctorlist('Cancelled', this.ppId, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.appointmentDataSource = new MatTableDataSource(array);
            setTimeout(() => {
              this.appointmentpaginator.pageIndex = 0;
              this.appointmentpaginator.pageSize=0
             });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }

  }
}
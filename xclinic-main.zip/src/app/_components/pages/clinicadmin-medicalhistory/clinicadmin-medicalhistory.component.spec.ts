import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminMedicalhistoryComponent } from './clinicadmin-medicalhistory.component';

describe('ClinicadminMedicalhistoryComponent', () => {
  let component: ClinicadminMedicalhistoryComponent;
  let fixture: ComponentFixture<ClinicadminMedicalhistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminMedicalhistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminMedicalhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

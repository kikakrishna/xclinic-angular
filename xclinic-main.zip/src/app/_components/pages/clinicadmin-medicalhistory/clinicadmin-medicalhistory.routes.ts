import { RouterModule } from '@angular/router';
import { ClinicadminMedicalhistoryComponent } from './clinicadmin-medicalhistory.component';
export const ClinicadminMedicalhistoryRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminMedicalhistoryComponent,
    }
]

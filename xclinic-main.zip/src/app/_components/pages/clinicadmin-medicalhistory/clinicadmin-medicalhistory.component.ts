import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { PatientService } from '../../../_services/patient.service'
declare var $: any;
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from "@angular/router";
import * as moment from 'moment';
import { ToastService } from 'ng-uikit-pro-standard';
@Component({
  selector: 'app-clinicadmin-medicalhistory',
  templateUrl: './clinicadmin-medicalhistory.component.html',
  styleUrls: ['./clinicadmin-medicalhistory.component.css']
})
export class ClinicadminMedicalhistoryComponent implements OnInit {
   public Editor = ClassicEditor;
   createMediHistory: FormGroup;
   array:any = [];
   userId;
   mdob: any;
   umdob: any;
   isshow:boolean
   isshowapimsg:string;
   getmedihistory: any;
   updatebtn: boolean;
   bloodgrp = [];
   submiterror: boolean;
   submiterrorMsg: any;
   forbiddenmessagebox: boolean;
   messagecontent: any;
   errormessagebox: boolean;
   messagebox: boolean;
   loading: boolean;
   allergymsg: boolean;
   historymsg: boolean;
   isError: boolean;
   patage: number;
   patcreateage: number;
   existmsg: boolean;
   cancelbtn:boolean = true;
   alcohallist: [];
   smokelist: [];
   isdataloaded:boolean;
   disableButton: boolean;
   temppatientid;
   constructor(private _activatedRoute: ActivatedRoute,
    private toastrService: ToastService, 
    private _formBuilder: FormBuilder,
     private _patientservice: PatientService,
      private router: Router) {
    this._activatedRoute.paramMap.subscribe(params => {      
      this.userId = +params.get('patientid');      
    });
     this.updatebtn = true;
     this.loading = false;
     this.historymsg = false;
     this.existmsg = false;
     this.allergymsg = false;
     this.createMediHistory = this._formBuilder.group({
      // gender: ['Male', Validators.required],
      // age: ['', Validators.required],
      weight: ['', [Validators.min(1),Validators.pattern('^-?[0-9]{1,2}\\d*(\\.\\d{1,2})?$')]],
      height: ['', [Validators.min(1),Validators.pattern('^[0-9]*$')]],
      history: [''],
      // dob: ['', Validators.required],
      allergy: [''],
      bloodgroup: [''],
      existdiseases: [''],
      smokestatus: [''],
      alcohalstatus: [''],
      currentmedication:['']      
    });
   }
   ngOnInit(): void {
    this.loading = true;
    this.Disabled();
    // this.userId = sessionStorage.getItem('userId');
    this._patientservice.getblood()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.bloodgrp = res.responseMessage;
        } else {
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('',res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('',err?.error, options);
      });

    this._patientservice.getmedihistory(this.userId)
      .pipe(first())
      .subscribe((res: any) => {        
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          if (res.responseMessage != null) {
            this.updatebtn = true;
            this.getmedihistory = res.responseMessage;
            this.patage = moment().diff(moment(res.responseMessage.dateofbirth, 'YYYYMMDD'), 'years')
            // this.createMediHistory.get('age').setValue(res.responseMessage.age);
            // this.createMediHistory.get('gender').setValue(res.responseMessage.gender);
            this.createMediHistory.get('weight').setValue(res.responseMessage.weight);
            this.createMediHistory.get('height').setValue(res.responseMessage.height);
            this.createMediHistory.get('history').setValue(res.responseMessage.medicalhistory1);
            this.createMediHistory.get('currentmedication').setValue(res.responseMessage.currentmedication);

            // this.createMediHistory.get('dob').setValue(res.responseMessage.dateofbirth);
            this.createMediHistory.get('allergy').setValue(res.responseMessage.allergy);
            if(res.responseMessage.bloodGroupid == 0 || res.responseMessage.bloodGroupid == "") {
              this.createMediHistory.get('bloodgroup').setValue(null);
            }else{
              this.createMediHistory.get('bloodgroup').setValue(res.responseMessage.bloodGroupid);
            }
            this.createMediHistory.get('existdiseases').setValue(res.responseMessage.existingDisease);
            this.createMediHistory.get('alcohalstatus').setValue(res.responseMessage.alcoholStatus?.typeId);
            this.createMediHistory.get('smokestatus').setValue(res.responseMessage.smokeStatus?.typeId);
            this.array.push(
              // {"age":res.responseMessage.age},{"gender":res?.responseMessage?.gender},
              {"weight":res?.responseMessage?.weight},
              {"height":res?.responseMessage?.height},{"history":res?.responseMessage?.medicalhistory1},
              // {"dob":res?.responseMessage?.dateofbirth},
              {"allergy":res?.responseMessage?.allergy},
              {"bloodgroup":res?.responseMessage?.bloodGroupid},{"existdiseases":res?.responseMessage?.existingDisease},
              {"alcohalstatus":res?.responseMessage?.alcoholStatus?.typeId},{"smokestatus":res?.responseMessage?.smokeStatus?.typeId})
              if(this.array.length != 0 ){
                this.isdataloaded = true;
              }
          } else {
            this.updatebtn = false;
          }
        } else {
          this.loading = false;
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
          this.isshow = true;
          this.isshowapimsg = res.errorMessage;
        }
      },
        err => {
          this.loading = false;
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

    $(".file-upload-wrapper").on("change", ".file-upload-field", function () {
      $(this).parent(".file-upload-wrapper").attr("data-text", $(this).val().replace(/.*(\/|\\)/, ''));
    });

  this._patientservice.getAlcoholStatus()
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {
        this.loading = false;
        this.alcohallist = res.responseMessage;
      } else{
        this.errormessagebox = true;
        this.messagecontent = res.errorMessage;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
    err => {
      this.loading = false;
      this.forbiddenmessagebox = true;
      this.messagecontent = err.error;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', err?.error, options);
    });

  this._patientservice.getSmokeStatus()
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {
        this.loading = false;
        this.smokelist = res.responseMessage;
      } else{
        this.errormessagebox = true;
        this.messagecontent = res.errorMessage;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
    err => {
      this.loading = false;
      this.forbiddenmessagebox = true;
      this.messagecontent = err.error;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', err?.error, options);
    });
  }
  //  ngOnInit(): void {
  //   this.temppatientid = sessionStorage.getItem('temppatientid');
  //    this.loading = true;
  //    this.Disabled();
  //   //  this.userId = sessionStorage.getItem('userId');
  //    this._patientservice.getblood()
  //      .pipe(first())
  //      .subscribe((res: any) => {
  //        if (!res.isError) {
  //          this.bloodgrp = res.responseMessage;
  //        } else {
  //          this.errormessagebox = true;
  //          this.messagecontent = res.errorMessage;
  //          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //          this.toastrService.warning('',res.errorMessage, options);
  //        }
  //      }, err => {
  //        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //        this.toastrService.warning('',err?.error, options);
  //      });
 
  //      this._patientservice.getmedihistory(this.userId)
  //      .pipe(first())
  //      .subscribe((res: any) => {        
  //        console.log(res)
  //        if (!res.isError) {
  //          this.loading = false;
  //          if (res.responseMessage != null) {
  //            this.updatebtn = true;
  //            this.getmedihistory = res.responseMessage;
  //            this.patage = moment().diff(moment(res.responseMessage.dateofbirth, 'YYYYMMDD'), 'years')
  //            // this.createMediHistory.get('age').setValue(res.responseMessage.age);
  //            // this.createMediHistory.get('gender').setValue(res.responseMessage.gender);
  //            this.createMediHistory.get('weight').setValue(res.responseMessage.weight);
  //            this.createMediHistory.get('height').setValue(res.responseMessage.height);
  //            this.createMediHistory.get('history').setValue(res.responseMessage.medicalhistory1);
  //            // this.createMediHistory.get('dob').setValue(res.responseMessage.dateofbirth);
  //            this.createMediHistory.get('allergy').setValue(res.responseMessage.allergy);
  //            if(res.responseMessage.bloodGroupid == 0 || res.responseMessage.bloodGroupid == "") {
  //              this.createMediHistory.get('bloodgroup').setValue(null);
  //            }else{
  //              this.createMediHistory.get('bloodgroup').setValue(res.responseMessage.bloodGroupid);
  //            }
  //            this.createMediHistory.get('existdiseases').setValue(res.responseMessage.existingDisease);
  //            this.createMediHistory.get('alcohalstatus').setValue(res.responseMessage.alcoholStatus?.typeId);
  //            this.createMediHistory.get('smokestatus').setValue(res.responseMessage.smokeStatus?.typeId);
  //            this.array.push(
  //              // {"age":res.responseMessage.age},{"gender":res?.responseMessage?.gender},
  //              {"weight":res?.responseMessage?.weight},
  //              {"height":res?.responseMessage?.height},{"history":res?.responseMessage?.medicalhistory1},
  //              // {"dob":res?.responseMessage?.dateofbirth},
  //              {"allergy":res?.responseMessage?.allergy},
  //              {"bloodgroup":res?.responseMessage?.bloodGroupid},{"existdiseases":res?.responseMessage?.existingDisease},
  //              {"alcohalstatus":res?.responseMessage?.alcoholStatus?.typeId},{"smokestatus":res?.responseMessage?.smokeStatus?.typeId})
  //              if(this.array.length != 0 ){
  //                this.isdataloaded = true;
  //              }
  //          } else {
  //            this.updatebtn = false;
  //          }
  //        } else {
  //          this.loading = false;
  //          this.errormessagebox = true;
  //          this.messagecontent = res.errorMessage;
  //          this.isshow = true;
  //          this.isshowapimsg = res.errorMessage;
  //        }
  //      },
  //        err => {
  //          this.loading = false;
  //          this.forbiddenmessagebox = true;
  //          this.messagecontent = err.error;
  //          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //          this.toastrService.warning('', err?.error, options);
  //        });
 
  //    $(".file-upload-wrapper").on("change", ".file-upload-field", function () {
  //      $(this).parent(".file-upload-wrapper").attr("data-text", $(this).val().replace(/.*(\/|\\)/, ''));
  //    });
 
  //  this._patientservice.getAlcoholStatus()
  //    .pipe(first())
  //    .subscribe((res: any) => {
  //      if (!res.isError) {
  //        this.loading = false;
  //        this.alcohallist = res.responseMessage;
  //      } else{
  //        this.errormessagebox = true;
  //        this.messagecontent = res.errorMessage;
  //        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //        this.toastrService.warning('', res.errorMessage, options);
  //      }
  //    },
  //    err => {
  //      this.loading = false;
  //      this.forbiddenmessagebox = true;
  //      this.messagecontent = err.error;
  //      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //      this.toastrService.warning('', err?.error, options);
  //    });
 
  //  this._patientservice.getSmokeStatus()
  //    .pipe(first())
  //    .subscribe((res: any) => {
  //      if (!res.isError) {
  //        this.loading = false;
  //        this.smokelist = res.responseMessage;
  //      } else{
  //        this.errormessagebox = true;
  //        this.messagecontent = res.errorMessage;
  //        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //        this.toastrService.warning('', res.errorMessage, options);
  //      }
  //    },
  //    err => {
  //      this.loading = false;
  //      this.forbiddenmessagebox = true;
  //      this.messagecontent = err.error;
  //      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //      this.toastrService.warning('', err?.error, options);
  //    });
  //  }
    // ngOnInit(): void {
  //   this.loading = true;
  //   this.Disabled();
  //   this.userId = sessionStorage.getItem('userId');
  //   this._patientservice.getblood()
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.bloodgrp = res.responseMessage;
  //       } else {
  //         this.errormessagebox = true;
  //         this.messagecontent = res.errorMessage;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('',res.errorMessage, options);
  //       }
  //     }, err => {
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('',err?.error, options);
  //     });

  //   this._patientservice.getmedihistory(this.userId)
  //     .pipe(first())
  //     .subscribe((res: any) => {        
  //       console.log(res.response)
  //       if (!res.isError) {
  //         this.loading = false;
  //         if (res.responseMessage != null) {
  //           this.updatebtn = true;
  //           this.getmedihistory = res.responseMessage;
  //           this.patage = moment().diff(moment(res.responseMessage.dateofbirth, 'YYYYMMDD'), 'years')
  //           this.createMediHistory.get('age').setValue(res.responseMessage.age);
  //           this.createMediHistory.get('gender').setValue(res.responseMessage.gender);
  //           this.createMediHistory.get('weight').setValue(res.responseMessage.weight);
  //           this.createMediHistory.get('height').setValue(res.responseMessage.height);
  //           this.createMediHistory.get('history').setValue(res.responseMessage.medicalhistory1);
  //           this.createMediHistory.get('dob').setValue(res.responseMessage.dateofbirth);
  //           this.createMediHistory.get('allergy').setValue(res.responseMessage.allergy);
  //           if(res.responseMessage.bloodGroupid == 0 || res.responseMessage.bloodGroupid == "") {
  //             this.createMediHistory.get('bloodgroup').setValue("");
  //           }else{
  //             this.createMediHistory.get('bloodgroup').setValue(res.responseMessage.bloodGroupid);
  //           }
  //           this.createMediHistory.get('existdiseases').setValue(res.responseMessage.existingDisease);
  //           this.createMediHistory.get('alcohalstatus').setValue(res.responseMessage.alcoholStatus?.typeId);
  //           this.createMediHistory.get('smokestatus').setValue(res.responseMessage.smokeStatus?.typeId);
  //           this.array.push(
  //             {"age":res.responseMessage.age},{"gender":res?.responseMessage?.gender},{"weight":res?.responseMessage?.weight},
  //             {"height":res?.responseMessage?.height},{"history":res?.responseMessage?.medicalhistory1},
  //             {"dob":res?.responseMessage?.dateofbirth},{"allergy":res?.responseMessage?.allergy},
  //             {"bloodgroup":res?.responseMessage?.bloodGroupid},{"existdiseases":res?.responseMessage?.existingDisease},
  //             {"alcohalstatus":res?.responseMessage?.alcoholStatus?.typeId},{"smokestatus":res?.responseMessage?.smokeStatus?.typeId})
  //             if(this.array.length != 0 ){
  //               this.isdataloaded = true;
  //             }
  //         } else {
  //           this.updatebtn = false;
  //         }
  //       } else {
  //         this.loading = false;
  //         this.errormessagebox = true;
  //         this.messagecontent = res.errorMessage;
  //         this.isshow = true;
  //         this.isshowapimsg = res.errorMessage;
  //       }
  //     },
  //       err => {
  //         this.loading = false;
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //       });

  //   $(".file-upload-wrapper").on("change", ".file-upload-field", function () {
  //     $(this).parent(".file-upload-wrapper").attr("data-text", $(this).val().replace(/.*(\/|\\)/, ''));
  //   });

  // this._patientservice.getAlcoholStatus()
  //   .pipe(first())
  //   .subscribe((res: any) => {
  //     if (!res.isError) {
  //       this.loading = false;
  //       this.alcohallist = res.responseMessage;
  //     } else{
  //       this.errormessagebox = true;
  //       this.messagecontent = res.errorMessage;
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', res.errorMessage, options);
  //     }
  //   },
  //   err => {
  //     this.loading = false;
  //     this.forbiddenmessagebox = true;
  //     this.messagecontent = err.error;
  //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     this.toastrService.warning('', err?.error, options);
  //   });

  // this._patientservice.getSmokeStatus()
  //   .pipe(first())
  //   .subscribe((res: any) => {
  //     if (!res.isError) {
  //       this.loading = false;
  //       this.smokelist = res.responseMessage;
  //     } else{
  //       this.errormessagebox = true;
  //       this.messagecontent = res.errorMessage;
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', res.errorMessage, options);
  //     }
  //   },
  //   err => {
  //     this.loading = false;
  //     this.forbiddenmessagebox = true;
  //     this.messagecontent = err.error;
  //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     this.toastrService.warning('', err?.error, options);
  //   });
  // }
  startlistdate() {
    const sdate = this.createMediHistory.value.dob;
    const medidate = sdate.toISOString();
    this.patcreateage = moment().diff(moment(medidate, 'YYYYMMDD'), 'years');
    this.createMediHistory.get('age').setValue(this.patcreateage);
  }

  changefielddetection(){    
  if(this.isdataloaded == true){
    if(
      // this.array[0]?.age  == this.createMediHistory?.value?.age &&  
      // this.array[1]?.gender == this.createMediHistory?.value?.gender &&  
      this.array[0]?.weight == this.createMediHistory?.value?.weight &&  
      this.array[1]?.height == this.createMediHistory?.value?.height &&  
      this.array[2]?.history == this.createMediHistory?.value?.history &&  
      // this.array[5]?.dob == this.createMediHistory?.value?.dob &&  
      this.array[3]?.allergy == this.createMediHistory?.value?.allergy &&  
      this.array[4]?.bloodgroup == this.createMediHistory?.value?.bloodgroup &&  
      this.array[5]?.existdiseases == this.createMediHistory?.value?.existdiseases &&  
      this.array[6]?.alcohalstatus == this.createMediHistory?.value?.alcohalstatus &&  
      this.array[7]?.smokestatus == this.createMediHistory?.value?.smokestatus){
       this.cancelbtn = true;
      }else{
       this.cancelbtn =false;
      }
    }
  }

  Disabled() {
    if(this.createMediHistory.touched){
      return false;
    } else {
      return true;
    }
  }

  submitmedihistory() {
    this.loading = true;
    this.isError = false;
    // const mediudob = this.createMediHistory.value.dob;
    // this.mdob = mediudob.toISOString();
    // if (this.createMediHistory.value.history === null || this.createMediHistory.value.history === '') {
    //   this.isError = true;
    //   this.historymsg = true;
    //   this.loading = false;
    // } else {
    //   this.historymsg = false;
    // }
    // if (this.createMediHistory.value.allergy === null || this.createMediHistory.value.allergy === "") {
    //   this.isError = true;
    //    this.allergymsg = true;
    //    this.loading = false;
    // } else {
    //   this.allergymsg = false;
    // }
    // if (!this.isError) {
      this.historymsg = false;
      this.allergymsg = false;
      console.log(this.createMediHistory.value)
      this._patientservice.createmedhistory(this.createMediHistory.value, this.userId)
        .pipe(first())
        .subscribe((res: any) => {
          this.Disabled();
          if (!res.isError) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res?.responseMessage, options);
            this.ngOnInit();
            this.messagebox = true;
            this.messagecontent = res.responseMessage;
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res?.errorMessage, options);
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    // }
  }

  updatehistory() {
    console.log(this.createMediHistory.value)    
    this.loading = true;
    if (this.createMediHistory.value.existdiseases === null || this.createMediHistory.value.existdiseases === "" || this.createMediHistory.value.existdiseases === undefined) {
      this.createMediHistory.value.existdiseases = null;
    }
    this.isError = false;
    this.umdob = this.createMediHistory.value.dob;
    // if (this.createMediHistory.value.history === null || this.createMediHistory.value.history === '') {
    //   this.isError = true;
    //   this.historymsg = true;
    //   this.loading = false;
    // } else {
    //   this.historymsg = false;
    // }
    // if (this.createMediHistory.value.allergy === null || this.createMediHistory.value.allergy === "") {
    //   this.isError = true;
    //   this.loading = false;
    //   this.allergymsg = true;
    // } else {
    //   this.allergymsg = false;
    // }
    if(this.createMediHistory.value.alcohalstatus === 0 ){
      this.createMediHistory.value.alcohalstatus = ""
    }
    if(this.createMediHistory.value.smokestatus === 0 ){
      this.createMediHistory.value.smokestatus = ""
    }
    // if (!this.isError) {
      this.historymsg = false;
      this.allergymsg = false;
      this.loading = true;
      this._patientservice.updatemedhistory(this.createMediHistory.value, this.userId, this.umdob)
        .pipe(first())
        .subscribe((res: any) => {
          this.Disabled();
          if (!res.isError) {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res?.responseMessage, options);
            this.loading = false;
            this.ngOnInit();
            this.messagebox = true;
            this.messagecontent = res.responseMessage;
            setTimeout(() => {
              // this.router.navigate(['/thealth/clinicadmin/patients/view/${ele.patienttrpackagemapid}']);
              this.router.navigate([`/thealth/clinicadmin/patients/view/${this.getmedihistory?.patientProfileId}`]);
              this.toastrService.clear(),1000
            }, 1000);
          } else {
            this.loading = false;
            this.errormessagebox = true;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res?.errorMessage, options);
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            this.loading = false;
            this.forbiddenmessagebox = true;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.messagecontent = err.error;
          });
    // }
  }
  reset(formData: any, formDirective: FormGroupDirective){
    formDirective.resetForm();
    this.createMediHistory.reset();
    this.createMediHistory.get('gender').setValue('');
    this.ngOnInit();
  }

  //  startlistdate() {
  //   const sdate = this.createMediHistory.value.dob;
  //   const medidate = sdate.toISOString();
  //   this.patcreateage = moment().diff(moment(medidate, 'YYYYMMDD'), 'years');
  //   this.createMediHistory.get('age').setValue(this.patcreateage);
  // }

  // changefielddetection(){    
  // if(this.isdataloaded == true){
  //   if(
  //     // this.array[0]?.age  == this.createMediHistory?.value?.age &&  
  //     // this.array[1]?.gender == this.createMediHistory?.value?.gender &&  
  //     this.array[0]?.weight == this.createMediHistory?.value?.weight &&  
  //     this.array[1]?.height == this.createMediHistory?.value?.height &&  
  //     this.array[2]?.history == this.createMediHistory?.value?.history &&  
  //     // this.array[5]?.dob == this.createMediHistory?.value?.dob &&  
  //     this.array[3]?.allergy == this.createMediHistory?.value?.allergy &&  
  //     this.array[4]?.bloodgroup == this.createMediHistory?.value?.bloodgroup &&  
  //     this.array[5]?.existdiseases == this.createMediHistory?.value?.existdiseases &&  
  //     this.array[6]?.alcohalstatus == this.createMediHistory?.value?.alcohalstatus &&  
  //     this.array[7]?.smokestatus == this.createMediHistory?.value?.smokestatus){
  //      this.cancelbtn = true;
  //     }else{
  //      this.cancelbtn =false;
  //     }
  //   }
  // }

  // Disabled() {
  //   if(this.createMediHistory.touched){
  //     return false;
  //   } else {
  //     return true;
  //   }
  // }

  // submitmedihistory() {
  //   this.loading = true;
  //   this.isError = false;
  //   // const mediudob = this.createMediHistory.value.dob;
  //   // this.mdob = mediudob.toISOString();
  //   // if (this.createMediHistory.value.history === null || this.createMediHistory.value.history === '') {
  //   //   this.isError = true;
  //   //   this.historymsg = true;
  //   //   this.loading = false;
  //   // } else {
  //   //   this.historymsg = false;
  //   // }
  //   // if (this.createMediHistory.value.allergy === null || this.createMediHistory.value.allergy === "") {
  //   //   this.isError = true;
  //   //    this.allergymsg = true;
  //   //    this.loading = false;
  //   // } else {
  //   //   this.allergymsg = false;
  //   // }
  //   // if (!this.isError) {
  //     this.historymsg = false;
  //     this.allergymsg = false;
  //      this._patientservice.createmedhistory(this.createMediHistory.value, this.userId, this.mdob)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         this.Disabled();
  //         if (!res.isError) {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.success('', res?.responseMessage, options);
  //           this.ngOnInit();
  //           this.messagebox = true;
  //           this.messagecontent = res.responseMessage;
  //         } else {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res?.errorMessage, options);
  //           this.errormessagebox = true;
  //           this.messagecontent = res.errorMessage;
  //         }
  //       },
  //         err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err.error, options);
  //           this.forbiddenmessagebox = true;
  //           this.messagecontent = err.error;
  //         });
  //   // }
  // }

  // updatehistory() {
  //   console.log(this.createMediHistory.value)    
  //   this.loading = true;
  //   if (this.createMediHistory.value.existdiseases === null || this.createMediHistory.value.existdiseases === "" || this.createMediHistory.value.existdiseases === undefined) {
  //     this.createMediHistory.value.existdiseases = null;
  //   }
  //   this.isError = false;
  //   this.umdob = this.createMediHistory.value.dob;
  //   // if (this.createMediHistory.value.history === null || this.createMediHistory.value.history === '') {
  //   //   this.isError = true;
  //   //   this.historymsg = true;
  //   //   this.loading = false;
  //   // } else {
  //   //   this.historymsg = false;
  //   // }
  //   // if (this.createMediHistory.value.allergy === null || this.createMediHistory.value.allergy === "") {
  //   //   this.isError = true;
  //   //   this.loading = false;
  //   //   this.allergymsg = true;
  //   // } else {
  //   //   this.allergymsg = false;
  //   // }
  //   if(this.createMediHistory.value.alcohalstatus === 0 ){
  //     this.createMediHistory.value.alcohalstatus = ""
  //   }
  //   if(this.createMediHistory.value.smokestatus === 0 ){
  //     this.createMediHistory.value.smokestatus = ""
  //   }
  //   // if (!this.isError) {
  //     this.historymsg = false;
  //     this.allergymsg = false;
  //     this.loading = true;
  //     this._patientservice.updatemedhistory(this.createMediHistory.value, this.userId, this.umdob)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         this.Disabled();
  //         if (!res.isError) {
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.success('', res?.responseMessage, options);
  //           this.loading = false;
  //           this.ngOnInit();
  //           this.messagebox = true;
  //           this.messagecontent = res.responseMessage;
  //         } else {
  //           this.loading = false;
  //           this.errormessagebox = true;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res?.errorMessage, options);
  //           this.messagecontent = res.errorMessage;
  //         }
  //       },
  //         err => {
  //           this.loading = false;
  //           this.forbiddenmessagebox = true;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //           this.messagecontent = err.error;
  //         });
  //   // }
  // }
  // reset(formData: any, formDirective: FormGroupDirective){
  //   formDirective.resetForm();
  //   this.createMediHistory.reset();
  //   this.createMediHistory.get('gender').setValue('');
  //   this.ngOnInit();
  // }

  // //  startlistdate() {
  // //    const sdate = this.createMediHistory.value.dob;
  // //    const medidate = sdate.toISOString();
  // //    this.patcreateage = moment().diff(moment(medidate, 'YYYYMMDD'), 'years');
  // //    this.createMediHistory.get('age').setValue(this.patcreateage);
  // //  }
 
  // //  changefielddetection(){    
  // //  if(this.isdataloaded == true){
  // //    if(this.array[0]?.age  == this.createMediHistory?.value?.age &&  
  // //      this.array[1]?.gender == this.createMediHistory?.value?.gender &&  
  // //      this.array[2]?.weight == this.createMediHistory?.value?.weight &&  
  // //      this.array[3]?.height == this.createMediHistory?.value?.height &&  
  // //      this.array[4]?.history == this.createMediHistory?.value?.history &&  
  // //      this.array[5]?.dob == this.createMediHistory?.value?.dob &&  
  // //      this.array[6]?.allergy == this.createMediHistory?.value?.allergy &&  
  // //      this.array[7]?.bloodgroup == this.createMediHistory?.value?.bloodgroup &&  
  // //      this.array[8]?.existdiseases == this.createMediHistory?.value?.existdiseases &&  
  // //      this.array[9]?.alcohalstatus == this.createMediHistory?.value?.alcohalstatus &&  
  // //      this.array[10]?.smokestatus == this.createMediHistory?.value?.smokestatus){
  // //       this.cancelbtn = true;
  // //      }else{
  // //       this.cancelbtn =false;
  // //      }
  // //    }
  // //  }
 
  // //  Disabled() {
  // //    if(this.createMediHistory.touched){
  // //      return false;
  // //    } else {
  // //      return true;
  // //    }
  // //  }
 
  // //  submitmedihistory() {
  // //    this.loading = true;
  // //    this.isError = false;
  // //    const mediudob = this.createMediHistory.value.dob;
  // //    this.mdob = mediudob.toISOString();
  // //    if (this.createMediHistory.value.history === null || this.createMediHistory.value.history === '') {
  // //      this.isError = true;
  // //      this.historymsg = true;
  // //      this.loading = false;
  // //    } else {
  // //      this.historymsg = false;
  // //    }
  // //    if (this.createMediHistory.value.allergy === null || this.createMediHistory.value.allergy === "") {
  // //      this.isError = true;
  // //       this.allergymsg = true;
  // //       this.loading = false;
  // //    } else {
  // //      this.allergymsg = false;
  // //    }
  // //    if (!this.isError) {
  // //      this.historymsg = false;
  // //      this.allergymsg = false;
  // //      this._patientservice.createmedhistory(this.createMediHistory.value, this.userId, this.mdob)
  // //        .pipe(first())
  // //        .subscribe((res: any) => {
  // //          this.Disabled();
  // //          if (!res.isError) {
  // //            this.loading = false;
  // //            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  // //            this.toastrService.success('', res?.responseMessage, options);
  // //            this.ngOnInit();
  // //            this.messagebox = true;
  // //            this.messagecontent = res.responseMessage;
  // //          } else {
  // //            this.loading = false;
  // //            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  // //            this.toastrService.warning('', res?.errorMessage, options);
  // //            this.errormessagebox = true;
  // //            this.messagecontent = res.errorMessage;
  // //          }
  // //        },
  // //          err => {
  // //            this.loading = false;
  // //            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  // //            this.toastrService.warning('', err.error, options);
  // //            this.forbiddenmessagebox = true;
  // //            this.messagecontent = err.error;
  // //          });
  // //    }
  // //  }
 
  // //  updatehistory() {
  // //    console.log(this.createMediHistory.value)    
  // //    this.loading = true;
  // //    if (this.createMediHistory.value.existdiseases === null || this.createMediHistory.value.existdiseases === "" || this.createMediHistory.value.existdiseases === undefined) {
  // //      this.createMediHistory.value.existdiseases = null;
  // //    }
  // //    this.isError = false;
  // //    this.umdob = this.createMediHistory.value.dob;
  // //    if (this.createMediHistory.value.history === null || this.createMediHistory.value.history === '') {
  // //      this.isError = true;
  // //      this.historymsg = true;
  // //      this.loading = false;
  // //    } else {
  // //      this.historymsg = false;
  // //    }
  // //    if (this.createMediHistory.value.allergy === null || this.createMediHistory.value.allergy === "") {
  // //      this.isError = true;
  // //      this.loading = false;
  // //      this.allergymsg = true;
  // //    } else {
  // //      this.allergymsg = false;
  // //    }
  // //    if(this.createMediHistory.value.alcohalstatus === 0 ){
  // //      this.createMediHistory.value.alcohalstatus = ""
  // //    }
  // //    if(this.createMediHistory.value.smokestatus === 0 ){
  // //      this.createMediHistory.value.smokestatus = ""
  // //    }
  // //    if (!this.isError) {
  // //      this.historymsg = false;
  // //      this.allergymsg = false;
  // //      this.loading = true;
  // //      this._patientservice.updatemedhistory(this.createMediHistory.value, this.userId, this.umdob)
  // //        .pipe(first())
  // //        .subscribe((res: any) => {
  // //          this.Disabled();
  // //          if (!res.isError) {
  // //            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  // //            this.toastrService.success('', res?.responseMessage, options);
  // //            this.loading = false;
  // //            this.ngOnInit();
  // //            this.messagebox = true;
  // //            this.messagecontent = res.responseMessage;
  // //          } else {
  // //            this.loading = false;
  // //            this.errormessagebox = true;
  // //            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  // //            this.toastrService.warning('', res?.errorMessage, options);
  // //            this.messagecontent = res.errorMessage;
  // //          }
  // //        },
  // //          err => {
  // //            this.loading = false;
  // //            this.forbiddenmessagebox = true;
  // //            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  // //            this.toastrService.warning('', err?.error, options);
  // //            this.messagecontent = err.error;
  // //          });
  // //    }
  // //  }
  // //  reset(formData: any, formDirective: FormGroupDirective){
  // //    formDirective.resetForm();
  // //    this.createMediHistory.reset();
  // //    this.createMediHistory.get('gender').setValue('');
  // //    this.ngOnInit();
  // //  }
}

import { RouterModule } from '@angular/router';
import { ClinicadminTransactioninvoiceComponent } from './clinicadmin-transactioninvoice.component';
export const ClinicadminTransactionInvoiceRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminTransactioninvoiceComponent,
    }
]
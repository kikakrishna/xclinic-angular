import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminTransactioninvoiceComponent } from './clinicadmin-transactioninvoice.component';

describe('ClinicadminTransactioninvoiceComponent', () => {
  let component: ClinicadminTransactioninvoiceComponent;
  let fixture: ComponentFixture<ClinicadminTransactioninvoiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminTransactioninvoiceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminTransactioninvoiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

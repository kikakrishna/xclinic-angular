import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';

@Component({
  selector: 'app-clinicadmin-transactioninvoice',
  templateUrl: './clinicadmin-transactioninvoice.component.html',
  styleUrls: ['./clinicadmin-transactioninvoice.component.css']
})
export class ClinicadminTransactioninvoiceComponent implements OnInit {
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  loading: boolean = false;
 public dataSourcetable: any = new MatTableDataSource([]);
  billid;
  invoicedet: any = [];
  displayedColumns: string[] = ['chargesname', 'quantity','description', 'amount',  'discount','gst', 'total'];
  constructor(
    private _DoctorService: DoctorService,
    public toastrService: ToastService,
    private router: Router,
    private _activatedRoute: ActivatedRoute) {
    this._activatedRoute.paramMap.subscribe(params => {
      this.billid = params.get('bill_appointment_map_id');
      console.log(this.billid)
    });
  }

  ngOnInit(): void {
    this.GetInvoicedet();
  }


  GetInvoicedet() {
    this.loading = true;
    this._DoctorService.GetInvoiceBillMapid(this.billid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          this.invoicedet = res.responseMessage
          this.dataSourcetable = new MatTableDataSource(res?.responseMessage?.billViewModel?.listbillItems);

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }

  goback(){
    this.router.navigate(['/thealth/clinicadmin/transaction/']);
  }
  // eprescription(aId) {
  //   this.loading = true;
  //   this._DoctorService.eprescription(aId)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.loading = false;
  //         const newBlob = new Blob([res], { type: 'application/pdf' });
  //         this.data = window.URL.createObjectURL(res);
  //         const file_path = this.data;
  //         const down = document.createElement('A') as HTMLAnchorElement;
  //         down.href = file_path;
  //         down.download = "Prescription-" + aId;
  //         document.body.appendChild(down);
  //         down.click();
  //         document.body.removeChild(down);
  //       } else {
  //         this.loading = false;
  //         this.errormessagebox = true;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //         this.messagecontent = res.errorMessage;
  //       }
  //     },
  //       err => {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //         this.loading = false;
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //       })
  // }
  data: string;
  DownloadInvoice() {
    this.loading = true;
    this._DoctorService.downloadInvoice(this.billid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Invoice-" + this.invoicedet?.invoiceNumber;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
}

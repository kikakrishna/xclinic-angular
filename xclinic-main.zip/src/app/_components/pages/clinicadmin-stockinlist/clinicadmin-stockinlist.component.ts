import { Component, OnInit, ViewChild,ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';

export interface PeriodicElement {
  date: string;
  supplier: string;
  items: string;
  location:string;
  refno: string;
  amount: string;
  action:string;
  
}

const ELEMENT_DATA: PeriodicElement[] = [
  {date: '21-05-2022', supplier: 'Pretham medic', items: '2',  location: 'location 1', refno:'1',  amount:'1',action:'' },
  {date: '21-05-2022', supplier: 'Pretham medic', items: '2', location: 'location 2',refno:'1',  amount:'1',action:'' },
  {date: '21-05-2022', supplier: 'Pretham medic', items:'2', location: 'location 3',refno:'1',  amount:'1',action:'' },
  
];
@Component({
  selector: 'app-clinicadmin-stockinlist',
  templateUrl: './clinicadmin-stockinlist.component.html',
  styleUrls: ['./clinicadmin-stockinlist.component.css']
})
export class ClinicadminStockinlistComponent implements OnInit {
  displayedColumns: string[] = [ 'date','supplier', 'items','location','refno','amount','action' ];
  //dataSource = ELEMENT_DATA;
  public stockinArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatPaginator, { static: false }) stockinlistpaginator: MatPaginator;

  loading:boolean;
  addressmodel:any;
  clinicId:any;
  btnAction: boolean;
  stockinstatus: any;
  getpendingstate:any;
  public filerpastform_pagination_show: boolean;
  
  public totalSize = 0;
  public pageindex = 0;

  searchstring :any;
  public searchinput = "";
  filterData: boolean;
  applyfilterData: boolean = false;
  listdata: boolean;
  supplierstatus:any;
  Fsearchstring:string;
  servicestatus: any;

  constructor(
  private _DoctorService: DoctorService,
  private _patientservice: PatientService,
  public toastrService: ToastService,
  private _formBuilder: FormBuilder,
  private router: Router,
  public dialog: MatDialog,
    ) { }

  ngOnInit(): void {
    this.loading = true;

    this.clinicId = sessionStorage.getItem('clinicId');
    this.stockinArraydataSource.paginator = this.paginator;
    this._DoctorService.getstockinslist(0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.responseMessage;

          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          
          console.log(array)
          this.stockinArraydataSource = new MatTableDataSource(array);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.stockinArraydataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }); 
     }


  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getstockinslist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          this.stockinArraydataSource = new MatTableDataSource(array);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  createclick(){
      this.router.navigate([`/thealth/clinicadmin/stockin`], { state: { stockinstatus: 'create', btnAction:true } });
  } 

  
  editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/stockin/view/${ele.stockinwardId}`], { state: { stockinstatus: ele, btnAction:false } });
      }

    //reset
      clearfilter() {
        this.loading=true;
        this.searchinput = "";
        let searchstring = this.searchinput;
        this.applyfilterData= false;
        this._DoctorService.getstockinslist(0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.responseMessage;
          this.totalSize = res.total;
          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              // item.formattedappointmentDate = moment(d).format('MMMM d, YYYY');
            item.formattedappointmentDate = moment(item?.date).format('ll');
              array.push(item);
          }
          
          console.log(array)
          this.stockinArraydataSource = new MatTableDataSource(array);

          setTimeout(() => {
            this.totalSize = res?.pagination.total;
             this.stockinArraydataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }); 
        if(searchstring ==""){
          this.filterData = false;
        }
      }

 filterstring
      applyFilter2() {
        const filterValue = this.searchinput;
        let searchstring = filterValue.trim()
        console.log(searchstring)
        if(searchstring != "") {
        if(searchstring) {
          this.applyfilterData = true;
        } else
        this. stockinArraydataSource.filter = filterValue.trim().toLowerCase();
        if(this. stockinArraydataSource.filteredData.length === 0) {
          this.filterData = true;
        } else {
          this.filterData = false;
        }
        this.loading = true;
        this.Fsearchstring=searchstring;
          this._DoctorService.stockinlistfilter(searchstring)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              console.log(res)
               let array = [];
              this.loading = false;
              for(let item of res?.responseMessage) {
                let d = new Date(item?.date);
                  item.formattedappointmentDate = moment(d).format('ll');
                  array.push(item);
                }
              
              setTimeout(() => {
                this.totalSize = res?.pagination?.total;
                ///this.stockinArraydataSource.paginator = this.stockinlistpaginator
              });

              this.stockinArraydataSource = new MatTableDataSource(res?.responseMessage);
              if(this.stockinArraydataSource.data.length === 0) {
                this.listdata = true;
              }
              else {
                this.listdata = false;
              }
               
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.loading = false;
            });
      }
      }

      filterGetnext(event) { 
        this.loading = true;
        this._DoctorService.stockinlistfilterwithpageSize(this.Fsearchstring,event.pageIndex, event.pageSize)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {          
              let array = [];                    
              this.loading = false;
              for(let item of res?.responseMessage) {
                let d = new Date(item?.date);
                  item.formattedappointmentDate = moment(d).format('ll');
                  array.push(item);
              }
              this.stockinArraydataSource = new MatTableDataSource(array);
              if (this.stockinArraydataSource.data.length === 0) {
                this.listdata = true;
                this.filterData = true;
              }
              else {
                this.listdata = false;
                this.filterData = false;
              }
             
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
              this.loading = false;
            });
      }

}
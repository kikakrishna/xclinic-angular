import { RouterModule } from '@angular/router';
import { ClinicadminStockinlistComponent } from './clinicadmin-stockinlist.component';
export const ClinicadminStockinlistRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockinlistComponent,
    }
]
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockinlistComponent } from './clinicadmin-stockinlist.component';

describe('ClinicadminStockinlistComponent', () => {
  let component: ClinicadminStockinlistComponent;
  let fixture: ComponentFixture<ClinicadminStockinlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockinlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockinlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

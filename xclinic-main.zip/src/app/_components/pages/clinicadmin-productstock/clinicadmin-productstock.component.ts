import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild,ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';

export interface PeriodicElement {
  productcode: number;
  productname: string;
  stockqty:number;
  action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {productcode:12133143124,productname:'product 1',stockqty:300, action:'' },
  {productcode:436436457,productname:'product 2',stockqty:300, action:'' },
  {productcode:234234223,productname:'product 3',stockqty:400, action:'' },
];

@Component({
  selector: 'app-clinicadmin-productstock',
  templateUrl: './clinicadmin-productstock.component.html',
  styleUrls: ['./clinicadmin-productstock.component.css']
})
export class ClinicadminProductstockComponent implements OnInit {

// ViewChild is used to access the input element.
  @ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', {static: false})InputVar: ElementRef;
      
  clinicId:any;
  displayedColumns: string[] = ['productcode', 'productname', 'stockqty','action', ];

  public dataSource: any = new MatTableDataSource([]);
  createproduct: FormGroup;
  total:any;
  granttotal:any;
  clinicid:any;
  chargesCategory:any;
  chargesTax:any;
  chargesUnit:any;
  addressmodel:any;
  hidediv:boolean = false;
  note:any;
  domaincurrency:any;
  productids:any;
  servid:any;
  loading:boolean;
  btnCreate:boolean;
  tableArray: any = [];
  productunitArray: any = [];
  locationarray: any = [];
  categoryarray: any = [];
  taxarray: any = [];
  public totalSize = 0;
  public pageindex = 0;

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('createpaginator', { read: MatPaginator }) createpaginator: MatPaginator;

  ngOnInit(): void {
  this.loading = true;
  setTimeout(()=>{
   this.loading = false;
  },2000)

    this.createproduct = this._formBuilder.group({
      name: [''],
      price: [''],
      code: [''],
      unittype: [''],
      category: [''],
      reorderevel: [''],
      taxtype: [''],
      typevalue: [''],
    });

   this.btnCreate = history.state.btnAction;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('stockinwardId')) {
        this.servid = params?.get('stockinwardId');
      }
    });

  console.log(this.servid);
  this.domaincurrency = sessionStorage.getItem('domaincurrencydetails');
  this.clinicid = sessionStorage.getItem('clinicId');

  this._DoctorService.getproductstocklist(0,5)
    .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];

          this.addressmodel = res?.responseMessage;
          console.log(this.addressmodel);
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
   }


 editclick(ele){
  this.router.navigate([`/thealth/clinicadmin/producttransactions/${ele.productid}`], { state: { stockstatus: ele, btnAction:false } });
  }

  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getproductstocklist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }


}
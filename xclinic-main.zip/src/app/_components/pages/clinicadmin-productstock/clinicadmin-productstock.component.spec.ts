import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminProductstockComponent } from './clinicadmin-productstock.component';

describe('ClinicadminProductstockComponent', () => {
  let component: ClinicadminProductstockComponent;
  let fixture: ComponentFixture<ClinicadminProductstockComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminProductstockComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminProductstockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

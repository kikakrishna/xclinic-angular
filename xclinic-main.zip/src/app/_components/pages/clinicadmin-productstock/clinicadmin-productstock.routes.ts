import { RouterModule } from '@angular/router';
import {ClinicadminProductstockComponent } from './clinicadmin-productstock.component';
export const ClinicadminProductstockRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminProductstockComponent,
    }
]
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-clincadmin-dialogcode-mappingdelete',
  templateUrl: './clincadmin-dialogcode-mappingdelete.component.html',
  styleUrls: ['./clincadmin-dialogcode-mappingdelete.component.css']
})
export class ClincadminDialogcodeMappingdeleteComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<ClincadminDialogcodeMappingdeleteComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
  }

  onNoClick(): void {
    this.dialogRef.close({data:"no"});
  }
  conform(){
    this.dialogRef.close({data:"conform"});

  }
}

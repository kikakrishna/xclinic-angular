import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClincadminDialogcodeMappingdeleteComponent } from './clincadmin-dialogcode-mappingdelete.component';

describe('ClincadminDialogcodeMappingdeleteComponent', () => {
  let component: ClincadminDialogcodeMappingdeleteComponent;
  let fixture: ComponentFixture<ClincadminDialogcodeMappingdeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClincadminDialogcodeMappingdeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClincadminDialogcodeMappingdeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

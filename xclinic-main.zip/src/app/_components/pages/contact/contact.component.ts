import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators, FormControl } from '@angular/forms';
import { PatientService } from 'src/app/_services/patient.service';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  cliniclogo: any;
  clinicdetails: any;
  isImgLoaded: boolean = false;
  msgShow: boolean = false;
  msgShowText: string;
  caddress: string;
  cstreet: string;
  cpincode: string;
  ccountryname: string;
  cstate: string;
  ccity: string;
  cemail: string;
  cphone: string;
  emailicon: string;
  phoneicon: string;
  subscription: any;
  contactform: FormGroup;
  minlen: any;
  maxlen: any;
  address: any;
  clinaddress: any;
  street: any;
  city: any;
  state: any;
  pincode: any;
  phoneno: any;
  email: any;
  validatemyemail: boolean;
  otherlocationsarray: any = [];
  socilicons: any;
  clinicID: any;
  loading: boolean;

  constructor(private _patientservice: PatientService, private _formBuilder: FormBuilder, public toastrService: ToastService,) { }

  ngOnInit(): void {
    this.subscription = this._patientservice.details.subscribe(res => {
      console.log(res)
      if(!res.isError){        
        this.cliniclogo = res.responseMessage.logoURL;
        this.clinicdetails = res.responseMessage;
        this.caddress = this.clinicdetails.clinicAddress + ',';
        this.cstreet = this.clinicdetails.clinicStreet + ',';
        this.ccity =this.clinicdetails.clinicCity + ',';
        this.cstate = this.clinicdetails.clinicState + '-' + this.clinicdetails.clinicPincode + ',';
        this.ccountryname = this.clinicdetails.clinicCountryName;
        this.cemail = this.clinicdetails.clinicEmail;
        this.cphone = this.clinicdetails.clinicPhoneNumber;
        this.emailicon = "mdi mdi-email";
        this.phoneicon = "mdi mdi-cellphone";
      }
    });

    this.minlen = sessionStorage.getItem("minlen");
    this.maxlen = sessionStorage.getItem("maxlen");

    this.contactform = this._formBuilder.group({
      firstname: [''],
      lastname: [''],
      email: ['', [Validators.email,Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      phoneno: ['', [Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      yourmessage: ['']
    });

    this.clinicdetails = this._patientservice.Domdetails.responseMessage;
    this.clinicID = this.clinicdetails.clinicId;

    this.clinaddress = this.clinicdetails.clinicAddressModel
        console.log(this.clinaddress)
        for(let i=0;i<this.clinaddress.length;i++){
          if(this.clinaddress[i].defaultclinic == true){
            this.address = this.clinaddress[i].clinicAddress + ',';
            this.street = this.clinaddress[i].clinicStreet + ',';
            this.city = this.clinaddress[i].clinicCity + ',';
            this.state = this.clinaddress[i].clinicState;
            this.pincode = this.clinaddress[i].clinicPincode;
            this.phoneno = this.clinaddress[i].clinicphonenumber;
            this.email = this.clinaddress[i].clinicemail;

          }
          else{
            this.otherlocationsarray.push(this.clinaddress[i])
          }
        }
  }

  sendform(){

     if(this.validatemyemail == false) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Invalid Email Address', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);

      return;
    }
    if (this.contactform.value.firstname == "" || this.contactform.value.lastname == "" ||
      this.contactform.value.email == "" || this.contactform.value.phoneno == "" ||
      this.contactform.value.yourmessage == "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Enter all the Mandatory Fields', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);
      return;
    }

    let payload: any = {
        "FirstName": this.contactform.value.firstname,
        "LastName": this.contactform.value.lastname,
        "Email": this.contactform.value.email,
        "MobileNumber":this.contactform.value.phoneno,
        "Comments": this.contactform.value.yourmessage,
        "ClinicId": this.clinicID
    }
    this.loading = true;
  
    if(this.contactform.value.yourmessage !== ''){
     this._patientservice.enqcontactsubmit(payload)
    .pipe(first())
    .subscribe((res: any) => {
    console.log('contact response', res)
    if (!res.isError) {
    this.loading = false;
    this.contactform.reset();
    this.msgShow = true;
    this.msgShowText = res.responseMessage;
     setTimeout(() =>{
      this.msgShow = false;
      this.msgShowText = '';
     },3000)
    }
    else {
    this.loading = false;
    this.contactform.reset();
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', res.errorMessage, options);
    }
    },
    err => {
    this.loading = false;
    this.contactform.reset();
    this.msgShow = false;
    const options = { opacity: 1, timeOut: 3000, tapToDismiss: true };
    //this.toastrService.success('','We have received your request and our team will get back to you at the earliest.', options);
    });
    }
  }

   save(event) {
    const regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (regularExpression.test(String(event.target.value).toLowerCase())) {
      this.validatemyemail = true
    }
    else {
      this.validatemyemail = false;
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}

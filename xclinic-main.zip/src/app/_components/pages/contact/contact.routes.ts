import { RouterModule } from '@angular/router';
import { ContactComponent } from './contact.component';
export const ContactRoutes: RouterModule[] = [
    {
        path: '',
        component: ContactComponent,
    }
]

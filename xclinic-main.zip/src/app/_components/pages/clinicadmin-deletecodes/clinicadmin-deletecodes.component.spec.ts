import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeletecodesComponent } from './clinicadmin-deletecodes.component';

describe('ClinicadminDeletecodesComponent', () => {
  let component: ClinicadminDeletecodesComponent;
  let fixture: ComponentFixture<ClinicadminDeletecodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeletecodesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeletecodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { RouterModule } from '@angular/router';
import { ClinicadminHeaderbannerComponent } from './clinicadmin-headerbanner.component';
export const ClinicadminHeaderbannerRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminHeaderbannerComponent,
    }
]
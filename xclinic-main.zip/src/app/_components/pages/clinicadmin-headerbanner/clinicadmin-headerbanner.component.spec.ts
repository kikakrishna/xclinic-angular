import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminHeaderbannerComponent } from './clinicadmin-headerbanner.component';

describe('ClinicadminHeaderbannerComponent', () => {
  let component: ClinicadminHeaderbannerComponent;
  let fixture: ComponentFixture<ClinicadminHeaderbannerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminHeaderbannerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminHeaderbannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

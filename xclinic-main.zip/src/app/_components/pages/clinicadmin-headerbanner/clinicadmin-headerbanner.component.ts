import { Component, OnInit, ViewChild,ElementRef  } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDeleteserviceComponent } from '../clinicadmin-deleteservice/clinicadmin-deleteservice.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-clinicadmin-headerbanner',
  templateUrl: './clinicadmin-headerbanner.component.html',
  styleUrls: ['./clinicadmin-headerbanner.component.css']
})

export class ClinicadminHeaderbannerComponent implements OnInit {
@ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', {static: false})InputVar: ElementRef;

  clinicId:any;
  displayedColumns: string[] = ['text','action'];
  public ClnicArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  addressmodel: any;
  createheader: FormGroup;
  imgfileWeb: any;
  imgfileonupdateWeb: boolean = false;
  imgerrorWeb: any;

  imgfileRes: any;
  imgfileonupdateRes: boolean = false;
  imgerrorRes: any;
  positionselect:any;
  positions:any;

  btnEnable: boolean = true;

  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
     private _formBuilder: FormBuilder,
    private router: Router,
    public dialog: MatDialog,
    ) { }


  ngOnInit(): void {
    this.loading = true;
    this.btnEnable = true;
    
     this.createheader = this._formBuilder.group({
      text: ['', [Validators.required,Validators.maxLength(100),Validators.pattern('^.{100,}$')]],
      position: ['', Validators.required],
    });

    this.positions = [
    {value: 'left', viewValue: 'Left'},
    {value: 'right', viewValue: 'Right'},
    ];

    this.clinicId = sessionStorage.getItem('clinicId');
     this.ClnicArraydataSource.paginator = this.paginator;
    this._DoctorService.getheaderbanner()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = [res?.responseMessage];
          //this.positionselect = 1;

          this.ClnicArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }


  createclick(){
      this.router.navigate([`/thealth/clinicadmin/headerbanner`], { state: { servicestatus: 'create', btnAction:true } });
  }


  editclick(ele){
  this.positionselect = this.addressmodel[0].position;
  this.btnEnable = false;
  this.imgfileWeb = null;
  this.imgfileRes = null;
    this.createheader.get('text').setValue(this.addressmodel[0].text);
    this.createheader.get('position').setValue(this.addressmodel[0].position);
      }

  deleteclick(deldata) {
  this.loading = false;
  const dialogRef = this.dialog.open(ClinicadminDeleteserviceComponent, {
  panelClass: 'deletewrapper',
  data: deldata.clinicserviceid
  });
  dialogRef.afterClosed().subscribe(res => {
  if (res) {
  if (!res.data.isError) {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.success('', res.data.responseMessage, options);
    this.headbannerlist();
  } else {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', res.data.errorMessage, options);
  }
  }
  },
  err => {
  this.loading = false;
  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  this.toastrService.warning('', err?.error, options);
  });
  }

  headbannerlist() {
     this._DoctorService.getheaderbanner()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = [res?.responseMessage];
          this.ClnicArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

	 uploadWebimage(event, DocSignFile) {
    let fileExt = event.target.files[0].type.split('/')[1]
    let fileSize = event.target.files[0].size;
    if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || fileExt === 'webp') {
      if (1000 <= fileSize ) {
        this.imgerrorWeb = false;
        let reader = new FileReader(); // HTML5 FileReader API
        let file = event.target.files[0];
        this.imgfileWeb = event.target.files[0];
        this.imgfileonupdateWeb = false;
        if (event.target.files && event.target.files[0]) {
          reader.readAsDataURL(file);
        }
      }
      else {
        DocSignFile.value = ''
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Plesae upload an image above 20kb", options);
      }
    }
    else {
      DocSignFile.value = ''
      this.imgerrorWeb = "Only jpg, jpeg, png file format is accepted"
    }

  }

  uploadResponimage(event, DocSignFileRes) {
  let fileExt = event.target.files[0].type.split('/')[1]
    let fileSize = event.target.files[0].size;
    if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || fileExt === 'webp') {
      if (1000 <= fileSize ) {
        this.imgerrorRes = false;
        let reader = new FileReader(); // HTML5 FileReader API
        let file = event.target.files[0];
        this.imgfileRes = event.target.files[0];
        this.imgfileonupdateRes = false;
        if (event.target.files && event.target.files[0]) {
          reader.readAsDataURL(file);
        }
      }
      else {
        DocSignFileRes.value = ''
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Plesae upload an image above 20kb", options);
      }
    }
    else {
      DocSignFileRes.value = ''
      this.imgerrorRes = "Only jpg, jpeg, png file format is accepted"
    }
  }

	updateService(formData: any, formDirective: FormGroupDirective){
  this.loading = true;
  //console.log(this.imgfileWeb,this.imgfileRes,this.createheader.value.text,this.createheader.value.position)

  // if(this.createheader.value.text == '' || this.createheader.value.text == null ||
  // this.createheader.value.position == '' || this.createheader.value.position == null
  // ){
  //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //   this.loading = false;
  //   this.toastrService.warning('', "Enter all the Mandatory Fields", options);
  //       return;
  //   }

    // if(this.createheader.value.text != '' && this.createheader.value.position != ''){
        
          this._DoctorService.updatehomebanner(this.createheader, this.imgfileWeb,this.imgfileRes)
          .pipe(first())
          .subscribe((res: any) => {
          if (!res.isError) {
          this.headbannerlist();

          this.loading = false;
          this.btnEnable = true;
          formDirective.resetForm();
          this.InputVar.nativeElement.value = "";
          this.myButton.nativeElement.value = "";
          this.createheader.reset(); 
          this.imgfileWeb=null; 
          this.imgfileRes=null; 
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          }

       })

      // }
	}

  Changeposition(){ 
  console.log(this.createheader.value.position)
  }

  bannerReset(formData: any, formDirective: FormGroupDirective)
  {
  formDirective.resetForm();
  this.InputVar.nativeElement.value = "";
  this.myButton.nativeElement.value = "";
  this.createheader.reset();
  this.btnEnable = true; 
  this.imgfileWeb=null; 
  this.imgfileonupdateWeb = false; 
  this.imgfileRes=null; 
  this.imgfileonupdateRes = false; 
  }


}

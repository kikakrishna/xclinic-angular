import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';


@Component({
  selector: 'app-clinicadmin-treatment',
  templateUrl: './clinicadmin-treatment.component.html',
  styleUrls: ['./clinicadmin-treatment.component.css']
})
export class ClinicadminTreatmentComponent implements OnInit {
  displayedColumns: string[] = ['drugname', 'dosage', 'frequency', 'duration', 'instruction', 'drugnotes'];
  displayedColumnsBypatient: string[] = ["file", "reporttype", "action"];
  displayedColumnsBydoctor: string[] = ["file", "action"];
  public viewPrescriptionArray: any = new MatTableDataSource<object>([]);
  public viewTreatmentArray: any = new MatTableDataSource<object>([]);
  public ArrayBypatient: any = new MatTableDataSource<any>([]);
  public ArrayBydoctor: any = new MatTableDataSource<any>([]);
  public labtestDetails: any = [];
  printcontent: any = [];

  loading: boolean;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatPaginator) uploadedbydoctorpaginator: MatPaginator;
  @ViewChild(MatPaginator) uploadedbypatientpaginator: MatPaginator;
  role: string;
  medicalrecordData: any;
  downloaddata: any;
  aptId: any;
  constructor(
    public dialogRef: MatDialogRef<ClinicadminTreatmentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _formBuilder: FormBuilder,
    private _patientservice: PatientService,
    private _DoctorService: DoctorService,
    public toastrService: ToastService,
    private _sanitizer: DomSanitizer,) {
    this.role = sessionStorage.getItem('Role');
    this.medicalrecordData = data;
    this.ArrayBypatient.paginator = this.uploadedbydoctorpaginator;
    this.ArrayBydoctor.paginator = this.uploadedbypatientpaginator;
  }

  ngOnInit(): void {
    this.loading = true;
    this.viewPrescriptionArray = new MatTableDataSource;
    this.viewTreatmentArray = new MatTableDataSource;


    this._DoctorService.doctortreatment(this.data?.appointmentId)

      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.aptId = res?.responseMessage?.appointmentId;
          this.viewTreatmentArray = new MatTableDataSource(res?.responseMessage?.viewTreatment);
          this.viewPrescriptionArray = new MatTableDataSource(res?.responseMessage?.viewPrescription);
          setTimeout(() => this.viewPrescriptionArray.paginator = this.paginator);
          this.recordlist()
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    this.getlabtest();
  }

  SelecttabClick(event) {
    console.log(event.tab.textLabel)
    if (event.tab.textLabel == "Medical Records") {
      this.recordlist();
    }

  }
  getlabtest() {
    this._DoctorService.getlabtest(this.data?.appointmentId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.labtestDetails = res?.responseMessage;
          console.log(res);
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  recordlist() {
    let filetype;
    let myfilename;
    let filetype2;
    let myfilename2;
    this.loading = true;
    let array = [];
    let array2 = [];
    this.ArrayBypatient.length = 0;
    this.ArrayBydoctor.length = 0;
    this._patientservice
      .viewapptuploadsbypatientanddoctor(this.medicalrecordData.appointmentId, this.medicalrecordData.patientId)
      .pipe(first())
      .subscribe(
        (res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            setTimeout(() => {
              this.ArrayBypatient.paginator = this.uploadedbydoctorpaginator;
              this.ArrayBydoctor.paginator = this.uploadedbypatientpaginator;
            });
            for (let item of res?.responseMessage[0].medicalRecordsByPatient) {
              myfilename = item.displayName.split(".").pop();
              if (myfilename == 'jpg' || myfilename == 'jpeg' || myfilename == 'png' ||
                myfilename == 'gif' || myfilename == 'bmp' || myfilename == 'tif' ||
                myfilename == 'eps' || myfilename == 'tiff') {

                item.filetype = "imageformat";

              } else if (myfilename == 'docx' || myfilename == 'doc' || myfilename == 'pdf' ||
                myfilename == 'xls' || myfilename == 'txt' || myfilename == 'xlsx') {

                item.filetype = "textformat";

              } else if (myfilename == 'mp4' || myfilename == 'wmv' || myfilename == 'avi' ||
                myfilename == 'mkv' || myfilename == '3gp' || myfilename == 'mov' ||
                myfilename == 'mxf' || myfilename == 'mts/m2ts' || myfilename == 'asf') {

                item.filetype = "videoformat"
              } else {
                item.filetype = "fileformat"
              }
              array.push(item);
            }
            for (let item of res?.responseMessage[0].medicalRecordsByDoctor) {
              myfilename2 = item.displayName.split(".").pop();
              if (myfilename2 == 'jpg' || myfilename2 == 'jpeg' || myfilename2 == 'png' ||
                myfilename2 == 'gif' || myfilename2 == 'bmp' || myfilename2 == 'tif' ||
                myfilename2 == 'eps' || myfilename2 == 'tiff') {

                item.filetype2 = "imageformat";

              } else if (myfilename2 == 'docx' || myfilename2 == 'doc' || myfilename2 == 'pdf' ||
                myfilename2 == 'xls' || myfilename2 == 'txt' || myfilename2 == 'xlsx') {

                item.filetype2 = "textformat";

              } else if (myfilename2 == 'mp4' || myfilename2 == 'wmv' || myfilename2 == 'avi' ||
                myfilename2 == 'mkv' || myfilename2 == '3gp' || myfilename2 == 'mov' ||
                myfilename2 == 'mxf' || myfilename2 == 'mts/m2ts' || myfilename2 == 'asf') {

                item.filetype2 = "videoformat"
              } else {
                item.filetype2 = "fileformat"
              }
              array2.push(item);
            }
            console.log(array2)
            this.ArrayBypatient = new MatTableDataSource(array);
            this.ArrayBydoctor = new MatTableDataSource(array2);

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      );
  }
  downloadMedicalRecordfile(SelectedRecord) {
    this.toastrService.clear();
    this.loading = true;
    this._DoctorService
      .getfiledownload(SelectedRecord?.recordGUID, SelectedRecord?.patientId)
      .pipe(first())
      .subscribe(
        (res: any) => {
          if (!res.isError) {
            this.loading = false;
            const newBlob = new Blob([res], { type: 'application/pdf' });
            const file_path = window.URL.createObjectURL(res);
            const down = document.createElement('A') as HTMLAnchorElement;
            down.href = file_path;
            down.download = SelectedRecord?.displayName;
            document.body.appendChild(down);
            down.click();
            document.body.removeChild(down);
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
        (err) => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        }
      );
  }
  downloadlabtest(appointmentId) {
    this.loading = true;
    this._DoctorService.downloadlabtest(appointmentId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res?.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.downloaddata = window.URL.createObjectURL(res);
          const file_path = this.downloaddata;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "LabTest-" + appointmentId;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // this.errormessagebox = true;
          // this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          // this.forbiddenmessagebox = true;
          // this.messagecontent = err.error;
        })
  }

  downloadEprescription(aId) {
    this.loading = true;
    this._DoctorService.eprescription(aId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.downloaddata = window.URL.createObjectURL(res);
          const file_path = this.downloaddata;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Prescription-" + aId;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          // this.errormessagebox = true;
          // this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          // this.forbiddenmessagebox = true;
          // this.messagecontent = err.error;
        })
  }
  Printprescription(): void {
    console.log(this.data?.appointmentId);

    this._DoctorService.printfunc(this.data?.appointmentId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.printcontent = this._sanitizer.bypassSecurityTrustHtml(res?.responseData)
          console.log(this.printcontent);
          setTimeout(() => {
            if (this.printcontent != undefined) {
              console.log("print");

              var printContents, popupWin;
              printContents = document.getElementById('print-section').innerHTML;
              popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
              popupWin.document.open();
              popupWin.document.write(`
                  <html>
                    <head>
                      <title>Print tab</title>
                      <style>
                      //........Customized style.......
                      </style>
                    </head>
                <body onload="window.print();window.close()">${printContents}</body>
                  </html>`
              );
              popupWin.document.close();
            }
          }, 0);

          // this.treatmentArray = res?.responseMessage;
          // this.viewPrescriptionArray = new MatTableDataSource(res?.responseMessage?.viewPrescription);
          // setTimeout(() => this.viewPrescriptionArray.paginator = this.paginator);
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          // this.errormessagebox = true;
          // this.messagecontent = res.errorMessage;
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
    console.log("Printprescription()" + this.printcontent);
    // window.print();
    // let printContents, popupWin;



  }
}
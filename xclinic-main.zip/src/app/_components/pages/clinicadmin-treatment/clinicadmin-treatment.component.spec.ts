import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminTreatmentComponent } from './clinicadmin-treatment.component';

describe('ClinicadminTreatmentComponent', () => {
  let component: ClinicadminTreatmentComponent;
  let fixture: ComponentFixture<ClinicadminTreatmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminTreatmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminTreatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

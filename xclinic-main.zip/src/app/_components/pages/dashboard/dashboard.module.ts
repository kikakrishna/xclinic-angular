import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDividerModule } from '@angular/material/divider';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutes } from './dashboard.routes';
import { LoginFamilymemberListComponent } from '../login-familymember-list/login-familymember-list.component';
import {MatTabsModule} from '@angular/material/tabs';


@NgModule({
  declarations: [DashboardComponent,LoginFamilymemberListComponent],
  imports: [
    RouterModule.forChild(DashboardRoutes),
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatDividerModule,
    MatTabsModule
  ],
  entryComponents: [
    LoginFamilymemberListComponent
  ],
  exports: [DashboardComponent]
})
export class DashboardModule { }

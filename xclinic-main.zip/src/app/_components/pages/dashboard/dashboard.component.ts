import { Component, OnInit } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';
import { ShareDataService } from '../../../_services/sharedata.service';
import { PatientService } from '../../../_services/patient.service';
import { first } from 'rxjs/operators';
import { DoctorService } from '../../../_services/doctor.service';
import * as moment from 'moment';
import { ToastService } from 'ng-uikit-pro-standard';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  appointmsg: any;
  apptmsg: any;
  showmsg: boolean;
  userdetails: any;
  user_id: string;
  apptcount: any;
  add: any;
  street: any;
  cityname: any;
  pincode: any;
  state: any;
  role: string;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  messagebox: boolean;
  errormessagebox: boolean;
  loading: boolean;
  labtestDetails:any =[];
  color: ThemePalette = 'primary';
  mode: ProgressSpinnerMode = 'determinate';
  value = 0;
  overlay: boolean = false;
  profile: string;
  upcominglist: any;
  eprescriptionlist: any;
  data: string;
  listnodata: boolean;
  listaptdata: boolean;
  listepresdata: boolean;
  patage: number;
  appointimg: any;
  uname: string;
  lname: string;
  udetails: any;
  applist: any;
  profileimage: string;
  val: any;
  clinicPatientId: any;

  constructor(private toastrService: ToastService, private sharedataService: ShareDataService, private _patientservice: PatientService, private _DoctorService: DoctorService,) {
    this.appointmsg = this.sharedataService.getSuccessmsg();
    if (this.appointmsg != undefined || null) {
      this.showmsg = true;
    }
    this.listaptdata = true;
    this.user_id = sessionStorage.getItem('userId');
    this.clinicPatientId = sessionStorage.getItem('clinicPatientId');
    this.role = sessionStorage.getItem('Role');
  }
  ngOnInit(): void {
    this.loading = true;
    setTimeout(() => { this.showmsg = false }, 3000);
    if (sessionStorage.getItem('profile') != 'null') {
      this.profile = sessionStorage.getItem('profile');
    } 
    else {
      this.profile = "./assets/images/noimage.webp";
    }
    this.uname = sessionStorage.getItem('userName');
    this.lname = sessionStorage.getItem('lastName');
    this._patientservice.dashboard(this.user_id)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.apptcount = res.responseMessage;

          if(res.responseMessage.appointmentList.length === 0) {
            this.listaptdata = true;
          }
          else {
            this.listaptdata = false;
            console.log(res.responseMessage)

            console.log(res.responseMessage.appointmentList.length - 1)
            // this.upcominglist = res.responseMessage.appointmentList[0]
            // this.appointimg = res?.responseMessage?.appointmentList[0]?.doctorProfileURL
            // this.upcominglist = res.responseMessage.appointmentList[res.responseMessage.appointmentList.length - 1]
            this.upcominglist = res.responseMessage.appointmentList[0]
            this.appointimg = res?.responseMessage?.appointmentList[res.responseMessage.appointmentList.length - 1]?.doctorProfileURL
          }
          this.userdetails = res.responseMessage.patientDetails;
          if(this.userdetails != null){
            this.udetails = this.userdetails;
          }
          if (res.responseMessage.patientDetails.dob != null) {
            this.patage = moment().diff(moment(res.responseMessage.patientDetails.dob, 'YYYYMMDD'), 'years')
          }
          if (res.responseMessage.patientDetails.profileCompletionPercentage != null) {
            this.val = res.responseMessage.patientDetails.profileCompletionPercentage;
            this.value = Math.round(this.val);
          }
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
          this.loading = false;
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });

    this._DoctorService.dasheprescription(3)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          if (res.responseMessage.length != 0) {
            this.listepresdata = false;
            this.eprescriptionlist = res.responseMessage;
          } else {
            this.listepresdata = true;
          }

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });

      this.getAlllabtest()
  }
  // ngOnInit(): void {
  //   this.loading = true;
  //   setTimeout(() => { this.showmsg = false }, 3000);
  //   if (sessionStorage.getItem('profile') != 'null') {
  //     this.profile = sessionStorage.getItem('profile');
  //   } 
  //   else {
  //     this.profile = "./assets/images/noimage.webp";
  //   }
  //   this.uname = sessionStorage.getItem('userName');
  //   this.lname = sessionStorage.getItem('lastName');
  //   this._patientservice.dashboard(this.user_id)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.loading = false;
  //         this.apptcount = res.responseMessage;

  //         if(res.responseMessage.appointmentList.length === 0) {
  //           this.listaptdata = true;
  //         }
  //         else {
  //           this.listaptdata = false;
  //           this.upcominglist = res.responseMessage.appointmentList[0]
  //           this.appointimg = res?.responseMessage?.appointmentList[0]?.doctorProfileURL
  //         }
  //         this.userdetails = res.responseMessage.patientDetails;
  //         if(this.userdetails != null){
  //           this.udetails = this.userdetails;
  //         }
  //         if (res.responseMessage.patientDetails.dob != null) {
  //           this.patage = moment().diff(moment(res.responseMessage.patientDetails.dob, 'YYYYMMDD'), 'years')
  //         }
  //         if (res.responseMessage.patientDetails.profileCompletionPercentage != null) {
  //           this.val = res.responseMessage.patientDetails.profileCompletionPercentage;
  //           this.value = Math.round(this.val);
  //         }
  //       }
  //       else {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //         this.errormessagebox = true;
  //         this.messagecontent = res.errorMessage;
  //         this.loading = false;
  //       }
  //     },
  //       err => {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //       });

  //   this._DoctorService.dasheprescription(3)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.loading = false;
  //         if (res.responseMessage.length != 0) {
  //           this.listepresdata = false;
  //           this.eprescriptionlist = res.responseMessage;
  //         } else {
  //           this.listepresdata = true;
  //         }

  //       } else {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //         this.loading = false;
  //         this.errormessagebox = true;
  //         this.messagecontent = res.errorMessage;
  //       }
  //     },
  //       err => {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //         this.loading = false;
  //         this.forbiddenmessagebox = true;
  //         this.messagecontent = err.error;
  //       });

  //     this.getAlllabtest()
  // }
  tabclick(event, uu){
    if(event.tab.textLabel == "Lab Test"){
      this.getAlllabtest()    
    }
  }
  getAlllabtest(){    
    this._DoctorService.getAlllabtest(3)
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {
        this.loading = false;
        if (res?.responseMessage.length != 0) {
          this.listnodata = false;
          this.labtestDetails = res?.responseMessage;
        } else {
          this.listnodata = true;
        }
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    }, err => {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', err?.error, options);
    });
  }
  
  setlattestval(){
    sessionStorage.setItem("labtest", 'true');
  }
  eprescription(aId) {
    this.loading = true;
    this._DoctorService.eprescription(aId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Prescription-" + aId;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          this.loading = false;
          this.errormessagebox = true;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        })
  }
  changedateformat(date){
    if(date != undefined){
      return moment(date).format('ll');
    }
  }
}

import { RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
export const DashboardRoutes: RouterModule[] = [
    {
        path: '',
        component: DashboardComponent,
    }
]
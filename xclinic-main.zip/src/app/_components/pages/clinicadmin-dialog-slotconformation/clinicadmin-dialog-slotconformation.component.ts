import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-clinicadmin-dialog-slotconformation',
  templateUrl: './clinicadmin-dialog-slotconformation.component.html',
  styleUrls: ['./clinicadmin-dialog-slotconformation.component.css']
})
export class ClinicadminDialogSlotconformationComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<ClinicadminDialogSlotconformationComponent>,
    @Inject(MAT_DIALOG_DATA) public dataval: any) {
      console.log(dataval)
  }

  ngOnInit(): void {
  }
  yes(){
    this.dialogRef.close({ data:"yes" });
  }
  no(){
    this.dialogRef.close({ data:"no" });
  }
  ok(){
    this.dialogRef.close({ data:"no" });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDialogSlotconformationComponent } from './clinicadmin-dialog-slotconformation.component';

describe('ClinicadminDialogSlotconformationComponent', () => {
  let component: ClinicadminDialogSlotconformationComponent;
  let fixture: ComponentFixture<ClinicadminDialogSlotconformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDialogSlotconformationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDialogSlotconformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

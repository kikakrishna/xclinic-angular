import { RouterModule } from '@angular/router';
import { ClinicadminStockissueComponent } from './clinicadmin-stockissue.component';
export const ClinicadminStockissueRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockissueComponent,
    }
]
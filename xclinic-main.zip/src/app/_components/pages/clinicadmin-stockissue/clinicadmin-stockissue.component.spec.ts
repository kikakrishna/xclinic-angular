import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockissueComponent } from './clinicadmin-stockissue.component';

describe('ClinicadminStockissueComponent', () => {
  let component: ClinicadminStockissueComponent;
  let fixture: ComponentFixture<ClinicadminStockissueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockissueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockissueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

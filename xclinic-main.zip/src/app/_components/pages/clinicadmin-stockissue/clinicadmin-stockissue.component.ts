import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';

export interface PeriodicElement {
  productname: string;
  qty: string;
  unittype: string;
  action:string; 
}
const ELEMENT_DATA: PeriodicElement[] = [
  {productname: 'Product 1', qty: '2', unittype: 'Box',  action:'' },
  {productname: 'Product 2', qty: '3', unittype: 'Piece',  action:'' },
  {productname: 'Product 3', qty: '4', unittype:'Box',  action:'' },
];
@Component({
  selector: 'app-clinicadmin-stockissue',
  templateUrl: './clinicadmin-stockissue.component.html',
  styleUrls: ['./clinicadmin-stockissue.component.css']
})

export class ClinicadminStockissueComponent implements OnInit {
  displayedColumns: string[] = [ 'productname','qty', 'unittype','action' ];
  createstockissue: FormGroup;
  public dataSource: any = new MatTableDataSource([]);
  total:any;
  granttotal:any;
  clinicid:any;
  btnCreate:any;
  servid:any;
  chargesProduct:any;
  note:any;
  domaincurrency:any;
  maxDate:any;
  loading:boolean;
  tableArray: any = [];
  inwardArray: any = [];
  locationarray: any = [];
  supplierarray: any = [];
  productarray: any = [];
  tableinwardArray: any = [];

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('createpaginator', { read: MatPaginator }) createpaginator: MatPaginator;

  ngOnInit(): void {
  this.loading = true;
  setTimeout(()=>{
   this.loading = false;
  },2000)

  this.maxDate = new Date();

  this.createstockissue = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      qty: ['', Validators.required],
    });

  this.domaincurrency = sessionStorage.getItem('domaincurrencydetails');
  this.clinicid = sessionStorage.getItem('clinicId');

   this.btnCreate = true;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('clinicissueid')) {
        this.servid = params?.get('clinicissueid');
        this.btnCreate = false;
      }
    })

 
  this.createstockissue = this._formBuilder.group({
      stockdate: [''],
      stockproduct: [''],
      stockissue: [''],
      stockqty: [''],
      stocklocation: [''],
      stockunit: [''],
      stockrefno: [''],
    });
     console.log('issue id', this?.servid);
        if(history.state.servicestatus != undefined){
        if(history.state.servicestatus != 'create')
        {
        this._DoctorService.getstockissuedetails(Number(this?.servid))
        // this._DoctorService.getstockissuedetails(16)
        .pipe(first())
        .subscribe((res: any) => {
        if (!res.isError) {
        console.log('issue details',res)
        this.loading = false;
        let data = res?.responseMessage[0];

        const d = new Date(data?.date) 
              let newdatevalue = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString();

        this.createstockissue.get('stockdate').setValue(newdatevalue);
        
        this.createstockissue.get('stockissue').setValue(data?.issueTo);
        this.createstockissue.get('stocklocation').setValue(data?.cliniclocationmapId);
        this.createstockissue.get('stockrefno').setValue(data?.referenceno);
        this.note = data?.notes;
        data?.clinicStockissue.map((datas,key) =>{

        this.tableArray.push(
        {
          "id": key,
          "productname": datas?.productName,
          "productdate": data?.date,
          "location": data?.cliniclocationmapId,
          "refno": data?.referenceno,
          "qty": datas.quantity,
          "unittype": datas?.unitType,
        })
         })

        this.dataSource = new MatTableDataSource(this.tableArray);
          setTimeout(() => {
          this.dataSource.paginator = this.createpaginator
        });


        }
        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
        }else{
        this.loading = false;
        }
    }else{
        this.loading = false;
    }  

  this._DoctorService.getlocations(this.clinicid)
      .pipe(first())
      .subscribe((res: any) => {
         this.locationarray = res?.responseMessage;
        // console.log('location details',res?.responseMessage);
        },
      err => {
  });

  // Get supplier list 
  this._DoctorService.getSupplierlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.supplierarray = res?.responseMessage;
         // console.log('supplier details',res?.responseMessage);
        },
        err => {
  });

  // Get product list 
  this._DoctorService.getStockIssueProductlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.productarray = res?.responseMessage;
          // console.log('product details',res?.responseMessage);
        },
        err => {
  });

  setTimeout(() => this.dataSource.paginator = this.createpaginator);
    this.dataSource.paginator = this.paginator;
  }

  selectedproduct(event){
  this.chargesProduct = event.value.productName;
   console.log('product change',this.chargesProduct, event.value.productId);
  }

  calculation(event){
   // console.log('calculationevent',event);
    let sumtotal = Number(event.stockqty) * Number(event.stockunit)
    this.total = sumtotal;
  }
 
  addstock(formData: any, formDirective: FormGroupDirective){
    console.log(this.createstockissue.value)
    //this.calculation(this.createstockissue.value);
    if(this.createstockissue.value.stockdate != '' && this.createstockissue.value.stockissue != "" && this.createstockissue.value.stocklocation != ""){
    if(this.createstockissue.value.stockproduct != '' && this.createstockissue.value.stockqty != "" && this.createstockissue.value.stockqty != "" )
    {
    let sumtotal = Number(this.createstockissue.value.stockqty)

    let count = 0;
      if (this.tableArray.length == 0) {
        count = 0;
      } else {
        count = this.tableArray.length + 1;
      }

      this.tableArray.push(
        {
          "id": count,
          //"productname": this.createstockissue.value.stockproduct,
          "productid": this.createstockissue.value.stockproduct.productId,
          "productname": this.chargesProduct,
          "productdate": this.createstockissue.value.stockdate,
          "location": this.createstockissue.value.stocklocation,
          "refno": this.createstockissue.value.stockrefno,
          "qty": this.createstockissue.value.stockqty,
          "unittype": this.createstockissue.value.stockproduct.unitType,
        })

      this.inwardArray.push(
        {
          "Productid": this.createstockissue.value.stockproduct.productId,
          "Quantity": Number(this.createstockissue.value.stockqty)
        })

      this.dataSource = new MatTableDataSource(this.tableArray);
      setTimeout(() => {
      this.dataSource.paginator = this.createpaginator
      });
      this.clearinput(formData,formDirective);

      console.log(this.tableArray);

    }
  }
  else {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please fill all the mandatory fields', options);
  }

  }

  clearinput(formData: any, formDirective: FormGroupDirective) {
 // formDirective.resetForm();
 // this.createstockissue.reset();

 // this.createstockissue.controls['stockproduct','stockqty'].reset();
  this.createstockissue.get('stockproduct').reset();
  this.createstockissue.get('stockqty').reset();
  this.createstockissue.value.stockproduct = "";
  }

  modelChangeQty(data,element){
    if(data != ''){
      let sumtotal = Number(data) * Number(element.unitcost)
      const idx = this.dataSource.data.findIndex((x) => x.id == element.id);
      this.dataSource.data[idx].qty = Number(data);
    }
  }

  modelChangeCost(data,element){
    if(data != ''){
      let sumtotal = Number(element.qty) * Number(data);
      const idx = this.dataSource.data.findIndex((x) => x.id == element.id);
    }
  }

  getstockissueform(){
  this.loading = true;
  console.log(this.note, this.createstockissue.value,this.inwardArray,this.granttotal);
  // product array from DataTable 
  this.tableinwardArray = []
  for(let tableData in this.dataSource.filteredData) {
    this.tableinwardArray.push({
      "Productid": this.dataSource.filteredData[tableData].productid,
      "Quantity": Number(this.dataSource.filteredData[tableData].qty)
    })
  }

  let formobject = {
  "Date": moment(this.createstockissue.value.stockdate).format(),
  "ReferenceNo": this.createstockissue.value.stockrefno,
  "Cliniclocationmapid": this.createstockissue.value.stocklocation,
  "Notes": this.note,
  "Issuetoname": this.createstockissue.value.stockissue,
  "StockIssues": this.tableinwardArray
  }

  this._DoctorService.createstockissuedata(formobject)
    .pipe(first())
        .subscribe((res: any) => {
             if(!res.isError) { 
                console.log(res);
                  this.loading = false;
                  this.createstockissue.reset();
                  this.note = "";
                  this.tableArray = [];
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.responseMessage, options);
                  setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/stockissuelist'])},2000);

             }else{
                 this.loading = false;
                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                 this.toastrService.warning('', res.errorMessage, options);
           }
     });
  }

  deletecharges(data) {
    // const filteredtabl3 = 
    let a = this.tableArray.filter((item) => item.id !== data.id);
    this.dataSource = new MatTableDataSource(a);
    this.tableArray = a;
    this.dataSource.paginator = this.paginator
  }

}
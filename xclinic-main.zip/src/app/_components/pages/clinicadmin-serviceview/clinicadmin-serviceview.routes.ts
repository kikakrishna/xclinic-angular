import { RouterModule } from '@angular/router';
import { ClinicadminServiceviewComponent } from './clinicadmin-serviceview.component';
export const ClinicadminServiceviewRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminServiceviewComponent,
    }
]
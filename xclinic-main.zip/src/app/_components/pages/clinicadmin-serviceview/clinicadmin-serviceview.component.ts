import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDeleteserviceComponent } from '../clinicadmin-deleteservice/clinicadmin-deleteservice.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-clinicadmin-serviceview',
  templateUrl: './clinicadmin-serviceview.component.html',
  styleUrls: ['./clinicadmin-serviceview.component.css']
})
export class ClinicadminServiceviewComponent implements OnInit {
  clinicId:any;
  displayedColumns: string[] = ['title', 'action'];
  public ClnicArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  addressmodel: any;
  publish: any;

  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    private router: Router,
    public dialog: MatDialog,
    ) { }


  ngOnInit(): void {
    this.loading = true;
    this.clinicId = sessionStorage.getItem('clinicId');
    
    this._DoctorService.getServiceslist(this.clinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.ClnicArraydataSource = new MatTableDataSource(this.addressmodel);
           this.ClnicArraydataSource.paginator = this.paginator;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

        this.getPublishService()
  }

  createclick(){
      this.router.navigate([`/thealth/clinicadmin/services/add`], { state: { servicestatus: 'create', btnAction:true } });
  }

  editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/services/edit/${ele.clinicserviceid}`], { state: { servicestatus: ele, btnAction:false } });
      }

  deleteclick(deldata) {
  console.log(deldata)
  this.loading = false;
  const dialogRef = this.dialog.open(ClinicadminDeleteserviceComponent, {
  panelClass: 'deletewrapper',
  data: deldata.clinicserviceid
  });
  dialogRef.afterClosed().subscribe(res => {
  if (res) {
  console.log(res)
  if (!res.data.isError) {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.success('', res.data.responseMessage, options);
    this.serviceslist();
  } else {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', res.data.errorMessage, options);
  }
  }
  },
  err => {
  this.loading = false;
  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  this.toastrService.warning('', err?.error, options);
  });
  }

  serviceslist() {
    this._DoctorService.getServiceslist(this.clinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.ClnicArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  getPublishService() {
    this._DoctorService.getPublishService()
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {
        this.loading = false;
        this.publish = res?.responseMessage;
        console.log(this.publish)
      } else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  UpdateStaus(event) {
    this._DoctorService.updatePublishService(event, this.publish[0].servicetypeid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.getPublishService()
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

}

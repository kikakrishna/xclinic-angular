import { AfterViewInit, Component,ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';

export interface PeriodicElement {
  date: string;
  issueto: string;
  productitems: number;
  location:string;
  refno: number;
  action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {date: '21-05-2022', issueto: 'Admid', productitems: 2, location:'location-1', refno:32422, action:'' },
  {date: '20-05-2022', issueto: 'John', productitems:3, location:'location-2', refno:42423,action:'' },
  {date: '19-05-2022', issueto: 'Michael', productitems:4, location:'location-3', refno:34234,action:'' },
];

@Component({
  selector: 'app-clinicadmin-stockissuelist',
  templateUrl: './clinicadmin-stockissuelist.component.html',
  styleUrls: ['./clinicadmin-stockissuelist.component.css']
})
export class ClinicadminStockissuelistComponent implements OnInit {
  displayedColumns: string[] = [ 'date','issueto', 'productitems','location','refno','action' ];
 // dataSource = ELEMENT_DATA;
  servicestatus:any;
  btnAction:boolean;

  public stockinArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  addressmodel:any;
  clinicId:any;
  
  public totalSize = 0;
  public pageindex = 0;

  applyfilterData: boolean = false;
  public dataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator, { static: false }) stockissuespaginator: MatPaginator;
  public filerpastform_pagination_show: boolean;
  getpendingstate:any;
  filterData: boolean;

  searchinput: any;
  listdata: boolean;


  constructor(
  private _DoctorService: DoctorService,
  private _patientservice: PatientService,
  public toastrService: ToastService,
  private _formBuilder: FormBuilder,
  private router: Router,
     public _activatedRoute: ActivatedRoute,
  public dialog: MatDialog,
    ) { }

  ngOnInit(): void {
    this.loading = true;

    this.clinicId = sessionStorage.getItem('clinicId');
    this.stockinArraydataSource.paginator = this.paginator;
    this._DoctorService.getstockissuelist(0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
        let array = [];
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          console.log('stockissue list', res);

          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          console.log(array)
          this.stockinArraydataSource = new MatTableDataSource(array);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.stockinArraydataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }); 
     }


  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getstockissuelist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          this.stockinArraydataSource = new MatTableDataSource(array);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

   createclick(){
      this.router.navigate([`/thealth/clinicadmin/stockissue/add`], { state: { servicestatus: 'create', btnAction:true } });
  } 

   
  editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/stockissue/edit/${ele.clinicissueid}`], { state: { servicestatus: ele, btnAction:false } });
      }


  //reset
  clearfilter() {
    this.loading = true;
    this.searchinput = "";
    let searchstring = this.searchinput;
    this.applyfilterData= false;
    this._DoctorService.getstockissuelist(0, 5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          let array = [];
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          console.log('stockissue list', res);
          this.totalSize = res.total;
          for (let item of res?.responseMessage) {
            let d = new Date(item?.date);
            item.formattedappointmentDate = moment(item?.date).format('ll');
            array.push(item);
          }

          this.stockinArraydataSource = new MatTableDataSource(array);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;        
             this.dataSource.paginator = this.stockissuespaginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      if (searchstring == "") {
          this.filterData = false;
        }

  }
  
  // search 
  filterString;
  Fsearchstring: string;
  applyFilter2() {
   const filterValue = this.searchinput;
  let searchstring = filterValue.trim();
   console.log(searchstring)
  if(searchstring != "") {
  this.loading = true;
   
   
    if (searchstring) {
      this.applyfilterData = true;
    } else {
      this.applyfilterData = false;
      return;
    }

    this.loading = true;
    this.Fsearchstring = searchstring;
    this._DoctorService.stockissuelistfilter(searchstring)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          let array = [];
          this.loading = false;
          for (let item of res?.responseMessage) {
            item.formattedappointmentDate = moment(item?.date).format('ll');
            array.push(item);
          }
          this.stockinArraydataSource = new MatTableDataSource(array);
          if (this.stockinArraydataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;        
           /// this.stockinArraydataSource.paginator = this.stockissuespaginator
          });
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
        }
  }

//pagination
filterGetnext(event ) {    
  // this.getpendingstate = timeframe;
  this.loading = true;
  this._DoctorService.stockissuefilterwithpageSize(this.Fsearchstring, event.pageIndex,event.pageSize)
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {          
        let array = [];                    
        this.loading = false;
        for (let item of res?.responseMessage) {
          item.formattedappointmentDate = moment(item?.date).format('ll');
          array.push(item);
        }
        this.stockinArraydataSource = new MatTableDataSource(array);
        if (this.stockinArraydataSource.data.length === 0) {
          this.listdata = true;
          this.filterData = true;

        }
        else {
          this.listdata = false;
          this.filterData = false;
        }
       
      }
      else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        this.loading = false;
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        this.loading = false;
      });
}

}
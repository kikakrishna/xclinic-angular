import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockissuelistComponent } from './clinicadmin-stockissuelist.component';

describe('ClinicadminStockissuelistComponent', () => {
  let component: ClinicadminStockissuelistComponent;
  let fixture: ComponentFixture<ClinicadminStockissuelistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockissuelistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockissuelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

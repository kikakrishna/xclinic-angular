import { RouterModule } from '@angular/router';
import { ClinicadminStockissuelistComponent } from './clinicadmin-stockissuelist.component';
export const ClinicadminStockissuelistRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockissuelistComponent ,
    }
]
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDocotorlistfeeComponent } from './clinicadmin-docotorlistfee.component';

describe('ClinicadminDocotorlistfeeComponent', () => {
  let component: ClinicadminDocotorlistfeeComponent;
  let fixture: ComponentFixture<ClinicadminDocotorlistfeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDocotorlistfeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDocotorlistfeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

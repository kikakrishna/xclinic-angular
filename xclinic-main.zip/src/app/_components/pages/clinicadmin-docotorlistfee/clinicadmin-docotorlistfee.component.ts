import { ArrayType } from '@angular/compiler';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDialogSlotconformationComponent } from '../clinicadmin-dialog-slotconformation/clinicadmin-dialog-slotconformation.component';

@Component({
  selector: 'app-clinicadmin-docotorlistfee',
  templateUrl: './clinicadmin-docotorlistfee.component.html',
  styleUrls: ['./clinicadmin-docotorlistfee.component.css']
})
export class ClinicadminDocotorlistfeeComponent implements OnInit {
  doctorfee: FormGroup;
  loading: boolean;
  sessioncurrency: string;
  consultationtypetoppings = new FormControl();
  consultationtypearray: any = []
  Isonline: boolean = false;
  Isoffline: boolean = false;
  ConsultationType: any;
  ctypename: string = "";
  SelectedDoctypes: any;
  // 
  selectedObjects: any[];
  consultationAppoinmntsArray: any = [];
  filteredData: any;
  arrayy: any = [];
  matcheddata: any;
  APPslotstruedata: any;
  constructor(private _formBuilder: FormBuilder,
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ClinicadminDocotorlistfeeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    console.log(data)
  }
  ngOnInit(): void {
    this.docconsultaionslot();
    this.Isonline = false;
    this.Isoffline = false;
    this.doctorfee = this._formBuilder.group({
      // domesticfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // overseasfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // domesticfollowfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // overseasfollowfees: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // clinicvisitconsultationfee: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      // clinicvisitfollowupfee: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]],
      consultationtype: ['']
    });

    // this.doctorfee.get('domesticfees').setValue(this.data?.selectedData?.fees?.domesticConsultation);
    // this.doctorfee.get('overseasfees').setValue(this.data?.selectedData?.fees?.overseasConsultation);
    // this.doctorfee.get('domesticfollowfees').setValue(this.data?.selectedData?.fees?.domesticFollowUp);
    // this.doctorfee.get('overseasfollowfees').setValue(this.data?.selectedData?.fees?.overseasFollowUp);
    // this.doctorfee.get('clinicvisitconsultationfee').setValue(this.data?.selectedData?.fees?.clinicVisitConsultationFee);
    // this.doctorfee.get('clinicvisitfollowupfee').setValue(this.data?.selectedData?.fees?.clinicVisitFollowUpFee);
    this.sessioncurrency = this.data?.currencyDetails?.currencySymbol;
    console.log(this.data)

    this._DoctorService.getappoinmenttype()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.consultationtypearray = res.responseMessage;
          let selecteddata = [];
          for (let item of this.data.selectedData.doctorConsultationType) {
            if (item.status == 1) {
              selecteddata.push(item.typeId)
            }
          }
          this.consultationtypetoppings.setValue(selecteddata);
          this.SelectedDoctypes = selecteddata;
          console.log(this.SelectedDoctypes)
          this.changeconsultation();
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });


  }
  docconsultaionslot() {
    this._DoctorService.getconsultationslotofDoctor(this.data?.selectedData?.doctorId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.consultationAppoinmntsArray = res.responseMessage;
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  //   uncheckeddataarray: any = [];
  //   changeconsultation() {
  //     this.uncheckeddataarray.length = 0;
  //     let array = [];
  //     this.consultationtypetoppings.value.forEach(element => {
  //       this.consultationtypearray.filter(x => {
  //         if (x.appointmentTypeId == element) {
  //           array.push(x)
  //         } else {
  //           this.uncheckeddataarray.push(x)
  //         }
  //       })
  //     });
  //     // console.log(array)
  //     this.unselecteddata.length = 0;
  //     if (array.length == 0) {
  //       this.Isonline = false;
  //       this.Isoffline = false;
  //     }
  //     if (array.length == 2) {
  //       this.Isonline = true;
  //       this.Isoffline = true;
  //       this.ConsultationType = 0;
  //       this.ctypename = "";
  //     } else {
  //       array.forEach(type => {    //   console.log(type)    
  //         if (type.appointmentTypeName === "Clinic Visit") {
  //           this.doctorfee.get('domesticfollowfees').setValue(null);
  //           this.doctorfee.get('domesticfees').setValue(null);
  //           this.Isonline = false;
  //           this.Isoffline = true;
  //           this.ConsultationType = type.appointmentTypeId;
  //           this.ctypename = type.appointmentTypeName;
  //         }
  //         if (type.appointmentTypeName === "Online Consultation") {
  //           this.doctorfee.get('clinicvisitconsultationfee').setValue(null);
  //           this.doctorfee.get('clinicvisitfollowupfee').setValue(null);
  //           this.Isonline = true;
  //           this.Isoffline = false;
  //           this.ConsultationType = type.appointmentTypeId;
  //           this.ctypename = type.appointmentTypeName;
  //         }
  //       });
  // ​
  //       // unchecked items
  //     }
  //     this.unselecteddata.length = 0;
  //     this.uncheckeddataarray.forEach(element => {
  //       this.consultationAppoinmntsArray.filter(appslots => {
  //         if (appslots.consultationTypeId == element.appointmentTypeId) {
  //           this.unselecteddata.push(appslots)
  //         }
  //       })
  //     });
  //     console.log(this.uncheckeddataarray)
  //     console.log(this.unselecteddata)
  //   }
  //   unselecteddata: any=[];
  //   feeSubmit(formData: any, formDirective: FormGroupDirective) {
  //     if (this.consultationtypetoppings.value.length == 0) {
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', "please select consultation type", options);
  //       return
  //     }
  //     if (this.ctypename != "" && this.ctypename == "Online Consultation") {
  //       this.doctorfee.value.clinicvisitconsultationfee = 0;
  //       this.doctorfee.value.clinicvisitfollowupfee = 0;
  //       console.log(this.doctorfee.value.domesticfollowfees)
  //       console.log(this.doctorfee.value.domesticfees)
  //       if (this.doctorfee.value.domesticfollowfees == null || this.doctorfee.value.domesticfollowfees == ""
  //         && this.doctorfee.value.domesticfees == null || this.doctorfee.value.domesticfees == "") {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', "please enter value for online consult", options);
  //         return;
  //       }
  //     }
  //     if (this.ctypename != "" && this.ctypename == "Clinic Visit") {
  //       this.doctorfee.value.domesticfollowfees = 0;
  //       this.doctorfee.value.domesticfees = 0;
  //       if (this.doctorfee.value.clinicvisitconsultationfee == null || this.doctorfee.value.clinicvisitconsultationfee == ""
  //         && this.doctorfee.value.clinicvisitfollowupfee == null || this.doctorfee.value.clinicvisitfollowupfee == "") {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', "please enter value for clinic visit", options);
  //         return;
  //       }
  //     }
  //     if (this.ctypename == "") {
  //       if (this.doctorfee.value.domesticfollowfees == null || this.doctorfee.value.domesticfollowfees == "" &&
  //         this.doctorfee.value.domesticfees == null || this.doctorfee.value.domesticfees == "" &&
  //         this.doctorfee.value.clinicvisitconsultationfee == null || this.doctorfee.value.clinicvisitconsultationfee == "" &&
  //         this.doctorfee.value.clinicvisitfollowupfee == null || this.doctorfee.value.clinicvisitfollowupfee == "") {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', "please enter value for online consult and clinic visit", options);
  //         return;
  //       }
  //     }
  // ​
  //     console.log(this.SelectedDoctypes);
  //     if (this.SelectedDoctypes.length == 2) {
  //       if (this.unselecteddata[0]?.appointmentSlots == true) {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', "Appointments already booked in this consultation type", options);
  //         return;
  //       }else{
  //         if (this.unselecteddata[0]?.slots == true) {
  //           const dialogRef = this.dialog.open(ClinicadminDialogSlotconformationComponent, {
  //             width: '24%',
  //             panelClass: 'editfeewrapper'
  //           });
  //           dialogRef.afterClosed().subscribe(result => {
  //             console.log(result)
  //             if (result) {
  //               if (result.data == "yes") {
  //                 this.aution();
  //               }
  //               if (result.data == "no") {
  //                 return;
  //               }
  //             }
  //           });
  //         }else {
  //           this.aution();
  //         }
  //       }       
  //     } else {
  //       console.log(this.unselecteddata[0])

  //       if (this.unselecteddata[0]?.appointmentSlots == true) {
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', "Appointments already booked in this consultation type", options);
  //         return;
  //       }else{
  //         // return
  //         this.aution();
  //       }
  //     }
  //   }
  // ​
  //   aution() {
  //     // let formDirective: FormGroupDirective
  //     let payloaddata: any = {
  //       domesticfees: Number(this.doctorfee?.value.domesticfees),
  //       domesticfollowfees: Number(this.doctorfee?.value.domesticfollowfees),
  //       overseasfees: Number(this.doctorfee?.value.domesticfees),
  //       overseasfollowfees: Number(this.doctorfee?.value.domesticfollowfees),
  //       clinicvisitconsultationfee: Number(this.doctorfee?.value.clinicvisitconsultationfee),
  //       clinicvisitfollowupfee: Number(this.doctorfee?.value.clinicvisitfollowupfee),
  //       ConsultationType: this.ConsultationType
  // ​
  //     }
  //     console.log(payloaddata)
  //     this.loading = true;
  //     this._patientservice.doctorpay(payloaddata, this.data?.selectedData?.doctorId)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         if (!res.isError) {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.success('', res.responseMessage, options);
  //           // formDirective.resetForm();
  //           this.doctorfee.reset();
  //           this.dialogRef.close({ data: res });
  //         } else {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //         }
  //       },
  //         err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //         });
  //   }

  // submit() {
  //   console.log(this.consultationtypetoppings.value)
  //   if (this.consultationtypetoppings.value.length == 0) {
  //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     this.toastrService.warning('', "Please Select ConsultationType", options);
  //     return;
  //   } else {
  //     let payload = {
  //       "DoctorId": this.data.selectedData.doctorId,
  //       "ConsultationType": this.consultationtypetoppings.value
  //     }
  //     // console.log(payload)
  //     this._patientservice.updatedoctorconsultation(payload)
  //       .pipe(first())
  //       .subscribe((res: any) => {
  //         if (!res.isError) {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.success('', res.responseMessage, options);
  //           // formDirective.resetForm();
  //           // this.doctorfee.reset();
  //           this.dialogRef.close({ data: res });
  //         } else {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', res.errorMessage, options);
  //         }
  //       },
  //         err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //         });
  //   }
  // }
  messageType

  submit() {
    this.APPslotstruedata = "";
    let slotstruedata = "";
    this.arrayy = [];
    console.log(this.consultationtypetoppings.value)


    if (this.consultationtypetoppings.value.length == 0) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Select ConsultationType", options);
      return;
    }
    else {
      console.log(this.filteredData)
      console.log(this.consultationAppoinmntsArray)

      this.matcheddata = this.consultationAppoinmntsArray.filter((o1, i) => {
        return this.filteredData.some((o2) => {
          return o1.consultationTypeId === o2.appointmentTypeId;
        });
      });
      console.log(this.matcheddata)

      this.APPslotstruedata = this.matcheddata.filter((o1, i) => {
        return o1.appointmentSlots === true;
      });
      console.log(this.APPslotstruedata)

      slotstruedata = this.matcheddata.filter((osl, i) => {
        return osl.slots === true;
      });
      console.log(slotstruedata)

      if (this.filteredData.length == 1 && this.APPslotstruedata.length == 1 || slotstruedata.length == 1) {
        // single uncheck process
        if (this.APPslotstruedata[0]?.appointmentSlots == true && slotstruedata[0]['slots'] == true) {
          this.messageType = "Appoinmentslots";
          // with appointment , with slot
          // alert("single with appointment , with slot")
          this.openpopup();
        }
        if (this.APPslotstruedata.length == 0 && slotstruedata[0]['slots'] == true) {
          this.messageType = "slots";
          // no appointment , with slot
          // alert("single no appointment , with slot")
          this.openpopup();
        }

      } else {
        // alert("multiple")

        let anyonetrue = this.matcheddata.filter((osl, i) => {
          return osl.appointmentSlots === true;
        });
        if (this.filteredData.length == 2 && anyonetrue) {
          this.messageType = "Appoinmentslots";
          // with appointment , with slot
          // alert("single with appointment , with slot")
          // this.openpopup();
          // start
          let payload = {
            "DoctorId": this.data.selectedData.doctorId,
            "ConsultationType": this.consultationtypetoppings.value
          }
          console.log(payload)
          this._patientservice.updatedoctorconsultation(payload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res.responseMessage, options);
                // formDirective.resetForm();
                // this.doctorfee.reset();
                this.dialogRef.close({ data: res });
              } else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
          // end
        } else {
          let payload = {
            "DoctorId": this.data.selectedData.doctorId,
            "ConsultationType": this.consultationtypetoppings.value
          }
          console.log(payload)
          this._patientservice.updatedoctorconsultation(payload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res.responseMessage, options);
                // formDirective.resetForm();
                // this.doctorfee.reset();
                this.dialogRef.close({ data: res });
              } else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
        }
      }
      return;

      // if (this.APPslotstruedata.length > 0) {
      //   this.openpopup();
      // }
      // else {
      //   let payload = {
      //     "DoctorId": this.data.selectedData.doctorId,
      //     "ConsultationType": this.consultationtypetoppings.value
      //   }
      //   console.log(payload)
      //   this._patientservice.updatedoctorconsultation(payload)
      //     .pipe(first())
      //     .subscribe((res: any) => {
      //       if (!res.isError) {
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.success('', res.responseMessage, options);
      //         // formDirective.resetForm();
      //         // this.doctorfee.reset();
      //         this.dialogRef.close({ data: res });
      //       } else {
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', res.errorMessage, options);
      //       }
      //     },
      //       err => {
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', err?.error, options);
      //       });
      // }
    }
  }

  openpopup() {
    const dialogRef = this.dialog.open(ClinicadminDialogSlotconformationComponent, {
      width: '24%',
      panelClass: 'editfeewrapper',
      data: this.messageType
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result)
      if (result) {
        if (result.data == "yes") {
          let payload = {
            "DoctorId": this.data.selectedData.doctorId,
            "ConsultationType": this.consultationtypetoppings.value
          }
          console.log(payload)
          this._patientservice.updatedoctorconsultation(payload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // this.toastrService.success('', res.responseMessage, options);
                // formDirective.resetForm();
                // this.doctorfee.reset();
                this.dialogRef.close({ data: res });
              } else {
                this.loading = false;
                // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
        }
        if (result.data == "no") {
          return;
        }
      }
    });
  }

  unselecteddata: any = [];
  uncheckeddataarray: any = [];
  changeconsultation() {

    this.APPslotstruedata = "";
    // this.uncheckeddataarray.length = 0;
    console.log(this.consultationtypetoppings.value)
    console.log(this.consultationtypearray)


    this.filteredData = this.consultationtypearray.filter((o1, i) => {
      return !this.consultationtypetoppings.value.some((o2) => {
        return o1.appointmentTypeId === o2;
      });
    });

    console.log(this.filteredData)
    // let array = [];

    // // pushing unchecked items
    // this.consultationtypetoppings.value.forEach(element => {
    //   console.log(element)
    //   this.consultationtypearray.filter(x => {
    //     console.log(x)
    //     if (x.appointmentTypeId == element) {
    //       array.push(x)
    //     } else {
    //       this.uncheckeddataarray.push(x)
    //     }
    //   })
    // });


    // this.uncheckeddataarray.forEach(uncheckeditems => {
    //   // console.log(uncheckeditems)
    //   this.consultationAppoinmntsArray.filter(appslots => {
    //     // console.log(appslots)
    //     if (appslots.consultationTypeId == uncheckeditems.appointmentTypeId) {
    //       this.unselecteddata.push(appslots)
    //     }
    //   })
    // });


    // console.log(array)
    // console.log(this.unselecteddata)

  }
}
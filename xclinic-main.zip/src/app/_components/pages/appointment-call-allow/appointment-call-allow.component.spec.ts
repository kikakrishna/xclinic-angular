import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppointmentCallAllowComponent } from './appointment-call-allow.component';

describe('AppointmentCallAllowComponent', () => {
  let component: AppointmentCallAllowComponent;
  let fixture: ComponentFixture<AppointmentCallAllowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppointmentCallAllowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppointmentCallAllowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-appointment-call-allow',
  templateUrl: './appointment-call-allow.component.html',
  styleUrls: ['./appointment-call-allow.component.css']
})
export class AppointmentCallAllowComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<AppointmentCallAllowComponent>) { }

  ngOnInit(): void {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}

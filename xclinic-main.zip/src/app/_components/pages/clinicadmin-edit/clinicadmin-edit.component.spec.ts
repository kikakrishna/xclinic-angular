import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminEditComponent } from './clinicadmin-edit.component';

describe('ClinicadminEditComponent', () => {
  let component: ClinicadminEditComponent;
  let fixture: ComponentFixture<ClinicadminEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { RouterModule } from '@angular/router';
import { ClinicadminEditComponent } from './clinicadmin-edit.component';
export const ClinicAdminEditRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminEditComponent,
    }
]
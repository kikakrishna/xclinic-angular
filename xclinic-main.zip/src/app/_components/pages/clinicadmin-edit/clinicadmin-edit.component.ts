import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { filter, first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';

@Component({
  selector: 'app-clinicadmin-edit',
  templateUrl: './clinicadmin-edit.component.html',
  styleUrls: ['./clinicadmin-edit.component.css']
})
export class ClinicadminEditComponent implements OnInit {
  cid: any;
  clinicdetails: any = [];
  createclinic: FormGroup;
  paymentmodetoppings = new FormControl();
  clinicvisitpaymentmodetoppings = new FormControl();
  imageUrl: any;
  count = [];
  public Currencydetails: any = [];
  imgfile: any;
  clinicadminDetail: any = [];
  public paymenttoppingsList: any = [];
  public paymenttoppingsList2: any = [];
  loading: boolean;
  reshaschatbotdata: any
  defaultclinicstate: any;
  defaultfields: boolean;
  videostatus: any;
  locationmapId: any;
  locationdetails: any;
  defaultstate: any;
  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  ngOnInit(): void {
    this.loading = true;
   /// this._activatedRoute.paramMap.subscribe(params => {
     /// if(params?.get('clinicid')) {
       /// this.cid = params?.get('clinicid');
       /// console.log('get params', params?.get('clinicid'))
      ///}
    ///})

    this.statusofdefaultclinic(history.state.defaultclinicstatus);


   /// this.statusofdefaultclinic(JSON.stringify(sessionStorage.getItem('defaultclinicstatus')));
    this.cid = Number(sessionStorage.getItem('eleclinicId'));
    this.locationmapId = Number(sessionStorage.getItem('eleloctionId'));
    this.videostatus = sessionStorage.getItem('videostatus');
    console.log('domain stste', sessionStorage.getItem('videostatus'))

    this.createclinic = this._formBuilder.group({
      clinicname: ['', Validators.required],
      locationname: ['', Validators.required],
      address: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      currency: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9]*$')]],
      clinicemail: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,10}$')]],
      clinicphone: ['', [Validators.required, Validators.min(1)]],
      ClinicAdminFirstName: ['', Validators.required],
      ClinicAdminLastName: ['', Validators.required],
      ClinicAdminEmail: ['', Validators.required],
    });
    this._DoctorService.reloadprofilename();

    this._DoctorService.getcountry()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.count = res?.responseMessage;
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

    this._DoctorService.getCurrency()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.Currencydetails = res?.responseMessage;
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

    this._DoctorService.getclinicval(this?.cid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.clinicdetails = res?.responseMessage;
          this.reshaschatbotdata = res?.responseMessage?.hasChatBot;
          sessionStorage.setItem('userName', res?.responseMessage?.clinicAdminFirstName);
          sessionStorage.setItem('lastName', res?.responseMessage?.clinicAdminLastName);
          sessionStorage.setItem('cliniclogo', res?.responseMessage?.logoURL);
          this.clinicadminDetail = res?.responseMessage;

          for(let item of this.clinicadminDetail?.clinicAddressModel){
            if(item?.clinicLocationMapId == this.locationmapId){
              this.locationdetails = item
            }
          }
          this.defaultstate = this.locationdetails;
          this.createclinic.get('ClinicAdminFirstName').setValue(res?.responseMessage?.clinicAdminFirstName);
          this.createclinic.get('ClinicAdminLastName').setValue(res?.responseMessage?.clinicAdminLastName);
          this.createclinic.get('ClinicAdminEmail').setValue(res?.responseMessage?.clinicAdminEmail);
          this.createclinic.get('clinicname').setValue(res?.responseMessage?.clinicName);
          this.createclinic.get('locationname').setValue(this.locationdetails?.locationName);
          this.createclinic.get('address').setValue(this.locationdetails?.clinicAddress);
          this.createclinic.get('street').setValue(this.locationdetails?.clinicStreet);
          this.createclinic.get('city').setValue(this.locationdetails?.clinicCity);
          this.createclinic.get('state').setValue(this.locationdetails?.clinicState);
          this.createclinic.get('country').setValue(res?.responseMessage?.clinicCountry);
          this.createclinic.get('currency').setValue(res?.responseMessage?.currencyDetails?.currencyId);
          this.createclinic.get('pincode').setValue(this.locationdetails?.clinicPincode);
          this.createclinic.get('clinicemail').setValue(this.locationdetails?.clinicemail);
          this.createclinic.get('clinicphone').setValue(this.locationdetails?.clinicphonenumber);
          this._DoctorService.reloadprofilename();

          if (res?.responseMessage?.logoURL != null) {
            this.imageUrl = res?.responseMessage?.logoURL;
          } else {
            this.imageUrl = './assets/images/default-logo.webp';
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    this.allpaymentMethodtype();
    this.activepaymentActive();
  }

  statusofdefaultclinic(defaultclinstate) {
    ///this.defaultstate = defaultclinstate
    ///this.locationmapId = defaultclinstate.clinicLocationMapId
   setTimeout(()=>{
    if(this.defaultstate.defaultclinic == false){
      this.defaultfields = false
    }
    else{
      this.defaultfields = true
    }
   },2000)

  }

  allpaymentMethodtype() {
    this.loading = true;
    this._DoctorService.getClinicPaymentMethodType()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.paymenttoppingsList = res?.responseMessage
          this.paymenttoppingsList2 = res?.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  activepaymentActive() {
    this.loading = true;
    this._DoctorService.getClinicPaymentActive()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          if (res.responseMessage !== null) {
            let onlineresPayidArray = [];
            let clinicvisisresPayidArray = [];
            console.log(this.paymenttoppingsList);
            
            
            for (let i of res?.responseMessage?.onlinePaymentDetails) {
              onlineresPayidArray.push(i.paymentMethodId)
            }
            for (let i of res?.responseMessage?.clinicVisitPaymentDetails) {
              clinicvisisresPayidArray.push(i.paymentMethodId)
            }
            this.paymentmodetoppings.setValue(onlineresPayidArray);
            this.clinicvisitpaymentmodetoppings.setValue(clinicvisisresPayidArray);

          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    this.imgfile = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
      }
    }
  }

  val(event) {
    console.log(event.target.value.toLowerCase().trim())
  }

  updateclinic() {
    if (this.createclinic.value.ClinicAdminFirstName.trim() == "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'First Name Should Not be Empty', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);
      return;
    }
    if (this.createclinic.value.ClinicAdminLastName.trim() == "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Last Name Should Not be Empty', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);
      return;
    }

    this.loading = true;
    if (this.imgfile === 0 || this.imgfile === null) {
      this.imgfile = null;
    } else if (this.imgfile === undefined) {
      this.imgfile = null;
    }
    this.ClinicUpdate();
  }

  ClinicUpdate() {
    var onlinepaymentid = "";
    var clinicvisitpaymentid = "";
    var onlinecount = 0;
    var clinicvisitcount = 0;

    for (let i of this.paymentmodetoppings.value) {
      onlinecount++;
      if (this.paymentmodetoppings.value.length == onlinecount) {
        onlinepaymentid += i
      } else {
        onlinepaymentid += i + ","
      }
    }
    for (let ci of this.clinicvisitpaymentmodetoppings.value) {
      clinicvisitcount++;
      if (this.clinicvisitpaymentmodetoppings.value.length == clinicvisitcount) {
        clinicvisitpaymentid += ci
      } else {
        clinicvisitpaymentid += ci + ","
      }
    }

    this.createclinic.value.OnlineConsultation = onlinepaymentid;
    this.createclinic.value.ClinicVisit = clinicvisitpaymentid;

   if(this.videostatus == 'true')
   {
    if (this.createclinic.value.ClinicVisit === "" || this.createclinic.value.OnlineConsultation === "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select any one payment mode', options);
      this.loading = false;
      return;
    }
   }

    // this.createclinic.value.PaymentId = onlinepaymentid;    
    this.createclinic.value.hasChatBot = this.reshaschatbotdata;
    this.createclinic.value.CurrencyId = this.createclinic.value.currency;

    //if(this.videostatus == false){
    if(this.defaultstate.defaultclinic == true){

    this._DoctorService.createclinicupdate(this.createclinic.value, this.imgfile, this?.cid, this.locationmapId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          setTimeout(() => {
            this.router.navigate([`/thealth/clinicadmin/view`]);
            this.toastrService.clear(),1000
          }, 1000)
          // this.ngOnInit();
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }
      else{

        this._DoctorService.createclinicupdateseclocation(this.createclinic.value, this.locationmapId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          // this.ngOnInit();
          setTimeout(() => {
            this.router.navigate([`/thealth/clinicadmin/view`]);
            this.toastrService.clear(),1000
          }, 1000)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }


  }
}

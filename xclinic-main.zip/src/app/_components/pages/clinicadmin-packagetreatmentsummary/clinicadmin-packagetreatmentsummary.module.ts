import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { ClinicadminPackagetreatmentsummaryComponent } from './clinicadmin-packagetreatmentsummary.component';
import { ClinicadminPackagetreatmentsummaryRoutes } from './clinicadmin-packagetreatmentsummary.routes';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatStepperModule } from '@angular/material/stepper';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSliderModule }  from '@angular/material/slider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {MatSelectModule} from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter';
@NgModule({
  declarations: [ClinicadminPackagetreatmentsummaryComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(ClinicadminPackagetreatmentsummaryRoutes),
    FormsModule, 
    ReactiveFormsModule, 
    MatCardModule,    
    MatButtonModule,
    MatDividerModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatInputModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatIconModule,
    MatStepperModule,
    MatExpansionModule,
    MatSidenavModule,
    MatSliderModule,
    MatCheckboxModule,
    MatSelectModule,
    MatTableModule,
    NgxMatSelectSearchModule,
    MatDatepickerModule
  ],
  
  exports: [ClinicadminPackagetreatmentsummaryComponent],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    ],
})
export class ClinicadminPackagetreatmentsummaryModule { }

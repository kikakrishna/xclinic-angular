import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { first, retry, take, takeUntil } from 'rxjs/operators';
import * as moment from 'moment';
import { JsonPipe } from '@angular/common';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

export interface PeriodicElement {
  name: string;
  code: string;
  category: string;
  record: string;
  unit: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { name: 'Advil Liqui-Gels', code: '400mg', category: '1-1-1', record: '10 days', unit: 'Apply once a day', action: 'next visit on 23, Jun 2023' },
  { name: 'Advil Liqui-Gels', code: '400mg', category: '1-1-1', record: '10 days', unit: 'Apply once a day', action: 'next visit on 23, Jun 2023' },
];
@Component({
  selector: 'app-clinicadmin-packagetreatmentsummary',
  templateUrl: './clinicadmin-packagetreatmentsummary.component.html',
  styleUrls: ['./clinicadmin-packagetreatmentsummary.component.css']
})
export class ClinicadminPackagetreatmentsummaryComponent implements OnInit {
  displayedColumns: string[] = ['name', 'code', 'category', 'record', 'unit', 'action',];
  //dataSource = ELEMENT_DATA;
  public dataSource: any = new MatTableDataSource([]);
  displayedColumns2: string[] = ['name', 'action',];
  displayedColumns3: string[] = ['name', 'action',];
  //dataSource2 = ELEMENT_DATA;
  public dataSource2: any = new MatTableDataSource([]);
  public dataSource3: any = new MatTableDataSource([]);
  servid: any;
  loading: boolean;
  appointmentarray: any;
  viewform: FormGroup;
  viewarray: any;
  clinicnotesarray: any;
  epresclist: any;
  doctordetailsarray: any;
  aptId: any;
  newdatevalue: any;
  downloaddata: any;
  visitmodel: any;
  labtestmodel: any;
  patientrec: any;
  doctrec: any = [];
  filterid: any = [];
  dropdwn: any;
  ff: any
  printcontent: any = [];

  constructor(private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private router: Router,
    public _activatedRoute: ActivatedRoute,
    private _sanitizer: DomSanitizer,) {

  }

  ngOnInit(): void {
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('patienttrpackagemapid')) {
        this.servid = params?.get('patienttrpackagemapid');
      }
    })
    this.viewform = this._formBuilder.group({
      treatmentview: [''],
    });
    // view DropDown
    this._DoctorService.getview()
      .pipe(first())
      .subscribe((res: any) => {
        this.viewarray = res?.responseMessage;
        let tempview = []
        this.viewarray.map((item) => {
          tempview.push({
            packagetreatmentviewID: item.packagetreatmentviewID,
            packagetreatmentviewName: item.packagetreatmentviewName,
            isChecked: false
          })
        })

        //tempview[0].isChecked=true
        this.viewarray = tempview

        console.log("aass" + JSON.stringify(this.viewarray))


      },
        err => {
        });


    this._DoctorService.packageSummaryDetails(this?.servid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appointmentarray = res?.responseMessage.patientdetail

          let array = []
          for (let item of res?.responseMessage.visitModel) {
            let d = new Date(item?.treatmentAppointmentDetails.date);
            item.treatmentAptDate = moment(d).format('MMM DD,y',);
            array.push(item);
          }
          this.visitmodel = array;
          console.log("visitemodel------------------->" + JSON.stringify(this.visitmodel))

          setTimeout(() => {

          });
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  gobackclk() {
    this.router.navigate([`/thealth/clinicadmin/plantreatmentschedule`]);
  }
  downloadEprescription(aId) {



    console.log("appid============>" + aId)
    this.loading = true;
    this._DoctorService.eprescription(aId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.downloaddata = window.URL.createObjectURL(res);
          const file_path = this.downloaddata;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "Prescription-" + aId;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          // this.errormessagebox = true;
          // this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          // this.forbiddenmessagebox = true;
          // this.messagecontent = err.error;
        })
  }
  downloadlabtest(appointmentId) {

    console.log("appointmentId===========>" + appointmentId)
    this.loading = true;
    this._DoctorService.downloadlabtest(appointmentId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res?.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.downloaddata = window.URL.createObjectURL(res);
          const file_path = this.downloaddata;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = "LabTest-" + appointmentId;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // this.errormessagebox = true;
          // this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          // this.forbiddenmessagebox = true;
          // this.messagecontent = err.error;
        })
  }
  downloadMedicalRecordfile(SelectedRecord) {
    this.toastrService.clear();
    this.loading = true;
    this._DoctorService
      .getfiledownload(SelectedRecord?.path, SelectedRecord?.patientId)
      .pipe(first())
      .subscribe(
        (res: any) => {
          if (!res.isError) {
            this.loading = false;
            const newBlob = new Blob([res], { type: 'application/pdf' });
            const file_path = window.URL.createObjectURL(res);
            const down = document.createElement('A') as HTMLAnchorElement;
            down.href = file_path;
            down.download = SelectedRecord?.displayName;
            document.body.appendChild(down);
            down.click();
            document.body.removeChild(down);
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
        (err) => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        }
      );
  }

  treatmentchange(event: any) {

    console.log("checked" + event)

    let temp = this.viewarray.map((pro) => {
      if (event === pro.packagetreatmentviewID) {
        return { ...pro, isChecked: !pro.isChecked };
      }
      return pro;
    });
    this.viewarray = temp
    console.log("viewarrayyyy----->" + JSON.stringify(this.viewarray))

  }


  SubmitFilter() {
    let filterarray = []

    console.log("array-------->1")
    console.log("array2------------>2" + this.viewarray)
    this.viewarray.map((data) => {
      if (data.isChecked == true) {
        filterarray.push(data.packagetreatmentviewID)
      }
    })

    console.log("arraychech-------->" + JSON.stringify(filterarray))

    // this._activatedRoute.paramMap.subscribe(params => {
    //   if (params?.get('patienttrpackagemapid')) {
    //     this.servid = params?.get('patienttrpackagemapid');
    //   }
    // })
    // this._activatedRoute.paramMap.subscribe(Array => {
    //   if (Array?.get('148,149,147,146')) {
    //     this.filterid = Array?.get('148,149,147,146');
    //   }
    // })
    //  let filterid=[148,149,147,146];
    this.loading = true;
    this._DoctorService.packageSummaryFilter(this.servid, filterarray)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.appointmentarray = res?.responseMessage.patientdetail
          this.visitmodel = res?.responseMessage.visitModel
          let array = []
          for (let item of res?.responseMessage.visitModel) {
            let d = new Date(item?.treatmentAppointmentDetails.date);
            item.treatmentAptDate = moment(d).format('MMM DD,y',);
            array.push(item);
          }
          this.visitmodel = array;
          setTimeout(() => {

          });
          console.log("res------>" + JSON.stringify(res))

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  Printprescription(aId): void {
    console.log(aId);

    this._DoctorService.printfunc(aId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.printcontent = this._sanitizer.bypassSecurityTrustHtml(res?.responseData)
          console.log(this.printcontent);
          setTimeout(() => {
            if (this.printcontent != undefined) {
              console.log("print");

              var printContents, popupWin;
              printContents = document.getElementById('print-section').innerHTML;
              popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
              popupWin.document.open();
              popupWin.document.write(`
                  <html>
                    <head>
                      <title>Print tab</title>
                      <style>
                      //........Customized style.......
                      </style>
                    </head>
                <body onload="window.print();window.close()">${printContents}</body>
                  </html>`
              );
              popupWin.document.close();
            }
          }, 0);

          // this.treatmentArray = res?.responseMessage;
          // this.viewPrescriptionArray = new MatTableDataSource(res?.responseMessage?.viewPrescription);
          // setTimeout(() => this.viewPrescriptionArray.paginator = this.paginator);
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          // this.errormessagebox = true;
          // this.messagecontent = res.errorMessage;
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
    console.log("Printprescription()" + this.printcontent);
    // window.print();
    // let printContents, popupWin;



  }
}

import { RouterModule } from '@angular/router';
import { ClinicadminPackagetreatmentsummaryComponent } from './clinicadmin-packagetreatmentsummary.component';
export const ClinicadminPackagetreatmentsummaryRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminPackagetreatmentsummaryComponent,
    }
]
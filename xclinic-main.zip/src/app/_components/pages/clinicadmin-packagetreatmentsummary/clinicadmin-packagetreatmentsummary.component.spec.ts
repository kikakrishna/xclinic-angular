import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminPackagetreatmentsummaryComponent } from './clinicadmin-packagetreatmentsummary.component';

describe('ClinicadminPackagetreatmentsummaryComponent', () => {
  let component: ClinicadminPackagetreatmentsummaryComponent;
  let fixture: ComponentFixture<ClinicadminPackagetreatmentsummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminPackagetreatmentsummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminPackagetreatmentsummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

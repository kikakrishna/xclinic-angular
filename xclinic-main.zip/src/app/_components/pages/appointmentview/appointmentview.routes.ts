import { RouterModule } from '@angular/router';
import { AppointmentviewComponent } from './appointmentview.component';
export const AppointmentviewRoutes: RouterModule[] = [
    {
        path: '',
        component: AppointmentviewComponent,
    }
]
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
declare var $: any;
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { first } from 'rxjs/operators';
import { PatientService } from '../../../_services/patient.service';
import { DoctorService } from '../../../_services/doctor.service';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
import { PatientCancelComponent } from '../patient-cancel/patient-cancel.component';
import { DeletemrPatientappointmentComponent } from '../deletemr-patientappointment/deletemr-patientappointment.component';
import { ShareDataService } from 'src/app/_services/sharedata.service';


@Component({
  selector: 'app-appointmentview',
  templateUrl: './appointmentview.component.html',
  styleUrls: ['./appointmentview.component.css']
})
export class AppointmentviewComponent implements OnInit {
  public payload: any = {};
  public myHolidayDates: any = [];
  displayedColumns: string[] = ['file', 'reporttype', 'action'];
  dataSource;
  Apptid: number;
  fileToUpload: File[] = [];
  patientvalue: any[] = [];
  createAptDetail: FormGroup;
  updateAppointment: FormGroup;
  filerr: boolean;
  fileerrmsg: string;
  filename: string;
  messagecontent: any;
  listdata: boolean;
  data: string;
  recdate: string;
  dt: any;
  maxdate1 = new Date();
  maxdate = new Date();
  gotodate = new Date();
  resbutton: boolean;
  followbtn: boolean;
  status: any;
  type: any;
  package: any;
  enablefollow: any;
  typelist: any;
  timeslots: any;
  stdate: any;
  noslotmsg: boolean;
  slotimeid: any;
  isShownReshedule: boolean = false;
  errormessagebox: boolean;
  loading: boolean;
  sloterrormsg: boolean;
  isShownbookFollowup: boolean = false;
  profileImage: any;
  currencyDetails: any
  myHolidayFilter
  public myarraystate: any = [];
  filter: string;
  consultationtype: any;
  @ViewChild('descriptionfile') descriptionfile: ElementRef;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  apptstate: string;
  tableTodaydate: any;
  sampledata: any = [];
  vitalist: any;
  vitalist2: any = [];
  vdata: any = [];
  vitaliputvalues: any = [];
  testarray: any = [];
  innervitalist: any = [];
  propname: any;
  delimiter: any;
  nodecimalerror: boolean = false;
  mustdecimalerror: boolean = false;
  checkvalidatearray: any = [];
  grpvitals: any = [];
  grpvitalvalues: any = [];
  truearray: any = [];
  error1: boolean;
  error2: boolean;
  error3: boolean;
  error4: boolean;
  // vitalvalues: any = [];
  // mainpayload: any = {};
  // mainobject: any = {};
  // mainpayload2: any = {};
  // mainarray: any = [];

  constructor(
    private _formBuilder: FormBuilder,
    private _patientservice: PatientService,
    private _activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private router: Router,
    private _DoctorService: DoctorService,
    private sharedataService: ShareDataService,
    private toastrService: ToastService) {
    this.noslotmsg = false;

    this.createAptDetail = this._formBuilder.group({
      recordtype: ['', Validators.required]
    });

    this.updateAppointment = this._formBuilder.group({
      dateofappointment: ['', Validators.required],
      timeslot: [''],
    });
    this.filter = this._activatedRoute.snapshot.params.tId;
  }
  public Isapp_reschebtn: boolean = false;
  public Isapp_cancelbtn: boolean = false;
  public appointmentstatus_text: string = "";

  columnNames;
  data2;

  ngOnInit(): void {

    this.data2 = [
      // {vitalname:"",units:""},
      { vitalname: 'Hydrogen', units: 1.0079 },
    ];
    console.log(this.data2[0])
    Object.keys(this.data2[0])
    this.tableTodaydate = moment(new Date()).format('DD/MM/YYYY, hh:mm A')
    // this.data[0]["vitalname"]=""
    // this.data[0]["units"]=""
    this.data2[0][moment(new Date()).format('DD/MM/YYYY, hh:mm A')] = ""
    this.data2[0][moment(new Date()).subtract(1, 'days').format('DD/MM/YYYY, hh:mm A')] = "100"
    this.data2[0][moment(new Date()).subtract(2, 'days').format('DD/MM/YYYY, hh:mm A')] = "200"

    console.log(this.data2[0])

    for (let i = 0; i < this.data2.length; i++) {
      this.data2[i]["vitalname"] = "Height"
      this.data2[i]["units"] = "Cms"
      // this.data[i][moment(new Date()).format('DD/MM/YYYY')] = ""
      // this.data[i][moment(new Date()).subtract(1, 'days').format('DD/MM/YYYY')] ="towo"+i
      // this.data[i][moment(new Date()).subtract(2, 'days').format('DD/MM/YYYY')] = "threee"+i
    }

    console.log(this.data2[0])

    this.columnNames = Object.keys(this.data2[0]);

    this.fileToUpload = [];
    this.patientvalue = [];
    this._activatedRoute.paramMap.subscribe(params => {
      this.Apptid = +params.get('aptId');
      this.apptstate = params.get('tId');
      console.log(this.apptstate)

      this._patientservice.Followupdoctordetails = "";
    });

    this._patientservice.appointmentdetail(this.Apptid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.currencyDetails = res?.responseMessage?.currencyDetails?.preferedCurrencyDisplay
          this.dt = res.responseMessage;
          this.status = res.responseMessage.status;
          this.type = res.responseMessage.type;
          this.package = res.responseMessage.package;
          this.enablefollow = res.responseMessage.followUp.followUpStatus;
          const currentdate = moment(this.maxdate).format('L');
          const apptdate = moment(res.responseMessage.appointmentDate).format('L');
          if (Date.parse(apptdate) > Date.parse(currentdate)) {
            // upcoming
            // alert("upcoming")
            this.appointmentstatus_text = "upcoming"

          } else if (Date.parse(apptdate) < Date.parse(currentdate)) {
            // past
            // alert("past")
            this.appointmentstatus_text = "past"
          } else {
            // today
            // alert("today")
            this.appointmentstatus_text = "today"
          }
          if (res.responseMessage.type == "walk_in") {

            this.Isapp_reschebtn = false;
            this.Isapp_cancelbtn = false;
            // if ((res?.responseMessage?.status == 'cancelled') || (res?.responseMessage?.status == 'past') ||
            //   this.appointmentstatus_text == "past" && res?.responseMessage?.status !== "completed") {
            //   this.Isapp_reschebtn = false;
            //   this.Isapp_cancelbtn = false;
            // } else {
            //   this.Isapp_reschebtn = false;
            //   this.Isapp_cancelbtn = true;
            // }

            // if (res?.responseMessage?.status == "completed") {
            //   this.Isapp_reschebtn = false;
            //   this.Isapp_cancelbtn = false;
            // }
          }
          if ((res?.responseMessage?.type == "visit_to_clinic" || res?.responseMessage?.type == "online")) {


            if ((res?.responseMessage?.type == "visit_to_clinic" || res?.responseMessage?.type == "online") &&
              (this.appointmentstatus_text == "today" && res?.responseMessage?.status == "completed")) {
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            }

            // only for cancelled            
            if (res?.responseMessage?.status == "cancelled" &&
              res?.responseMessage?.typeDisplayName == "Video Consultation" ||
              res?.responseMessage?.typeDisplayName == "Clinic Visit") {
              // alert("tet")
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            }

            if (
              (res?.responseMessage?.status !== "cancelled") &&
              (res?.responseMessage?.status !== "completed") &&
              (res?.responseMessage?.type == "visit_to_clinic" || res?.responseMessage?.type == "online") &&
              (this.appointmentstatus_text == "upcoming" || this.appointmentstatus_text == "today")
            ) {
              this.Isapp_reschebtn = true;
              this.Isapp_cancelbtn = true;
            } else {
              this.Isapp_reschebtn = false;
              this.Isapp_cancelbtn = false;
            }

          }

          if (this.type == 'online') {
            this.consultationtype = 1;
          } else {
            this.consultationtype = 2;
          }
          this.dateSlots()
          if (Date.parse(apptdate) >= Date.parse(currentdate)) {
            this.resbutton = true;
          } else {
            this.resbutton = false;
          }
          if (Date.parse(apptdate) <= Date.parse(currentdate)) {
            this.followbtn = true;
          } else {
            this.followbtn = false;
          }
          if (res.responseMessage.doctorProfileURL != null) {
            this.profileImage = res.responseMessage.doctorProfileURL;
          } else {
            this.profileImage = "./assets/images/noimage.webp";
          }
        }
        else {
          this.messagecontent = res.errorMessage;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.messagecontent = err.error;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

    this.recordlist();

    this._patientservice.recordtypeapi()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.typelist = res.responseMessage;
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errrorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  onTabChanged(event) {
    console.log(event)
    if (event.tab.textLabel == 'Vitals') {
      this.getvitalist(this.Apptid)
    }
  }

  getvitalist(apid) {
    this.loading = true
    this._patientservice.vitalistget(apid)
      .pipe(first())
      .subscribe((res: any) => {
        this.loading = false
        if (!res.isError) {
          this.vitalist = res.responseMessage;
          console.log(this.vitalist)


          console.log(this.vitalist)
          for (let i = 0; i < this.vitalist.length; i++) {
            this.vdata = this.vitalist[i].vitallist
            for (let j = 0; j < this.vdata.length; j++) {
              // let array=[];
              this.vdata[j]['userinputvalues'] = {}
            }
          }
          console.log(this.vitalist)
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errrorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  //   "vitalvalues": [
  //     {
  //         "vitalsid":6,
  //         "values":"60/100"
  // },
  //   {
  //         "vitalsid":7,
  //         "values":"+80"
  // }



  //   "Appointmentid" :31,  
  //      "Groupvitals": [
  //          {
  //             "Groupid":1547,
  //             "vitalvalues": [
  //                 {
  //                     "vitalsid":6,
  //                     "values":"60/100"
  //             },
  //               {
  //                     "vitalsid":7,
  //                     "values":"+80"
  //             }
  //             ]
  //          },
  public Gropmyarray: any = []

  check() {
    //     for (let group of this.vitalist) {
    //       console.log(group)
    //       for(let i of group.vitallist){
    //         console.log(i)
    //         var propOwn = Object.getOwnPropertyNames(i?.userinputvalues);
    //  console.log(propOwn)
    //         // if(i?.userinputvalues)
    //       }
    //     }

    //     return;
    this.truearray = []
    this.grpvitalvalues = []
    this.grpvitals = []
    this.checkvalidatearray = []

    console.log(this.truearray)
    console.log(this.grpvitalvalues)
    console.log(this.grpvitals)

    console.log(this.vitalist)

    this.loading = true;
    let mainpayload = {}
    mainpayload["Appointmentid"] = this.Apptid;
    var mainarray = [];
    for (let i of this.vitalist) {
      var ipayload = {};
      console.log(i)
      var inArray = [];
      for (let item of i.vitallist) {
        let payload = {}
        var propOwn = Object.getOwnPropertyNames(item?.userinputvalues);
        console.log(propOwn)
        if (propOwn.length == 2) {

          console.log(item?.configmetadata?.fractiondelimiter)
          if (item?.configmetadata?.fractiondelimiter != 0 || item?.configmetadata?.fractiondelimiter != 'null') {
            this.delimiter = item?.configmetadata?.fractiondelimiter
          }

          // payload['values'] = Object.values(item?.userinputvalues)[0] + "/" + Object.values(item?.userinputvalues)[1]
          payload['values'] = Object.values(item?.userinputvalues)[0] + this.delimiter + Object.values(item?.userinputvalues)[1]
          payload['vitalsid'] = item?.vitalid
        } else {
          payload['values'] = String(Object.values(item?.userinputvalues)[0])
          payload['vitalsid'] = item?.vitalid
        }
        inArray.push(payload);
        // console.log(payload)
        // console.log(inArray, "**")
        ipayload['vitalvalues'] = inArray;
      }
      ipayload['Groupid'] = i?.vitalgroupid;
      mainarray.push(ipayload)
      // console.log(mainarray, "%%")
    }
    mainpayload["Groupvitals"] = mainarray;
    console.log(mainpayload)


    this.checkvalidatearray.push(mainpayload)

    console.log(this.checkvalidatearray)

    for (let j = 0; j < this.checkvalidatearray.length; j++) {
      console.log(this.checkvalidatearray[j])
      this.grpvitals = this.checkvalidatearray[j].Groupvitals
      for (let k = 0; k < this.grpvitals.length; k++) {
        console.log(this.grpvitals[k].vitalvalues)
        this.grpvitalvalues = this.grpvitals[k].vitalvalues

        let checktruevalues = this.grpvitalvalues.some(function (e) {
          console.log(e)
          return e.values == 'undefined' || e.values == null || e.values == '';
        });

        console.log(checktruevalues)

        this.truearray.push(checktruevalues)

      }
    }


    console.log(this.truearray)
    let checktrue = this.truearray.includes(true)

    console.log(checktrue)


    if (checktrue == true) {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the fields', options);
      return;
    }
    if (this.error1 == true || this.error2 == true || this.error3 == true || this.error4 == true) {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Correct the incorrect data', options);
      return;
    }
    else {
      console.log(mainpayload)
      this._patientservice.submitvitals(mainpayload)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          console.log(res)
          if (!res.isError) {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);

            this.vitalist = []
            this.getvitalist(this.Apptid)

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }



    // let groupvitalarray = []
    // console.log(this.vitalist)
    // this.mainpayload = {};
    // this.mainpayload2 = {};
    // this.vitalvalues = []

    // for (let i = 0; i < this.vitalist.length; i++) {
    //   this.mainobject["Groupid"] = this.vitalist[i].vitalgroupid
    //   console.log("groupname",this.mainobject)


    //   this.innervitalist = this.vitalist[i].vitallist;
    //   console.log(this.innervitalist)
    //   for (let j = 0; this.innervitalist.length; j++) {
    //     this.propname = Object.getOwnPropertyNames(this.innervitalist[j]?.userinputvalues);

    //     if (this.propname.length != 0) {
    //       if (this.propname.length == 2) {
    //         alert("33")
    //         this.mainpayload["values"] = Object.values(this.innervitalist[j]?.userinputvalues)[0] + "/" + Object.values(this.innervitalist[j]?.userinputvalues)[1]
    //         this.mainpayload["vitalsid"] = this.innervitalist[j]?.vitalid;
    //         console.log("firstobject", this.mainpayload)
    //         this.vitalvalues.push(this.mainpayload)
    //         console.log(this.vitalvalues)
    //         // return;
    //       }
    //       else{
    //         alert("44")
    //         this.mainpayload2["values"] = String(Object.values(this.innervitalist[j]?.userinputvalues)[0])
    //         this.mainpayload2["vitalsid"] = this.innervitalist[j]?.vitalid;
    //         console.log(this.vitalvalues)

    //         console.log(this.mainpayload2)
    //         this.vitalvalues.push(this.mainpayload2)
    //         console.log(this.vitalvalues)
    //         return;
    //       }
    //     }

    //     console.log(this.vitalvalues)
    //   }
    // }









  }

  validateNumber(event) {
    var inp = String.fromCharCode(event.keyCode);

    if (/[a-zA-Z]/.test(inp)) {
      event.preventDefault();
      return false;

    } else {
      return true;
    }
  }

  didModify(val, tabledata, Titr) {
    console.log(val)
    console.log(tabledata)
    console.log(Titr)

    if (tabledata?.configmetadata?.decimalno == 0) {
      // alert("no decimal error")
      // alert("11")
      if (Number.isInteger(val) == false) {
        // alert("22")
        return tabledata['nodecimalerror'] = true
      }
      else {
        // alert("33")
        // this.nodecimalerror = false
        return tabledata['nodecimalerror'] = false
      }

    }
    if (tabledata?.configmetadata?.decimalno == 1) {
      // alert("must decimal error")
      // alert("44")
      if (Number.isInteger(val) == false) {
        // alert("55")
        // this.mustdecimalerror = false
        return tabledata['mustdecimalerror'] = false

      }
      else {
        // alert("66")
        // this.mustdecimalerror = true
        return tabledata['mustdecimalerror'] = true
      }
    }


  }

  onBlur(val, tabledata, Titr, ivalue) {
    console.log(val)
    console.log(tabledata)
    console.log(Titr)
    console.log(ivalue)


    var decimalvlue = tabledata?.configmetadata?.decimalno

    if (decimalvlue == 0) {
      // alert("no decimal error")
      // alert("11")

      if (val.includes('.')) {
        // alert("22 no")

        console.log("111")
        // tabledata['nodecimalerror'] = true
        // this.error1 = true

        tabledata["userinputvalues"][tabledata?.vitalname] = String(val).split(".")[0];
        console.log(tabledata)
      }
      else {
        // alert("33")
        // this.nodecimalerror = false
        console.log("222")
        tabledata['nodecimalerror'] = false
        this.error1 = false
      }

    }


    if (decimalvlue > 0) {
      // alert("no decimal error")
      // alert("11")

      if (val.includes('.')) {
        // alert("2222")

        var stringlength = String(val).split(".")[1].length
        console.log(stringlength)
        if (stringlength == decimalvlue) {



          console.log("111")
          tabledata['mustdecimalerror'] = false
          this.error2 = false
        }
        else {
          // alert("565656")
          // tabledata['mustdecimalerror'] = true
          // tabledata['mustdecimalerrorvalue'] = decimalvlue
          // this.error2 = true
          if (tabledata?.configmetadata?.fraction == 1) {
            var value = Number(val);
            // console.log(value)
            // console.log(value.toFixed(2))
            // console.log(tabledata?.vitalname)
            tabledata["userinputvalues"][tabledata?.vitalname + ivalue] = value.toFixed(decimalvlue);
            console.log(tabledata)
          }

          else {
            // alert("nan check")
            var value = Number(val);
            console.log(value)
            // console.log(value.toFixed(2))
            // console.log(tabledata?.vitalname)
            if (isNaN(value)) {
              // alert("dfkghdfgh")
              // tabledata["userinputvalues"][tabledata?.vitalname] = value.toFixed(decimalvlue);
            }
            else {
              tabledata["userinputvalues"][tabledata?.vitalname] = value.toFixed(decimalvlue);
            }
            // console.log(tabledata)
          }
        }
      }
      else {
        // alert("33")
        // this.nodecimalerror = false
        console.log("222")
        // tabledata['mustdecimalerror'] = true
        // tabledata['mustdecimalerrorvalue'] = decimalvlue
        // this.error2 = true

        if (tabledata?.configmetadata?.fraction == 1) {
          var value = Number(val);
          // console.log(value)
          // console.log(value.toFixed(2))
          // console.log(tabledata?.vitalname)
          tabledata["userinputvalues"][tabledata?.vitalname + ivalue] = value.toFixed(decimalvlue);
          console.log(tabledata)
        }

        else {
          var value = Number(val);
          // console.log(tabledata?.vitalname)

          if (isNaN(value)) {
            // alert("dfkghdfgh")
            // tabledata["userinputvalues"][tabledata?.vitalname] = value.toFixed(decimalvlue);
          }
          else {
            tabledata["userinputvalues"][tabledata?.vitalname] = value.toFixed(decimalvlue);
          }
        }

      }

    }

    if (tabledata?.configmetadata?.plussign == 0) {
      console.log("plus sign")
      this.containsSpecialChars(val)

      if (this.containsSpecialChars(val) == true) {
        tabledata['nopluserror'] = true
        this.error3 = true
      }
      else {
        tabledata['nopluserror'] = false
        this.error3 = false
      }
    }

    if (tabledata?.configmetadata?.plussign == 1) {
      console.log("plus sign 3")
      console.log(val)
      this.containsSpecialChars(val)

      if (this.containsSpecialChars(val) == true) {
        tabledata['pluserror'] = false
        this.error4 = false
      }
      else {
        tabledata['pluserror'] = true
        this.error4 = true
      }
    }


  }



  containsSpecialChars(str) {
    console.log(str)
    const specialChars = `\`!@#$%^&*()_+\-=\[\]{};':"\\|,<>\/?~`;

    const result = specialChars.split('').some(specialChar => {
      if (str.includes(specialChar)) {
        return true;
      }
      else {
        return false;
      }
    });
    console.log(result)
    return result;
  }



  cancelbookfollowup() {
    this.isShownbookFollowup = false;
  }
  bookfollowup() {
    this.dt["mybookfollowup"] = true;
    this._patientservice.Followupdoctordetails = this.dt
    console.log(this.dt)
    sessionStorage.setItem("followupdetails", JSON.stringify(this.dt))
    this.sharedataService.setDatafollowup(this.dt.appointmentId);
    sessionStorage.setItem('navtype', "bookfollowup")
    this.router.navigate(['/thealth/appointment']);
  }
  togglebookFollowup() {
    if (this.dt.isDoctorActive == true) {
      this.isShownbookFollowup = !this.isShownbookFollowup;
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Followup can't be created. Contact Clinic Administrator", options);
    }
  }
  disableUploadbtn: boolean;
  handleFileInput(event) {
    if (event.target.files.length > 0) {
      if (event.target.files[0].size > 5242880) {
        this.disableUploadbtn = true;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "This file exceeds the maximum size limit of 5MB", options);
        return;
      } else {
        this.disableUploadbtn = false;
        const file = event.target.files[0];
        this.fileToUpload = file;
      }
    }
  }

  togglereschedule(formData: any, formDirective: FormGroupDirective) {
    this.updateAppointment.reset();
    this.timeslots = [];
    this.isShownReshedule = !this.isShownReshedule;
  }

  submitapptdetail(formData: any, formDirective: FormGroupDirective) {
    this.loading = true;
    if (this.createAptDetail.value.recorddate != null || this.createAptDetail.value.recorddate != '' || this.createAptDetail.value.recorddate != undefined) {
      const listsdate = this.createAptDetail.value.recorddate;
      const getstdate = moment(listsdate).format();
      this.recdate = getstdate.substr(0, 19);
    }

    if (this.fileToUpload.length === 0) {
      this.filerr = true;
      this.fileerrmsg = "File is required";
      this.loading = false;
      return;
    } else {
      this.filerr = false;
      this._patientservice.apptdetfile(this.createAptDetail.value, this.recdate, this.fileToUpload, this.Apptid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.messagecontent = res.responseMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.ngOnInit();
            formDirective.resetForm();
            this.createAptDetail.reset();
            this.fileToUpload = [];
            $('#medicalrecordsUpload').val(null);
            let x = $('#medicalrecordsUpload').val('');
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.messagecontent = res.errorMessage;
            formDirective.resetForm();
            this.createAptDetail.reset();
            this.fileToUpload = [];
            $('#medicalrecordsUpload').val(null);
            let x = $('#medicalrecordsUpload').val('');
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.messagecontent = err.error;
            formDirective.resetForm();
            this.createAptDetail.reset();
            $('#medicalrecordsUpload').val(null);
            let x = $('#medicalrecordsUpload').val('');
          });
    }
  }

  recordlist() {
    let filetype;
    this.patientvalue = [];
    this._patientservice.viewapptpatientuploads(this.Apptid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          if (res.responseMessage[0].medicalRecordsByPatient.length > 0) {
            for (let i = 0; i < res.responseMessage[0].medicalRecordsByPatient.length; i++) {
              this.filename = res.responseMessage[0].medicalRecordsByPatient[i].displayName.split('.').pop();


              if (this.filename == 'jpg' || this.filename == 'jpeg' || this.filename == 'png' ||
                this.filename == 'gif' || this.filename == 'bmp' || this.filename == 'tif' ||
                this.filename == 'eps' || this.filename == 'tiff') {

                filetype = "imageformat";

              } else if (this.filename == 'docx' || this.filename == 'doc' || this.filename == 'pdf' ||
                this.filename == 'xls' || this.filename == 'txt' || this.filename == 'xlsx') {

                filetype = "textformat";

              } else if (this.filename == 'mp4' || this.filename == 'wmv' || this.filename == 'avi' ||
                this.filename == 'mkv' || this.filename == '3gp' || this.filename == 'mov' ||
                this.filename == 'mxf' || this.filename == 'mts/m2ts' || this.filename == 'asf') {

                filetype = "videoformat"
              } else {
                filetype = "fileformat"
              }
              const fileextension = {
                "appointmentId": res.responseMessage[0].medicalRecordsByPatient[i].appointmentId,
                "displayName": res.responseMessage[0].medicalRecordsByPatient[i].displayName,
                "filepath": res.responseMessage[0].medicalRecordsByPatient[i].filepath,
                "patientId": res.responseMessage[0].medicalRecordsByPatient[i].patientId,
                "recordGUID": res.responseMessage[0].medicalRecordsByPatient[i].recordGUID,
                "uploadDate": res.responseMessage[0].medicalRecordsByPatient[i].uploadDate,
                "imgfileextension": this.filename,
                "medicalRecordType": res.responseMessage[0].medicalRecordsByPatient[i].medicalRecordType,
                "filetype": filetype
              }
              this.patientvalue.push(fileextension);
            }
            console.log(this.patientvalue);
            this.dataSource = new MatTableDataSource(this.patientvalue);
            this.dataSource.paginator = this.paginator;
            if (this.dataSource.data === null || this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
          } else {
            this.dataSource = [];
            this.listdata = true;
          }
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.messagecontent = err.error;
        });
  }

  getslot() {
    this.slotimeid = ""
    this.loading = true;
    this.timeslots = [];
    this.sloterrormsg = false;
    const sdate = this.updateAppointment.value.dateofappointment;
    const dobdate = moment(sdate).format();
    this.stdate = dobdate.substr(0, 19);
    this._patientservice.timeslotres(this.dt.appointmentId, this.dt.doctorId, this.stdate, this.consultationtype, this.dt.clinicLocationMapId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          if (res.responseMessage.length === 0) {
            this.noslotmsg = true;
          } else {
            this.noslotmsg = false;
            this.timeslots = res.responseMessage;
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.messagecontent = err.error;
        });
  }

  slotid(sltId) {
    this.slotimeid = sltId;
  }

  isActive(sltId) {
    return this.slotimeid === sltId;
  };

  updateappoint(formData: any, formDirective: FormGroupDirective) {
    this.loading = true;
    if (!this.slotimeid || this.slotimeid === 'undefined') {
      this.sloterrormsg = true;
      this.loading = false;
    } else {
      this.sloterrormsg = false;
      this._patientservice.upappointment(this.updateAppointment.value, this.stdate, this.slotimeid, this.dt.appointmentId)
        .pipe(first())
        .subscribe((res: any) => {
          if (res) {
            if (!res.isError) {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const dt = this.maxdate1.toISOString();
              if (this.stdate > dt) {
                this.router.navigate(['/thealth/appointments/upcoming'])
              } else {
                this.router.navigate(['/thealth/appointments/today'])
              }
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              formDirective.resetForm();
              this.updateAppointment.reset();
            }
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.messagecontent = err.error;
            formDirective.resetForm();
            this.updateAppointment.reset();
          });
    }
  }

  downloadfile(guid, apptid, displayName) {
    this.loading = true;
    this._DoctorService.getfiledownload(guid, apptid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const newBlob = new Blob([res], { type: 'application/pdf' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = displayName;
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);
        } else {
          this.loading = false;
          this.messagecontent = res.errorMessage;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.messagecontent = err.error;
        });
  }

  deletefile(element) {
    console.log(element)
    const dialogRef = this.dialog.open(DeletemrPatientappointmentComponent, {
      data: element
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log(result)
        if (!result.data.isError) {
          this.ngOnInit();
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', result.data.responseMessage, options);
          this.messagecontent = result.data.responseMessage;

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', result.data.errorMessage, options);
          this.errormessagebox = true;
          this.messagecontent = result.data.errorMessage;
        }
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
        this.messagecontent = err.error;
      });
  }

  toggleFollowup() {
    this.isShownReshedule = !this.isShownReshedule;
  }

  cancelModalPatient(cancelappointmentid) {
    const dialogRef = this.dialog.open(PatientCancelComponent, {
      data: cancelappointmentid,
      panelClass: 'cancelwrapper'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', result.data.responseMessage, options);
          this.messagecontent = result.data.responseMessage;
          setTimeout(() => {
            this.router.navigate(['/thealth/appointments/cancelled']);
          }, 3000);
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', result.data.errorMessage, options);
          this.errormessagebox = true;
          this.messagecontent = result.data.errorMessage;
        }
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err.error, options);
        this.messagecontent = err.error;
      });
  }

  // please dont remove this function
  myopen() {

    // this.updateAppointment.get('dateofappointment').setValue(null);
    // this.timeslots.length = 0;
    // if(this.timeslots.length == 0){
    //   this.dateSlots()
    //   this.slotimeid = ""
    // }

    // setTimeout(() => {

    //   const prev = document.querySelector(".mat-calendar-previous-button");
    //   const next = document.querySelector(".mat-calendar-next-button");    


    //   prev.addEventListener("click", () => {  
    //     this.loading = true;
    //     this.myarraystate.length =0;
    //     // Previous Button      
    //     this.myHolidayFilter = (d: Date): any => {
    //       this.myarraystate.push(moment(d).format('YYYY-MM-DD'))
    //     }  
    //     setTimeout(()=>{
    //       // console.log("prev",this.myarraystate[0],this.myarraystate[this.myarraystate.length -1])
    //       this.payload = {
    //         StartDate:moment(this.myarraystate[0]).format('YYYY-MM-DD'),
    //         EndDate:moment(this.myarraystate[this.myarraystate.length -1]).format('YYYY-MM-DD'),
    //         ClinicId:this.dt.clinicId,
    //         DoctorId:this.dt.doctorId
    //       }
    //       this.myHolidayDates.length = 0;
    //       this._patientservice.getdateslot(this.payload)
    //       .pipe(first())
    //       .subscribe((res: any) => {                     
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.myHolidayDates = res?.responseMessage[0]?.slotDates;                
    //         this.myHolidayFilter = (d: Date): any => {
    //           return this.myHolidayDates.find(x=>moment(x).format('MM/DD/YYYY')==moment(d).format('MM/DD/YYYY'));  
    //         }
    //         }
    //         else {
    //           this.loading = false;
    //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //           this.toastrService.warning('', res.errorMessage, options);
    //         }
    //       },
    //         err =>{
    //           this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err.error, options);      
    //           })
    //     });
    //   });


    //   next.addEventListener("click", () => {
    //     this.loading = true;
    //     this.myarraystate.length =0;
    //     // Previous Button      
    //     this.myHolidayFilter = (d: Date): any => {
    //       this.myarraystate.push(moment(d).format('YYYY-MM-DD'))
    //     }  
    //     setTimeout(()=>{
    //       // console.log("next",this.myarraystate[0],this.myarraystate[this.myarraystate.length -1])
    //       this.payload = {
    //         StartDate:moment(this.myarraystate[0]).format('YYYY-MM-DD'),
    //         EndDate:moment(this.myarraystate[this.myarraystate.length -1]).format('YYYY-MM-DD'),
    //         ClinicId:this.dt.clinicId,
    //         DoctorId:this.dt.doctorId
    //       }
    //       this.myHolidayDates.length = 0;
    //       this._patientservice.getdateslot(this.payload)
    //       .pipe(first())
    //       .subscribe((res: any) => {                     
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.myHolidayDates = res?.responseMessage[0]?.slotDates;                
    //         this.myHolidayFilter = (d: Date): any => {
    //           return this.myHolidayDates.find(x=>moment(x).format('MM/DD/YYYY')==moment(d).format('MM/DD/YYYY'));  
    //         }
    //         }
    //         else {
    //           this.loading = false;
    //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //           this.toastrService.warning('', res.errorMessage, options);
    //         }
    //       },
    //         err =>{
    //           this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err.error, options);      
    //           })
    //     });
    //   });
    // }); 
  }

  dateSlots() {
    this.loading = true;
    this.payload = {
      StartDate: moment(this.maxdate).format('YYYY-MM-DD'),
      // EndDate:moment().clone().endOf('month').format('YYYY-MM-DD'),
      EndDate: moment(this.maxdate).add(365, 'days').format('YYYY-MM-DD'),
      ClinicId: this.dt.clinicId,
      DoctorId: this.dt.doctorId,
      ConsultationType: this.consultationtype,
      CliniclocMapid: this.dt.clinicLocationMapId
    }
    this.myHolidayDates.length = 0;
    this._patientservice.getdateslot(this.payload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.loading = false;
          this.myHolidayDates = res?.responseMessage[0]?.slotDates;
          if (res?.responseMessage[0]?.slotDates.length == 0) {
            this.noslotmsg = true;
          } else {
            this.noslotmsg = false;
          }
          this.myHolidayFilter = (d: Date): any => {
            return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
        // go to date
        this.gotodate = new Date(res?.responseMessage[0]?.slotDates[0].substr(0, 10));
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        })
  }

  choosevault() {
    let appointmentdetails = {
      "apptid": this.Apptid,
      "apptstate": this.apptstate,
    }

    this.sharedataService.shareapptdetails(appointmentdetails);
    this.router.navigate(['/thealth/medicalrecords']);
  }
}

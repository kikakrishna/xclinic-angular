import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminCreatepaymentlinkComponent } from './clinicadmin-createpaymentlink.component';

describe('ClinicadminCreatepaymentlinkComponent', () => {
  let component: ClinicadminCreatepaymentlinkComponent;
  let fixture: ComponentFixture<ClinicadminCreatepaymentlinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminCreatepaymentlinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminCreatepaymentlinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

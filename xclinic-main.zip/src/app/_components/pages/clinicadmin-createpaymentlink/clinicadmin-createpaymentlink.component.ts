import { Component, OnInit, Inject } from '@angular/core';

import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDeletesliderComponent } from '../clinicadmin-deleteslider/clinicadmin-deleteslider.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-clinicadmin-createpaymentlink',
  templateUrl: './clinicadmin-createpaymentlink.component.html',
  styleUrls: ['./clinicadmin-createpaymentlink.component.css']
})
export class ClinicadminCreatepaymentlinkComponent implements OnInit {


  loading: boolean;

  payment: FormGroup


  appointment_view_id: any = [];
  constructor(
    private _DoctorService: DoctorService,

    public toastrService: ToastService,
    private _formBuilder: FormBuilder,

    public dialogRef: MatDialogRef<ClinicadminCreatepaymentlinkComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,

  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    console.log("aa---" + this.data)
    this.payment = this._formBuilder.group({
      amount: ['',[Validators.required, Validators.pattern('^[0-9]*$')]],
    });
  }

  createpayment() {
    console.log("fdsfsdfdf")
    this.loading = true;
  }

  paymentlink() {
    this.loading = true;
    console.log(this.payment.valid)
    // if (this.payment.value.amount == '' || this.payment.value.amount == null || this.payment.value.amount == undefined){
    //   this.loading = false;
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', 'Please enter the amount', options);
    //   return
    // } else {
      if(this.payment.invalid) {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        if (this.payment.value.amount == '' || this.payment.value.amount == null || this.payment.value.amount == undefined){
          this.toastrService.warning('', 'Please enter the amount', options);
          return
        } else {
          this.toastrService.warning('', 'Please enter the amount in numbers', options);
          return
        }
      } else {
        let payload = {
          "AppointmentId": this.data,
          "Amount": this.payment.value.amount,
        }
        console.log(this.data)
        this._DoctorService.createpaymentlink(payload)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res)
            if (!res.isError) {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              this.dialogRef.close({ data: res });
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              console.log(err)
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            })
          }
      // }
  }

}

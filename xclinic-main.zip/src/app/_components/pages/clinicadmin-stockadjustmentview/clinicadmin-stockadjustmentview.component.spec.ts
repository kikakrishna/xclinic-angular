import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockadjustmentviewComponent } from './clinicadmin-stockadjustmentview.component';

describe('ClinicadminStockadjustmentviewComponent', () => {
  let component: ClinicadminStockadjustmentviewComponent;
  let fixture: ComponentFixture<ClinicadminStockadjustmentviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockadjustmentviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockadjustmentviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

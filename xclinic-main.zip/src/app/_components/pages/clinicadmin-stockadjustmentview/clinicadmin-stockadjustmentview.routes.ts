import { RouterModule } from '@angular/router';
import { ClinicadminStockadjustmentviewComponent } from './clinicadmin-stockadjustmentview.component';
export const ClinicadminStockadjustmentviewRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockadjustmentviewComponent,
    }
]
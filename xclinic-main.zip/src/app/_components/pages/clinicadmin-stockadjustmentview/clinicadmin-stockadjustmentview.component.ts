import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { filter, first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
export interface PeriodicElement {
  productname: string;
  adjustqty: number;
  unittype: string;
  adjustmenttype: string;

 
}

const ELEMENT_DATA: PeriodicElement[] = [
  { productname: 'product 1', adjustqty: 2, unittype: 'Box', adjustmenttype:'',  },
  { productname: 'product 2', adjustqty: 3, unittype: 'piece', adjustmenttype:'',   },
  { productname: 'product 3', adjustqty: 4, unittype: 'Box', adjustmenttype:'',  },
  
];
@Component({
  selector: 'app-clinicadmin-stockadjustmentview',
  templateUrl: './clinicadmin-stockadjustmentview.component.html',
  styleUrls: ['./clinicadmin-stockadjustmentview.component.css']
})
export class ClinicadminStockadjustmentviewComponent implements OnInit {
  displayedColumns: string[] = ['productname', 'adjustqty', 'unittype', 'adjustmenttype', ];
  dataSource = ELEMENT_DATA;
  servid:any;
  btnCreate: boolean;
  loading: boolean;
  createstockadjustmentview: FormGroup;
 
  constructor(  private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  ngOnInit(): void {
  this.loading = true;
    this.createstockadjustmentview = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      location: ['', Validators.required],
      refno: ['', Validators.required],
    });


    this.btnCreate = history.state.btnAction;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('stockadjustmentid')) {
        this.servid = params?.get('stockadjustmentid');
      }
    })

    console.log('edit details ',history.state.servicestatus)

    if(history.state.servicestatus != undefined){
        if(history.state.servicestatus != 'create')
        {
        this._DoctorService.getstockadjusdetails(Number(this?.servid))
        // this._DoctorService.getstockadjusdetails(16)
        .pipe(first())
        .subscribe((res: any) => {
        if (!res.isError) {
        console.log('adjust details',res)
        this.loading = false;
        let data = res?.responseMessage[0];
          data?.productStockList.map((datas,key) => {
          
          })

        }
        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
        }else{
        this.loading = false;
        }
    }else{
        this.loading = false;
    }

  }
}
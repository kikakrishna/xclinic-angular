import { RouterModule } from '@angular/router';
import { ClinicadminTestimonialeditComponent } from './clinicadmin-testimonialedit.component';
export const ClinicadminTestimonialeditRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminTestimonialeditComponent,
    }
]
import { Component, OnInit, ViewChild,ElementRef  } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';

import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDeleteserviceComponent } from '../clinicadmin-deleteservice/clinicadmin-deleteservice.component';
import { MatDialog } from '@angular/material/dialog';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
  selector: 'app-clinicadmin-testimonialedit',
  templateUrl: './clinicadmin-testimonialedit.component.html',
  styleUrls: ['./clinicadmin-testimonialedit.component.css']
})

export class ClinicadminTestimonialeditComponent implements OnInit {
 
@ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', {static: false})InputVar: ElementRef;

  clinicId:any;
  public ClnicArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  addressmodel: any;
  createtesti: FormGroup;
  imgfileWeb: any;
  imgfileonupdateWeb: boolean = false;
  imgerrorWeb: any;

  imgfileRes: any;
  public Editor = ClassicEditor;
  imgfileonupdateRes: boolean = false;
  imgerrorRes: any;
  positionselect:any;
  btnCreate: boolean;
  foods:any;
  servid: any;
  description: boolean=false;
  isError: boolean;

  btnEnable: boolean = true;

  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
     private _formBuilder: FormBuilder,
    private router: Router,
    public dialog: MatDialog,
     public _activatedRoute: ActivatedRoute,
    ) { }


  ngOnInit(): void {
    this.loading = true;
    this.btnEnable = true;
    this.btnCreate = history.state.btnAction;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('testimonialId')) {
        this.servid = params?.get('testimonialId');
      }
    })
    
    this.createtesti = this._formBuilder.group({
      testiname: ['', Validators.required],
      testiurl: ['', Validators.required],
      testidescription: ['', Validators.required],
      testirating: ['', Validators.required],
      position: ['', Validators.required],
    });

    this.foods = [
    {value: '1', viewValue: '1'},
    {value: '2', viewValue: '2'},
    {value: '3', viewValue: '3'},
    {value: '4', viewValue: '4'},
    {value: '5', viewValue: '5'},
    ];

    this.clinicId = sessionStorage.getItem('clinicId');
     this.ClnicArraydataSource.paginator = this.paginator;
   
    if(history.state.testitatus != undefined){
        if(history.state.testitatus !== 'create')
        {
        this._DoctorService.gettestimonialdetails(this?.servid)
        .pipe(first())
        .subscribe((res: any) => {
        if (!res.isError) {
        console.log('service details',res)
        this.loading = false;
        let data = res?.responseMessage;

        this.createtesti.get('testiname').setValue(data?.name);
        this.createtesti.get('testidescription').setValue(data?.content);
        this.createtesti.get('testiurl').setValue(data?.url);
        this.createtesti.get('testirating').setValue(data?.rating);
        this.positionselect = (data?.rating).toString();;

        }
        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
        }else{
        this.loading = false;
        }
    }else{
        this.loading = false;
    }
  }

  Changeposition(){ 
  console.log(this.createtesti.value.position)
  }

  updatedoctorprofile(formData: any, formDirective: FormGroupDirective) {
    if (this.createtesti.value.testiname == '') {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Enter all the Mandatory Fields", options);
          return;
        }
        this.toastrService.clear();
        this.loading = true;
        this.isError = false;
        const listsdate = this.createtesti.value.dateofBirth;
    
        if(this.createtesti.value.testidescription == '' || this.createtesti.value.testidescription == null || this.createtesti.value.testiname == '' || this.createtesti.value.testiname == null || this.createtesti.value.testirating == undefined){
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Enter all the Mandatory Fields", options);
        this.description = true;
        this.loading = false;
        return;
        }

        if (!this.isError) {
        if(history.state.testitatus !== 'create')
        {
          this._DoctorService.updatetestidata(this.createtesti,this?.servid)
          .pipe(first()).subscribe((res: any) => {
              if(!res.isError) {   
              console.log('updated data', res) 

                this.loading = false;
                formDirective.resetForm();
                this.createtesti.reset();
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res.responseMessage, options);
                setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/testimonial'])},2000);

              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
              }
            },
              err => {
              console.log('error 2')
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);
                this.loading = false;
              });
              }
        }
        else {
        console.log('error 3')
          this.loading = false;
        }
  }

  createService(formData: any, formDirective: FormGroupDirective){
    this.description = false;

    if(this.createtesti.value.testidescription == '' || this.createtesti.value.testidescription == null || this.createtesti.value.testiname == '' || this.createtesti.value.testiname == null || this.createtesti.value.testirating == undefined){
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.description = true;
      this.toastrService.warning('', "Enter all the Mandatory Fields", options);
      return;
    }

    if(this.createtesti.value.testiname != ''){
    this._DoctorService.createtestidata(this.createtesti)
    .pipe(first())
    .subscribe((res: any) => {
    if(!res.isError) {
      if(!res.isError) {   
        console.log('updated data', res) 
        this.loading = false;
        formDirective.resetForm();
        this.createtesti.reset();
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.success('', res.responseMessage, options);
        setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/testimonial'])},2000);
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
      }
    }
    });
    }
  }


}
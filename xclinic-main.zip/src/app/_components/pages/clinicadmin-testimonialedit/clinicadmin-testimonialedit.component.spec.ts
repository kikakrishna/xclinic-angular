import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminTestimonialeditComponent } from './clinicadmin-testimonialedit.component';

describe('ClinicadminTestimonialeditComponent', () => {
  let component: ClinicadminTestimonialeditComponent;
  let fixture: ComponentFixture<ClinicadminTestimonialeditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminTestimonialeditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminTestimonialeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

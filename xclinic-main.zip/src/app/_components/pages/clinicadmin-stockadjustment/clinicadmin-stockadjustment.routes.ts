import { RouterModule } from '@angular/router';
import { ClinicadminStockadjustmentComponent } from './clinicadmin-stockadjustment.component';
export const ClinicadminStockadjustmentRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockadjustmentComponent,
    }
]
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';

export interface PeriodicElement {
  productname: string;
  adjustqty: string;
  unittype: string;
  adjustmenttype:string;
  action:string;
  
}
const ELEMENT_DATA: PeriodicElement[] = [
  {productname: 'Product 1', adjustqty: '2', unittype: 'Box',adjustmenttype:'1' , action:'' },
  {productname: 'Product 2', adjustqty: '3', unittype: 'Piece', adjustmenttype:'2' , action:'' },
  {productname: 'Product 3', adjustqty: '4', unittype:'Box', adjustmenttype:'3' , action:'' },
];

@Component({
  selector: 'app-clinicadmin-stockadjustment',
  templateUrl: './clinicadmin-stockadjustment.component.html',
  styleUrls: ['./clinicadmin-stockadjustment.component.css']
})

export class ClinicadminStockadjustmentComponent implements OnInit {
  displayedColumns: string[] = [ 'productname','adjustqty', 'unittype','adjustmenttype','action' ];
  public dataSource: any = new MatTableDataSource([]);
  createstockadjustment: FormGroup;
  total:any;
  subtotal:any;
  granttotal:any;
  clinicid:any;
  chargesProduct:any;
  chargesAdjust:any;
  chargesAdjustid:any;
  note:any;
  maxDate:any;
  domaincurrency:any;
  selectedItem:any;
  servid:any;
  loading:boolean;
  btnCreate:boolean;
  tableArray: any = [];
  inwardArray: any = [];
  locationarray: any = [];
  supplierarray: any = [];
  productarray: any = [];
  stockadtypearray: any = [];
  tableinwardArray: any = [];

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('createpaginator', { read: MatPaginator }) createpaginator: MatPaginator;

  ngOnInit(): void {
  this.loading = true;
  setTimeout(()=>{
   this.loading = false;
  },2000)

  this.maxDate = new Date();

  this.createstockadjustment = this._formBuilder.group({
      stockaddate: [''],
      stockadproduct: [''],
      stockadrefno: [''],
      stockadadjustqty: [''],
      stockadtype: [''],
      stockadlocation: [''],
      stockrefno: [''],
    });

  this.domaincurrency = sessionStorage.getItem('domaincurrencydetails');
  this.clinicid = sessionStorage.getItem('clinicId');

   this.btnCreate = true;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('stockadjustmentid')) {
        this.servid = params?.get('stockadjustmentid');
        this.btnCreate = false;
      }
    })

    if(this.servid != undefined){
        this._DoctorService.getstockadjusdetails(Number(this?.servid))
        // this._DoctorService.getstockadjusdetails(16)
        .pipe(first())
        .subscribe((res: any) => {
        if(!res.isError) {
        console.log('adjust details',res)
        this.loading = false;
        let getdata = res?.responseMessage[0];
           
        const d = new Date(getdata?.date) 
              let newdatevalue = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString();
           
        this.createstockadjustment.get('stockaddate').setValue(newdatevalue);

        this.createstockadjustment.get('stockadlocation').setValue(getdata?.cliniclocationmapId);
        this.createstockadjustment.get('stockadrefno').setValue(getdata?.referenceno);
        this.note = getdata?.notes;

        getdata?.clinicStockadjustment?.map((datas,key) => {
       
        this.tableArray.push(
        {
          "id": key,
          "productname": datas?.productName,
          "productdate": datas?.date,
          "location": getdata?.cliniclocationmapId,
          "refno": datas?.referenceno,
          "unittype": datas?.unitType ,
          "adjustmenttypenames": datas?.adjustmentType,
          "qty": datas?.quantity 
        })


        console.log(this.tableArray);
        
        this.dataSource = new MatTableDataSource(this.tableArray);
        setTimeout(() => {
        this.dataSource.paginator = this.createpaginator
        });
          })
        }
        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
    }else{
        this.loading = false;
    }

  this._DoctorService.getlocations(this.clinicid)
      .pipe(first())
      .subscribe((res: any) => {
         this.locationarray = res?.responseMessage;
        // console.log('location details',res?.responseMessage);
        },
        err => {
  });

  // Get supplier list 
  this._DoctorService.getSupplierlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.supplierarray = res?.responseMessage;
         // console.log('supplier details',res?.responseMessage);
        },
        err => {
  });

  // Get product list 
  this._DoctorService.getProductlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.productarray = res?.responseMessage;
          console.log('product details',res?.responseMessage);
        },
        err => {
  });

  // Get adjustmenttype list 
  this._DoctorService.getAdjustlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.stockadtypearray = res?.responseMessage;
          console.log('stockadtypearray details',res?.responseMessage);
        },
        err => {
  });

  setTimeout(() => this.dataSource.paginator = this.createpaginator);
    this.dataSource.paginator = this.paginator;
  }

  selectedproduct(event){
  this.chargesProduct = event.value.productName;

   console.log('product change',this.chargesProduct, event.value.productId);
  }

  selectedadjust(event){
   console.log('calculationevent',event.value);
   this.chargesAdjust = event.value.adjustmentTypeName;
   this.chargesAdjustid = event.value.adjustmentTypeId;
   this.selectedItem = event.value.adjustmentTypeName;
   console.log('adjust change',this.chargesAdjust, event.value.adjustmentTypeId);
  }

  calculation(event){
   // console.log('calculationevent',event);
    let sumtotal = Number(event.stockadadjustqty)
    this.total = sumtotal;
  }

  getTotalCost() {
    let granttotal = this.tableArray.map(t => Number(t.subtotal)).reduce((acc, value) => acc + value, 0);
    this.granttotal = granttotal;
    return this.tableArray.map(t => Number(t.subtotal)).reduce((acc, value) => acc + value, 0);
  }

  addstockdjust(formData: any, formDirective: FormGroupDirective){
  //  console.log(this.createstockadjustment.value)
    //this.calculation(this.createstockadjustment.value);
    if(this.createstockadjustment.value.stockaddate != '' && this.createstockadjustment.value.stockadlocation != "" ) {
      if(this.createstockadjustment.value.stockadtype != "" && this.createstockadjustment.value.stockadproduct != '' && this.createstockadjustment.value.stockadadjustqty != "" )
      {
      let sumtotal = Number(this.createstockadjustment.value.stockadadjustqty)
      this.subtotal = sumtotal;

      let count = 0;
        if (this.tableArray.length == 0) {
          count = 0;
        } else {
          count = this.tableArray.length + 1;
        }

        this.inwardArray.push(
          {
            "Productid": this.createstockadjustment.value.stockadproduct.productId,
            "AdjQty": Number(this.createstockadjustment.value.stockadadjustqty),
            "Adjtype": Number(this.createstockadjustment.value.stockadtype.adjustmentTypeId)
          })

        this.tableArray.push(
          {
            "id": count,
            //"productname": this.createstockadjustment.value.stockadproduct,
            "productname": this.chargesProduct,
            "productid": this.createstockadjustment.value.stockadproduct.productId,
            "productdate": this.createstockadjustment.value.stockaddate,
            "location": this.createstockadjustment.value.stockadlocation,
            "refno": this.createstockadjustment.value.stockadrefno,
            "adjustmenttype": this.chargesAdjustid,
            "adjustmenttypenames":  this.chargesAdjust,
            "unittype": this.createstockadjustment.value.stockadproduct.unitType,
            "subtotal": Number(this.subtotal).toFixed(2),
            "inwardarray": this.inwardArray,
            "qty": this.createstockadjustment.value.stockadadjustqty 
          })
          // console.log(this.chargesAdjustid)
          console.log(this.tableArray)
          console.log('Product entries ', this.tableArray, this.inwardArray)
          this.dataSource = new MatTableDataSource(this.tableArray);
          setTimeout(() => {
          this.dataSource.paginator = this.createpaginator
          });
          console.log(this.dataSource,'table')
          this.clearinput(formData,formDirective);
      }
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the mandatory fields', options);
    }

  }

  clearinput(formData: any, formDirective: FormGroupDirective) {
  // formDirective.resetForm();
  // this.createstockadjustment.reset();

  this.createstockadjustment.get('stockadproduct').reset();
  this.createstockadjustment.get('stockadadjustqty').reset();
  this.createstockadjustment.get('stockadtype').reset();
  this.createstockadjustment.value.stockadproduct = "";
  }

  modelChangeQty(data,element){
    console.log('modelChangeQty', data, element)
    if(data != ''){
      //const idx = this.inwardArray.findIndex((x) => x.Productid == element.productid);
      //this.inwardArray[idx].AdjQty = Number(element.adjustmenttype);

      const idx = this.dataSource.data.findIndex((x) => x.id == element.id);
      this.dataSource.data[idx].inwardarray[idx].AdjQty = Number(data);
      // this.dataSource.data[idx].adjustmenttype = Number(data);


     console.log(this.dataSource.data)
    }
  }

  modelChangeCost(data,element){
  console.log('modelChangeCost', JSON.parse(data), element)
  //this.selectedItem = element.adjustmenttypenames;

 // if(data != ''){
   //   let sumtotal = Number(element.qty) * Number(data);
     // this.subtotal = sumtotal;
     // const idx = this.inwardArray.findIndex((x) => x.Productid == element.productid);
     // this.inwardArray[idx].Adjtype = Number(element.unittype);
   // }

    // console.log(this.inwardArray)

  }
  getselectedAdjustmentId(event, element) {
    console.log(event.value)
    console.log(element)
  }
  getstockadjustform(){
  this.loading = true;
  console.log(this.note, this.createstockadjustment.value,this.inwardArray,this.granttotal);
  // product array from DataTable 
  this.tableinwardArray = []
  for(let tableData in this.dataSource.filteredData) {
    this.tableinwardArray.push({
      "Productid": this.dataSource.filteredData[tableData].productid,
      "AdjQty": Number(this.dataSource.filteredData[tableData].qty),
      "Adjtype": Number(this.dataSource.filteredData[tableData].adjustmenttype)
    })
  }



  let formobject = {
  "Date": moment(this.createstockadjustment.value.stockaddate).format(),
  "ReferenceNo": this.createstockadjustment.value.stockadrefno,
  "Cliniclocationmapid": this.createstockadjustment.value.stockadlocation,
  "Notes": this.note,
  "Productstockadjustment": this.tableinwardArray
  }
  console.log(formobject)
  
  this._DoctorService.createissueadjustdata(formobject)
    .pipe(first())
        .subscribe((res: any) => {
             if(!res.isError) { 
                console.log(res);
                  this.loading = false;
                  this.createstockadjustment.reset();
                  this.note = "";
                  this.tableArray = [];
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.responseMessage, options);
                  setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/stockadjustmentlist'])},2000);
             }else{
                 this.loading = false;
                 const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                 this.toastrService.warning('', res.errorMessage, options);
             }
         });

      }

  deletecharges(data) {
    // const filteredtabl3 = 
    let a = this.tableArray.filter((item) => item.id !== data.id);
    this.dataSource = new MatTableDataSource(a);
    this.tableArray = a;
    this.dataSource.paginator = this.paginator
  }

}
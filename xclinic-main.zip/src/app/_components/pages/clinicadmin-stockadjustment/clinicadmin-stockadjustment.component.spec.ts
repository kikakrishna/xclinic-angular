import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockadjustmentComponent } from './clinicadmin-stockadjustment.component';

describe('ClinicadminStockadjustmentComponent', () => {
  let component: ClinicadminStockadjustmentComponent;
  let fixture: ComponentFixture<ClinicadminStockadjustmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockadjustmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockadjustmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminGalleryimageComponent } from './clinicadmin-galleryimage.component';

describe('ClinicadminGalleryimageComponent', () => {
  let component: ClinicadminGalleryimageComponent;
  let fixture: ComponentFixture<ClinicadminGalleryimageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminGalleryimageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminGalleryimageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

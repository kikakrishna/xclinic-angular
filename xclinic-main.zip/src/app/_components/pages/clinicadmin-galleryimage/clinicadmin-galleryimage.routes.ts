import { RouterModule } from '@angular/router';
import { ClinicadminGalleryimageComponent } from './clinicadmin-galleryimage.component';
export const ClinicadminGalleryimageRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminGalleryimageComponent,
    }
]
import { Component, OnInit, ViewChild,ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { MatDialog } from '@angular/material/dialog';
import { DeleteGalleryImageComponent } from '../delete-gallery-image/delete-gallery-image.component';
@Component({
  selector: 'app-clinicadmin-galleryimage',
  templateUrl: './clinicadmin-galleryimage.component.html',
  styleUrls: ['./clinicadmin-galleryimage.component.css']
})

export class ClinicadminGalleryimageComponent implements OnInit {
// ViewChild is used to access the input element.
  @ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', {static: false})InputVar: ElementRef;
  displayedColumns: string[] = ['title', 'action'];
  dataSource;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  getAllGalleryImages: any;
  galleryGroupId: number;
  uploadgalleryForm: FormGroup;
  imgfile: any;
  imgfileonupdate: boolean = false;
  imgerror: any;
  totalSize: number;
  noresults: boolean = false;
  constructor(
    private _DoctorService: DoctorService,
    public toastrService: ToastService,
     private _formBuilder: FormBuilder,
    private router: Router,
    public dialog: MatDialog,
    private _activatedRoute: ActivatedRoute
    ) {
      this.dataSource = new MatTableDataSource;
     }


  ngOnInit(): void {
    this._activatedRoute.paramMap.subscribe(params => {
      this.galleryGroupId = +params.get('id');
    });
     this.uploadgalleryForm = this._formBuilder.group({
      imagetitle: [''],
      choosefile: [''],
    });
    this.getGalleryImages();
  }
  getGalleryImages() {
    this.loading = true;
    this._DoctorService.getGalleryImages(this.galleryGroupId)
      .pipe(first())
      .subscribe((res:any) => {
        if (!res.isError) {
          this.loading = false;
          this.getAllGalleryImages = res?.responseMessage;
          if(this.getAllGalleryImages.length == 0) {
            this.noresults = true;
          }
          else {
            this.noresults = false;
          }
          this.dataSource = new MatTableDataSource(this.getAllGalleryImages);
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  uploadGalleryimage(event, galleryFile) {
    let fileExt = event.target.files[0].type.split('/')[1]
    let fileSize = event.target.files[0].size;
    if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || fileExt === 'webp') {
      if (1000 <= fileSize ) {
        this.imgerror = false;
        let reader = new FileReader(); // HTML5 FileReader API
        let file = event.target.files[0];
        this.imgfile = event.target.files[0];
        this.imgfileonupdate = false;
        if (event.target.files && event.target.files[0]) {
          reader.readAsDataURL(file);
        }
      }
      else {
        galleryFile.value = ''
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Plesae upload an image above 20kb", options);
      }
    }
    else {
      galleryFile.value = ''
      this.imgerror = "Only jpg, jpeg, png file format is accepted"
    }
  }
  createGalleryImage() {
    this.loading = true;
    if(this.uploadgalleryForm.value.imagetitle != '' && this.imgfile != '' &&
    this.uploadgalleryForm.value.imagetitle != null && this.imgfile != null) {
      console.log(this.imgfile)
      let payload = {
        'GalleryGroupid': this.galleryGroupId,
        'GalleryImagetitle': this.uploadgalleryForm.value.imagetitle,
        'Image' : this.imgfile
      }
      this._DoctorService.createGalleryImages(this.galleryGroupId, this.uploadgalleryForm.value.imagetitle,this.imgfile)
      .pipe(first())
      .subscribe((res:any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res?.responseMessage, options);   
          this.getGalleryImages()
          this.uploadgalleryForm.reset();
          this.imgfile = ""
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
    }
    else{
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the mandatory fields', options);
    }
  }
  reset(){
    this.uploadgalleryForm.reset();
    this.imgfile = ""
  }
  deleteGalleryImage(galleryId){
    const dialogRef =  this.dialog.open(DeleteGalleryImageComponent, {
      width: '300px',
      panelClass: 'delete-galleryImagePopup',
      data: galleryId
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result)
      if (result) {
        this.getGalleryImages()
      }
    });
    // this.loading = true;
    // this._DoctorService.deleteGalleryImage(galleryId)
    //   .pipe(first())
    //   .subscribe((res:any) => {
    //     if (!res.isError) {
    //       this.loading = false;
    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //       this.toastrService.success('', res?.responseMessage, options);   
    //       this.getGalleryImages()
    //       this.uploadgalleryForm.reset();
    //     } else {
    //       this.loading = false;
    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //       this.toastrService.warning('', res.errorMessage, options);
    //     }
    //   },
    //   err => {
    //     this.loading = false;
    //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //     this.toastrService.warning('', err?.error, options);
    //   })
  }
  UpdateStaus() {

  }
}

import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';

export interface PeriodicElement {
  date: string;
  productcode: number;
  productname: string;
  qty:number;
  transactiontype:string;
  refno: number;
  createby:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {date: '21-05-2022', productcode:21342424 , productname:'Product1', qty:2 ,transactiontype:'Stockin', refno:32422, createby:'Admin'  },
  {date: '20-05-2022', productcode:23423424 , productname:'Product2', qty:3 ,transactiontype:'Stockissue', refno:42423, createby:'Admin'},{date: '19-05-2022', productcode:42424242 , productname:'Product3', qty:4 ,transactiontype:'Adjustment - Add', refno:34234, createby:'Admin'  },
];

@Component({
  selector: 'app-clinicadmin-producttransactions',
  templateUrl: './clinicadmin-producttransactions.component.html',
  styleUrls: ['./clinicadmin-producttransactions.component.css']
})
export class ClinicadminProducttransactionsComponent implements OnInit {
  displayedColumns: string[] = [ 'date','productcode', 'productname', 'qty','transactiontype','refno','createby'];
   public dataSource: any = new MatTableDataSource([]);
   @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
   createproducttrans: FormGroup;
  todaydate = new Date();   

  // productid
  
  myHolidayDates
  maxDate = new Date();
  selectedDate: any;
  myStartDate: any;
  myEndDate: any;
  timeFrame: any;
  current_date: any;
  Noslotmsg: boolean;
  apt_date: any;
  public filerpastform_pagination_show: boolean;

  startdate: any;
  enddate: any;
  loading: any;
  servid: any;
  btnCreate: any;
  productarray: any = [];
  locationarray: any = [];
  productstocktypearray: any = [];
  addressmodel: any = [];
  chargesProduct: any;
  chargestransid: any;
  clinicid: any;
  domaincurrency: any;
  locatioid: any;
  dysdate: any;
  dyedate: any;
  public totalSize = 0;
  public pageindex = 0;
  public pagesize = 5;

  listdata: boolean;
  filterData: boolean;
  applyfilterData: boolean = false;

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router
    ) { 
  }

  ngOnInit(): void {
  this.chargestransid = '0';
  this.loading = true;
  this.maxDate = new Date();
  this.dataSource.paginator = this.paginator;
  this.createproducttrans = this._formBuilder.group({
      stockproduct: [''],
      producttranstype: [''],
      stocklocation: [''],
      startdate: [''],
      enddate: ['']
    });

  this.domaincurrency = sessionStorage.getItem('domaincurrencydetails');
  this.locatioid = sessionStorage.getItem('defaultlocationmapid');
  this.clinicid = sessionStorage.getItem('clinicId');

   this.btnCreate = false;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('productid')) {
        this.servid = params?.get('productid');
        this.createproducttrans.get('stockproduct').setValue(Number(this.servid));
        this.createproducttrans.get('stocklocation').setValue(Number(this.locatioid));
      }
    })

  this._DoctorService.getlocations(this.clinicid)
      .pipe(first())
      .subscribe((res: any) => {
         this.locationarray = res?.responseMessage;
        console.log('location details',res?.responseMessage);
        },
        err => {
     });

   // Get product list 
  this._DoctorService.getProductlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.productarray = res?.responseMessage;
          console.log('product details',res?.responseMessage);
        },
        err => {
    });

  // Get producttranstype list 
  this._DoctorService.getproducttranstype()
      .pipe(first())
      .subscribe((res: any) => {
         this.productstocktypearray = res?.responseMessage;
          console.log('product details',res?.responseMessage);
        },
        err => {
    });

var currentDate = moment(new Date());
var futureMonth = moment(currentDate).add(1, 'M');
var futureMonthEnd = moment(futureMonth).endOf('month');

const datde = new Date();
let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, 1)
let ssdate = moment(dydate).format('YYYY-MM-DD'); 
this.dysdate = moment(dydate).format('YYYY-MM-DD'); 

if(currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
  futureMonth = futureMonth.add(1,'d');
}

let eedate = moment(currentDate).format('YYYY-MM-DD');
this.dyedate = moment(currentDate).format('YYYY-MM-DD');

  this._DoctorService.getproducttranslist(0,5,this.servid,this.locatioid,this.dysdate,this.dyedate,this.chargestransid)
    .pipe(first())
    .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.responseMessage;

          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          
          console.log(array)
          this.dataSource = new MatTableDataSource(array);
          // this.totalSize = res?.pagination?.total;
          // this.dataSource.paginator = this.paginator
          // this.totalSize = res?.pagination?.total;
          // console.log(res?.pagination?.total)
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });    
    }

  selectedproduct(event){
  this.chargesProduct = event.value;
  this.servid = event.value;
   console.log('product change',this.chargesProduct, event.value);
  }
  
  selectedtrans(event){
  this.chargestransid = event.value;
   console.log('product change',this.chargestransid, event.value);
  }
  
  selectedlocat(event){
  this.locatioid= event.value;
   console.log('product change',this.locatioid, event.value);
  }

  getNext(event) {
      this.loading = true;
      let array = [];
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');

      if(this.dysdate != '' && this.dyedate != '') {

      }else{
      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, 1)
      this.dysdate = moment(dydate).format('YYYY-MM-DD'); 

      if(currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1,'d');
      }

      this.dyedate = moment(currentDate).format('YYYY-MM-DD');
      }

      this._DoctorService.getproducttranslist(event.pageIndex, event.pageSize,this.servid,this.locatioid,this.dysdate,this.dyedate,Number(this.chargestransid))
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if(!res.isError) {
            let array = [];
            this.addressmodel = res?.responseMessage;
            this.loading = false;
            for(let item of res?.responseMessage) {
              let d = new Date(item?.date);
                item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
                array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
  }

  addprostock(formData: any, formDirective: FormGroupDirective){
   let sDate="";
   let eDate="";
   
   console.log('product trans ', this.createproducttrans.value)
    if (this.createproducttrans.value.startdate != '' && this.createproducttrans.value.enddate != '') {
      sDate = moment(this.createproducttrans.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.createproducttrans.value.enddate).format('YYYY-MM-DD');

      this.dysdate = moment(this.createproducttrans.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.createproducttrans.value.enddate).format('YYYY-MM-DD');

    }
   if (this.createproducttrans.value.startdate == '' || this.createproducttrans.value.enddate == '') {
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');

      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, 1)
      sDate = moment(dydate).format('YYYY-MM-DD'); 

      if(currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1,'d');
      }

      eDate = moment(currentDate).format('YYYY-MM-DD');

      this.dysdate = sDate;
      this.dyedate = eDate;
   }

   let protypes = "";
   if(this.createproducttrans.value.producttranstype == ''){
     protypes = '0';
     this.chargestransid = '0';
   }else{
     protypes = this.createproducttrans.value.producttranstype;
     this.chargestransid = this.createproducttrans.value.producttranstype;
   }

   this.applyfilterData = true;

   this.loading = true;
    let array = [];
    this._DoctorService.getproducttranslist(0, 5,this.createproducttrans.value.stockproduct, this.locatioid,this.dysdate, this.dyedate ,Number(this.chargestransid))
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          let array = [];
          this.addressmodel = res?.responseMessage;
             this.loading = false;
             if(this.dataSource.paginator) {
              this.dataSource.paginator.firstPage();
            }
          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          console.log('product transaction res ', res)
            setTimeout(() => {
              this.totalSize = res?.pagination?.total;
              this.pageindex = res?.pagination?.pageNumber;
              this.pagesize = res?.pagination?.pageSize;
              // this.dataSource.paginator = this.paginator
            });
          
          if(this.dataSource.paginator) {
                this.dataSource.paginator.pageIndex = 0;
            }

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

  }

  addprostocknext(formData: any, formDirective: FormGroupDirective,event){
   let sDate="";
   let eDate="";
   
   console.log('product trans ', this.createproducttrans.value)
    if (this.createproducttrans.value.startdate != '' && this.createproducttrans.value.enddate != '') {
      sDate = moment(this.createproducttrans.value.startdate).format('YYYY-MM-DD');
      eDate = moment(this.createproducttrans.value.enddate).format('YYYY-MM-DD');

      this.dysdate = moment(this.createproducttrans.value.startdate).format('YYYY-MM-DD');
      this.dyedate = moment(this.createproducttrans.value.enddate).format('YYYY-MM-DD');

    }
   if (this.createproducttrans.value.startdate == '' || this.createproducttrans.value.enddate == '') {
      var currentDate = moment(new Date());
      var futureMonth = moment(currentDate).add(1, 'M');
      var futureMonthEnd = moment(futureMonth).endOf('month');

      const datde = new Date();
      let dydate = new Date(datde.getFullYear(), datde.getMonth() - 1, 1)
      sDate = moment(dydate).format('YYYY-MM-DD'); 

      if(currentDate.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
        futureMonth = futureMonth.add(1,'d');
      }

      eDate = moment(currentDate).format('YYYY-MM-DD');

      this.dysdate = sDate;
      this.dyedate = eDate;
   }

   let protypes = "";
   if(this.createproducttrans.value.producttranstype == ''){
     protypes = '0';
     this.chargestransid = '0';
   }else{
     protypes = this.createproducttrans.value.producttranstype;
     this.chargestransid = this.createproducttrans.value.producttranstype;
   }

   this.applyfilterData = true;

   this.loading = true;
    let array = [];
    this._DoctorService.getproducttranslist(event.pageIndex,event.pageSize,this.createproducttrans.value.stockproduct, this.locatioid,this.dysdate, this.dyedate ,Number(this.chargestransid))
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          let array = [];
          this.addressmodel = res?.responseMessage;
             this.loading = false;
            
          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);

            setTimeout(() => {
              this.totalSize = res?.pagination?.total;
              this.dataSource.paginator = this.paginator;
               this.dataSource.paginator.firstPage();
            });
          
          if(this.dataSource.paginator) {
            this.dataSource.paginator.pageIndex = 0;
          }

           if(this.dataSource.data.length === 0) {
              this.listdata = true;
              this.filterData = true;
            }
            else {
              this.listdata = false;
              this.filterData = false;
            }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

  }


}
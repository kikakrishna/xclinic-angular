import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminProducttransactionsComponent } from './clinicadmin-producttransactions.component';

describe('ClinicadminProducttransactionsComponent', () => {
  let component: ClinicadminProducttransactionsComponent;
  let fixture: ComponentFixture<ClinicadminProducttransactionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminProducttransactionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminProducttransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

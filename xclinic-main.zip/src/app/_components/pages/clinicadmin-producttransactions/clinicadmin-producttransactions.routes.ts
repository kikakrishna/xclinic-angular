import { RouterModule } from '@angular/router';
import { ClinicadminProducttransactionsComponent } from './clinicadmin-producttransactions.component';
export const ClinicadminProducttransactionsRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminProducttransactionsComponent ,
    }
]
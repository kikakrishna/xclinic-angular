import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter';
import { MY_DATE_FORMATS } from '../appointments/my-date-formats';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { ClinicadminBookappointmentComponent } from '../clinicadmin-bookappointment/clinicadmin-bookappointment.component';
import { ClinicadminBookappointmentRoutes } from '../clinicadmin-bookappointment/clinicadmin-bookappointment.routes';
import {MatRadioModule} from '@angular/material/radio';

@NgModule({
  declarations: [ClinicadminBookappointmentComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(ClinicadminBookappointmentRoutes),
    FormsModule, ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    MatSelectModule,
    MatButtonModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatRadioModule
  ],
  exports: [ClinicadminBookappointmentComponent],
  providers: [
    // { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { strict: true } },

    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },

  ]
})
export class ClinicadminBookappointmentModule { }

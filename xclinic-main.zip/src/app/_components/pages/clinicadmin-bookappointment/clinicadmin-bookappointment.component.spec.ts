import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminBookappointmentComponent } from './clinicadmin-bookappointment.component';

describe('ClinicadminBookappointmentComponent', () => {
  let component: ClinicadminBookappointmentComponent;
  let fixture: ComponentFixture<ClinicadminBookappointmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminBookappointmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminBookappointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

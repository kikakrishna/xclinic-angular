import { RouterModule } from '@angular/router';
import { ClinicadminBookappointmentComponent } from '../clinicadmin-bookappointment/clinicadmin-bookappointment.component';

export const ClinicadminBookappointmentRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminBookappointmentComponent,
    }
]
import { Component, NgZone, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import { observable, Observable } from 'rxjs';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { PatientService } from '../../../_services/patient.service';
import { DoctorService } from '../../../_services/doctor.service';
import * as moment from 'moment';
import { MatCalendar } from '@angular/material/datepicker';
import { ShareDataService } from '../../../_services/sharedata.service';
declare var $;
import { WindowRefService } from 'src/app/_services/window-ref.service';
import {of} from 'rxjs';


@Component({
  selector: 'app-clinicadmin-bookappointment',
  templateUrl: './clinicadmin-bookappointment.component.html',
  styleUrls: ['./clinicadmin-bookappointment.component.css']
})
export class ClinicadminBookappointmentComponent implements OnInit {
  patid: number;
  loading: boolean;
  Medihistory_array: any;
  filter = new FormControl();
  calStartDate 
  calEndDate 
  ppId: number;
  profileImage: string;
  clinicId: any;
  finalFee: any;
  getAllDoctor: any;
  isConsultaionselected: boolean = false
  isCodemap: boolean = false
  doctorslist: Observable<string[]>;
  myControl = new FormControl();
  speclilatylist: any = [];
  public testarray: any = [];
  Book_SelectedDocInfo: any = "";
  consultationTypeArrayBookappointment: any = [];
  consultationTypeArrayBookappointmentArray: any = [];
  doctorlist: any;
  nodoctorlist: boolean;
  searchform: FormGroup;
  myHolidayFilter: any = [];
  locationData: any [];
  selectedLocation: any;
  locationDate: any;
  bookappointmentDet: any;
  timeslots: any = [];
  myHolidayDates
  slotimeid = "";
  showmsg: boolean;
  selectedDate: any = "";
  Noslotmsg: boolean;
  maxdate = new Date();
  slottime: any;
  public SelectedSlotDet: any;
  searchDoctorItem: any;
  rescheduleapptdetails: any;
  reschedulewalkin: any;
  rescheduledocdetails: any;
  reschedulepatientdetails: any;
  mycheck: Boolean = false;
  consultationType: any;
  ConsulationtypeList: any = [];
  showPaymentType: boolean;
  public clickedselectedDate: string = "";
  Book_SelectedDoctor: any = ""
  Book_SelectedSpeciality: any = ""
  @ViewChild('calendar', { static: false }) calendar: MatCalendar<any>;
  consulttext: any;
  paymentTy: any;
  Iswalk_inselected: boolean = true;
  walkin_appoinmentdate
  userSelectedconsultationType

   // Payments section
   paymethodlist: any = [];
   cardpaymentform: boolean;
   Insuranceform: FormGroup;
   user_id: string;
   pat_id: string;
   ord_id: any;
   sign: any;
   parentaId: any;
   pAId: number;
   sloterrormsg: boolean;
   stdate: string;
   blckbtn:boolean = false;
   forbiddenmessagebox: boolean;
   messagecontent: any;
   pay_id: any;
   consFess: number;
   checkproerror: boolean;
   messagecontentflag: any;
   navigateflag: any;
   errormessagebox: boolean;
   mobilenumber: any;
   razorinfo: any;
   checkpro: any;
   masteruser_id: string;
   docdetails: any;
   docdClinicVisit: any;
   followupdetails = null;
   myfollowupdetails: any = ""
   apptdetails: any = "";
   patdetails: any;
   patLocaDetail: any;
   clinicID: any;
   doctorimage: any;
   docimage: any;
   cashpaymentform: boolean;
   docid: any;
   cliname: any;
   specid: any;
   odId: any;
   skey: any;
   paymentId: any;
   orderId: any;
   signature: any;
   razorpaymentform: boolean;
   activepaymethod: any;
   availablepaymethods: any;
   freeapptform: boolean;
   insuranceform: boolean;
   newArray: any = [];
   apptid: any;
   successection: boolean;
   paymentsection: boolean;
   resposnsedata: any;
   methodtype: any;
   searchspecial: any;
   searchdoc: any;
   searchdocspecial: any;
   searchddates: any;
   searchdoctordates: any;
   parentGroup: FormGroup;
   pageCheck: any;
   consultationType_walkin = "";
   walkin_appoinmentDate;
   selectedconsultationtype;
   disabledIswalkin: boolean = false;
   IspressedNextperviouscalenderbtn: boolean = false;
  constructor(
    private _formBuilder: FormBuilder,
    private _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    private toastrService: ToastService,
    private _patientservice: PatientService,
    private router: Router,
    private sharedataService: ShareDataService,
    private winRef: WindowRefService,
    private ngZone: NgZone,
  ) { }

  ngOnInit(): void {

    this.calStartDate = new Date();
    this.selectedLocation = ""
    this.loading = true;
    this._activatedRoute.paramMap.subscribe(params => {
      this.patid = +params.get('patientId');
    });
    this.searchform = this._formBuilder.group({
      doctorname: [''],
      speciality: [''],
    })
    this.clinicId = sessionStorage.getItem('clinicId');
    // this.rescheduledocdetails = this.sharedataService.ResheclinicadminDoctordetails;
    // this.rescheduleapptdetails = this.sharedataService.ResheclinicadminAppointmentdetails;
    // this.reschedulepatientdetails = this.sharedataService.ResheclinicadminPatientdetails;
    // this.reschedulewalkin = this.sharedataService.Resheclinicadminwalkinconsultation;

    // if(sessionStorage.getItem('changedate') == 'yes'){
    //   sessionStorage.setItem('changedate','yes')
    //   this.isConsultaionselected = true;
    //   this.selectedDate =moment(this.sharedataService?.clinicadminAppointmentdetails?.slotTime).format('YYYY-MM-DD')

    //    this.sharedataService.docdetails?.doctorConsultationType.filter(docContype =>{
    //           if(docContype?.status == 1){
    //              docContype.loccm.map((data) =>{
    //                 if(data.isConsultationCodeMapped == true){
    //                   this.isCodemap = true
    //                   }

    //                   if(data.isConsultationCodeMapped == true){
    //                   if(data.isConsultationCodeMapped == true && data.defaultlocation == true){
    //                   this.selectedLocation = data.clinicLocationMapId;
    //                   }
    //                   }
    //                   if(data.isConsultationCodeMapped == false && data.defaultlocation == false){
    //                   this.selectedLocation = data.clinicLocationMapId;
    //                   }                    
    //              })

    //              this.locationData = docContype.loccm;
    //           }
    //        })

    // }else{
    //   sessionStorage.setItem('changedate','')
    //   this.isConsultaionselected = false;
    // }
    
    // if( this.sharedataService.locMapid != undefined){
    //    this.selectedLocation = this.sharedataService.locMapid;
    // }

    // if(this.rescheduledocdetails) {
    //   this.sharedataService.ResheclinicadminDoctordetails = ""
    // }
    // if(this.rescheduleapptdetails) {
    //   this.sharedataService.ResheclinicadminAppointmentdetails = ""
    // }
    // if(this.reschedulepatientdetails) {
    //   this.sharedataService.ResheclinicadminPatientdetails = ""
    // }
    // if(this.reschedulewalkin) {
    //   this.sharedataService.Resheclinicadminwalkinconsultation = ""
    // }

    // if(this.rescheduleapptdetails) {
    //   this.consultationType = this.rescheduleapptdetails.consultationtype;
    //   this.userSelectedconsultationType = this.rescheduleapptdetails.consultationtype;
    // }
    // if (this.reschedulewalkin) {
    //   this.consultationType = this.reschedulewalkin;
    // }

    this._DoctorService.medihistory(this.patid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError && res.responseMessage != null) {
          this.Medihistory_array = res?.responseMessage;
          sessionStorage.setItem("mobilenumber", res?.responseMessage?.mobileNumber)
          this.ppId = res?.responseMessage?.patientProfileId;
          if (res?.responseMessage.patientProfile != null) {
            this.profileImage = res.responseMessage.patientProfile;
          } else {
            this.profileImage = "./assets/images/noimage.webp";
          }
          this.loading = false;
        } else {
          this.profileImage = "./assets/images/noimage.webp";

          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });

    this.speciality();

    // if(this.rescheduledocdetails) {
    //   // to load speciality
    //   this.searchform.get('speciality').setValue(this.rescheduledocdetails.specialityId);
    //   this.reschedulechangeSpecility()
    //   let redate = this.rescheduleapptdetails.slotTime.substr(0, 10)
    //   let f = new Date(redate);
    //   let a = moment(f, "MM/DD/YYYY");
    //   this.calendar?._goToDateInView(a, 'month');
    //   this.myHolidayFilter = (d: Date): any => {
    //   }
    //   return;
    // }

    this._patientservice.getLocation(this.clinicId)
      .subscribe((res: any) => {
         let locationArray = [];
         if(res.isError == false){
           res.responseMessage.map((data)=>{
           if(data.defaultclinic == true){         
           }
            locationArray.push({"clinicLocationMapId":data.clinicLocationMapId,
              "locationName":data.locationName,
              "defaultclinic":data.defaultclinic,
              })
           })
         }
      })



  }
  // loads speciality
  speciality() {
    this.loading = true;
    this._patientservice.specialitylist(this.clinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.speclilatylist = res.responseMessage;
        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      });
  }

  FilterSpecilitydoc: any = [];
  changeSpecility() {
    this.doctorlist = '';
    this.confirmPayment = false;
    this.loading = true;
    let payload = {
      "SpecialityId": this.searchform.value.speciality
    }

    this._patientservice.clinicadminDocfilterByspecility(payload)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.Book_SelectedDocInfo = res.responseMessage;
          this.FilterSpecilitydoc = res.responseMessage;
          this.doctorslist = res.responseMessage.doctors;
        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      });
    return;
  }

  reschedulechangeSpecility() {
    // Book_SelectedSpeciality
    this.doctorlist = '';
    this.loading = true;
    let payload = {
      "SpecialityId": this.searchform.value.speciality
    }
    this._patientservice.clinicadminDocfilterByspecility(payload)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.FilterSpecilitydoc = res.responseMessage;
          this.doctorslist = res.responseMessage.doctors;
          // setting selected speciality reschue
          this.searchform.get('speciality').setValue(this.rescheduledocdetails.specialityId);
          // setting selected doctor while reschue                      
          res?.responseMessage?.doctors?.findIndex(x => {
            if (x?.doctorId == this.rescheduledocdetails?.doctorId) {            
              this.Book_SelectedDocInfo = x;
              this.Book_SelectedDocInfo.currencyDetails = this.FilterSpecilitydoc.currencyDetails
            }
          })
          this.doctorlist = this.Book_SelectedDocInfo
          this.showPaymentType = true;
        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      }, () => {

        // reload consultation type while reschedule
        this.rescheduleconsulationtype();

      });
    return;
  }

  rescheduleconsulationtype() {
    this._patientservice.ClinicadminGetconsultationslots(this.rescheduledocdetails?.doctorId)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.consultationTypeArrayBookappointmentArray = res.responseMessage;
        }
        else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      }, () => {

      setTimeout(()=>{
           this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype =>{
              if(docContype?.status == 1){
                 docContype.loccm.map((data) =>{
                    if(data.isConsultationCodeMapped == true){
                      this.isCodemap = true
                    }
                 })
              }
           })

        let CodemappedTrueArray = this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
          if (docContype?.status == 1) {
             return this.consultationTypeArrayBookappointmentArray.some(allContype => 
                this.isCodemap == true && docContype.status == 1
             )
          }
        });

        let tempArray = [];
        for(let it of this.consultationTypeArrayBookappointmentArray) {
          CodemappedTrueArray.filter(i => {
           if(it?.consultationTypeId == i.typeId) {
              tempArray.push(it)
            }
          })
        }

        let array = tempArray;
        var unique = [];
        var distinct = [];
        for( let i = 0; i < array.length; i++ ){
        if( !unique[array[i].consultationTypeId]){
        distinct.push(array[i]);
        unique[array[i].consultationTypeId] = 1;
        }
        }

        this.consultationTypeArrayBookappointment = distinct;

        this.consultationType = this.rescheduleapptdetails?.consultationtype;
        if (this.consultationType == 1 || this.consultationType == 2) {
          let reAppdet = moment(this.rescheduleapptdetails?.slotTime).format('YYYY-MM-DD')
          this.loadDoctorDateInCalender(this.doctorlist);
          this.getslots(moment(reAppdet).format('YYYY-MM-DD'));
        }


        if (this.consultationTypeArrayBookappointment.length > 1) {
        } else {
        if (this.consultationTypeArrayBookappointment.length == 1) {
        if(this.consultationType == 2 || this.consultationType == 102){
        this.isConsultaionselected = true;
        }

        if(this.consultationType == 1){
        this.isConsultaionselected = false;
        }

        this.consultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
        this.userSelectedconsultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
        this.radioChangeForSingletype();
        }
        }



       },3000)
     
      })
  }
  
  searchDoctorValue() {
    this.doctorlist = '';
    if (this.rescheduleapptdetails && this.mycheck == true) {
      this.timeslots.length = 0;
      this.selectedDate = null;
      this.mycheck = false;
      this.rescheduleapptdetails = "";
      this.rescheduledocdetails = "";
      this.searchDoctorValue();
      return;
    } else {
      let payload = {
        "SearchString": this.searchform.value.doctorname
      }
      this.searchDoctorItem = payload;
      this._patientservice.doctoravailableWithDoctornameSearch(payload)
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.doctorlist = res?.responseMessage;
            if (this.doctorlist.length > 0 || this.doctorlist != "") {
              for (let docitem of this.doctorlist) {
                docitem.Isopenstep = true;
                if (docitem.slotModel != null) {
                  docitem.availableon = moment(docitem.slotModel.slotTime).format('ll');
                }
                else {
                  docitem.availableon = "No Slots"
                }
                for (let consultationTypes of docitem.doctorConsultationType) {
                  if (consultationTypes.consultationType == 'Online Consultation') {
                    consultationTypes.doctorFee = docitem.doctorFees.domesticFee;
                    docitem.onlineconsultStatus = consultationTypes.status;
                  }
                  if (consultationTypes.consultationType == "Clinic Visit") {
                    consultationTypes.doctorFee = docitem.doctorFees.clinicVisitFee;
                    docitem.clinicvisitStatus = consultationTypes.status;
                  }
                  if (consultationTypes.consultationType == "Walk-In") {
                    consultationTypes.doctorFee = docitem.doctorFees.walkInFee;
                    docitem.walkin = consultationTypes.status;
                  }
                 
                }
              }
              if (this.doctorlist != undefined) {
                this.Openstepper(this.doctorlist);
              }
            }
            else {
              this.nodoctorlist = true;
            }

          } else {
            this.loading = false;
          }
        }, err => {
          this.loading = false;
        });
      return
    }
  }

  // auto submit after doctor select
  changeDoctor() {
    this.loading = true;
    this.clearSlots();
    this.consultationTypeArrayBookappointmentArray.length = 0;
    this.consultationTypeArrayBookappointment.length = 0;
    this.testarray.length = 0;
    this.clearvaluesforsingleTypeload()
    this.consultationType = "";
    this.consulttext = "";
    this.Book_SelectedDocInfo.currencyDetails = this.FilterSpecilitydoc.currencyDetails
    this.doctorlist = this.Book_SelectedDocInfo;
    this.showPaymentType = true; 
    this.isConsultaionselected = false;
    this.confirmPayment = false;

    this._patientservice.ClinicadminGetconsultationslots(this.Book_SelectedDocInfo?.doctorId)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = true; 
          let consultationTypeArrayBookappointmentArray = res.responseMessage;
          this.consultationTypeArrayBookappointmentArray = consultationTypeArrayBookappointmentArray.sort( (a,b)=> a.consultationType > b.consultationType ? -1:1 ).reverse()
          }
        else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      })

      this.loading = true;
      setTimeout(()=>{
       this._patientservice.ClinicadminGetconsultationslots(this.Book_SelectedDocInfo?.doctorId)
      .subscribe((res: any) => {
        this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype =>{
              if(docContype?.status == 1){
                 docContype.loccm.map((data) =>{
                    if(data.isConsultationCodeMapped == true){
                      this.isCodemap = true
                      }

                      if(data.isConsultationCodeMapped == true){
                      if(data.isConsultationCodeMapped == true && data.defaultlocation == true){
                      this.selectedLocation = data.clinicLocationMapId;
                      }
                      }
                      if(data.isConsultationCodeMapped == false && data.defaultlocation == false){
                      this.selectedLocation = data.clinicLocationMapId;
                      }                    
                 })

                 this.locationData = docContype.loccm;
              }
           })

        let CodemappedTrueArray = this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
          if (docContype?.status == 1) {
             return this.consultationTypeArrayBookappointmentArray.some(allContype => 
                this.isCodemap == true && docContype.status == 1
             )
          }
        });


        let tempArray = [];
        for(let it of this.consultationTypeArrayBookappointmentArray) {
          CodemappedTrueArray.filter(i => {
           if(it?.consultationTypeId == i.typeId) {
              tempArray.push(it)
            }
          })
        }

        let array = tempArray;
        var unique = [];
        var distinct = [];
        for( let i = 0; i < array.length; i++ ){
        if( !unique[array[i].consultationTypeId]){
        distinct.push(array[i]);
        unique[array[i].consultationTypeId] = 1;
        }
        }

        this.consultationTypeArrayBookappointment = distinct;
         // if multiple type have na
        if(this.consultationTypeArrayBookappointment.length > 1) {
             
        } else {
                  if (this.consultationTypeArrayBookappointment.length == 1) {
                  if(this.consultationType == 2 || this.consultationType == 102){
                  this.isConsultaionselected = true;
                  }else{
                  this.isConsultaionselected = false;
                  }

                  // if only one type , it will selected that type by default
                  this.consultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;

                  this.userSelectedconsultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
                  this.radioChangeForSingletype();
                  }
               }
      })
      this.loading = false;
      },2500)

    this.showdisabledalldates();
  }

  // this radioChangeForSingletype function only activate on single type only
  radioChangeForSingletype() {    
    this.SelectedSlotDet = {};
    this.timeslots.length = 0;
    if(this.consultationType == 102) {
    this.isConsultaionselected = true;
      $('.mat-calendar-next-button').addClass("disabled").attr('disabled', true);
      // walk in  selected na
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
      this.selectedDate = this.walkin_appoinmentdate;
      // selecting today date in calender
      this.myHolidayFilter = (d: Date): any => {
        return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
      }
      this.getslots(this.walkin_appoinmentdate)
      return;
      } else {
       if(this.consultationType == 2 || this.consultationType == 102){
           this.isConsultaionselected = true;
          }else{
            this.isConsultaionselected = false;
          }
      $('.mat-calendar-next-button').removeClass("disabled").removeAttr('disabled', true);
      this.Iswalk_inselected = true;
      // not walkin selected
    }

    // this will enable while reschedule
    if (this.clickedselectedDate && this.rescheduleapptdetails?.consultationtype == 1 || this.rescheduleapptdetails?.consultationtype == 2) {
      this.NextPreviousslots();
      // reschdule with same date
      if (this.clickedselectedDate == moment(this.rescheduleapptdetails?.slotTime).format('YYYY-MM-DD')) {
        this.clickedselectedDate = moment(this.rescheduleapptdetails?.slotTime).format('YYYY-MM-DD')
        this.loadDoctorDateInCalender(this.doctorlist);
        this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));

      } else {
        // reschdule with diff date
        this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
      }
      return;
    }

    // it enable while nextpervious button press
    if (this.IspressedNextperviouscalenderbtn == true) {
      this.NextPreviousslots();
      this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
      return;
    }
    this.loadDoctorDateInCalender(this.doctorlist);

    if (this.clickedselectedDate != "") {
      this.loadDoctorDateInCalender(this.doctorlist);
      this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
    }
  }

  clearvaluesforsingleTypeload() {
    // this.doctorlist = '';
    // this.searchform.reset();
    this.consultationType = ""
    this.clickedselectedDate = ""
    this.timeslots.length = 0
    this.myHolidayFilter = [];
    this.myHolidayDates = ""
    this.bookappointmentDet = ""
    this.selectedDate = "";
    this.IspressedNextperviouscalenderbtn = false;
    // this.ngOnInit();
  }
  // intiall loads disable dates
  showdisabledalldates() {
    this.selectedDate = "";
    this.showPaymentType = true;
    this.myHolidayFilter = (d: Date): any => {
      return false;
    }
  }

  // consulation type change function
  radioChange($event, docdetails) {
  // WFH
   this.IspressedNextperviouscalenderbtn = false;
    console.log(this.IspressedNextperviouscalenderbtn)
    this.SelectedSlotDet = {};
    this.timeslots.length = 0;
    this.userSelectedconsultationType = $event.value;
    this.consultationType = $event.value;
    console.log(this.consultationType)
    this.clickedselectedDate = ""
    if(this.consultationType) {
      this.isConsultaionselected = true;
    } else {
      this.isConsultaionselected = false;
    }

    this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype =>{
        if(docContype?.status == 1){
            docContype.loccm.map((data) =>{
                if($event.value ==  docContype.typeId){
                  if(data.isConsultationCodeMapped == true){
                    if(data.isConsultationCodeMapped == true && data.defaultlocation == true){
                      return this.selectedLocation = data.clinicLocationMapId;
                    }
                  }else{
                    return this.selectedLocation = data.clinicLocationMapId;
                  }
                }
            })

            this.locationData = docContype.loccm;
        }
      })
           
    console.log(this.Book_SelectedDocInfo)
    if(sessionStorage.getItem('changedate') !=  'yes'){ 
     if(this.consultationType == 102) {
      $('.mat-calendar-next-button').addClass("disabled").attr('disabled', true);
      // walk in  selected na
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
      this.selectedDate = this.walkin_appoinmentdate;
      // selecting today date in calender
      this.myHolidayFilter = (d: Date): any => {
        return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
      }
      this.loadwalkinDate()
      this.getslots(this.walkin_appoinmentdate);
      return;
    } else {
     this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
      this.selectedDate = this.walkin_appoinmentdate;
      this.myHolidayFilter = (d: Date): any => {
        return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
      }
     this.getslots(this.walkin_appoinmentdate)
      $('.mat-calendar-next-button').removeClass("disabled").removeAttr('disabled', true);
      this.Iswalk_inselected = true;
      // not walkin selected
    }
    }

    // return;
    // this will enable while reschedule
    //if (this.clickedselectedDate && this.rescheduleapptdetails?.userSelectedconsultationType == 1 || //this.rescheduleapptdetails?.userSelectedconsultationType == 2) {
    if (this.clickedselectedDate && this.rescheduleapptdetails?.consultationtype == 1 || this.rescheduleapptdetails?.consultationtype == 2) {
      this.NextPreviousslots();
      // reschdule with same date
      if (this.clickedselectedDate == moment(this.rescheduleapptdetails?.slotTime).format('YYYY-MM-DD')) {
        this.clickedselectedDate = moment(this.rescheduleapptdetails?.slotTime).format('YYYY-MM-DD')
        // this.loadDoctorDateInCalender(this.doctorlist);
        this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));

      } else {
        // reschdule with diff date
        this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
      }
      return;
    }

    // it enable while nextpervious button press
    // if (this.IspressedNextperviouscalenderbtn == true) {
    //   this.NextPreviousslots();
    //   this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
    //   return;
    // }
    this.loadDoctorDateInCalender(this.doctorlist);
    console.log(this.clickedselectedDate )
    if (this.clickedselectedDate != "") {
      this.loadDoctorDateInCalender(this.doctorlist);
      this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
    }
  }

  loadDoctorDateInCalender(doctor) {
    // alert('in')
    this.NextPreviousslots()
    this.bookappointmentDet = doctor;
    console.log(doctor.slotModel.slotTime)
    if (doctor.slotModel != null) {
      let f = new Date(doctor.slotModel.slotTime.substr(0, 10));
      let a = moment(f, "MM/DD/YYYY");
      setTimeout(() => {
        this.calendar?._goToDateInView(a, 'month');
      });
      setTimeout(() => {
        this.getBookingslots(doctor.slotModel.slotTime);
      })
    }
  }
  loadcalenderDates() {
    let localarray = []
    this.myHolidayFilter = (d: Date): any => {
      localarray.push(moment(d).format('YYYY-MM-DD'));
    }
    setTimeout(() => {
      // rescheduleapptdetails
      let payload = {
        StartDate: localarray[0],
        EndDate: localarray[localarray.length - 1],
        ClinicId: this.doctorlist.clinicId,
        DoctorId: this.doctorlist.doctorId,
       // ConsultationType: this.consultationType
        CliniclocMapid: this.selectedLocation
      }

      this._patientservice.getdateslot(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.myHolidayDates = res?.responseMessage[0]?.slotDates;
            this.myHolidayFilter = (d: Date): any => {
              return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
            }
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          })
    });
  }
  Openstepper(data) {
    if (data.onlineconsultStatus == 1 && data.clinicvisitStatus == 1) {
      this.showPaymentType = true;
    }
    else {
      this.showPaymentType = false;
    }
    this.NextPreviousslots()
    this.bookappointmentDet = data;
    this.timeslots.length = 0;
    if (data.onlineconsultStatus == 1) {
      this.consultationType = 1
    } else if (data.clinicvisitStatus == 1) {
      this.consultationType = 2
    }
    // load only specif slots date avaliable
    if (data.slotModel) {
      let resDate = data.slotModel.slotTime;
      data.slotModel.slotTime = resDate.substr(0, 10)
      let f = new Date(data.slotModel.slotTime);
      let a = moment(f, "MM/DD/YYYY");
      let IscallafterDate = false
      setTimeout(() => {
        this.calendar?._goToDateInView(a, 'month');
        IscallafterDate = true;
      });
      setTimeout(() => {
        if (IscallafterDate == true) {
          this.getBookingslots(data.slotModel.slotTime);
        }
      })
      return;
    } else {
      // load today slots date
      let a = '';
      this.getBookingslots(a);
      return;
    }

  }
  
  NextPreviousslots() {
    // alert('innext')
    setTimeout(() => {
      let myarray = [];
      const prev = document.querySelector('.mat-calendar-previous-button');
      const next = document.querySelector('.mat-calendar-next-button');
      
      prev.addEventListener('click', () => { // Previous Button
        this.IspressedNextperviouscalenderbtn = true
        myarray.length = 0;
        this.myHolidayFilter = (d: Date): any => {
          myarray.push(moment(d).format('YYYY-MM-DD'))
        }
        setTimeout(() => {
          this.slotimeid = "";
          this.loading = true;
          let payload = {
            StartDate: myarray[0],
            EndDate: myarray[myarray.length - 1],
            ClinicId: this.doctorlist.clinicId,
            DoctorId: this.doctorlist.doctorId,
            CliniclocMapid: this.selectedLocation
          }
          console.log(payload)
          this._patientservice.getdateslot(payload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                this.myHolidayDates = res?.responseMessage[0]?.slotDates;
                this.myHolidayFilter = (d: Date): any => {
                  return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
                }
              }
              else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);
              })
        });
      });

      next.addEventListener('click', () => { // Next Button
        this.IspressedNextperviouscalenderbtn = true
        myarray.length = 0;
        this.myHolidayFilter = (d: Date): any => {
          myarray.push(moment(d).format('YYYY-MM-DD'))
        }
        setTimeout(() => {
          this.slotimeid = "";
          this.loading = true;
          let payload = {
            StartDate: myarray[0],
            EndDate: myarray[myarray.length - 1],
            ClinicId: this.doctorlist.clinicId,
            DoctorId: this.doctorlist.doctorId,
            CliniclocMapid: this.selectedLocation
          }
          console.log(payload)
          this._patientservice.getdateslot(payload)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                this.myHolidayDates = res?.responseMessage[0]?.slotDates;
                this.myHolidayFilter = (d: Date): any => {
                  return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
                }

              }
              else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);
              })
        });
      });

    }, 150);
  }

  // it loads slot model dates depends on api response
  getBookingslots(a) {
    this.loading = true;
    var myarray = [];
    // To make the slot date as selected;
    this.myHolidayFilter = (d: Date): any => {
      if (a) {
        if (moment(d).format('YYYY-MM-DD') >= moment(a).format('YYYY-MM-DD')) {
          myarray.push(moment(d).format('YYYY-MM-DD'));
        }
      } else {
        myarray.push(moment(d).format('YYYY-MM-DD'));
      }
    }

    console.log(myarray);
    // Previous code

    setTimeout(() => {
      this.loading = true;
      let payload = {
        StartDate: myarray[0],
        EndDate: myarray[myarray.length - 1],
        ClinicId: this.doctorlist.clinicId,
        DoctorId: this.doctorlist.doctorId,
        CliniclocMapid: this.selectedLocation
      }
      console.log(payload);
      this._patientservice.getdateslot(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.myHolidayDates = res?.responseMessage[0]?.slotDates;
            this.myHolidayFilter = (d: Date): any => {
              return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
            }
            if (this.clickedselectedDate != "") {
              this.getslots(moment(this.clickedselectedDate).format('YYYY-MM-DD'));
            } else {
              this.defaultSelectedSlots()
            }


          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          })
    });
  }

  //default selected slots
  defaultSelectedSlots() {
    if (this.rescheduledocdetails != undefined && this.rescheduledocdetails != '') {
      if (this.rescheduleapptdetails.consultationtype == 1) {
        this.consultationType = 1
        this.clickedselectedDate = moment(this.rescheduleapptdetails.slotTime).format('YYYY-MM-DD')
      }
      if (this.rescheduleapptdetails.consultationtype == 2) {
        this.consultationType = 2
        this.clickedselectedDate = moment(this.rescheduleapptdetails.slotTime).format('YYYY-MM-DD')
      }
      this.getslots(moment(this.rescheduleapptdetails.slotTime).format('YYYY-MM-DD'));
      this.selectedDate = moment(this.rescheduleapptdetails.slotTime).format('YYYY-MM-DD')
      let f = new Date(this.selectedDate);
      let a = moment(f, "MM/DD/YYYY");
      this.calendar?._goToDateInView(a, 'month');

      let localarray = [];
      this.myHolidayFilter = (d: Date): any => {
        localarray.push(moment(d).format('YYYY-MM-DD'));
      }
      setTimeout(() => {
        let payload = {
          StartDate: localarray[0],
          EndDate: localarray[localarray.length - 1],
          ClinicId: this.doctorlist.clinicId,
          DoctorId: this.doctorlist.doctorId,
          CliniclocMapid: this.selectedLocation
        }

        this._patientservice.getdateslot(payload)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              this.myHolidayDates = res?.responseMessage[0]?.slotDates;
              this.myHolidayFilter = (d: Date): any => {
                return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
              }
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
            })
      });
      return;
    }
    else {
      this.getslots(moment(this.myHolidayDates[0]).format('YYYY-MM-DD'))
      this.selectedDate = moment(this.myHolidayDates[0]).format('YYYY-MM-DD')
      return;
    }

  }
  clickeddate(e) {
    // this.clickedselectedDate = moment(e).toISOString().substr(0, 10)
  }
  getslots(e, doct?: any, templateclick?: string) {

    // this.clickedselectedDate = "";
    if (templateclick == "clickedfromviaui") {
      this.clickedselectedDate = moment(e).format('YYYY-MM-DD')
      sessionStorage.setItem('changedate','')
    }

    this.slotimeid = "";
    this.loading = true;
    this.showmsg = false;
    this.locationDate = moment(e).format('YYYY-MM-DD');

    this._patientservice.timeslot(this.doctorlist.doctorId, moment(e).format('YYYY-MM-DD'), this.consultationType, this.selectedLocation)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
         
          if(this.consultationType != 102){
            this.timeslots = res.responseMessage;
            if (res.responseMessage.length == 0) {
            this.Noslotmsg = true;
            } else {
            this.Noslotmsg = false;
            }
          }else{
            this.timeslots = [];
            if(this.consultationType == 102){
              this.Noslotmsg = false;
            }else{
              this.Noslotmsg = true;
            }
          }
          
        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      });
    return doct;
  }
  loadwalkinDate() {
    this.loading = true;
    var dateD = new Date();
    let firstDayD;
    let lastDayD;
    if (this.consultationType == 102) {

      firstDayD = moment(new Date()).format('YYYY-MM-DD')
      lastDayD = moment(new Date()).format('YYYY-MM-DD')
    }

    console.log(firstDayD)
    console.log(lastDayD)
    setTimeout(() => {
      this.loading = true;
      let payload = {
        StartDate: firstDayD,
        EndDate: lastDayD,
        ClinicId: this.Book_SelectedDocInfo.clinicId,
        DoctorId: this.Book_SelectedDocInfo.doctorId,
        // ConsultationType: this.selectedconsultationtype
        CliniclocMapid: this.selectedLocation
      }
      console.log(payload)
      // return
      this._patientservice.getdateslot(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.myHolidayDates = res?.responseMessage[0]?.slotDates;
            this.myHolidayFilter = (d: Date): any => {
              return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
            }
            // this.defaultSelectedSlots()
            let f = new Date(this.selectedDate);
            let a = moment(f, "MM/DD/YYYY");
            this.calendar?._goToDateInView(a, 'month');
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          })
    });

  }
  slotid(sltId, time, data) {
    this.slottime = time;
    this.slotimeid = sltId;
    this.SelectedSlotDet = data
    console.log(this.SelectedSlotDet)
    this.showmsg = false;
    
  }
  isActive(sltId) {
    return this.slotimeid === sltId;
  };
  Closestepper(data) {
    this.doctorlist = '';
    this.searchform.reset();
    this.consultationType = ""
    this.clickedselectedDate = ""
    this.timeslots.length = 0
    this.myHolidayFilter = [];
    this.myHolidayDates = ""
    this.bookappointmentDet = ""
    this.IspressedNextperviouscalenderbtn = false;
    this.confirmPayment = false;
    this.doctorslist = null;
    this.ngOnInit();
  }

  clearpage() {
    this.bookappointmentDet = ""
    this.IspressedNextperviouscalenderbtn = false;
    this.searchform.reset();
    this.consultationType = ""
    this.SelectedSlotDet = "";
    this.clickedselectedDate = "";
    this.myHolidayDates = "";
    this.doctorlist = '';
    this.userSelectedconsultationType = ""
    this.Book_SelectedSpeciality = "";
    this.Book_SelectedDocInfo = "";
    this.timeslots.length = 0
    this.myHolidayFilter = [];
    this.rescheduledocdetails = "";
    this.sharedataService.ResheclinicadminDoctordetails = "";
    this.rescheduleapptdetails = "";
    this.sharedataService.ResheclinicadminAppointmentdetails = "";
    this.reschedulepatientdetails = "";
    this.sharedataService.ResheclinicadminPatientdetails = "";
    this.sharedataService.docdetails = "";
    this.confirmPayment = false;
    this.doctorslist = null;
    this.ngOnInit();
  }

  clearSlots() {
    this.bookappointmentDet = ""
    this.IspressedNextperviouscalenderbtn = false;
    this.consultationType = ""
    this.SelectedSlotDet = "";
    this.clickedselectedDate = "";
    this.myHolidayDates = "";
    this.doctorlist = '';
    this.userSelectedconsultationType = ""
    // this.Book_SelectedSpeciality = "";
    // this.Book_SelectedDocInfo = "";
    this.timeslots.length = 0
    this.myHolidayFilter = [];
    this.rescheduledocdetails = "";
    this.sharedataService.ResheclinicadminDoctordetails = "";
    this.rescheduleapptdetails = "";
    this.sharedataService.ResheclinicadminAppointmentdetails = "";
    this.reschedulepatientdetails = "";
    this.sharedataService.ResheclinicadminPatientdetails = "";
  }


  // Location dropdown
  ChangeLocChange(event) {
    this.selectedLocation = event.value;
    this.loading = true;
    this.Noslotmsg = true;
    this.clickedselectedDate = "";
     this._patientservice.timeslot(this.doctorlist.doctorId, this.locationDate, this.consultationType, event.value)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          
           if(this.consultationType != 102){
            this.timeslots = res.responseMessage;
              if (res.responseMessage.length == 0) {
              this.Noslotmsg = true;
              } else {
              this.Noslotmsg = false;
              }
          }else{
            this.timeslots = [];
            this.Noslotmsg = false;
          }
    
          if(this.consultationType != 102) {
          if(sessionStorage.getItem('changedate') == 'yes'){

                if(this.consultationType == 1){
                 this.selectedLocation = 1;
                }

                this.walkin_appoinmentdate = moment(this.selectedDate).format('YYYY-MM-DD');

                this.myHolidayFilter = (d: Date): any => {
                return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
                }

                this.selectedDate = this.walkin_appoinmentdate
                this.getBookingslots(this.walkin_appoinmentdate);
                this.getslots(this.walkin_appoinmentdate)

                }else{
                if(this.consultationType == 1){
                 this.selectedLocation = 1;
                }

                this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');

                this.myHolidayFilter = (d: Date): any => {
                return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
                }

                this.selectedDate = this.walkin_appoinmentdate
                this.getBookingslots(this.walkin_appoinmentdate);
                this.getslots(this.walkin_appoinmentdate)
                } 
          }else {
                this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');

                // hidden due to disable upcoming dates in calender
                // this.loadDoctorDateInCalender(this.doctorlist);
          }

        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      });
  }
  confirmPayment: boolean = false;
  confrimSubmit(e) {
    this.methodtype = ''
    this.SelectedSlotDet.userSelectedconsultationType = this.userSelectedconsultationType;
      if(this.consultationType == 1) {
      this.finalFee = this.Book_SelectedDocInfo.fees.domesticConsultation;
      } 
      else if (this.consultationType == 102) {
      this.Book_SelectedDocInfo?.fees?.wfList.map((cwdata) =>{
      if(cwdata.cliniclocationmapId == this.selectedLocation){
      this.finalFee = cwdata.walkinfee;
      }
      })
      }else if (this.consultationType == 2) {
      this.Book_SelectedDocInfo?.fees?.cvfList.map((cvdata) =>{
      if(cvdata.cliniclocationmapId == this.selectedLocation){
      this.finalFee = cvdata.clinicVisitFee;
      }
      })
      }
    if (this.userSelectedconsultationType == 102) {
      if (this.userSelectedconsultationType == 102 && this.slotimeid == "" || this.userSelectedconsultationType == 102 &&this.slotimeid == undefined) {
        let payl = {
          "consultationtype": 102,
          "slotTime":this.locationDate,
          "IsWalkselectedtype": "no_slot_walkin",
          "userSelectedconsultationType": this.userSelectedconsultationType
        }
        this.SelectedSlotDet = payl;
        this.showmsg = false;
        this.sharedataService.doctordetails(e);
        this.sharedataService.appointmentdetails(this.SelectedSlotDet);
        this.sharedataService.searchdoc(this.searchDoctorItem);
        this.Medihistory_array["patient_params"] = this.patid;
        // this.sharedataService.clinicadminPatientdetails = this.Medihistory_array;
        // this.sharedataService.clinicadminDoctordetails = this.Book_SelectedDocInfo;
        // this.sharedataService.clinicadminAppointmentdetails = this.SelectedSlotDet;
        // this.sharedataService.locMapid = this.selectedLocation;
        // this.sharedataService.finalFee = this.finalFee;
        // this.sharedataService.docdetails = this.Book_SelectedDocInfo;
        // this.router.navigate(['/thealth/clinicadmin/bookingdetail']);
        this.docdetails = e;
        this.loadPaymentDetail();
        this.confirmPayment = true;
      } else {
        this.SelectedSlotDet.IsWalkselectedtype = "slot_walkin"
        this.showmsg = false;
        this.sharedataService.doctordetails(e);
        this.sharedataService.appointmentdetails(this.SelectedSlotDet);
        this.sharedataService.searchdoc(this.searchDoctorItem);
        this.Medihistory_array["patient_params"] = this.patid;
        // this.sharedataService.clinicadminPatientdetails = this.Medihistory_array;
        // this.sharedataService.clinicadminDoctordetails = this.Book_SelectedDocInfo;
        // this.sharedataService.clinicadminAppointmentdetails = this.SelectedSlotDet;
        // this.sharedataService.locMapid = this.selectedLocation;
        // this.sharedataService.finalFee = this.finalFee;
        // this.sharedataService.docdetails = this.Book_SelectedDocInfo;
        // this.router.navigate(['/thealth/clinicadmin/bookingdetail']);
        this.docdetails = e;
        this.loadPaymentDetail();
        this.confirmPayment = true;
      }
    } else if (this.userSelectedconsultationType != 102 && this.slotimeid && this.slotimeid != "") {
      this.showmsg = false;
      this.sharedataService.doctordetails(e);
      this.sharedataService.appointmentdetails(this.SelectedSlotDet);
      this.sharedataService.searchdoc(this.searchDoctorItem);
      this.Medihistory_array["patient_params"] = this.patid;
      // this.sharedataService.clinicadminPatientdetails = this.Medihistory_array;
      // this.sharedataService.clinicadminDoctordetails = this.Book_SelectedDocInfo;
      // this.sharedataService.clinicadminAppointmentdetails = this.SelectedSlotDet;
      // this.sharedataService.locMapid = this.selectedLocation;
      // this.sharedataService.finalFee = this.finalFee;
      // this.sharedataService.docdetails = this.Book_SelectedDocInfo;
      this.docdetails = e;
      this.loadPaymentDetail();
      this.confirmPayment = true;
     // patLocaDetail

      // this.router.navigate(['/thealth/clinicadmin/bookingdetail']);
    } else {
      this.showmsg = true;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Select Slots", options);
      return;
    }
  }

  loadPaymentDetail() {
            // payments methods
            this.parentGroup = this._formBuilder.group({
              'radio-group1': [''],
            });
          
            this.successection = false;
            this.paymentsection = true;
            this.loadScript();
            this.Insuranceform = this._formBuilder.group({
            appointtype: ['online'],
            insuranceNumber: ['', [Validators.required]],
            insuranceProvider: ['', [Validators.required]],
            validity: ['', [Validators.required]],
            insurarname: ['', [Validators.required]],
          });

    this.apptdetails = this.SelectedSlotDet;
    console.log(this.apptdetails)
    this.docdClinicVisit = this.Book_SelectedDocInfo?.fees?.cvfList;

    this.patdetails = this.Medihistory_array;
    this.patLocaDetail = this.selectedLocation;
    this.finalFee = this.finalFee;

    this.clinicID = this.docdetails?.clinicId;
    this.stdate = this.apptdetails?.slotTime;
    this.slotimeid = this.apptdetails?.appointmentslotId;
    // this.consFess = this.docdetails?.doctorFee;
    this.docid = this.docdetails?.doctorId;
    this.cliname = this.docdetails?.clinicName;
    this.specid = this.docdetails?.specialityId;
    this.doctorimage = this.docdetails?.doctorProfileURL;
    if (this.doctorimage != 'null' || this.doctorimage != '') {
      this.docimage = this.doctorimage;
    }
    else {
      this.docimage = "./assets/images/noimage.webp"
    }
    this.cardpaymentform = false;
    this.cashpaymentform = false;
    this.freeapptform = false;
    this.insuranceform = false;
    this.user_id = sessionStorage.getItem('userId');
    this.masteruser_id = sessionStorage.getItem('masteruserId');

    $('.payment-methods input:radio').change(function () {
      // Only remove the class in the specific `box` that contains the radio
      $('label.highlight').removeClass('highlight');
      $(this).closest('.row').addClass('highlight');
    });
    
    if (this.apptdetails?.userSelectedconsultationType == 1) {
      this.selectedconsultationtype = 'online';
      this.consFess = this.docdetails.fees.domesticConsultation;
    }
     if (this.apptdetails?.userSelectedconsultationType == 102) {
      this.docdetails?.fees?.wfList.map((cwdata) =>{
         if(cwdata.cliniclocationmapId == this.patLocaDetail){
            this.selectedconsultationtype = 'walk_in';
            this.consFess = cwdata.walkinfee;
            this.consultationType_walkin = this.apptdetails?.consultationtype;
         }
      })
    }
    if (this.apptdetails?.userSelectedconsultationType == 2) {
      this.docdetails?.fees?.cvfList.map((cvdata) =>{
         if(cvdata.cliniclocationmapId == this.patLocaDetail){
            this.selectedconsultationtype = 'visit_to_clinic';
            this.consFess = cvdata.clinicVisitFee;
         }
      })
    }
    else {

    }

    if (this.apptdetails?.userSelectedconsultationType == 102) {
      // alert("walkin")
      this.disabledIswalkin = false;
    } else {
      // alert("not walkin")
      this.disabledIswalkin = true;
    }
    this.loadpaymentmethods()
    this._patientservice.checkprofile2(this.patdetails.userId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.checkpro = res.responseMessage;
          this.loading = true;
          console.log(this.patdetails.userId, "******")
          this._patientservice.patientdetail(this.patdetails.userId)
            .pipe(first())
            .subscribe((res: any) => {
              console.log('Raor response..... ', res)
              if (!res.isError) {
                this.loading = false;
                this.razorinfo = res.responseMessage;
                // this.mobilenumber = res?.responseMessage?.mobileNumber
                this.mobilenumber = sessionStorage.getItem("mobilenumber")

              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
        } else {
          this.checkproerror = true;
          this.messagecontentflag = res.errorMessage;
          this.navigateflag = res.responseMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });

    this.listInsuranceProvider();
  }
  // payment methods
    
  // load checkout script
  public loadScript() {        
    var isFound = false;
    var scripts = document.getElementsByTagName("script")
    for (var i = 0; i < scripts.length; ++i) {
        if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
            isFound = true;
        }
    }

    if (!isFound) {
        var dynamicScripts = ["https://checkout.razorpay.com/v1/checkout.js"];
        for (var i = 0; i < dynamicScripts.length; i++) {
            let node = document.createElement('script');
            node.src = dynamicScripts [i];
            node.type = 'text/javascript';
            node.async = false;
            node.charset = 'utf-8';
            document.getElementsByTagName('head')[0].appendChild(node);
        }
    }
}

  loadpaymentmethods() {
    this.paymethodlist.length = 0;
    this.newArray = []
    this._patientservice.loadpaymentmethods()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res);
        if (!res.isError) {
          this.loading = false;
          this.paymethodlist = res.responseMessage;
          console.log(res.responseMessage)
          this._patientservice.activeclinicpayment(this.docdetails?.clinicId)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                console.log(res);
                if (this.apptdetails.consultationtype == 2) {
                  this.availablepaymethods = res.responseMessage.clinicVisitPaymentDetails;
                } else {
                  this.availablepaymethods = res.responseMessage.onlinePaymentDetails;
                }
                console.log(this.availablepaymethods);
                // this.availablepaymethods = res.responseMessage.paymentDetails;
                for (let i = 0; i < this.paymethodlist.length; i++) {
                  var ismatch = false;
                  for (let j = 0; j < this.availablepaymethods.length; j++) {
                    if (this.paymethodlist[i].paymentMethodId == this.availablepaymethods[j].paymentMethodId) {
                      ismatch = true;
                      this.paymethodlist[i].showDateInput = false;
                      this.newArray.push(this.paymethodlist[i]);
                      break;
                    }
                  }
                  if (!ismatch) {
                    this.paymethodlist[i].showDateInput = true;
                    this.paymethodlist[i].mychecked2 = false;
                    this.newArray.push(this.paymethodlist[i]);
                  }

                  //End if
                }
                console.log(this.newArray)
              } else {
                console.log('error');
              }
            },
              err => {
                console.log('error2');
              });
        } else {
          console.log('error');
        }
      },
        err => {
          console.log('error2');
        });
  }


  onItemChange(paymethod) {
    console.log(paymethod)
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.methodtype = paymethod.paymentMethodReferenceName;

    if (paymethod.paymentMethodReferenceName === 'razorpay') {
      this.cashpaymentform = false;
      this.cardpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'cash') {
      this.cardpaymentform = false;
      this.cashpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'free_service') {
      this.freeapptform = true;
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.insuranceform = false;
    }
    else {
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.freeapptform = false;
      this.insuranceform = true;
    }
  }


  ispaymentActive(item) {
    return this.methodtype === item.paymentMethodReferenceName;
  }

  imgfile: any;
  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    console.log(file)
    this.imgfile = event.target.files[0];
    console.log(this.imgfile)
    this.filevalidation = false;
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
      }
    }
  }
  clearfreeapptform() {
  this.blckbtn = false;
    this.freeapptform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcashpayment() {
  this.blckbtn = false;
    this.cashpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearinsurance() {
  this.blckbtn = false;
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.insuranceform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcardpayment() {
  this.blckbtn = false;
    this.cardpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    let item = [];
    this.isActive(item);
  }
  filevalidation: boolean;
  consultationTypeText

  submitappointment(paytype) {
   this.blckbtn = true;
    if (this.apptdetails?.userSelectedconsultationType == 1) {
      this.consultationTypeText = 'online';
      this.consFess = this.docdetails.fees.domesticConsultation;
    } 

    if (this.apptdetails?.userSelectedconsultationType == 102) {
      this.docdetails?.fees?.wfList.map((cwdata) =>{
         if(cwdata.cliniclocationmapId == this.patLocaDetail){
            this.consultationTypeText = 'walk_in';
            this.consFess = cwdata.walkinfee;
         }
      })
    }
    if (this.apptdetails?.userSelectedconsultationType == 2) {
      this.docdetails?.fees?.cvfList.map((cvdata) =>{
         if(cvdata.cliniclocationmapId == this.patLocaDetail){
            this.consultationTypeText = 'visit_to_clinic';
            this.consFess = cvdata.clinicVisitFee;
         }
      })
    }


  //  else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 1) {
    //  this.consultationTypeText = 'walk_in';
      //this.consFess = this.docdetails?.fees?.wfList[0].walkinfee;
    //} else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 2) {
      //this.consultationTypeText = 'walk_in';
      //this.consFess = this.docdetails?.fees?.wfList[1].walkinfee;
    //} else if (this.apptdetails?.userSelectedconsultationType == 2 && this.patLocaDetail == 1) {
      //this.consultationTypeText = 'visit_to_clinic';
      //this.consFess = this.docdetails?.fees?.cvfList[0].clinicVisitFee;
   // }
    // else {
      //this.consultationTypeText = 'visit_to_clinic';
      //this.consFess = this.docdetails?.fees?.cvfList[1].clinicVisitFee;
    //}

    this.docid = this.docdetails?.doctorId;
    this.cliname = this.docdetails?.clinicName;
    this.specid = this.docdetails?.specialityId;
    this.mobilenumber = this.patdetails?.mobileNumber;
    console.log(this.apptdetails)
    this.slotimeid = this.apptdetails?.appointmentslotId;
    this.stdate = this.apptdetails?.slotTime;
    let meta = this
    if (this.apptdetails?.userSelectedconsultationType == 102 && this.consultationTypeText == "walk_in" && this.apptdetails?.IsWalkselectedtype == "no_slot_walkin") { 
      if (paytype == "insurance") {
        // alert("walkin ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined || 
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsuranceinsurance.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.specid);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.mobilenumber);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('CliniclocMapid', this.patLocaDetail);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.paymentsection = false;
                this.doctorlist = false;
                this.blckbtn = false;
                const slotDate = moment(this.stdate).format('MM/DD/YYYY'); 
                const dt = moment(this.maxdate).format('MM/DD/YYYY');           
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        let insurancedoctorfee
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataPaymentWalkin.append('PatientId', this.patdetails?.userId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.mobilenumber);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);
        formDataPaymentWalkin.append('CliniclocMapid', this.patLocaDetail);
        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              // this.SelectedSlotDet = "";
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.successection = true;
              this.paymentsection = false;
              this.doctorlist = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const slotDate = moment(this.stdate).format('MM/DD/YYYY');   
              const dt = moment(this.maxdate).format('MM/DD/YYYY'); 
              this.blckbtn = false;             
              setTimeout(() => {
                if (slotDate > dt) {
                  this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                } else {
                  this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                }
              }, 2000);
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    } else if (this.apptdetails?.userSelectedconsultationType == 102 && this.consultationTypeText == "walk_in" && this.apptdetails?.IsWalkselectedtype == "slot_walkin") { 
      if (paytype == "insurance") {
        // alert("walkin  slot ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined || 
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          this.filevalidation = true;
             this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsuranceinsurance.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.specid);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.mobilenumber);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('CliniclocMapid', this.patLocaDetail);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              this.successection = true;
              this.paymentsection = false;
              this.doctorlist = false;
              this.blckbtn = false;
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";   
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');             
                const dt = moment(this.maxdate).format('MM/DD/YYYY');                
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataPaymentWalkin.append('PatientId', this.patdetails?.userId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.mobilenumber);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('AppoinmentSlotid', this.apptdetails?.appointmentslotId);
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);
        formDataPaymentWalkin.append('CliniclocMapid', this.patLocaDetail);
        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              // this.SelectedSlotDet = "";   
              this.resposnsedata = res;
              this.apptid = res.responseData;           
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const slotDate = moment(this.stdate).format('MM/DD/YYYY');
              const dt = moment(this.maxdate).format('MM/DD/YYYY');;    
              this.successection = true;
              this.paymentsection = false;
              this.doctorlist = false;
              this.blckbtn = false;    
              console.log(this.stdate) 
              console.log(dt)        
              setTimeout(() => {
                if (slotDate > dt) {
                  this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                } else {
                  this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                }
              }, 2000);
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    }
    else { 
      if (paytype == "insurance") {
        // alert(" online offline , insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined || 
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          this.filevalidation = true;
             this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsurance: FormData = new FormData();
        formDataInsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsurance.append('AppointmentDate', this.stdate);
        formDataInsurance.append('Comments', "Regularcheckup");
        formDataInsurance.append('Firstname', "");
        formDataInsurance.append('Lastname', "");
        formDataInsurance.append('DoctorId', this.docid);
        formDataInsurance.append('SpecilalityId', this.specid);
        formDataInsurance.append('Email', "");
        formDataInsurance.append('Mobile', this.mobilenumber);
        formDataInsurance.append('PaymentMethod', "Insurance");
        formDataInsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsurance.append('BookingType', "regular");
        formDataInsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsurance.append('CliniclocMapid', this.patLocaDetail);
        formDataInsurance.append('OrderId', this.ord_id);
        formDataInsurance.append('PaymentId', this.pay_id);
        formDataInsurance.append('Signature', this.sign);
        formDataInsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsurance.append('Cardimagepath', this.imgfile);
        formDataInsurance.append('PatientId', this.pat_id);

        this._patientservice.paymentsubmitForInsurance(formDataInsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.paymentsection = false;
                this.doctorlist = false;
                this.blckbtn = false;
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');                
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        // alert("online offline , cash and free")
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        const payment = paytype;
        const aptmnt = {
          appointtype: this.consultationTypeText,
          comment: "",
          fname: "",
          lname: "",
          doctor: this.docid,
          clinic: this.cliname,
          speciality: this.specid,
          email: "",
          mobile: "",
          dateofappointment: "",
          timeslot: "",
          paymentid: ""
        }
        let parentappid = "";
        this._patientservice.paymentsubmit(aptmnt, this.stdate, this.pat_id, this.slotimeid, this.pay_id, this.ord_id, this.sign, this.consFess, payment, this.mobilenumber, parentappid,this.patLocaDetail)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                this.successection = true;
                this.paymentsection = false;
                this.doctorlist = false;
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                // const dt = moment(this.maxdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');  
                console.log(slotDate > dt)
                this.blckbtn = false;              
                setTimeout(() => {
                  if (slotDate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);
              });
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
          }
        }
      }

  listinsuranceproviderArray: any = [];
  listInsuranceProvider() {
    this._patientservice.getInsturanceProvider()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        this.listinsuranceproviderArray = res.responseMessage
      }, err => {
      })
  }

  initPay() {
  this.blckbtn = true;
    if (this.consultationType_walkin == "102") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
         this.blckbtn = false;
      this.toastrService.warning('', "Rayzor Not Applicable for Walk-In", options);
      return;
    }
    if (this.apptdetails?.userSelectedconsultationType == 1) {
      this.consultationTypeText = 'online';
      // this.consFess = this.docdetails.fees?.domesticConsultation;
    }
    if (this.apptdetails?.userSelectedconsultationType == 102) {
      this.consultationTypeText = 'walk_in';
      // this.consFess = this.docdetails.fees?.walkInFee;
    }
    if (this.apptdetails?.userSelectedconsultationType == 2) {
      this.consultationTypeText = 'visit_to_clinic';
      // this.consFess = this.docdetails.fees?.clinicVisitConsultationFee;
    }

    this.user_id = sessionStorage.getItem('userId');
    console.log('pay details... ',this.consFess, this.docid, this.clinicID, this.user_id, "*******", this.slotimeid)
    if (!this.slotimeid || this.slotimeid === 'undefined') {
      this.sloterrormsg = true;
      this.loading = false;
    } else {
      this.sloterrormsg = false;
      this._patientservice.emailinitpay(this.consFess, this.docid, this.clinicID, this.user_id)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.odId = res.responseMessage;
            this.skey = res.responseData
            this.blckbtn = false;
            this.payWithRazor(this.odId, this.skey);
          }
          else {
            this.errormessagebox = true;
               this.blckbtn = false;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
             this.blckbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }
  cleardata() {
    this.apptdetails = ""
    this.consultationType_walkin = ""
  }
  // for testing
  payWithRazor(oid, sk) {
    console.log(this.consultationTypeText);
    let razorpaydescription = ""
    this.pat_id = this.patdetails.userId;
    let meta = this
    if (this.myfollowupdetails &&
      this.myfollowupdetails.mybookfollowup == true &&
      this.myfollowupdetails.followUp.parentAppointmentId) {
      razorpaydescription = "Followup Fee";
    } else {
      razorpaydescription = "Consultation Fee";
    }
    const options: any = {
      key: sk,
      amount: this.consFess * 100, // amount should be in paise format to display Rs 1255 without decimal point
      currency: 'INR',
      name: 'ClinaNG', // company name or product name
      description: razorpaydescription,  // product description
      // description: 'Consultation Fee',  // product description
      image: './assets/images/clina-blue.webp', // company logo or product image
      order_id: oid, // order_id created by you in backend
      modal: {
        // We should prevent closing of the form when esc key is pressed.
        escape: false,
      },
      notes: {
        // include notes if any
      },
      theme: {
        color: '#0c238a'
      }
    };
    console.log(options)
    options.handler = ((response, error) => {
      options.response = response;
      this.paymentId = response.razorpay_payment_id;
      this.orderId = response.razorpay_order_id;
      this.signature = response.razorpay_signature;

      if (response.razorpay_payment_id && response.razorpay_order_id && response.razorpay_signature) {
        this.loading = true;
        if (!this.slotimeid || this.slotimeid === 'undefined') {
          this.sloterrormsg = true;
          this.loading = false;
        }
        else {
          const payment = 'RazorPay';
          if (this.parentaId != 0) {
            this.pAId = this.parentaId;
          } else {
            this.pAId = 0;
          }
          const aptmnt = {
            appointtype: this.consultationTypeText,
            comment: "",
            fname: "",
            lname: "",
            doctor: this.docid,
            clinic: this.cliname,
            speciality: this.specid,
            email: "",
            mobile: "",
            dateofappointment: "",
            timeslot: "",
            paymentid: ""
          }
          let parentappid = "";
          if (this.myfollowupdetails &&
            this.myfollowupdetails.mybookfollowup == true &&
            this.myfollowupdetails.followUp.parentAppointmentId) {
            parentappid = this.myfollowupdetails.followUp.parentAppointmentId
          }
          this._patientservice.paymentsubmit(aptmnt, this.stdate, this.pat_id, this.slotimeid, this.paymentId, this.orderId, this.signature, this.consFess, payment, this.mobilenumber, parentappid, this.patLocaDetail)
            .pipe(first())
            .subscribe((res: any) => {
              console.log(res);
              if (res && !res.isError) {
                this.resposnsedata = res;
                this.apptid = res.responseData;
                this.loading = false;
                this.sloterrormsg = false;
                this.followupdetails = "";
                this.sharedataService.reschefollowdetails = "";
                this.sharedataService.followupdet = "";
                this._patientservice.Followupdoctordetails = "";
                this.myfollowupdetails = ""
                sessionStorage.removeItem("followupdetails");
                this.sharedataService.rescheduledocdetails('');
                this.sharedataService.searchdats = "";
                this.sharedataService.searchdates('');
                this.sharedataService.searchspeciality = '';
                this.sharedataService.searchspecial('');
                this.sharedataService.searchdoctor = '';
                this.sharedataService.searchdoc('');
                this.sharedataService.docspeciality = "";
                this.sharedataService.searchdocspeciality('');
                this.sharedataService.docdate = "";
                this.sharedataService.searchdocdate('');
                this.sharedataService.docspecdate = "";
                this.sharedataService.searchdocspecdate('');
                this.sharedataService.specdate = '';
                this.sharedataService.searchspecdate('');
                this.sharedataService.ResheclinicadminAppointmentdetails = ""
                this.sharedataService.ResheclinicadminDoctordetails = ""
                this.sharedataService.ResheclinicadminPatientdetails = ""
                this.sharedataService.clinicadminconsulatationType = "";
                this.consultationType_walkin = "";
                sessionStorage.removeItem("specialityId")
                // meta.ngZone.run(() => {
                //   this.successection = true;
                //   this.paymentsection = false;
                // });

                meta.ngZone.run(() => {
                  this.successection = true;
                  this.paymentsection = false;
                  this.doctorlist = false;
                  const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                  const dt = moment(this.maxdate).format('MM/DD/YYYY');
                  this.blckbtn = false;
                  setTimeout(() => {
                    if (slotDate > dt) {
                      meta.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                    } else {
                      meta.router.navigate(['/thealth/clinicadmin/appointments/today'])
                    }
                  }, 3000);
                });

                this.sharedataService.setSuccessmsg(res.responseMessage);
              }
              else {
                 this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res?.errorMessage, options);
                this.sloterrormsg = false;
                if (this.errormessagebox) {
                  this.loading = false;
                }
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            },
              err => {
                 this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
                this.sloterrormsg = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
                if (this.forbiddenmessagebox) {
                  this.loading = false;
                }
              });
        }
      }
      // call your backend api to verify payment signature & capture transaction
    });
    options.prefill = {
      name: this.razorinfo.firstName,
      email: this.razorinfo.eMail,
      contact: this.razorinfo.mobileNumber
    },
      options.modal.ondismiss = (() => {
        // handle the case when user closes the form while transaction is in progress
      });
    const rzp = new this.winRef.nativeWindow.Razorpay(options);
    rzp.open();
  }

  changeDateFunction(docdetails) {
    this.sharedataService.ResheclinicadminAppointmentdetails = this.apptdetails;
    this.sharedataService.ResheclinicadminDoctordetails = docdetails;
    this.sharedataService.ResheclinicadminPatientdetails = this.patdetails;
    this.sharedataService.Resheclinicadminwalkinconsultation = this.consultationType_walkin
    // this.consultationType_walkin = this.sharedataService?.clinicadminconsulatationType;
    
    this.sharedataService.locMapid = this.patLocaDetail;

    this.sharedataService.clinicadminconsulatationType = "";
    console.log(this.patdetails["patient_params"])
    sessionStorage.setItem('changedate','yes')

    this.router.navigate(['/thealth/clinicadmin/patients/bookappointment', this.patdetails["patient_params"]]);
  }
  ngOnDestroy() {
    this.pageCheck = "bookingdetail";
    this.cleardata()
  }

}
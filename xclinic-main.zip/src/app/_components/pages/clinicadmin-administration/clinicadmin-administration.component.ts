import { Component, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { MatTabGroup } from '@angular/material/tabs';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { ClincadminDialogcodeMappingdeleteComponent } from '../clincadmin-dialogcode-mappingdelete/clincadmin-dialogcode-mappingdelete.component';
import { ClinicadminDeletechargesComponent } from '../clinicadmin-deletecharges/clinicadmin-deletecharges.component';
import { ClinicadminDeletecodesComponent } from '../clinicadmin-deletecodes/clinicadmin-deletecodes.component';
import { ClinicadminDeletemapComponent } from '../clinicadmin-deletemap/clinicadmin-deletemap.component';
import { DialogMappingdeletedComponent } from '../dialog-mappingdeleted/dialog-mappingdeleted.component';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-clinicadmin-administration',
  templateUrl: './clinicadmin-administration.component.html',
  styleUrls: ['./clinicadmin-administration.component.css']
})
export class ClinicadminAdministrationComponent implements OnInit {
  displayedColumns: string[] = ['chargesname', 'status', 'action'];
  dataSource;

  displayedColumns2: string[] = ['chargesname', 'description', 'codeid', 'amount', 'gst', 'vat', 'status', 'action'];
  dataSource2;


  displayedColumns3: string[] = ['chargesname', 'description', 'codeid', 'doctors', 'location', 'feetype', 'amount',
    'action'];
  dataSource3;

  listdoctors = new FormControl();

  doctorsList: string[] = ['Dr.Vignesh', 'Dr.Ramesh', 'Dr.Ramesh', 'Dr.Ramesh', 'Dr.Ramesh', 'Dr.Ramesh'];



  foods: Food[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' }
  ];


  @ViewChild('formDirective') private formDirective: NgForm;
  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;
  @ViewChild('tabGroup') private tabGroup: MatTabGroup;
  @ViewChildren(MatPaginator) paginator = new QueryList<MatPaginator>();
  addchargesform: FormGroup;
  codesform: FormGroup;
  mappingform: FormGroup;
  loading: boolean;


  // ngAfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  // }

  // multiple search start
  /** list of banks */
  public banks: Bank[] = [];
  /** control for the selected bank for multi-selection */
  public bankMultiCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword multi-selection */
  public bankMultiFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanksMulti: ReplaySubject<Bank[]> = new ReplaySubject<Bank[]>(1);

  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();
  listdata: boolean;
  updatebutton: boolean = false;
  mappingupdatebtn: boolean;
  addbutton: boolean = true;
  chargeid: any;
  togstate: boolean;
  // end


  // single search start
  protected banks2: Bank2[] = [];
  protected banks3: Bank3[] = [];

  /** control for the selected bank */
  public bankCtrl2: FormControl = new FormControl();
  public bankCtrl3: FormControl = new FormControl();
  // bankCtrl2 = new FormControl();

  /** control for the MatSelect filter keyword */
  public bankFilterCtrl2: FormControl = new FormControl();
  public bankFilterCtrl3: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanks2: ReplaySubject<Bank2[]> = new ReplaySubject<Bank2[]>(1);
  public filteredBanks3: ReplaySubject<Bank3[]> = new ReplaySubject<Bank3[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  @ViewChild('singleSelect2', { static: true }) singleSelect2: MatSelect;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy2 = new Subject<void>();
  protected _onDestroy3 = new Subject<void>();
  taxtype: any;
  listdata2: boolean;
  taxtypevalue: number;
  tax: any;
  submitbtn: boolean = true;
  updtbutton: boolean = false;
  codid: any;
  searchinput: any;
  mapdata: any;
  mappingsection: boolean;
  consultlist: any;
  listdata3: boolean;
  rowmapid: any;
  cmapid: any;
  mappingsubmitbtn: boolean;
  codesid: any;
  docsid: any;
  doctorid: any;
  obs: any;
  filterData: boolean;
  mappinglistarr: any;
  gstvalue: number;
  vatvalue: number;
  codesarray: any;
  locationonclinicselect: boolean = false;
  cliniId: any;
  locationlist: any;
  locatlist: any;
  mappayload: { clinic_codes_id: any; doctor_id: any; consultation_feetype: any; clinic_location_map_id: any; };
  locationmapID: any;
  locid: any;
  clnid: string;
  mappinglistarr2: any = [];
  maplist: any;
  resultlocation: any;
  consutlfeetype: any;
  // single search end



  constructor(private _formBuilder: FormBuilder, private toastrService: ToastService,
    private _DoctorService: DoctorService, public dialog: MatDialog,) { }

  ngOnInit(): void {


    //  multiple selection start
    // set initial selection
    // this.bankMultiCtrl.setValue([this.banks[10], this.banks[11], this.banks[12]]);

    // load the initial bank list
    this.filteredBanksMulti.next(this.banks.slice());

    // listen for search field value changes
    this.bankMultiFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBanksMulti();
      });
    //  multiple selection end




    // single search start
    // set initial selection
    // this.bankCtrl2.setValue(this.banks2[10]);
    // this.getchargesnames()
    // load the initial bank list
    console.log(this.banks2)
    this.filteredBanks2.next(this.banks2.slice());
    console.log(this.filteredBanks2)
    // listen for search field value changes
    this.bankFilterCtrl2.valueChanges
      .pipe(takeUntil(this._onDestroy2))
      .subscribe(() => {
        this.filterBanks2();
      });

    this.filteredBanks3.next(this.banks3.slice());

    this.bankFilterCtrl3.valueChanges
      .pipe(takeUntil(this._onDestroy3))
      .subscribe(() => {
        this.filterBanks3();
      });
    //  sinle search end






    this.addchargesform = this._formBuilder.group({
      chargesname: ['', [Validators.required, Validators.maxLength(30), Validators.pattern(/^(?!\s)[\w\s-]*$/)]],
    });

    this.codesform = this._formBuilder.group({
      // chargename: ['', [Validators.required]],
      description: ['', [Validators.maxLength(50), Validators.required]],
      codeid: ['', [Validators.maxLength(10), Validators.required]],
      amount: ['', [Validators.required, Validators.pattern(/^\d*\.?\d*$/)]],
      type: [''],
      typevalue: [''],
    });

    this.mappingform = this._formBuilder.group({
      chargenames: ['', [Validators.required]],
      description: ['', [Validators.required]],
      consultatype: ['', [Validators.required]],
      locationname: ['']
    });

    this.chargeslist();
    // this.codeslist();

    // this.getchargesnames();
  }

  tabClick(tab) {
    console.log(tab.tab.textLabel)
    if (tab.tab.textLabel == "Codes") {
      this.getchargesnames();
      this.taxlist();
      this.codeslist()
      this.mapdata = '';
    }
    else if (tab.tab.textLabel == "Mapping") {
      console.log(this.mapdata)
      if (this.mapdata === '' || this.mapdata === undefined || this.mapdata === 'undefined') {
        this.mappingsection = false;
        this.codesid = undefined
        this.getmaplist(this.codesid);
      }
      else {
        this.mappingsection = true;
        this.mappingupdatebtn = false;
        this.mappingsubmitbtn = true;
        this.consulttypelist()
        this.bankMultiCtrl.disable();
        this.mappingform.get('consultatype').setValue('');
        this.mappingform.get('locationname').setValue('');
        this.mappingform.get('chargenames').setValue(this.mapdata.clinicChargeName);
        this.mappingform.get('description').setValue(this.mapdata.description);
        this.codesid = this.mapdata.clinicCodesId
        console.log(this.codesid)
        this.getmaplist(undefined);
      }
    }
    else {
      this.mapdata = '';
      this.addchargesform.reset()
    }
  }


  // doctorsbyconsultaion() {
  //   this.loading = true;
  //   this._DoctorService.getdoctorsbyconsultype(consultid)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       console.log(res)
  //       if (!res.isError) {
  //         this.loading = false;
  //         this.banks2 = res.responseMessage;
  //         this.filteredBanks2.next(this.banks2.slice());
  //         console.log(this.filteredBanks2)
  //         console.log(this.banks2)
  //         // this.bankCtrl2.setValue(this.banks2[1]);
  //       }
  //       else {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //       }
  //     },
  //       err => {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //       })
  // }

  taxlist() {
    this.loading = true;
    this._DoctorService.listtaxes()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.taxtype = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  getchargesnames() {
    // debugger;
    this.loading = true;
    this._DoctorService.getchargesnames()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.banks2 = res.responseMessage;
          this.filteredBanks2.next(this.banks2.slice());
          console.log(this.filteredBanks2)
          console.log(this.banks2)
          // this.bankCtrl2.setValue(this.banks2[1]);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  consulttypelist() {
    this.loading = true;
    this._DoctorService.consultlisttype()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.consultlist = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  changeslect(event) {
    console.log(event)
    if (event.value) {
      // this.bankMultiCtrl.enable();
      // this.bankCtrl3.enable();
      // this.getdoctorsonconsultype(event.value);
      this.bankMultiCtrl.reset();
      console.log(this.bankMultiCtrl.value)
      this.consutlfeetype = event.value
      console.log(this.consutlfeetype)
      this.loadlocations(event.value);
    }
  }
  
  loadlocations(eve){
    console.log(eve)
    // this.bankMultiCtrl.enable();
    this.cliniId = sessionStorage.getItem("clinicId")
    if (eve == 87 || eve == 88 || eve == 104) {
      this.locationonclinicselect = true;
      // this.mappingform.controls['locationname'].setValidators([Validators.required]);

      this.mappingform.controls['locationname'].setValidators([Validators.required]);
      this.mappingform.controls['locationname'].updateValueAndValidity();



      this._DoctorService.getlocations(this.cliniId)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            this.locationlist = res.responseMessage;
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })

    }
    else {
      this.bankMultiCtrl.enable()
      this.locationonclinicselect = false;
      // this.mappingform.controls['locationname'].clearValidators();
      this.mappingform.controls['locationname'].clearValidators();
      this.mappingform.controls['locationname'].updateValueAndValidity();

      this._DoctorService.getlocations(this.cliniId)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            this.locationlist = res.responseMessage;
            for (let i = 0; i < this.locationlist.length; i++) {
              if (this.locationlist[i].defaultclinic == true) {
                this.locationmapID = this.locationlist[i].clinicLocationMapId
              }
            }
            console.log(this.locationmapID)
            this.getdoctorsonconsultationype(this.consutlfeetype, this.locationmapID)
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  changeslectlocation(event) {
    console.log(event)
    if (event.value) {
      this.bankMultiCtrl.enable();
      // this.bankCtrl3.enable();
      this.getdoctorsonconsultationype(this.consutlfeetype, event.value);
    }
  }


  getdoctorsonconsultype(evalue) {
    this.loading = true;
    console.log(evalue)
    // this.cliniId = sessionStorage.getItem("clinicId")
    // if (evalue == 87 || evalue == 88 || evalue == 104) {
    //   this.locationonclinicselect = true;
    //   // this.mappingform.controls['locationname'].setValidators([Validators.required]);

    //   this.mappingform.controls['locationname'].setValidators([Validators.required]);
    //   this.mappingform.controls['locationname'].updateValueAndValidity();



    //   this._DoctorService.getlocations(this.cliniId)
    //     .pipe(first())
    //     .subscribe((res: any) => {
    //       console.log(res)
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.locationlist = res.responseMessage;
    //       }
    //       else {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', res.errorMessage, options);
    //       }
    //     },
    //       err => {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err?.error, options);
    //       })

    // }
    // else {
    //   this.locationonclinicselect = false;
    //   // this.mappingform.controls['locationname'].clearValidators();
    //   this.mappingform.controls['locationname'].clearValidators();
    //   this.mappingform.controls['locationname'].updateValueAndValidity();

    //   this._DoctorService.getlocations(this.cliniId)
    //     .pipe(first())
    //     .subscribe((res: any) => {
    //       console.log(res)
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.locationlist = res.responseMessage;
    //         for (let i = 0; i < this.locationlist.length; i++) {
    //           if (this.locationlist[i].defaultclinic == true) {
    //             this.locationmapID = this.locationlist[i].clinicLocationMapId
    //           }
    //         }
    //         console.log(this.locationmapID)
    //       }
    //       else {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', res.errorMessage, options);
    //       }
    //     },
    //       err => {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err?.error, options);
    //       })
    // }
    this._DoctorService.getdoctorsonconsulttype(evalue)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.banks = res.responseMessage;
          console.log(this.banks)
          this.filteredBanksMulti.next(this.banks.slice());
          console.log(this.filteredBanksMulti)
          console.log(this.banks)


          // single selection dropdown for edit mapping
          this.banks3 = res.responseMessage;
          this.filteredBanks3.next(this.banks3.slice());
          console.log(this.filteredBanks3)
          console.log(this.banks3)
          if (this.isEditclicked) {
            const getchergeid3 = this.banks3.findIndex(x => x.doctorId == this.isEditclicked.doctorId);
            console.log(getchergeid3)
            this.bankCtrl3.setValue(this.banks3[getchergeid3]);
            console.log(this.banks3[getchergeid3])
            console.log(this.bankCtrl3)
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  getdoctorsonconsultationype(confeetypeid, evalue) {
    this.loading = true;
    console.log(confeetypeid)
    console.log(evalue)
    // this.cliniId = sessionStorage.getItem("clinicId")
    // if (evalue == 87 || evalue == 88 || evalue == 104) {
    //   this.locationonclinicselect = true;
    //   // this.mappingform.controls['locationname'].setValidators([Validators.required]);

    //   this.mappingform.controls['locationname'].setValidators([Validators.required]);
    //   this.mappingform.controls['locationname'].updateValueAndValidity();



    //   this._DoctorService.getlocations(this.cliniId)
    //     .pipe(first())
    //     .subscribe((res: any) => {
    //       console.log(res)
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.locationlist = res.responseMessage;
    //       }
    //       else {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', res.errorMessage, options);
    //       }
    //     },
    //       err => {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err?.error, options);
    //       })

    // }
    // else {
    //   this.locationonclinicselect = false;
    //   // this.mappingform.controls['locationname'].clearValidators();
    //   this.mappingform.controls['locationname'].clearValidators();
    //   this.mappingform.controls['locationname'].updateValueAndValidity();

    //   this._DoctorService.getlocations(this.cliniId)
    //     .pipe(first())
    //     .subscribe((res: any) => {
    //       console.log(res)
    //       if (!res.isError) {
    //         this.loading = false;
    //         this.locationlist = res.responseMessage;
    //         for (let i = 0; i < this.locationlist.length; i++) {
    //           if (this.locationlist[i].defaultclinic == true) {
    //             this.locationmapID = this.locationlist[i].clinicLocationMapId
    //           }
    //         }
    //         console.log(this.locationmapID)
    //       }
    //       else {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', res.errorMessage, options);
    //       }
    //     },
    //       err => {
    //         this.loading = false;
    //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //         this.toastrService.warning('', err?.error, options);
    //       })
    // }

    this._DoctorService.getdoctorsonconsultationtype(confeetypeid,evalue)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.banks = res.responseMessage;
          console.log(this.banks)
          this.filteredBanksMulti.next(this.banks.slice());
          console.log(this.filteredBanksMulti)
          console.log(this.banks)


          // single selection dropdown for edit mapping
          this.banks3 = res.responseMessage;
          this.filteredBanks3.next(this.banks3.slice());
          console.log(this.filteredBanks3)
          console.log(this.banks3)
          if (this.isEditclicked) {
            const getchergeid3 = this.banks3.findIndex(x => x.doctorId == this.isEditclicked.doctorId);
            console.log(getchergeid3)
            this.bankCtrl3.setValue(this.banks3[getchergeid3]);
            console.log(this.banks3[getchergeid3])
            console.log(this.bankCtrl3)
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  addcharges() {
    if (this.addchargesform.invalid) {

      // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      // this.toastrService.warning('', 'Please fill the fields', options);
      this.loading = false;
      return;
    }
    else {
      this.loading = true;
      this._DoctorService.createcharges(this.addchargesform.value)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.chargeslist();
            this.formDirective.resetForm();
            this.addchargesform.reset()
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  submitcodes(formDirective: FormGroupDirective) {
    // console.log(this.codesform.value)
    // console.log(this.bankCtrl2.value?.clinicChargesId)
    if (this.codesform.invalid || this.codesform.value.amount == null || this.codesform.value.codeid == null ||
      this.codesform.value.description == null) {
      if (this.bankCtrl2.value?.clinicChargesId == '' || this.bankCtrl2.value?.clinicChargesId == null) {

        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select the service name', options);
        this.loading = false;
        return;
      }
      return;
    }
    else {
      this.loading = true;
      if (this.codesform.value.type == '' || this.codesform.value.type == null) {
        this.tax = 0;
      }
      else {
        this.tax = this.codesform.value.type
      }
      if (this.codesform.value.typevalue == '' || this.codesform.value.typevalue == null) {
        this.taxtypevalue = 0;
      }
      else {
        this.taxtypevalue = this.codesform.value.typevalue
      }
      this.selectedcharge = this.bankCtrl2.value
      this._DoctorService.createcodes(this.codesform.value, this.tax, this.taxtypevalue, this.bankCtrl2.value?.clinicChargesId)
        .pipe(first())
        .subscribe((res: any) => {
          // console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.codeslist();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.formDirective.resetForm();
            this.codesform.reset();
            // this.codesform.controls.description.setErrors(null)
            // this.codesform.controls.codeid.setErrors(null)
            // this.codesform.controls.amount.setErrors(null)
            this.bankCtrl2.setValue(this.banks2['']);
            this.initformgroup();
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            // console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  initformgroup() {
    this.codesform.reset();
    this.codesform.controls.description.setErrors(null)
    this.codesform.controls.codeid.setErrors(null)
    this.codesform.controls.amount.setErrors(null)
  }
  clearFilter() {
    this.searchinput = "";
    this.codeslist()
  }
  submitmapping() {
    // console.log(this.mappingform.value)
    // console.log(this.bankMultiCtrl.value)
    // console.log(this.codesid)


    if (this.mappingform.invalid) {
      if (this.bankMultiCtrl.value == '' || this.bankMultiCtrl.value == null) {

        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select Doctor', options);
        this.loading = false;
        return;
      }
      return;
    }
    else {
      if (!this.bankMultiCtrl.value) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select Doctor', options);
        this.loading = false;
        return;
      }
      this.loading = true;
      this.docsid = this.bankMultiCtrl.value.map(n => n.doctorId)
      console.log(this.docsid)

      if (this.locationonclinicselect == true) {
        this.mappayload = {
          "clinic_codes_id": this.codesid,
          "doctor_id": this.docsid,
          "consultation_feetype": this.mappingform.value.consultatype,
          "clinic_location_map_id": this.mappingform.value.locationname
        }
        console.log(this.mappayload)
      }
      else {
        this.mappayload = {
          "clinic_codes_id": this.codesid,
          "doctor_id": this.docsid,
          "consultation_feetype": this.mappingform.value.consultatype,
          "clinic_location_map_id": this.locationmapID
        }
        console.log(this.mappayload)

      }
      console.log(this.mappayload)

      this._DoctorService.createmapping(this.mappayload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.getmaplist(undefined);
            this.mappingform.reset()
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.mappingsection = false;
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  getmaplist(clid) {
    console.log(clid)
    this.loading = true;
    if (clid != undefined) {
      this.mappinglistarr2 = []
      this._DoctorService.getlistmaps(clid)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            this.maplist = res.responseMessage
            this.clnid = sessionStorage.getItem("clinicId")
            console.log(this.clnid)

            this._DoctorService.getlocations(this.clnid)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res)
                if (!res.isError) {
                  this.loading = false;
                  this.locatlist = res.responseMessage;
                  console.log(this.locatlist)


                  console.log(this.locatlist)

                  for (let item of this.maplist) {
                    console.log(item)
                    console.log(this.locatlist)
                    this.locid = item.cliniclocationmapId
                    this.resultlocation = this.locatlist.filter(x => x.clinicLocationMapId === this.locid);
                    console.log(this.resultlocation)
                    console.log(this.resultlocation[0].locationName)
                    item.locationame = this.resultlocation[0].locationName
                    this.mappinglistarr2.push(item);
                  }


                  console.log(this.mappinglistarr2)

                  this.dataSource3 = new MatTableDataSource(this.mappinglistarr2);



                  setTimeout(() => this.dataSource3.paginator = this.paginator.toArray()[2]);
                  this.paginator.toArray()[2].firstPage();

                  if (this.dataSource3?.data?.length === 0) {
                    this.listdata3 = true;
                  }
                  else {
                    this.listdata3 = false;
                  }


                }
                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                })
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
    else {
      this.mappinglistarr2 = []
      this._DoctorService.getlistmapsall()
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;

            this.maplist = res.responseMessage
            this.clnid = sessionStorage.getItem("clinicId")
            console.log(this.clnid)

            this._DoctorService.getlocations(this.clnid)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res)
                if (!res.isError) {
                  this.loading = false;
                  this.locatlist = res.responseMessage;
                  console.log(this.locatlist)


                  console.log(this.locatlist)

                  for (let item of this.maplist) {
                    console.log(item)
                    console.log(this.locatlist)
                    this.locid = item.cliniclocationmapId
                    this.resultlocation = this.locatlist.filter(x => x.clinicLocationMapId === this.locid);
                    console.log(this.resultlocation)
                    console.log(this.resultlocation[0].locationName)
                    item.locationame = this.resultlocation[0].locationName
                    this.mappinglistarr2.push(item);
                  }


                  console.log(this.mappinglistarr2)

                  this.dataSource3 = new MatTableDataSource(this.mappinglistarr2);



                  setTimeout(() => this.dataSource3.paginator = this.paginator.toArray()[2]);
                  this.paginator.toArray()[2].firstPage();

                  if (this.dataSource3?.data?.length === 0) {
                    this.listdata3 = true;
                  }
                  else {
                    this.listdata3 = false;
                  }


                }
                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                })


          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }

  }

  chargeslist() {
    this.loading = true;
    this._DoctorService.getchargeslist()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          let array = [];
          for (let item of res.responseMessage) {
            if (item.editable != 0) {
              array.push(item)
            }
            // if(item.chargeName != "Remaining Charges"){
            //   array.push(item)
            // }
          }
          // this.dataSource = new MatTableDataSource(res.responseMessage);
          this.dataSource = new MatTableDataSource(array);
          setTimeout(() => this.dataSource.paginator = this.paginator.toArray()[0]);
          this.paginator.toArray()[0].firstPage();

          if (this.dataSource.data === null || this.dataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  codeslist() {
    this.loading = true;
    this._DoctorService.getcodeslist()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          let array = [];
          for (let item of res.responseMessage) {
            if (item.editable != 0) {
              item.amount = item.amount;
              item.clinicChargeName = item.clinicChargeName;
              item.clinicCodesId = item.clinicCodesId;
              item.clinic_charges_id = item.clinic_charges_id;
              item.codeId = item.codeId;
              item.description = item.description;
              item.status = item.status;
              item.taxTypeName = item.taxTypeName;

              if (item.taxAmount == 0) {
                item.gstvalue = 0;
                item.vatvalue = 0;
              }
              else {
                if (item.taxId == 92) {
                  item.gstvalue = item.taxAmount;
                  item.vatvalue = 0;
                }
                else {
                  item.vatvalue = item.taxAmount;
                  item.gstvalue = 0;
                }
              }
              array.push(item)
            }
          }

          console.log(res.responseMessage)
          this.dataSource2 = new MatTableDataSource(array);

          // this.dataSource2 = new MatTableDataSource(res.responseMessage);

          setTimeout(() => this.dataSource2.paginator = this.paginator.toArray()[1]);
          this.paginator.toArray()[1].firstPage();

          if (this.dataSource2.data === null || this.dataSource2.data.length === 0) {
            this.listdata2 = true;
          }
          else {
            this.listdata2 = false;
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  editcharges(edidata) {
    // alert("hai")
    if (edidata?.editable != 0) {
      console.log(edidata)
      this.chargeid = edidata.clinicChargesId;
      this.addchargesform.get('chargesname').setValue(edidata.chargeName);
      this.updatebutton = true;
      this.addbutton = false;
    }
  }
  selectedcharge
  isEditcodedisable: boolean = false;
  editcodes(edidata) {
    console.log(edidata)
    if (edidata.editable != 0) {
      if (edidata?.status != 0) {
        this.codid = edidata.clinicCodesId;
        // console.log(this.selectedcharge)
        // this.selectedcharge = edidata?.clinic_charges_id
        // this.bankCtrl2.setValue(this.banks2[10]);

        // this.bankCtrl2.value?.clinicChargesId
        const getchergeid = this.banks2.findIndex(x => x.clinicChargesId == edidata.clinic_charges_id);
        console.log(getchergeid)
        this.bankCtrl2.setValue(this.banks2[getchergeid]);
        this.setInitialValue2()
        console.log(this.banks2[getchergeid])
        console.log(this.bankCtrl2)


        // this.bankCtrl2.setValue(this.banks2[1]);
        this.codesform.get('description').setValue(edidata.description);
        this.codesform.get('codeid').setValue(edidata.codeId);
        this.codesform.get('amount').setValue(edidata.amount);
        this.codesform.get('type').setValue(edidata.taxId);
        if (edidata.taxAmount != 0) {
          this.codesform.get('typevalue').setValue(edidata.taxAmount);
        }
        this.updtbutton = true;
        this.submitbtn = false;
      }
      this.isEditcodedisable = false;
    } else {
      this.isEditcodedisable = true;
    }
  }

  updatecodes() {
    if (this.codesform.invalid || this.codesform.value.amount == null || this.codesform.value.codeid == null ||
      this.codesform.value.description == null) {
      if (this.bankCtrl2.value?.clinicChargesId == '' || this.bankCtrl2.value?.clinicChargesId == null) {

        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select the charges name', options);
        this.loading = false;
        return;
      }
      return;
    }
    else {
      this.loading = true;
      this.loading = true;
      if (this.codesform.value.type == '' || this.codesform.value.type == null) {
        this.tax = 0;
      }
      else {
        this.tax = this.codesform.value.type
      }
      if (this.codesform.value.typevalue == '' || this.codesform.value.typevalue == null) {
        this.taxtypevalue = 0;
      }
      else {
        this.taxtypevalue = this.codesform.value.typevalue
      }
      // this.selectedcharge = this.bankCtrl2.value
      this._DoctorService.codesupdate(this.codesform.value, this.tax, this.taxtypevalue, this.bankCtrl2.value?.clinicChargesId, this.codid)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.codeslist();
            this.formDirective.resetForm();
            this.codesform.reset();
            this.bankCtrl2.setValue(this.banks2['']);
            this.updtbutton = false;
            this.submitbtn = true;
            this.initformgroup()
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  updatecharges() {
    console.log(this.chargeid)
    if (this.addchargesform.invalid) {

      // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      // this.toastrService.warning('', 'Please fill the fields', options);
      this.loading = false;
      return;
    }
    else {
      this.loading = true;
      this._DoctorService.chargesupdate(this.addchargesform.value, this.chargeid)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            this.chargeslist();
            this.formDirective.resetForm();
            this.addchargesform.reset();
            this.updatebutton = false;
            this.addbutton = true;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  statchanged(cId, togglestate) {
    console.log(cId, togglestate)
    if (togglestate === 1) {
      this.togstate = true;
    }
    else {
      this.togstate = false;
    }
    this.loading = true;
    this._DoctorService.changechargestate(cId, this.togstate)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.chargeslist();
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.chargeslist();
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  codesstatchanged(cId, togglestate, event, elementData) {
    console.log(cId, togglestate)
    console.log(event)
    console.log(elementData)
    if (elementData?.isClinicCodeMapped == true) {
      // only if mapped
      const dialogRef = this.dialog.open(DialogMappingdeletedComponent, {
        panelClass: 'deletewrapper',
      });
      dialogRef.afterClosed().subscribe(userAnswer => {
        if (userAnswer) {
          if (userAnswer.data == "no") {
            return event.source.checked = true;
          }
          if (userAnswer.data == "conform") {
            if (togglestate === 1) {
              this.togstate = true;
            }
            else {
              this.togstate = false;
            }
            this.loading = true;
            this._DoctorService.changecodestate(cId, this.togstate)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res)
                if (!res.isError) {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.responseMessage, options);
                  this.codeslist();
                } else {
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                  this.codeslist();
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                });
          }
        }
      })
    } else {
      if (togglestate === 1) {
        this.togstate = true;
      }
      else {
        this.togstate = false;
      }
      this.loading = true;
      this._DoctorService.changecodestate(cId, this.togstate)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.codeslist();
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.codeslist();
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });

    }
  }

  deletecharges(deldata) {
    console.log(deldata)
    this.loading = false;
    const dialogRef = this.dialog.open(ClinicadminDeletechargesComponent, {
      panelClass: 'deletewrapper',
      data: deldata.clinicChargesId
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        console.log(res)
        if (!res.data.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.data.responseMessage, options);
          this.chargeslist();
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.data.errorMessage, options);
        }
      }
    },
      err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }

  deletecodes(deldata) {
    if (deldata?.isClinicCodeMapped == true) {
      // only if mapped
      const dialogRefwithmapped = this.dialog.open(ClincadminDialogcodeMappingdeleteComponent, {
        panelClass: 'deletewrapper',
      });
      dialogRefwithmapped.afterClosed().subscribe(userAnswer => {
        if (userAnswer) {
          if (userAnswer.data == "no") {

          }
          if (userAnswer.data == "conform") {
            this.loading = true;
            this._DoctorService.deletecodes(deldata.clinicCodesId)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res)
                if (!res.isError) {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.data.responseMessage, options);
                  this.codeslist();

                } else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.data.errorMessage, options);
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', err?.error, options);
                });
          }
        }
      })

    } else {
      console.log(deldata)
      this.loading = false;
      const dialogRef = this.dialog.open(ClinicadminDeletecodesComponent, {
        panelClass: 'deletewrapper',
        data: deldata.clinicCodesId
      });
      dialogRef.afterClosed().subscribe(res => {
        if (res) {
          console.log(res)
          if (!res.data.isError) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.data.responseMessage, options);
            this.codeslist();
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.data.errorMessage, options);
          }
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    }
  }

  deletemap(deldata) {
    console.log(deldata)
    this.loading = true;


    this._DoctorService.ischeckdelete(deldata.clinicode_clinicdoctor_map_id)
      .pipe(first())
      .subscribe((res: any) => {
        this.loading = false;
        console.log(res)
        if (!res.isError) {
          if (res.responseMessage == false) {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', 'This Doctor have appointments', options);
            const dialogRef = this.dialog.open(ClinicadminDeletemapComponent, {
              panelClass: 'deletewrapper',
              data: deldata.clinicode_clinicdoctor_map_id
            });
            dialogRef.afterClosed().subscribe(res => {
              if (res) {
                console.log(res)
                if (!res.data.isError) {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.data.responseMessage, options);
                  console.log(this.codesid)
                  this.getmaplist(undefined);
                } else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.data.responseMessage, options);
                }
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
          }
          else {
            const dialogRef = this.dialog.open(ClinicadminDeletemapComponent, {
              panelClass: 'deletewrapper',
              data: deldata.clinicode_clinicdoctor_map_id
            });
            dialogRef.afterClosed().subscribe(res => {
              if (res) {
                console.log(res)
                if (!res.data.isError) {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res.data.responseMessage, options);
                  console.log(this.codesid)
                  this.getmaplist(undefined);
                } else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.data.responseMessage, options);
                }
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              });
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.data.responseMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });





    // const dialogRef = this.dialog.open(ClinicadminDeletemapComponent, {
    //   panelClass: 'deletewrapper',
    //   data: deldata.clinicode_clinicdoctor_map_id
    // });
    // dialogRef.afterClosed().subscribe(res => {
    //   if (res) {
    //     console.log(res)
    //     if (!res.data.isError) {
    //       this.loading = false;
    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //       this.toastrService.success('', res.data.responseMessage, options);
    //       console.log(this.codesid)
    //       this.getmaplist(undefined);
    //     } else {
    //       this.loading = false;
    //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //       this.toastrService.warning('', res.data.responseMessage, options);
    //     }
    //   }
    // },
    //   err => {
    //     this.loading = false;
    //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //     this.toastrService.warning('', err?.error, options);
    //   });
  }

  mappindcodes(mapdata) {
    this.locationonclinicselect = false;
    if (mapdata?.status != 0) {
      // clear doctor perviously selected
      this.bankMultiCtrl.setValue(this.banks3['']);
      this.mapdata = mapdata;
      console.log(mapdata)
      this.tabGroup.selectedIndex = 2
    }
  }

  applyFilter(event: Event) {
    console.log(event)
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource3.filter = filterValue.trim().toLowerCase();
  }

  //  multiple selection start
  AfterViewInit() {
    this.setInitialValue();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
    this._onDestroy2.next();
    this._onDestroy2.complete();
    this._onDestroy3.next();
    this._onDestroy3.complete();
  }
  //  multiple selection end


  // single search statr
  ngAfterViewInit() {
    this.setInitialValue2();
    this.setInitialValue3();
  }


  protected setInitialValue2() {
    this.filteredBanks2
      .pipe(take(1), takeUntil(this._onDestroy2))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.singleSelect2.compareWith = (a: Bank2, b: Bank2) => a && b && a.clinicChargesId === b.clinicChargesId;
        // this.singleSelect.compareWith = (a: Bank2, b: Bank2) => a && b && a.clinicChargesId === b.clinicChargesId;
      });
  }

  protected setInitialValue3() {
    this.filteredBanks3
      .pipe(take(1), takeUntil(this._onDestroy3))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.singleSelect.compareWith = (a: Bank3, b: Bank3) => a && b && a.doctorId === b.doctorId;
      });
  }

  protected filterBanks2() {
    if (!this.banks2) {
      return;
    }
    // get the search keyword
    let search = this.bankFilterCtrl2.value;
    if (!search) {
      this.filteredBanks2.next(this.banks2.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanks2.next(
      this.banks2.filter(cbank => cbank.chargeName.toLowerCase().indexOf(search) > -1)
    );
  }

  protected filterBanks3() {
    if (!this.banks3) {
      return;
    }
    // get the search keyword
    let search = this.bankFilterCtrl3.value;
    if (!search) {
      this.filteredBanks3.next(this.banks3.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanks3.next(
      this.banks3.filter(bank => bank.doctorName.toLowerCase().indexOf(search) > -1)
    );
  }
  // single search end


  //  multiple selection start
  /**
   * Sets the initial value after the filteredBanks are loaded initially
   */
  protected setInitialValue() {
    this.filteredBanksMulti
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.multiSelect.compareWith = (a: Bank, b: Bank) => a && b && a.doctorId === b.doctorId;
      });
  }

  protected filterBanksMulti() {
    if (!this.banks) {
      return;
    }
    // get the search keyword
    let search = this.bankMultiFilterCtrl.value;
    if (!search) {
      this.filteredBanksMulti.next(this.banks.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanksMulti.next(
      this.banks.filter(bank => bank.doctorName.toLowerCase().indexOf(search) > -1)
    );
  }

  //  multiple selection end

  searchappoinmentfilter() {
    let searchstring = this.searchinput.trim();
    // this.Fsearchstring = searchstring
    if (searchstring) {
      // this.applyfilterData = true;
      this.loading = true;
      this._DoctorService.codesfilter(searchstring)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;

            for (let item of res.responseMessage) {
              item.amount = item.amount;
              item.clinicChargeName = item.clinicChargeName;
              item.clinicCodesId = item.clinicCodesId;
              item.clinic_charges_id = item.clinic_charges_id;
              item.codeId = item.codeId;
              item.description = item.description;
              item.status = item.status;
              item.taxTypeName = item.taxTypeName;

              if (item.taxAmount == 0) {
                item.gstvalue = 0;
                item.vatvalue = 0;
              }
              else {
                if (item.taxId == 92) {
                  item.gstvalue = item.taxAmount;
                  item.vatvalue = 0;
                }
                else {
                  item.vatvalue = item.taxAmount;
                  item.gstvalue = 0;
                }
              }
            }
            // let array = [];
            // array.push(res.responseMessage);
            this.dataSource2 = []
            this.dataSource2 = new MatTableDataSource(res.responseMessage);
            setTimeout(() => this.dataSource2.paginator = this.paginator.toArray()[1]);
            this.paginator.toArray()[1].firstPage();

            if (this.dataSource2.data === null || this.dataSource2.data.length === 0) {
              this.listdata2 = true;
            }
            else {
              this.listdata2 = false;
            }
            // setTimeout(() => {
            //   this.dataSource.paginator = this.paginator
            // });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    }
    // else {
    //   this.applyfilterData = false;
    //   if (this.getpendingstate == "today") {
    //     this.appt('today');
    //   }
    //   if (this.getpendingstate == "past") {
    //     this.appt('past');
    //   }
    //   if (this.getpendingstate == "upcoming") {
    //     this.appt('upcoming');
    //   }
    //   if (this.getpendingstate == "cancelled") {
    //     this.appt('cancelled');
    //   }
    //   return;
    // }

  }


  clearinput(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    let searchstring = filterValue.trim()
    if (searchstring == "") {
      this.listdata2 = false;
      this.codeslist()
      return;
    }
  }
  isEditclicked;
  editmap(edimapdata) {
    this.isEditclicked = edimapdata
    // debugger;
    if (edimapdata.consultationFeeTypeId) {
      this.getdoctorsonconsultype(edimapdata)
      console.log(this.banks3)
    }
    console.log(edimapdata)
    this.mappingsection = true;
    this.mappingupdatebtn = true;
    this.mappingsubmitbtn = false;
    // this.mappingform.get('consultatype').setValue('');
    this.bankCtrl3.disable()
    this.cmapid = edimapdata.clinicode_clinicdoctor_map_id;


    console.log(this.banks3)
    // const getchergeid = this.banks3.findIndex(x => x.clinicChargesId == edimapdata.clinic_charges_id);
    // console.log(getchergeid)
    // this.bankCtrl.setValue(this.banks[getchergeid]);
    // console.log(this.banks[getchergeid])
    // console.log(this.bankCtrl)


    this.mappingform.get('chargenames').setValue(edimapdata.chargesname);
    this.mappingform.get('description').setValue(edimapdata.description);
    this.mappingform.get('consultatype').setValue(edimapdata.consultationFeeTypeId);
    this.consulttypelist()

    // setTimeout(() => {
    //   console.log(this.banks3)
    //   alert("HI");
    // });

  }


  updatemapping() {
    console.log(this.mappingform.value)
    console.log(this.bankCtrl3.value)
    console.log(this.cmapid)

    console.log(this.codesid)

    if (this.mappingform.invalid) {

      if (this.bankCtrl3.value == '' || this.bankCtrl3.value == null) {

        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select Doctor', options);
        this.loading = false;
        return;
      }
    }
    else {
      this.loading = true;

      this.doctorid = this.bankCtrl3.value.doctorId
      console.log(this.doctorid)

      let paylod = {
        "CcCdmMapId": this.cmapid,
        "DoctorId": this.doctorid,
        "FeeType": this.mappingform.value.consultatype
      }
      this._DoctorService.updateemapping(paylod)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.loading = false;
            console.log(this.codesid)
            this.mappingform.reset();
            this.getmaplist(undefined)
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.mappingsection = false;
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  cancelmapping() {
    this.mappingform.reset();
    this.mappingsection = false;
  }
  cancelcode() {
    this.submitbtn = true;
    this.updtbutton = false;
    this.bankCtrl2.setValue(this.banks2[''])
    this.ngOnInit()
  }

  cancelcharges() {
    this.updatebutton = false;
    this.addbutton = true;
    this.addchargesform.reset();
  }


  applyFilter2(event) {
    this.dataSource3.filter = event.target.value;
    if (this.dataSource3.filteredData.length === 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
    }
    // console.log(filteredArray)
    console.log(event.target.value.toLowerCase().trim())
    let filteredArray = this.mappinglistarr.filter(data => {
      if (data.chargesname.toLowerCase().trim().startsWith(event.target.value.toLowerCase().trim())) {
        return true;
      } else if (data.codeid.toLowerCase().trim().startsWith(event.target.value.toLowerCase().trim())) {
        return true;
      } else if (data.description.toLowerCase().trim().startsWith(event.target.value.toLowerCase().trim())) {
        return true;
      }
      else {
        return false;
      }
    })
    console.log(filteredArray)
    console.log(event.target.value.toLowerCase().trim())
    this.dataSource3 = new MatTableDataSource<any>(filteredArray);
    console.log(filteredArray)
    console.log(event.target.value.toLowerCase().trim())
    this.obs = this.dataSource3.connect();
    if (this.dataSource3.filteredData.length === 0) {
      this.filterData = true;
    } else {
      this.filterData = false;

    }
    // if(event.target.value =="" || event.target.value ==null){
    //   this.dataSource3 = new MatTableDataSource<any>(this.mappinglistarr)
    //   this.obs = this.dataSource3.connect();
    //   console.log(this.mappinglistarr)
    // }
    if (this.dataSource3.paginator) {
      this.paginator.toArray()[1].firstPage();
    }
  }

}

export interface PeriodicElement {
  chargesname: string;
  status: any;
  action: any;
}

export interface Bank {
  doctorId: any;
  doctorName: any;
}
export interface Bank2 {
  clinicChargesId: any;
  status: any;
  chargeName: any;
}

export interface Bank3 {
  doctorId: any;
  doctorName: any;
}


const ELEMENT_DATA: PeriodicElement[] = [
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
  { chargesname: 'Dr Charge', status: '', action: '' },
];

export interface PeriodicElement2 {
  chargesname: string;
  description: string;
  codeid: any;
  amount: any;
  gst: any;
  status: any;
  action: any;
}

const ELEMENT_DATA2: PeriodicElement2[] = [
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', amount: '100', gst: '100', status: '', action: '' },
];

export interface PeriodicElement3 {
  chargesname: string;
  description: any;
  codeid: any;
  doctors: any;
  feetype: any;
  amount: any;
  action: any;
}

const ELEMENT_DATA3: PeriodicElement3[] = [
  { chargesname: 'Dr Charge2222', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
  { chargesname: 'Dr Charge', description: 'Vignesh consult fee', codeid: 'V001', doctors: 'Dr.Vignesh', feetype: 'Online Consultation Fee', amount: '100', action: '' },
];



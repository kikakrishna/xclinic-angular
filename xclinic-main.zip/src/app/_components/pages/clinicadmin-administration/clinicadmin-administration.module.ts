import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { HttpClientModule } from '@angular/common/http';
import { ClinicadminAdministrationComponent } from './clinicadmin-administration.component';
import { ClinicadminAdministrationRoutes } from './clinicadmin-administration.routes';
import {MatTabsModule} from '@angular/material/tabs';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { ClinicadminDeletechargesComponent } from '../clinicadmin-deletecharges/clinicadmin-deletecharges.component';
import { ClinicadminDeletecodesComponent } from '../clinicadmin-deletecodes/clinicadmin-deletecodes.component';
import { ClinicadminDeletemapComponent } from '../clinicadmin-deletemap/clinicadmin-deletemap.component';
import { DialogMappingdeletedComponent } from '../dialog-mappingdeleted/dialog-mappingdeleted.component';
import { ClincadminDialogcodeMappingdeleteComponent } from '../clincadmin-dialogcode-mappingdelete/clincadmin-dialogcode-mappingdelete.component';



@NgModule({
  declarations: [ClinicadminAdministrationComponent, ClinicadminDeletechargesComponent, 
    ClinicadminDeletecodesComponent, ClinicadminDeletemapComponent, DialogMappingdeletedComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule.forChild(ClinicadminAdministrationRoutes),
    MatCardModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatPaginatorModule,
    MatTabsModule,
    MatSlideToggleModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMatSelectSearchModule
  ],
  entryComponents:[
    ClinicadminDeletechargesComponent,
    ClinicadminDeletecodesComponent,
    ClinicadminDeletemapComponent,
    DialogMappingdeletedComponent,
    ClincadminDialogcodeMappingdeleteComponent
  ],
})
export class ClinicadminAdministrationModule { }

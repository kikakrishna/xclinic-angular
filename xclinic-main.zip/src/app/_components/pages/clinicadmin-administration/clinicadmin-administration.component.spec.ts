import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminAdministrationComponent } from './clinicadmin-administration.component';

describe('ClinicadminAdministrationComponent', () => {
  let component: ClinicadminAdministrationComponent;
  let fixture: ComponentFixture<ClinicadminAdministrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminAdministrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminAdministrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

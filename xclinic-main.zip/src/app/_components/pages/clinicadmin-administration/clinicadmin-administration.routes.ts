import { RouterModule } from '@angular/router';
import { ClinicadminAdministrationComponent } from './clinicadmin-administration.component';
export const ClinicadminAdministrationRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminAdministrationComponent,
    }
]
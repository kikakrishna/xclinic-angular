import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminServiceeditComponent } from './clinicadmin-serviceedit.component';

describe('ClinicadminServiceeditComponent', () => {
  let component: ClinicadminServiceeditComponent;
  let fixture: ComponentFixture<ClinicadminServiceeditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminServiceeditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminServiceeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

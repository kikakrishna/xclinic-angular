import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { filter, first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
  selector: 'app-clinicadmin-serviceedit',
  templateUrl: './clinicadmin-serviceedit.component.html',
  styleUrls: ['./clinicadmin-serviceedit.component.css']
})

export class ClinicadminServiceeditComponent implements OnInit {
  
  clinicdetails: any = [];
  createclinic: FormGroup;
  paymentmodetoppings = new FormControl();
  clinicvisitpaymentmodetoppings = new FormControl();
  count = [];
  public Currencydetails: any = [];
  clinicadminDetail: any = [];
  public paymenttoppingsList: any = [];
  public paymenttoppingsList2: any = [];
  loading: boolean;
  reshaschatbotdata: any
  defaultclinicstate: any;
  defaultfields: boolean;
  btnCreate: boolean;
  locationmapId: any;
  locationdetails: any;
  defaultstate: any;

  description: boolean=false;
  servid: any;
  public Editor = ClassicEditor;
  [x: string]: any;
  imgfile: any;
  imgfileonupdate: boolean = false;
  imgerror: any;
  docsignfilevalidationmes: any = '';
  docsignfilesizevalidationmes: any = '';
  imgfiledocsignature: any = null;
  imageUrl: any;
  imageUrldocsignature: any;
  mimeTypedocsign: any;
   currentSignature:any;
    resimage: any = null;
    isError: boolean;

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  ngOnInit(): void {
    this.loading = true;
    this.btnCreate = history.state.btnAction;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('clinicserviceid')) {
        this.servid = params?.get('clinicserviceid');
      }
    })

    this.statusofdefaultclinic(history.state.servicestatus);

    this.createclinic = this._formBuilder.group({
      servicename: ['', Validators.required],
      description: ['', Validators.required],
    });

    if(history.state.servicestatus != undefined){
        if(history.state.servicestatus !== 'create')
        {
        this._DoctorService.getservicedetails(this?.servid)
        .pipe(first())
        .subscribe((res: any) => {
        if (!res.isError) {
        console.log('service details',res)
        this.loading = false;
        let data = res?.responseMessage[0];
        this.clinicdetails = data;
        this.clinicadminDetail = data;
        this.imgfile = data?.image;
        this.imgfileonupdate = true;

        this.createclinic.get('servicename').setValue(data?.serviceName);
        this.createclinic.get('description').setValue(data?.description);
        this._DoctorService.reloadprofilename();

        if(data?.image != null) {
        this.imageUrl = data?.image;
        } else {
        this.imageUrl = './assets/images/default-logo.webp';
        }
        }
        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
        }else{
        this.loading = false;
        }
    }else{
        this.loading = false;
    }

  }

  statusofdefaultclinic(defaultclinstate) {
   if(defaultclinstate != undefined){
   if(defaultclinstate !== 'create')
    {
    this.defaultstate = defaultclinstate
    console.log(this.defaultstate)

    if(defaultclinstate.defaultclinic == false){
      this.defaultfields = false
    }
    else{
      this.defaultfields = true
    }
    }
   }

  }

  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    this.imgfile = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
      }
    }
  }

  val(event) {
    console.log(event.target.value.toLowerCase().trim())
  }

  updateclinic() {
    
  }

  ClinicUpdate() {
    
  }

  uploadServiceimage(event, DocSignFile) {
  this.docsignfilevalidationmes = '';
    this.docsignfilevalidationmes = '';
    let fileExt = event.target.files[0].type.split('/')[1]
    let fileSize = event.target.files[0].size
    console.log(fileSize)
    console.log(event)
    if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || fileExt === 'webp') {
      if (fileSize <= 131072) {
        this.imgerror = false;
        this.imgtype = false;
        let reader = new FileReader(); // HTML5 FileReader API
        let file = event.target.files[0];
        this.imgfile = event.target.files[0];
        this.imgfileonupdate = false;
        console.log('this is image', this.imgfile)
        this.imgfiledocsignature = event.target.files[0];
        if (event.target.files && event.target.files[0]) {
          reader.readAsDataURL(file);
          reader.onload = () => {
            this.imageUrldocsignature = reader.result;
          }
        }
        this.mimeTypedocsign = event.target.files[0].type;
      }
      else {
        DocSignFile.value = ''
       this.docsignfilesizevalidationmes = "This file exceeds the maximum size limit of 100kb";
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "This file exceeds the maximum size limit of 100kb", options);
      }
    }
    else {
      DocSignFile.value = ''
      this.docsignfilevalidationmes = "Only jpg, jpeg, png file format is accepted"
    }
    this.currentSignature = event.target.files; 
  }

  updatedoctorprofile(formData: any, formDirective: FormGroupDirective) {
  console.log('sid', this.servid)
    if (this.docsignfilevalidationmes == '') {
      if (this.docsignfilesizevalidationmes === '') {
        if (this.createclinic.value.servicename == '') {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Enter Service Title", options);
          return;
        }
        this.toastrService.clear();
        this.loading = true;
        this.isError = false;
        const listsdate = this.createclinic.value.dateofBirth;
        if (this.createclinic.value.description === null || this.createclinic.value.description === '') {
          this.isError = true;
          this.loading = false;
          this.description = true;
        } else {
          this.description = false;
          this.isError = false;
        }

        if (this.imgfile === 0 || this.imgfile === null || this.imgfile === undefined) {
          this.imgfile = null;
        }
       // if (!this.resimage && !this.imgfile) {
         // this.loading = false;
          //this.imgerror = true;
          //return;
        //}
        //if (this.resimage === null || this.imgfile != null) {
          //if (this.mimeType.match(/image\/*/) == null) {
            //this.isError = true;
            //this.imgtype = true;
            //this.loading = false;
            //return;
          //}
       // }

        if (!this.isError) {
          this.imgerror = false;
           this.aboutme = false;

          this._DoctorService.updateservicedata(this.createclinic, this.imgfile, "",this?.servid, this.imgfileonupdate)
          .pipe(first()).subscribe((res: any) => {
              if(!res.isError) {   
              console.log('updated data', res) 

                this.loading = false;
                formDirective.resetForm();
                this.createclinic.reset();
                this.imgfile=null; 
                this.imgfileonupdate = false;                 
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res.responseMessage, options);
                setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/services'])},2000);

              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
              }
            },
              err => {
              console.log('error 2')
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);
                this.loading = false;
              });
        }
        else {
        console.log('error 3')
          this.loading = false;
        }
      }
      else {
        this.loading = false;
         console.log('error 2')
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "This file exceeds the maximum size limit of 20kb", options);
      }
    }
    else {
      this.loading = false;
      console.log('error 1')
      this.docsignfilevalidationmes = "Only jpg, jpeg, png file format is accepted"
    }
  }

  createService(formData: any, formDirective: FormGroupDirective){
    console.log('form data', formData,this.imgfile)
    this.description = false;

    if(this.createclinic.value.description == '' || this.createclinic.value.description == null || this.createclinic.value.servicename == '' || this.createclinic.value.servicename == null){
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.description = true;
          this.toastrService.warning('', "Enter all the Mandatory Fields", options);
          return;
    }

    if(this.imgfile?.name == '' || this.imgfile?.name == null || this.imgfile?.name == undefined){
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please upload an service image", options);
    }

    if(this.imgfile?.name != ''){
        this._DoctorService.createservicedata(this.createclinic, this.imgfile)
    .pipe(first())
    .subscribe((res: any) => {
    if (!res.isError) {
    console.log(res)
      if(!res.isError) {   
              console.log('updated data', res) 

        this.loading = false;
        formDirective.resetForm();
        this.createclinic.reset();
        this.imgfile=null; 
        this.imgfileonupdate = false;               
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.success('', res.responseMessage, options);
        setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/services'])},2000);


        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
      }

    }
    });
    }


  }




}
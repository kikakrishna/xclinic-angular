import { RouterModule } from '@angular/router';
import { ClinicadminServiceeditComponent } from './clinicadmin-serviceedit.component';
export const ClinicadminServiceeditRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminServiceeditComponent,
    }
]
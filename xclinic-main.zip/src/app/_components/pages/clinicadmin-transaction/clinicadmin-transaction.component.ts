import { AfterViewInit, Component, Input, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatCalendar } from '@angular/material/datepicker';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { Observable, ReplaySubject, Subject } from 'rxjs';
import { first, retry, take, takeUntil, map, startWith } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { ShareDataService } from 'src/app/_services/sharedata.service';
import { WindowRefService } from 'src/app/_services/window-ref.service';
import { MatSidenav } from '@angular/material/sidenav';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
interface apptstatus {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-clinicadmin-transaction',
  templateUrl: './clinicadmin-transaction.component.html',
  styleUrls: ['./clinicadmin-transaction.component.css']
})

export class ClinicadminTransactionComponent implements OnInit, AfterViewInit, OnDestroy {
  displayedColumns: string[] = ['invoiceo', 'paymenttype', 'transactionid', 'paymentdate', 'amount', 'status', 'action'];
  dataSource = new MatTableDataSource<any>([]);
  opened: boolean;
  todaydate = new Date();
  minlen: any = sessionStorage.getItem('minlen');
  maxlen: any = sessionStorage.getItem('maxlen');
  myHolidayFilter: any = []
  myHolidayDates
  maxdate = new Date();
  isCodemap: boolean = false
  blckbtn: boolean = false;
  selectedDate: any;
  loading: boolean = false;
  doctorlist: any = [];
  selectedconsultationtype
  isConsultaionselected: boolean = false
  walkin_appoinmentdate;
  Selecteddoctordropdown = "";
  Selectedconsultiontype: any = "";
  consultypearray: any = [];
  timeslots: any = [];
  filteredOptions: Observable<any[]>;
  filteredOptionssidenav: Observable<any[]>;
  filteredOptionsdoctor: Observable<any[]>;
  transactionForm: FormGroup;
  viewTransaction: FormGroup;
  paymentmodeform: FormGroup;
  obs: Observable<any>;
  consultationTypeArrayBookappointment: any = [];
  consultationTypeArrayBookappointmentArray: any = [];
  TransactiondataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  consultationtyperbtbuttonform: FormGroup;
  myStartDate: any;
  myEndDate: any;
  timeFrame: any;
  current_date: any;
  Noslotmsg: boolean;
  apt_date: any;
  sdate: any;
  enddate: any;
  transactionlistarray: any = [];
  specialityArray: any = [];
  clinicId: any;
  slotimeid = "";
  SelectedSlotDet
  slottime: any;
  showmsg: boolean;
  getallbills: any = [];
  user_id: string;
  patientname: any;
  patientnamesidenav: any;
  // patientControl: any;
  patientControl = new FormControl();
  patientControlsidenav = new FormControl();

  drugControl = new FormControl();
  createpatProfile: FormGroup
  payUpdateform: FormGroup;
  parentGroup: FormGroup;
  Insuranceform: FormGroup;
  remainingamt: any;

  Selectedlocationdropdown: any = "";
  genderlist: Gender[] = [
    { value: 'Male' },
    { value: 'Female' }
  ];

  // dropdown search start
  /** list of banks */
  protected banks: Bank[] = [];

  /** control for the selected bank */
  public bankCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword */
  public bankFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanks: ReplaySubject<Bank[]> = new ReplaySubject<Bank[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;

  @ViewChild('sidenav') public sidenav: MatSidenav;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();
  // dropdown search end
  @ViewChild('calendar', { static: false }) calendar: MatCalendar<any>;
  patientlistarr: any;
  IsBookPayment: boolean = false;
  IsPaypopup: boolean = false;
  payform: FormGroup;
  billapptid: any;

  locationData: any[];
  selectedLocation: any;
  locationDate: any;

  paylist: any;
  initialapptdetails: any;
  patclicked: { patfname: any, patlname: any, patmobno: any };
  getinput: { fname: any; clinicpatid: any; }
  patientfirstname: any;
  patientlastname: any;
  patientphoneno: any;
  totalpagecount: number;
  totalpagecountwithdate: any;
  datechange: boolean = true;
  createfamiltype: FormGroup;
  reloadnavtxdetails = "";
  IsfromTodateEnabled: boolean = false;
  clinicLocations: any = [];
  sessionclinicId: any;
  enableLocation: boolean = false;

  visitfield: boolean = false;
  yesscreen: boolean = true;
  treatmentscreensearch: boolean = false;
  appointmentscreensearch: boolean = true;
  appointmentiddetails: boolean = true;

  public billingsearchbox: string = "";
  public datefilterform: boolean = false;
  treatmentsList: any;
  selectpatient;
  selecttreatmentvalue;
  /** control for the selected bank */
  public selecttreatment: FormControl = new FormControl();
  // hideradiobtn: boolean = true;
  selectedappointmentType: any;
  patientlist: any;
  druglist: any[];
  dropdowmpatientid: any;
  drugArray: any[];
  constructor(private _patientservice: PatientService,
    public toastrService: ToastService,
    public _DoctorService: DoctorService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private sharedataService: ShareDataService,
    private winRef: WindowRefService,
    private ngZone: NgZone,
    public _formBuilder: FormBuilder) {

    this.viewTransaction = this._formBuilder.group({
      startdate: ['', Validators.required],
      enddate: ['', Validators.required],
    })
    this.Insuranceform = this._formBuilder.group({
      appointtype: ['online'],
      insuranceNumber: ['', [Validators.required]],
      insuranceProvider: ['', [Validators.required]],
      validity: ['', [Validators.required]],
      insurarname: ['', [Validators.required]],
    });

    this.payUpdateform = this._formBuilder.group({
      paytype: [''],
      amount: [''],
      transactionid: ['']
    });

    this.payform = this._formBuilder.group({
      paymenttype: ['', Validators.required],
      amount: ['', Validators.required],
      transactionid: ['']
    });
  }


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('tablepaginator', { read: MatPaginator }) tablepaginator: MatPaginator;
  @ViewChild('txpaginator', { read: MatPaginator }) txpaginator: MatPaginator;


  ngOnInit(): void {
    this.loading = true;
    // this.hideradiobtn = true;
    setTimeout(() => {
      this.loading = true;
      this.GetAlldoctors()
    }, 2000)
    this.loadScript();
    // this.myStartDate = new Date();
    // this.viewTransaction.controls.enddate.disable();
    setTimeout(() => this.TransactiondataSource.paginator = this.txpaginator);
    this.obs = this.TransactiondataSource.connect();

    // side window for create patient
    this.clinicId = sessionStorage.getItem('clinicId');

    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: [''],
      aadharno: ['', [Validators.maxLength(12), Validators.minLength(12), Validators.pattern('^[0-9]*$')]],
      patientclinicidentifier: ['', Validators.required],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });

    this.createfamiltype = this._formBuilder.group({
      relationtype: ['', [Validators.required]],
    });

    // load the initial bank list
    this.filteredBanks.next(this.banks.slice());

    // listen for search field value changes
    this.bankFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBanks();
      });
    this.loading = true;

    this.txconsultationtype();
    this.reloadnavtxdetails = JSON.parse(sessionStorage.getItem('SessionselectedTxdet'));
    sessionStorage.removeItem('SessionselectedTxdet')

    // side window code
    this.speciality();
    this.myHolidayFilter = (d: Date): any => {
      return false;
    }
    this.parentGroup = this._formBuilder.group({
      'radio-group1': [''],
    });
    this.getpatientslist();
    // this.loadpaymentmethods()
    this.listInsuranceProvider()
    this.user_id = sessionStorage.getItem('userId');
    this.getClinicLocations();
    // Default select,
    this.selectedappointmentType = "1"
  }

  // load checkout script
  public loadScript() {
    var isFound = false;
    var scripts = document.getElementsByTagName("script")
    for (var i = 0; i < scripts.length; ++i) {
      if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
        isFound = true;
      }
    }

    if (!isFound) {
      var dynamicScripts = ["https://checkout.razorpay.com/v1/checkout.js"];
      for (var i = 0; i < dynamicScripts.length; i++) {
        let node = document.createElement('script');
        node.src = dynamicScripts[i];
        node.type = 'text/javascript';
        node.async = false;
        node.charset = 'utf-8';
        document.getElementsByTagName('head')[0].appendChild(node);
      }
    }
  }

  getClinicLocations() {
    // Get clinic locations
    this.loading = true;
    this.sessionclinicId = sessionStorage.getItem('clinicId');
    this._DoctorService.getclinicLocations(this.sessionclinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.clinicLocations = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }

  txconsultationtype() {
    this.loading = true;
    this._patientservice.getpaymentType()
      .subscribe((res: any) => {
        if (!res.isError) {
          // this.loading = false;
          this.consultypearray = res.responseMessage;
          this.Selectedconsultiontype = "0";
        }
        else {
          // this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          // this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }
  public filterData: boolean = false;
  applyFilter2(event) {

  }

  getpatientslist() {
    this.loading = true;
    this._patientservice.getpatients()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          // this.patientlistarr = res.responseMessage.map(n => n.firstName + ' ' + n.lastName)
          for (let item of res.responseMessage) {
            item.name = item.firstName + ' ' + item.lastName + '-' + item.clinicPatientId;
            // item.firstName = 
            // item.lastName = 
            // item.patientId = 
            // item.patientOfficialId = 
            // item.phoneNumber = 
          }
          this.patientlistarr = res.responseMessage
          // this.patientlistarr = res.responseMessage.map(n => (
          //   {
          //     displayname: n.firstName + ' ' + n.lastName + '-' + n.patientOfficialId,
          //     name: n.firstName + ' ' + n.lastName +,
          //     patientid: n.patientId,
          //     phoneno: n.phoneNumber
          //   }
          // ))

          this.banks = this.patientlistarr;
          this.filteredBanks.next(this.banks.slice());

          if (this.patclicked) {
            const getchergeid3 = this.patientlistarr.findIndex(x => {
              if (x.firstName == this.patclicked.patfname && x.phoneNumber == this.patclicked.patmobno) {
                return x;
              }
            });

            this.bankCtrl.setValue(this.banks[getchergeid3]);
          }


        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }
  public totalSize = 0;
  public pageindex = 0;

  GetAlldoctors() {
    this.loading = true;
    const sdate = this.viewTransaction.value.startdate;
    const getstdate = moment(sdate).format();
    let startdate = getstdate.substr(0, 10);

    const edate = this.viewTransaction.value.enddate;
    const getedate = moment(edate).format();
    let enddate = getedate.substr(0, 10);
    if (startdate != "Invalid da" && enddate != "Invalid da") {
      this.datefilterform = true;
    } else {
      this.datefilterform = false;
    }
    this._DoctorService.clinicadminTransactionDoctor('withprofile')
      // this._patientservice.getalldocdrop()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          if (res?.responseMessage?.length != 0) {
            this.doctorlist = res?.responseMessage?.doctors;
            // this.Selecteddoctordropdown = res?.responseMessage[0]?.doctorId;
            this.Selecteddoctordropdown = "0";
          } else {
            this.loading = false;
          }
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      }, () => {
        // reload nav txdetails
        if (this.reloadnavtxdetails) {
          let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
          this.selectedtxDet = this.reloadnavtxdetails;

          // no date , no pagination
          if (nInfo?.txformdetails?.withOutdate == true &&
            nInfo?.txformdetails?.withdate == "" &&
            nInfo.paginationClicked == "") {
            this.IsfromTodateEnabled = false;
            // alert("no date , no pagination , reload")
            setTimeout(() => {
              this.loadConsultationTran();
            })
          }

          // no date , with pagination
          if (nInfo?.txformdetails?.withOutdate == true &&
            nInfo?.txformdetails?.withdate == "" &&
            nInfo.paginationClicked == "clicked") {
            this.IsfromTodateEnabled = false;
            // alert("no date , with pagination , reload")
            setTimeout(() => {
              this.loadTranspecificPage();
            })
          }

          // with date, with pagination
          if (nInfo?.txformdetails?.withdate == true &&
            nInfo?.txformdetails?.withOutdate == "" &&
            nInfo?.paginationClicked == "clicked") {
            this.IsfromTodateEnabled = true;
            // alert("with pagination, with date")
            setTimeout(() => {
              this.loadPaginationgetNexttransactionwithdate();
            });
          }

          // with date, no pagination
          if (nInfo?.txformdetails?.withdate == true &&
            nInfo?.txformdetails?.withOutdate == "" &&
            nInfo?.paginationClicked == "") {
            this.IsfromTodateEnabled = true;
            // alert("no pagination, with date")
            setTimeout(() => {
              this.loadgetTransactionlistWithDate();
            });
          }
          let aptType = JSON.parse(sessionStorage.getItem("appointmentType"))
          // console.log(aptType)
          if (aptType == 2) {
            this.ngOnInit()
          }
        } else {
          // alert("nonreload data")
          // this.datefilterform = true;
          const sdate = this.viewTransaction.value.startdate;
          const getstdate = moment(sdate).format();
          let startdate = getstdate.substr(0, 10);

          const edate = this.viewTransaction.value.enddate;
          const getedate = moment(edate).format();
          let enddate = getedate.substr(0, 10);
          if (startdate != "Invalid da" && enddate != "Invalid da") {
            this.getTransactionlistWithDate();
          } else {
            this.ChangeConsultationTran();
          }
        }
      })
  }
  PaginationgetNexttransaction(event: PageEvent) {
    // alert("*** page no date")
    console.log("PaginationgetNexttransaction")
    // // pagination track info            
    let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
    let a = {
      "pageNumber": event?.pageIndex,
      "pageSize": event?.pageSize,
      "totalSize": nInfo.paginatorinfo.totalSize,
    }
    let filterdetils = {
      Selectedstartdate: "",
      Selectedenddate: "",
      Selecteddoctor: this.Selecteddoctordropdown,
      SelectedCtype: this.Selectedconsultiontype,
      billingsearchbox: this.billingsearchbox,
      withdate: "",
      withOutdate: true,
    }
    let navinfo = {
      paginationClicked: "clicked",
      txformdetails: filterdetils,
      paginatorinfo: a,
    }
    sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
    this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    this.txpaginator.length = navinfo.paginatorinfo.totalSize;


    this.loading = true;
    this._DoctorService.transactionList2(this.Selecteddoctordropdown, this.Selectedconsultiontype, event.pageIndex, event.pageSize, this.billingsearchbox)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          for (let i of res.responseMessage) {
            if (i.paymentstatus == 1) {
              i.paymentstatustext = "Payment Received"
            }
            if (i.paymentstatus == 0) {
              i.paymentstatustext = "Payment Not Received"
            }
            i.converteddate = moment(i.appointmentDateTime).format('ll');
            this.current_date = moment(new Date()).format('L');
            this.apt_date = moment(i.appointmentDateTime).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            i.timeFrame = this.timeFrame;
          }
          if (res.responseMessage.length == 0 || res.responseMessage == null) {
            this.filterData = true;
            this.selectedtxDet = '';
            this.appointmentstatus.length = 0;
            this.dataSource = new MatTableDataSource<any>([]);
            this.listdata = true;
          } else {
            this.filterData = false;
            this.selectedtxDet = res.responseMessage[0];
            this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
            this.Getallbills()
            this.listdata = false;
          }
          this.transactionlistarray = res.responseMessage;
          this.loading = false;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
          this.obs = this.TransactiondataSource.connect();
        });

  }
  dateenabled() {
    // this.viewTransaction.controls.enddate.reset();
    if (this.reloadnavtxdetails == "" || this.reloadnavtxdetails == null) {
      // alert("123");
      if (this.viewTransaction.value.startdate != "") {
        this.viewTransaction.controls.enddate.enable();
      }
    }
  }
  datevalidation() {
    if (this.reloadnavtxdetails == "" || this.reloadnavtxdetails == null) {
      // alert("456");
      if (this.viewTransaction.value.startdate == "") {
        this.viewTransaction.controls.enddate.disable();
        this.viewTransaction.controls.enddate.setValue('');
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please Choose From Date", options);
        return;
      }
      this.myEndDate = this.viewTransaction.value.startdate;

    }
    const sdate = this.viewTransaction.value.startdate;
    const getstdate = moment(sdate).format();
    let startdate = getstdate.substr(0, 10);

    const edate = this.viewTransaction.value.enddate;
    const getedate = moment(edate).format();
    let enddate = getedate.substr(0, 10);
    if (startdate != "Invalid da" && enddate != "Invalid da") {
      this.datefilterform = true;
      this.getTransactionlistWithDate();
    } else {
      this.datefilterform = false;
    }
  }

  setDefaultLocation() {
    // Set default clinic location if consultation type is video
    this.getClinicLocations();
    this.clinicLocations.forEach(element => {
      if (element.defaultclinic == true) {
        this.Selectedlocationdropdown = element.clinicLocationMapId;
      }
    });
  }

  ChangeConsultationTran() {
    // if (this.reloadnavtxdetails == "" || this.reloadnavtxdetails == null) {
    // this.hideradiobtn = false;
    if (this.Selectedlocationdropdown != 2) {
      this.setDefaultLocation();
    }

    const sdate = this.viewTransaction.value.startdate;
    const getstdate = moment(sdate).format();
    let startdate = getstdate.substr(0, 10);

    const edate = this.viewTransaction.value.enddate;
    const getedate = moment(edate).format();
    let enddate = getedate.substr(0, 10);
    if (startdate != "Invalid da" && enddate != "Invalid da") {
      this.datefilterform = true;
      this.getTransactionlistWithDate();
      return
    } else {
      this.datefilterform = false;
    }

    // }
    // alert("no pagination, no date, go")
    this.loading = true;
    console.log(this.Selecteddoctordropdown)

    if (this.Selecteddoctordropdown && this.Selecteddoctordropdown.trim()) {
      this._DoctorService.transactionList(this.Selecteddoctordropdown, this.Selectedconsultiontype, 0, 5, this.billingsearchbox, this.Selectedlocationdropdown)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            for (let i of res.responseMessage) {
              if (i.paymentstatus == 1) {
                i.paymentstatustext = "Payment Received"
              }
              if (i.paymentstatus == 0) {
                i.paymentstatustext = "Payment Not Received"
              }
              i.converteddate = moment(i.appointmentDateTime).format('ll');
              this.current_date = moment(new Date()).format('L');
              this.apt_date = moment(i.appointmentDateTime).format('L');
              if (this.current_date <= this.apt_date) {
                this.timeFrame = 'upcoming';
              }
              if (this.current_date >= this.apt_date) {
                this.timeFrame = 'past';
              }
              if (this.current_date == this.apt_date) {
                this.timeFrame = 'today';
              }
              i.timeFrame = this.timeFrame;
            }
            if (res.responseMessage.length == 0 || res.responseMessage == null) {
              this.filterData = true;
              this.selectedtxDet = '';
              this.appointmentstatus.length = 0;
              this.dataSource = new MatTableDataSource<any>([]);
              this.listdata = true;
            } else {
              this.filterData = false;
              this.selectedtxDet = res.responseMessage[0];
              this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
              if (this.selectedtxDet.appointmentStatus == "Completed") {
                this.tx_table_appoinmentstatus = this.selectedtxDet.appointmentStatusId;
                this.Iscompleted = true;
              } else {
                this.Iscompleted = false;
              }
              this.listdata = false;
            }
            this.transactionlistarray = res.responseMessage;
            this.loading = false;

            // pagination track info            
            let a = {
              "pageNumber": res.pagination.pageNumber,
              "pageSize": res.pagination.pageSize,
              "totalSize": res.pagination.total
            }
            let filterdetils = {
              Selectedstartdate: "",
              Selectedenddate: "",
              Selecteddoctor: this.Selecteddoctordropdown,
              SelectedCtype: this.Selectedconsultiontype,
              withdate: "",
              withOutdate: true,
              SelectedLocation: this.Selectedlocationdropdown,
              billingsearchbox: this.billingsearchbox

            }
            let navinfo = {
              paginationClicked: "",
              txformdetails: filterdetils,
              paginatorinfo: a,
            }
            sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
            this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
            this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
            this.txpaginator.length = navinfo.paginatorinfo.totalSize;


          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          }, () => {
            this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
            this.obs = this.TransactiondataSource.connect();
            this.Getallbills();
          });
    }
    // else {
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', "Please select the doctor", options);
    //   return;
    // }
  }
  getTransactionlistWithDate() {
    const sdate = this.viewTransaction.value.startdate;
    const getstdate = moment(sdate).format();
    let startdate = getstdate.substr(0, 10);

    const edate = this.viewTransaction.value.enddate;
    const getedate = moment(edate).format();
    let enddate = getedate.substr(0, 10);
    if (startdate == "Invalid da" || enddate == "Invalid da") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Choose From and To Date", options);
      return
    } else {

      // alert("go")
      this.loading = true;
      this.IsfromTodateEnabled = true;
      this.TransactiondataSource = new MatTableDataSource<any>([]);
      this._DoctorService.transactionListwithdate(this.Selecteddoctordropdown, startdate, enddate, this.Selectedconsultiontype, 0, 5, this.billingsearchbox)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let i of res.responseMessage) {
              if (i.paymentstatus == 1) {
                i.paymentstatustext = "Payment Received"
              }
              if (i.paymentstatus == 0) {
                i.paymentstatustext = "Payment Not Received"
              }
              i.converteddate = moment(i.appointmentDateTime).format('ll');
              this.current_date = moment(new Date()).format('L');
              this.apt_date = moment(i.appointmentDateTime).format('L');
              if (this.current_date <= this.apt_date) {
                this.timeFrame = 'upcoming';
              }
              if (this.current_date >= this.apt_date) {
                this.timeFrame = 'past';
              }
              if (this.current_date == this.apt_date) {
                this.timeFrame = 'today';
              }
              i.timeFrame = this.timeFrame;
            }

            if (res.responseMessage.length == 0) {
              this.filterData = true;
            } else {
              this.filterData = false;
            }

            // pagination track info            
            let a = {
              "pageNumber": res.pagination.pageNumber,
              "pageSize": res.pagination.pageSize,
              "totalSize": res.pagination.total,
            }
            let filterdetils = {
              Selectedstartdate: startdate,
              Selectedenddate: enddate,
              Selecteddoctor: this.Selecteddoctordropdown,
              SelectedCtype: this.Selectedconsultiontype,
              withdate: true,
              withOutdate: "",
              billingsearchbox: this.billingsearchbox

            }
            let navinfo = {
              paginationClicked: "",
              txformdetails: filterdetils,
              paginatorinfo: a,
            }
            sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
            this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
            this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
            this.txpaginator.length = navinfo.paginatorinfo.totalSize;

            this.transactionlistarray = res?.responseMessage;
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          }, () => {
            this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
            this.obs = this.TransactiondataSource.connect();
          });
    }
  }
  PaginationgetNextpatienttransaction(event) {
    // alert("*** page no date")
    console.log("PaginationgetNextpatienttransaction")
    // PaginationgetNextpatienttransaction
    // // pagination track info            
    let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
    let a = {
      "pageNumber": event?.pageIndex,
      "pageSize": event?.pageSize,
      "totalSize": nInfo.paginatorinfo.totalSize,
    }
    let filterdetils = {
      selectpatient: this.selectpatient?.patientId,
      selecttreatmentvalue: this.selecttreatmentvalue,
    }
    let navinfo = {
      paginationClicked: "clicked",
      txformdetails: filterdetils,
      paginatorinfo: a,
    }
    sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
    this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    this.txpaginator.length = navinfo.paginatorinfo.totalSize;
    console.log(this.selecttreatmentvalue)
    let patienttrpackagemapid = this.selecttreatmentvalue.patienttrpackagemapid
    this.loading = true;
    this._DoctorService.getAppointmentTreatmentbyPatient(this.dropdowmpatientid, event?.pageIndex, event?.pageSize, patienttrpackagemapid)
      .pipe(first()).subscribe((res: any) => {
        if (!res.isError) {
          for (let i of res.responseMessage) {
            if (i.paymentstatus == 1) {
              i.paymentstatustext = "Payment Received"
            }
            if (i.paymentstatus == 0) {
              i.paymentstatustext = "Payment Not Received"
            }
            i.converteddate = moment(i.appointmentDateTime).format('ll');
            this.current_date = moment(new Date()).format('L');
            this.apt_date = moment(i.appointmentDateTime).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            i.timeFrame = this.timeFrame;
          }
          if (res.responseMessage.length == 0 || res.responseMessage == null) {
            this.filterData = true;
            this.selectedtxDet = '';
            this.appointmentstatus.length = 0;
            this.dataSource = new MatTableDataSource<any>([]);
            this.listdata = true;
          } else {
            this.filterData = false;
            this.selectedtxDet = res.responseMessage[0];
            this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
            // if (this.selectedtxDet.appointmentStatus == "Completed") {
            //   this.tx_table_appoinmentstatus = this.selectedtxDet.appointmentStatusId;
            //   this.Iscompleted = true;
            // } else {
            //   this.Iscompleted = false;
            // }
            this.listdata = false;
          }
          this.transactionlistarray = res.responseMessage;
          this.loading = false;

          // pagination track info            
          // let a = {
          //   "pageNumber": res.pagination.pageNumber,
          //   "pageSize": res.pagination.pageSize,
          //   "totalSize": res.pagination.total
          // }
          // let filterdetils = {
          //   selectpatient: this.selectpatient?.patientId,
          //   selecttreatmentvalue: this.selecttreatmentvalue,
          // }
          // let navinfo = {
          //   paginationClicked: "",
          //   txformdetails: filterdetils,
          //   paginatorinfo: a,
          // }
          // sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
          // this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
          // this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
          // this.txpaginator.length = navinfo.paginatorinfo.totalSize;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
          this.obs = this.TransactiondataSource.connect();
          this.Getallbills();
        });
  }
  appointmentType: any;
  directappointment(val) {
    this.patientname = ""
    this.filteredOptions = null
    this.treatmentAppointmentFields = false;
    this.directAppointmentFields = true;
    this.ChangeConsultationTran()
    this.selectpatient = ""
    this.selecttreatmentvalue = ''
    this.appointmentType = val
  }
  treatment_appointment(val) {
    this.patientname = ""
    this.filteredOptions = null
    this.directAppointmentFields = false;
    this.treatmentAppointmentFields = true;
    // this.getTreatmentsdropdownbyPatient()
    // this.transactionlistarray = ''
    this.TransactiondataSource = new MatTableDataSource();
    this.obs = this.TransactiondataSource.connect();
    this.dataSource = new MatTableDataSource();
    this.listdata = true;
    this.IsfromTodateEnabled = false;
    this.appointmentType = val;
    this.selectedtxDet = ""
    this.remainingamt = ""
    this.treatmentsList = ""
  }

  patphonenum: any;
  getDropdownbyPatient(event) {
    console.log("event--------->" + event.target.value)


    // if(this.patientfirstname){
    //   var inputparam;
    //   inputparam = this.patientfirstname
    // }else{
    //   var inputparam;
    //   inputparam = event.target.value
    // }

    if (event.target.value.length >= 2) {
      this.loading = true;

      // this.patclicked = {
      //   patfname: this.patientfirstname,
      //   patlname: this.patientlastname,
      //   patmobno: this.patientphoneno
      // }




      this._DoctorService.getPatientbysearch(event.target.value)
        .pipe(first())
        .subscribe((res: any) => {
          if (res.isError) {
            this.Book_SelectedSpeciality = ""
            this.Book_SelectedDoctor = ""
            this.selectedconsultationtype = ""
            this.SelectedSlotDet = ""
            this.timeslots = []
            this.selectedLocation = ""
            this.slottime = ""
            this.slotimeid = ""
            this.isConsultaionselected = false
            this.specialityArray = []
            this.filteredOptionsdoctor = null
            this.consultationTypeArrayBookappointment = []
          }
          if (!res.isError) {
            

            // this.patientlist = res.responseMessage;


            this.drugArray = [];
            for (let items of res.responseMessage) {

              const array1 = {
                'patientId': items.patientId,
                'patientOfficialId': items.patientOfficialId,
                'firstName': items.firstName + (items.clinicPatientId == null || items.clinicPatientId == '' ? '' : ('-' + items.clinicPatientId)),
                'lastName': items.lastName,
                'phoneNumber': items.phoneNumber,
                'clinicPatientId': items.clinicPatientId
              }

              this.drugArray.push(array1);

            }
            this.patientlist = this.drugArray;
            this.filteredOptionssidenav = this.patientControlsidenav.valueChanges
              .pipe(
                startWith(''),
                map(value => this._filter(value))
              );
            console.log(this.filteredOptionssidenav)

          } else {
            this.loading = false;
          }
        })
    }
    else if (event.target.value.length == 0) {
      console.log('in')
      this.patientlist = "";
      this.filteredOptionssidenav = this.patientControlsidenav.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
        );
    }
    if (event.target.value.length >= 1) {
      this.filteredOptionssidenav = null;
      this.loading = false;

    }
    if (event.target.value.length == 0) {
      this.Book_SelectedSpeciality = ""
      this.Book_SelectedDoctor = ""
      this.selectedconsultationtype = ""
      this.SelectedSlotDet = ""
      this.timeslots = []
      this.selectedLocation = ""
      this.slottime = ""
      this.slotimeid = ""
      this.isConsultaionselected = false
      this.specialityArray = []
      this.filteredOptionsdoctor = null
      this.consultationTypeArrayBookappointment = []
    }

    // if (event.target.value.length >= 2 && this.filteredOptionssidenav == null) {
    //   this.patientnamesidenav = ""
    // }
  }

  patoffid: any;

  getpatientbyregisterpatient(event) {
    console.log("event--------->" + event)

    setTimeout(() => {
      this.loading = true;
      this._DoctorService.getPatientbysearch(event)
        .pipe(first())
        .subscribe((res: any) => {
         
          if (!res.isError) {
            this.loading = false;

            this.patientlist = res.responseMessage;
            // this.dropdowmpatientid = res.responseMessage[0].patientOfficialId;
            // if (this.dropdowmpatientid != null || this.dropdowmpatientid != undefined) {
            //   this.speciality();

            // }


            console.log("firstname======" + this.getinput.fname);
            console.log("clinicpatid======" + this.getinput.clinicpatid);

            var getchergeid3 = this.patientlist.findIndex(x => {
              if (x.firstName == this.getinput.fname && x.clinicPatientId == this.getinput.clinicpatid) {
                console.log("x======" + JSON.stringify(x));
                // console.log("x.firstName======" + x.firstName);
                // console.log("x.phoneNumber======" + x.clinicPatientId);
                // console.log("firstname======" + this.getinput.fname);
                // console.log("clinicpatid======" + this.getinput.clinicpatid);

                this.patoffid = x
                return x;
              }
            });

            console.log("getchergeid3======" + getchergeid3);

            console.log("this.patoffid======" + JSON.stringify(this.patoffid));
            this.dropdowmpatientid = this.patoffid?.patientOfficialId
            console.log(" this.dropdowmpatientid=====>" + this.dropdowmpatientid)
            this.speciality();

            this.drugArray = [];
            for (let items of res.responseMessage) {

              const array1 = {
                'patientId': items.patientId,
                'patientOfficialId': items.patientOfficialId,
                'firstName': items.firstName + (items.clinicPatientId == null || items.clinicPatientId == '' ? '' : ('-' + items.clinicPatientId)),
                'lastName': items.lastName,
                'phoneNumber': items.phoneNumber,
                'clinicPatientId': items.clinicPatientId
              }

              this.drugArray.push(array1);

            }
            this.patientlist = this.drugArray;
            this.filteredOptions = this.patientControlsidenav.valueChanges
              .pipe(
                startWith(''),
                map(value => this._filter(value))
              );
            console.log(this.filteredOptions)

          } else {
            this.loading = false;
          }
        })
      console.log('in')
      this.patientlist = "";
      this.filteredOptions = this.patientControlsidenav.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
        );
    }, 1000)



  }

  getTreatmentsDropdownbyPatient(event) {

    console.log("event--------->" + event.target.value)
    if (event.target.value.length >= 2) {
      this.loading = true;
      this._DoctorService.getPatientbysearch(event.target.value)
        .pipe(first())
        .subscribe((res: any) => {
          if (res.isError) {
            this.treatmentsList = []
          }
          if (!res.isError) {
            this.loading = false;

            this.drugArray = [];
            for (let items of res.responseMessage) {

              const array1 = {
                'patientId': items.patientId,
                'patientOfficialId': items.patientOfficialId,
                'firstName': items.firstName + (items.lastName == null || items.lastName == '' ? '' : ('-' + items.lastName)) + (items.clinicPatientId == null || items.clinicPatientId == '' ? '' : ('-' + items.clinicPatientId)),
                'lastName': items.lastName,
                'phoneNumber': items.phoneNumber,
                'clinicPatientId': items.clinicPatientId
              }

              this.drugArray.push(array1);

            }





            this.patientlist = this.drugArray;

            this.filteredOptions = this.patientControl.valueChanges
              .pipe(
                startWith(''),
                map(value => this._filter(value))
              );
            console.log(this.filteredOptions)

          } else {
            this.loading = false;
          }
        })
    }
    else if (event.target.value.length == 0) {
      console.log('in')
      this.patientlist = "";
      this.filteredOptions = this.patientControl.valueChanges
        .pipe(
          startWith(''),
          map(value => this._filter(value))
        );
    }
    if (event.target.value.length >= 1) {
      this.filteredOptions = null;
      this.loading = false;

    }

    if (event.target.value.length == 0) {
      this.treatmentsList = []
      this.selecttreatmentvalue = []
    }

  }


  private _filter(value: string): string[] {
    const filterValue = value;
    if (this.patientlist) {
      return this.patientlist.filter(option => option.firstName.toLowerCase().includes(filterValue));
    }
  }

  //   searchNewsInList2(filterValue:any):Observable<New[]>{
  //     return this.httpClient.get<New[]>(this.basePath)
  //       .pipe(
  //           map((response:any)=>{
  //              response=response.filter(news=>news.title.includes(filterValue));
  //              return response;
  //          })
  //       );
  // }

  onSelectionsidenavChange(event) {
    this.speciality()
    // items.clinicPatientId = this.patphonenum
    console.log("event--------->" + event.option.value.phoneNumber)

    console.log("event--------->" + event.option.value.patientOfficialId)
    console.log("event--------->" + event.option.value.firstName)

    this.patphonenum = event.option.value.phoneNumber
    console.log("patphonenum--------->" + this.patphonenum)

    this.filteredOptionssidenav = null

    this.consultationTypeArrayBookappointment = []
    this.filteredOptionsdoctor = null;
    this.Book_SelectedSpeciality = ""
    this.Book_SelectedDoctor = ""
    this.selectedconsultationtype = ""
    this.SelectedSlotDet = ""
    this.timeslots = []
    this.selectedLocation = ""
    this.slottime = ""
    this.slotimeid = ""
    this.isConsultaionselected = false


    this.patientnamesidenav = event.option.value.firstName

    this._DoctorService.getTreatmentsDropdownbyPatient(event.option.value.patientOfficialId).pipe(first())
      .subscribe((res: any) => {

        if (!res.isError) {
          this.loading = false;
          this.treatmentsList = res?.responseMessage;
          console.log(this.treatmentsList)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      )
    let patientOfficialid = event.option.value.patientOfficialId
    this.dropdowmpatientid = patientOfficialid
    this.patientnamesidenav = event.option.value.firstName
  }
  onSelectionChange(event) {
    console.log(this.patientControl)
    this.filteredOptionssidenav = null
    console.log("event--------->" + event.option.value.patientOfficialId)
    console.log("event--------->" + event.option.value.firstName)

    this.patientname = event.option.value.firstName

    this._DoctorService.getTreatmentsDropdownbyPatient(event.option.value.patientOfficialId).pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.treatmentsList = res?.responseMessage;
          console.log(this.treatmentsList)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        }
      )
    let patientOfficialid = event.option.value.patientOfficialId
    this.dropdowmpatientid = patientOfficialid
    this.patientname = event.option.value.firstName



  }
  getSelectedTreatment(event) {

    console.log(event)

  }
  getPatientTransaction() {
    console.log("grgrgrgrrgggrgrgrgr")
    console.log(this.selectpatient)
    console.log(this.selecttreatment.value)
    console.log("filteredOptions------------" + this.filteredOptions)

    if (this.patientControl.value !== "" && this.patientControl.value.trim() !== "") {

      if (this.filteredOptions == null) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please select patient name', options);
      } else {
        if (this.selecttreatment.value == undefined || this.selecttreatment.value == '') {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', 'Please select the treatment', options);
          return
        }
        else {
          // console.log(this.selecttreatment.value.patienttrpackagemapid)
          console.log(this.selectpatient?.patientId)
          let treatmentId = this.selecttreatment.value.treatmentId
          let patienttrpackagemapid = this.selecttreatment.value.patienttrpackagemapid
          this._DoctorService.getAppointmentTreatmentbyPatient(this.dropdowmpatientid, 0, 5, patienttrpackagemapid)
            .pipe(first()).subscribe((res: any) => {
              if (!res.isError) {
                for (let i of res.responseMessage) {
                  if (i.paymentstatus == 1) {
                    i.paymentstatustext = "Payment Received"
                  }
                  if (i.paymentstatus == 0) {
                    i.paymentstatustext = "Payment Not Received"
                  }
                  i.converteddate = moment(i.appointmentDateTime).format('ll');
                  this.current_date = moment(new Date()).format('L');
                  this.apt_date = moment(i.appointmentDateTime).format('L');
                  if (this.current_date <= this.apt_date) {
                    this.timeFrame = 'upcoming';
                  }
                  if (this.current_date >= this.apt_date) {
                    this.timeFrame = 'past';
                  }
                  if (this.current_date == this.apt_date) {
                    this.timeFrame = 'today';
                  }
                  i.timeFrame = this.timeFrame;
                }
                if (res.responseMessage.length == 0 || res.responseMessage == null) {
                  this.filterData = true;
                  this.selectedtxDet = '';
                  this.appointmentstatus.length = 0;
                  this.dataSource = new MatTableDataSource<any>([]);
                  this.listdata = true;
                } else {
                  this.filterData = false;
                  this.selectedtxDet = res.responseMessage[0];
                  this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
                  if (this.selectedtxDet.appointmentStatus == "Completed") {
                    this.tx_table_appoinmentstatus = this.selectedtxDet.appointmentStatusId;
                    this.Iscompleted = true;
                  } else {
                    this.Iscompleted = false;
                  }
                  this.listdata = false;
                }
                this.transactionlistarray = res.responseMessage;
                this.loading = false;

                // pagination track info            
                let a = {
                  "pageNumber": res.pagination.pageNumber,
                  "pageSize": res.pagination.pageSize,
                  "totalSize": res.pagination.total
                }
                let filterdetils = {
                  selectpatient: this.selectpatient?.patientId,
                  selecttreatmentvalue: this.selecttreatmentvalue,
                }
                let navinfo = {
                  paginationClicked: "",
                  txformdetails: filterdetils,
                  paginatorinfo: a,
                }
                sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
                this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
                this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
                this.txpaginator.length = navinfo.paginatorinfo.totalSize;
              } else {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              }, () => {
                this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
                this.obs = this.TransactiondataSource.connect();
                this.Getallbills();
              });
        }
      }


    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please select patient name', options);
    }

  }
  txPaginationIndex;
  PaginationgetNexttransactionwithdate(event: PageEvent) {
    console.log("PaginationgetNexttransactionwithdate")
    // alert("*** page with date")
    const sdate = this.viewTransaction.value.startdate;
    const getstdate = moment(sdate).format();
    let startdate = getstdate.substr(0, 10);

    const edate = this.viewTransaction.value.enddate;
    const getedate = moment(edate).format();
    let enddate = getedate.substr(0, 10);
    if (startdate == "Invalid da" || enddate == "Invalid da") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Choose From and To Date", options);
      return
    } else {

      // // pagination track info            
      let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
      let a = {
        "pageNumber": event?.pageIndex,
        "pageSize": event?.pageSize,
        "totalSize": nInfo.paginatorinfo.totalSize,
      }
      let filterdetils = {
        Selectedstartdate: startdate,
        Selectedenddate: enddate,
        Selecteddoctor: this.Selecteddoctordropdown,
        SelectedCtype: this.Selectedconsultiontype,
        withdate: true,
        withOutdate: "",
        billingsearchbox: this.billingsearchbox

      }
      let navinfo = {
        paginationClicked: "clicked",
        txformdetails: filterdetils,
        paginatorinfo: a,
      }
      sessionStorage.setItem("navInfo", JSON.stringify(navinfo))
      this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
      this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
      this.txpaginator.length = navinfo.paginatorinfo.totalSize;

      this.loading = true;
      this.TransactiondataSource = new MatTableDataSource<any>([]);
      this._DoctorService.transactionListwithdate2(this.Selecteddoctordropdown, startdate, enddate, this.Selectedconsultiontype, event.pageIndex, event.pageSize, this.billingsearchbox)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            for (let i of res.responseMessage) {
              if (i.paymentstatus == 1) {
                i.paymentstatustext = "Payment Received"
              }
              if (i.paymentstatus == 0) {
                i.paymentstatustext = "Payment Not Received"
              }
              i.converteddate = moment(i.appointmentDateTime).format('ll');
              this.current_date = moment(new Date()).format('L');
              this.apt_date = moment(i.appointmentDateTime).format('L');
              if (this.current_date <= this.apt_date) {
                this.timeFrame = 'upcoming';
              }
              if (this.current_date >= this.apt_date) {
                this.timeFrame = 'past';
              }
              if (this.current_date == this.apt_date) {
                this.timeFrame = 'today';
              }
              i.timeFrame = this.timeFrame;
            }
            if (res.responseMessage.length == 0) {
              this.filterData = true;
            } else {
              this.filterData = false;
            }

            this.transactionlistarray = res.responseMessage;

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          }, () => {
            this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
            this.obs = this.TransactiondataSource.connect();
          });
    }
  }
  selectedtxDet: any;
  Iscompleted: boolean = false;

  selectedtx(i) {
    this.selectedtxDet = i;
    this.tx_table_appoinmentstatus = "";
    this.tx_table_appoinmentstatus = i.appointmentStatusId;
    if (i.appointmentStatus == "Completed") {
      this.Iscompleted = true;
    } else {
      this.Iscompleted = false;
    }
    // if (i?.consultationTypeName == "Clinic Visit") {
    //   this.AppoinmentstatusDropdownclinivisit();
    // }
    // if (i?.consultationTypeName == "Online Consultation") {
    //   this.AppoinmentstatusDropdownOnline();
    // }
    this.appointmentstatusdropdown(i?.consultationType)
    // loading table based on app id
    this.Getallbills();
  }

  appointmentstatusdropdown(ctype) {
    this.appointmentstatus.length = 0;
    this.loading = true;
    this._DoctorService.appstatusdropdown(ctype)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appointmentstatus = res?.responseMessage;
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }



  public appointmentstatus: any = [];
  // for only online in appointment status dropdown
  AppoinmentstatusDropdownOnline() {
    this.appointmentstatus.length = 0;
    this.loading = true;
    this._DoctorService.OnlineAppointmentStatus()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appointmentstatus = res?.responseMessage;
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  // for only clinicvisit in appointment status dropdown
  AppoinmentstatusDropdownclinivisit() {
    this.appointmentstatus.length = 0;
    this.loading = true;
    this._DoctorService.ClinicvisitAppointmentStatus()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appointmentstatus = res?.responseMessage;
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  // navigate to preview invoice screen
  previewScreen(data) {
    sessionStorage.setItem("SessionselectedTxdet", JSON.stringify(this.selectedtxDet));
    this.router.navigate(['/thealth/clinicadmin/transactioninvoice/', data.bamid]);

  }
  // navigate to view appointment
  viewAppoinmentScreen() {
    const dt = new Date(this.selectedtxDet?.appointmentDateTime);
    // setTimeout(() => {
    if (this.todaydate > dt) {
      this.router.navigate(['/thealth/clinicadmin/appointments/today/', this.selectedtxDet?.appointmentId]);
    } else if (this.todaydate == dt) {
      this.router.navigate(['/thealth/clinicadmin/appointments/upcoming/', this.selectedtxDet?.appointmentId]);
    } else if (this.todaydate < dt) {
      this.router.navigate(['/thealth/clinicadmin/appointments/past/', this.selectedtxDet?.appointmentId]);
    } else {
      // this.router.navigate(['/thealth/clinicadmin/appointments/cancelled/',this.selectedtxDet?.appointmentId]);
    }
    // }, 3000);
  }
  createBill() {

    if (this.selectedtxDet) {
      sessionStorage.setItem("SessionselectedTxdet", JSON.stringify(this.selectedtxDet));
      sessionStorage.setItem("appointmentType", this.selectedappointmentType)
      this.router.navigate(['/thealth/clinicadmin/createtransaction/']);

    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Select Appointment Transaction", options);
    }
  }
  relationshiptype: any;

  booksideopen() {
    // this.filteredOptions = null
    this.patientname = ""
    this.filteredOptionssidenav = null
    this._DoctorService.getrelation()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.relationshiptype = res.responseMessage;
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
    this.loadDoctorDateInCalender();
    // this.alreadymemb = false;
    this.Isbookingscreen = true;
    this.Ispaymentscreen = false;
    this.Ispatregscreen = false
    this.consultationTypeText = "";
    this.apptid = ""
    this.successection = false;
    // this.filteredOptions = null;

  }
  booksideclose() {
    this.dropdowmpatientid = ""
    // this.patientname = ""
    // this.filteredOptions = null
    this.bankCtrl.setValue(this.banks['']);
    this.patientnamesidenav = ""
    this.Book_SelectedSpeciality = '';
    this.Book_SelectedDoctor = ""
    this.Book_SelectedDocInfo = '';
    this.selectedconsultationtype = '';
    // this.notwalkin = false;
    this.isConsultaionselected = false;
    this.timeslots.length = 0;
    // this.filteredOptions = null;
    this.consultationTypeText = "";
    this.apptid = ""
    this.successection = false;
    this.SelectedSlotDet = "";
    this.slotimeid = "";
    this.familytype = false;
    this.alreadymemb = false;
    this.regbtn = true;

    this.selectedLocation = ""
    this.slottime = ""
    // this.specialityArray = []
    this.filteredOptionsdoctor = null
    this.consultationTypeArrayBookappointment = []
  }
  cleardata() {
    this.SelectedSlotDet = "";
  }
  cancelbooknow() {
    this.bankCtrl.setValue(this.banks['']);
    this.Book_SelectedSpeciality = '';
    this.Book_SelectedDocInfo = '';
    this.selectedconsultationtype = '';
    // this.notwalkin = false;
    this.isConsultaionselected = false;
    this.timeslots.length = 0;
    this.sidenav.close();
  }
  tx_table_appoinmentstatus
  // update appoinment status
  updateAppointmentstatus(e) {
    this.loading = true;
    this._DoctorService.UpdateAppointmentStatus(this.selectedtxDet.appointmentId, e.value)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;

          let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))

          // no date , no pagination
          if (nInfo?.txformdetails?.withOutdate == true &&
            nInfo?.txformdetails?.withdate == "" &&
            nInfo.paginationClicked == "") {
            this.IsfromTodateEnabled = false;
            // alert("no date , no pagination , reload")
            setTimeout(() => {
              this.loadConsultationTran();
            })
          }

          // no date , with pagination
          if (nInfo?.txformdetails?.withOutdate == true &&
            nInfo?.txformdetails?.withdate == "" &&
            nInfo.paginationClicked == "clicked") {
            this.IsfromTodateEnabled = false;
            // alert("no date , with pagination , reload")
            setTimeout(() => {
              this.loadTranspecificPage();
            })
          }

          // with date, with pagination
          if (nInfo?.txformdetails?.withdate == true &&
            nInfo?.txformdetails?.withOutdate == "" &&
            nInfo?.paginationClicked == "clicked") {
            this.IsfromTodateEnabled = true;
            // alert("with pagination, with date")
            setTimeout(() => {
              this.loadPaginationgetNexttransactionwithdate();
            });
          }

          // with date, no pagination
          if (nInfo?.txformdetails?.withdate == true &&
            nInfo?.txformdetails?.withOutdate == "" &&
            nInfo?.paginationClicked == "") {
            this.IsfromTodateEnabled = true;
            // alert("no pagination, with date")
            setTimeout(() => {
              this.loadgetTransactionlistWithDate();
            });
          }

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      }, () => {

      })
    // AppointmentStatus
  }
  IsloadtranfunctionBoolen: boolean = false;
  IsloadtranfunctionText: any = {};
  IsloadtranfunctionText_withdate: string = "";
  IsloadtranfunctionBoolenWithDate: boolean = false;


  // reload  no date, no pagination
  loadConsultationTran() {

    // pagination track info       
    let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))

    let a = {
      "pageNumber": nInfo?.paginatorinfo?.pageNumber,
      "pageSize": nInfo?.paginatorinfo?.pageSize,
      "totalSize": nInfo?.paginatorinfo?.totalSize,
    }
    let filterdetils = {
      Selectedstartdate: "",
      Selectedenddate: "",
      Selecteddoctor: nInfo?.txformdetails?.Selecteddoctor,
      SelectedCtype: nInfo?.txformdetails?.SelectedCtype,
      withdate: "",
      withOutdate: true,
      billingsearchbox: nInfo?.txformdetails?.billingsearchbox

    }
    let navinfo = {
      paginationClicked: "",
      txformdetails: filterdetils,
      paginatorinfo: a,
    }
    // this.selectedtxDet = this.reloadnavtxdetails;
    this.Selecteddoctordropdown = navinfo?.txformdetails?.Selecteddoctor
    this.Selectedconsultiontype = navinfo?.txformdetails?.SelectedCtype
    this.billingsearchbox = navinfo?.txformdetails?.billingsearchbox

    this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    this.txpaginator.length = navinfo.paginatorinfo.totalSize;

    this.setDefaultLocation();
    this.loading = true;
    this._DoctorService.transactionList(this.Selecteddoctordropdown, this.Selectedconsultiontype, 0, 5, this.billingsearchbox, this.Selectedlocationdropdown)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          for (let i of res.responseMessage) {
            if (i.paymentstatus == 1) {
              i.paymentstatustext = "Payment Received"
            }
            if (i.paymentstatus == 0) {
              i.paymentstatustext = "Payment Not Received"
            }
            i.converteddate = moment(i.appointmentDateTime).format('ll');
            this.current_date = moment(new Date()).format('L');
            this.apt_date = moment(i.appointmentDateTime).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            i.timeFrame = this.timeFrame;
          }
          if (res.responseMessage.length == 0 || res.responseMessage == null) {
            this.filterData = true;
            this.selectedtxDet = '';
            this.appointmentstatus.length = 0;
            this.dataSource = new MatTableDataSource<any>([]);
            this.listdata = true;
          } else {
            this.filterData = false;
            // this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
            // if (this.selectedtxDet.appointmentStatus == "Completed") {
            //   this.tx_table_appoinmentstatus = this.selectedtxDet.appointmentStatusId;
            //   this.Iscompleted = true;
            // } else {
            //   this.Iscompleted = false;
            // }
            this.listdata = false;
          }
          this.transactionlistarray = res.responseMessage;
          this.loading = false;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
          this.obs = this.TransactiondataSource.connect();
          this.txbillSelected_inSpecificpage();
        });
  }


  // reload with date ,no pagination
  loadgetTransactionlistWithDate() {
    // pagination track info       
    let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))

    let a = {
      "pageNumber": nInfo?.paginatorinfo?.pageNumber,
      "pageSize": nInfo?.paginatorinfo?.pageSize,
      "totalSize": nInfo?.paginatorinfo?.totalSize,
    }
    let filterdetils = {
      Selectedstartdate: nInfo?.txformdetails?.Selectedstartdate,
      Selectedenddate: nInfo?.txformdetails?.Selectedenddate,
      Selecteddoctor: nInfo?.txformdetails?.Selecteddoctor,
      SelectedCtype: nInfo?.txformdetails?.SelectedCtype,
      withdate: true,
      withOutdate: "",
      billingsearchbox: nInfo?.txformdetails?.billingsearchbox,
    }
    let navinfo = {
      paginationClicked: "",
      txformdetails: filterdetils,
      paginatorinfo: a,
    }
    // this.selectedtxDet = this.reloadnavtxdetails;

    this.viewTransaction.get('startdate').setValue(navinfo?.txformdetails?.Selectedstartdate);
    this.viewTransaction.get('enddate').setValue(navinfo?.txformdetails?.Selectedenddate);
    this.Selecteddoctordropdown = navinfo?.txformdetails?.Selecteddoctor
    this.Selectedconsultiontype = navinfo?.txformdetails?.SelectedCtype
    this.billingsearchbox = navinfo?.txformdetails?.billingsearchbox

    this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    this.txpaginator.length = navinfo.paginatorinfo.totalSize;

    this.loading = true;
    this.TransactiondataSource = new MatTableDataSource<any>([]);
    this._DoctorService.transactionListwithdate(this.Selecteddoctordropdown, this.viewTransaction.value.startdate, this.viewTransaction.value.enddate, this.Selectedconsultiontype, 0, 5, this.billingsearchbox)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let i of res.responseMessage) {
            if (i.paymentstatus == 1) {
              i.paymentstatustext = "Payment Received"
            }
            if (i.paymentstatus == 0) {
              i.paymentstatustext = "Payment Not Received"
            }
            i.converteddate = moment(i.appointmentDateTime).format('ll');
            this.current_date = moment(new Date()).format('L');
            this.apt_date = moment(i.appointmentDateTime).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            i.timeFrame = this.timeFrame;
          }

          if (res.responseMessage.length == 0) {
            this.filterData = true;
          } else {
            this.filterData = false;
            // if (this.selectedtxDet?.appointmentStatus == "Completed") {
            //   // this.tx_table_appoinmentstatus = this.selectedtxDet?.appointmentStatusId;
            //   this.Iscompleted = true;
            // } else {
            //   this.Iscompleted = false;
            // }
          }
          this.transactionlistarray = res.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
          this.obs = this.TransactiondataSource.connect();
          this.txbillSelected_inSpecificpage();
        });
  }

  // reload with date , with pagination
  loadPaginationgetNexttransactionwithdate() {

    // this.IsfromTodateEnabled = true;
    // pagination track info       
    let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
    let a = {
      "pageNumber": nInfo?.paginatorinfo?.pageNumber,
      "pageSize": nInfo?.paginatorinfo?.pageSize,
      "totalSize": nInfo?.paginatorinfo?.totalSize,
    }
    let filterdetils = {
      Selectedstartdate: nInfo?.txformdetails?.Selectedstartdate,
      Selectedenddate: nInfo?.txformdetails?.Selectedenddate,
      Selecteddoctor: nInfo?.txformdetails?.Selecteddoctor,
      SelectedCtype: nInfo?.txformdetails?.SelectedCtype,
      withdate: true,
      withOutdate: "",
      billingsearchbox: nInfo?.txformdetails?.billingsearchbox,

    }
    let navinfo = {
      paginationClicked: "clicked",
      txformdetails: filterdetils,
      paginatorinfo: a,
    }
    // this.selectedtxDet = this.reloadnavtxdetails;

    this.viewTransaction.get('startdate').setValue(navinfo?.txformdetails?.Selectedstartdate);
    this.viewTransaction.get('enddate').setValue(navinfo?.txformdetails?.Selectedenddate);
    this.Selecteddoctordropdown = navinfo?.txformdetails?.Selecteddoctor
    this.Selectedconsultiontype = navinfo?.txformdetails?.SelectedCtype
    this.billingsearchbox = navinfo?.txformdetails?.billingsearchbox


    this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    this.txpaginator.length = navinfo.paginatorinfo.totalSize;

    this.loading = true;
    this.TransactiondataSource = new MatTableDataSource<any>([]);
    this._DoctorService.transactionListwithdate2(this.Selecteddoctordropdown, this.viewTransaction.value.startdate, this.viewTransaction.value.enddate, this.Selectedconsultiontype, this.txpaginator.pageIndex, this.txpaginator.pageSize, this.billingsearchbox)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let i of res.responseMessage) {
            if (i.paymentstatus == 1) {
              i.paymentstatustext = "Payment Received"
            }
            if (i.paymentstatus == 0) {
              i.paymentstatustext = "Payment Not Received"
            }
            i.converteddate = moment(i.appointmentDateTime).format('ll');
            this.current_date = moment(new Date()).format('L');
            this.apt_date = moment(i.appointmentDateTime).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            i.timeFrame = this.timeFrame;
          }
          if (res.responseMessage.length == 0) {
            this.filterData = true;
          } else {
            this.filterData = false;
          }

          this.transactionlistarray = res.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
          this.obs = this.TransactiondataSource.connect();
          this.txbillSelected_inSpecificpage();
        });
  }


  //load no date,with pagination
  loadTranspecificPage() {
    // pagination track info       
    let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
    let a = {
      "pageNumber": nInfo?.paginatorinfo?.pageNumber,
      "pageSize": nInfo?.paginatorinfo?.pageSize,
      "totalSize": nInfo?.paginatorinfo?.totalSize,
    }
    let filterdetils = {
      Selectedstartdate: "",
      Selectedenddate: "",
      Selecteddoctor: nInfo?.txformdetails?.Selecteddoctor,
      SelectedCtype: nInfo?.txformdetails?.SelectedCtype,
      withdate: "",
      withOutdate: true,
      billingsearchbox: nInfo?.txformdetails?.billingsearchbox
    }
    let navinfo = {
      paginationClicked: "clicked",
      txformdetails: filterdetils,
      paginatorinfo: a,
    }
    // this.selectedtxDet = this.reloadnavtxdetails;

    this.Selecteddoctordropdown = navinfo?.txformdetails?.Selecteddoctor
    this.Selectedconsultiontype = navinfo?.txformdetails?.SelectedCtype
    this.billingsearchbox = navinfo?.txformdetails?.billingsearchbox;


    this.txpaginator.pageIndex = navinfo.paginatorinfo.pageNumber;
    this.txpaginator.pageSize = navinfo.paginatorinfo.pageSize;
    this.txpaginator.length = navinfo.paginatorinfo.totalSize;

    this.setDefaultLocation();
    this.loading = true;
    this._DoctorService.transactionList(this.Selecteddoctordropdown, this.Selectedconsultiontype, this.txpaginator.pageIndex, this.txpaginator.pageSize, this.billingsearchbox, this.Selectedlocationdropdown)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          for (let i of res.responseMessage) {
            if (i.paymentstatus == 1) {
              i.paymentstatustext = "Payment Received"
            }
            if (i.paymentstatus == 0) {
              i.paymentstatustext = "Payment Not Received"
            }
            i.converteddate = moment(i.appointmentDateTime).format('ll');
            this.current_date = moment(new Date()).format('L');
            this.apt_date = moment(i.appointmentDateTime).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            i.timeFrame = this.timeFrame;
          }
          if (res.responseMessage.length == 0 || res.responseMessage == null) {
            this.filterData = true;
            this.appointmentstatus.length = 0;
            this.dataSource = new MatTableDataSource<any>([]);
            this.listdata = true;
          } else {
            this.filterData = false;
            // this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
            // if (this.selectedtxDet?.appointmentStatus == "Completed") {
            //   this.tx_table_appoinmentstatus = this.selectedtxDet?.appointmentStatusId;
            //   this.Iscompleted = true;
            // } else {
            //   this.Iscompleted = false;
            // }
            this.listdata = false;
          }
          this.transactionlistarray = res.responseMessage;
          this.loading = false;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          this.TransactiondataSource = new MatTableDataSource(this.transactionlistarray);
          this.obs = this.TransactiondataSource.connect();

          // loading selected tx bill record
          this.txbillSelected_inSpecificpage();
        });
  }

  // it load tx-bill for specific page selected
  txbillSelected_inSpecificpage() {
    this.dataSource.data = []
    if (this.selectedtxDet?.appointmentId != undefined) {
      this.loading = true;
      this._DoctorService.Getallbills(this.selectedtxDet?.appointmentId)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError && res.responseMessage) {
            this.loading = false;
            this.getallbills = res.responseMessage.billViewModel
            this.remainingamt = res?.responseMessage?.rmvmodels
            this.dataSource = new MatTableDataSource(res.responseMessage.billViewModel);


            this.appointmentstatusdropdown(this.selectedtxDet?.consultationType);
            if (this.selectedtxDet?.appointmentStatus == "Completed") {
              // alert("completed")              
              this.Iscompleted = true;
            } else {
              this.Iscompleted = false;
            }
            this.tx_table_appoinmentstatus = this.selectedtxDet?.appointmentStatusId;


          }
          else {
            this.loading = false;
            this.listdata = true;
            // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            // this.toastrService.warning('', res?.errorMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {
          // setTimeout(() => {
          this.dataSource.paginator = this.tablepaginator;
          // });
          if (this.dataSource?.data?.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
        })
    }
  }


  listdata: boolean = true;
  Getallbills() {
    this.dataSource.data = []
    if (this.selectedtxDet?.appointmentId != undefined) {
      this.loading = true;

      this._DoctorService.Getallbills(this.selectedtxDet?.appointmentId)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError && res.responseMessage) {
            this.loading = false;
            this.getallbills = res.responseMessage.billViewModel;
            this.remainingamt = res?.responseMessage?.rmvmodels
            this.dataSource = new MatTableDataSource(res.responseMessage.billViewModel);
            setTimeout(() => {
              this.dataSource.paginator = this.tablepaginator;
            });
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
          }
          else {
            this.loading = false;
            this.listdata = true;
            // const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            // this.toastrService.warning('', res?.errorMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
    }
  }
  Changedoctor() {
    this.ChangeConsultationTran();
  }
  // AfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  // }
  // hide/ show patient reg screen
  Ispatregscreen: boolean = false;
  Isbookingscreen: boolean = true;
  Ispaymentscreen: boolean = false;
  showpatient() {
    this.patientnamesidenav = ""
    this.Book_SelectedSpeciality = ""
    this.Book_SelectedDoctor = ""
    this.selectedconsultationtype = ""
    this.SelectedSlotDet = ""
    this.timeslots = []
    this.selectedLocation = ""
    this.slottime = ""
    this.slotimeid = ""
    this.isConsultaionselected = false
    this.specialityArray = []
    this.filteredOptionsdoctor = null
    this.consultationTypeArrayBookappointment = []


    this.Ispatregscreen = true;
    this.Isbookingscreen = false;
    this.Ispaymentscreen = false;
    this.createpatProfile.reset();
  }
  cancelpatient() {
    this.regbtn = true;
    this.Ispatregscreen = false;
    this.Isbookingscreen = true;
    this.alreadymemb = false;
    this.familytype = false;
    this.resetall();
  }

  // IsEditpopup: boolean = false;
  editPopup(data) {
    this.selectedtxDet['bill_appointment_map_id'] = data.bamid;
    sessionStorage.setItem("SessionselectedTxdet", JSON.stringify(this.selectedtxDet));
    this.router.navigate(['/thealth/clinicadmin/createtransaction/', data.bamid]);

  }

  paypopup(ele) {
    this.payform.reset();
    this.payform.get('amount').setValue(ele?.amountPayable);

    for (let i of this.getallbills) {
      if (i.bamid !== ele.bamid) {
        i.IsPaypopup = false;
      }
      else {
        i.IsPaypopup = !i.IsPaypopup;
      }
    }
    this.billapptid = ele.bamid;
    this.paytypelist()
  }


  cancelPayPopup(ele) {
    ele.IsPaypopup = false;
  }

  paytypelist() {
    this.loading = true;
    this._patientservice.paymentypelist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.paylist = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  submitpaypopup(ele) {
    if (this.payform.value.paymenttype == '' || this.payform.value.paymenttype == null ||
      this.payform.value.amount == '' || this.payform.value.amount == null) {

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill payment type and amount', options);
      this.loading = false;
      return;
    }
    else {

      if (this.payform.value.paymenttype == null) {
        this.payform.value.paymenttype = ""
      }
      if (this.payform.value.amount == null) {
        this.payform.value.amount = "";
      }
      if (this.payform.value.transactionid == null) {
        this.payform.value.transactionid = "";
      }
      this.loading = true;
      this._patientservice.paysubmit(this.payform.value, this.billapptid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.payform.reset();
            let nInfo = JSON.parse(sessionStorage.getItem("navInfo"))
            // no date , no pagination
            if (nInfo?.txformdetails?.withOutdate == true &&
              nInfo?.txformdetails?.withdate == "" &&
              nInfo.paginationClicked == "") {
              this.IsfromTodateEnabled = false;
              // alert("no date , no pagination , reload")
              setTimeout(() => {
                this.loadConsultationTran();
              })
            }

            // no date , with pagination
            if (nInfo?.txformdetails?.withOutdate == true &&
              nInfo?.txformdetails?.withdate == "" &&
              nInfo.paginationClicked == "clicked") {
              this.IsfromTodateEnabled = false;
              // alert("no date , with pagination , reload")
              setTimeout(() => {
                this.loadTranspecificPage();
              })
            }

            // with date, with pagination
            if (nInfo?.txformdetails?.withdate == true &&
              nInfo?.txformdetails?.withOutdate == "" &&
              nInfo?.paginationClicked == "clicked") {
              this.IsfromTodateEnabled = true;
              // alert("with pagination, with date")
              setTimeout(() => {
                this.loadPaginationgetNexttransactionwithdate();
              });
            }

            // with date, no pagination
            if (nInfo?.txformdetails?.withdate == true &&
              nInfo?.txformdetails?.withOutdate == "" &&
              nInfo?.paginationClicked == "") {
              this.IsfromTodateEnabled = true;
              // alert("no pagination, with date")
              setTimeout(() => {
                this.loadgetTransactionlistWithDate();
              });
            }

            let aptType = JSON.parse(sessionStorage.getItem("appointmentType"))
            // console.log(aptType)
            if (aptType == 2) {
              this.ngOnInit()
              // setTimeout(() => {
              // this.Getallbills()
              // },2500);
            }

            // this.ChangeConsultationTran();
            // this.Getallbills()
            ele.IsPaypopup = false;
            // this.codeslist();
            // this.formDirective.resetForm();
            // this.codesform.reset()
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
          }
          else {
            this.loading = false;
            ele.IsPaypopup = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            ele.IsPaypopup = false;
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }


  ngAfterViewInit() {
    this.setInitialValue();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();

  }

  /**
   * Sets the initial value after the filteredBanks are loaded initially
   */
  protected setInitialValue() {
    this.filteredBanks
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.singleSelect.compareWith = (a: Bank, b: Bank) => a && b && a.patientid === b.patientid;
      });
  }

  protected filterBanks() {
    if (!this.banks) {
      return;
    }
    // get the search keyword
    let search = this.bankFilterCtrl.value;
    if (!search) {
      this.filteredBanks.next(this.banks.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanks.next(
      this.banks.filter(bank => bank.name.toLowerCase().indexOf(search) > -1)
    );
  }

  apptstatus: apptstatus[] = [
    { value: 'checked-in', viewValue: 'Checked-in' },
    { value: 'delayed', viewValue: 'Delayed' },
    { value: 'emergency', viewValue: 'Emergency' },
    { value: 'visit completed', viewValue: 'Visit Completed' }
  ];

  // side window code starts
  // allow only number
  validateNumber(event) {
    const keyCode = event.keyCode;
    const excludedKeys = [8, 37, 39, 46];
    if (!((keyCode >= 48 && keyCode <= 57) ||
      // keyCode > 31 && (keyCode < 48 || keyCode > 57) ||
      // (keyCode >= 96 && keyCode <= 105)  && ((keyCode > 64 && keyCode < 91) || (keyCode > 96 && keyCode < 123) || keyCode == 8 || keyCode == 32 || (keyCode >= 48 && keyCode <= 57)) ||
      (excludedKeys.includes(keyCode)))) {
      event.preventDefault();
    }
  }

  resetall() {
    this.bankCtrl.setValue(this.banks['']);
    this.Book_SelectedSpeciality = '';
    this.Book_SelectedDocInfo = '';
    this.selectedconsultationtype = '';
    // this.notwalkin = false;
    this.isConsultaionselected = false;
    this.timeslots.length = 0;
    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: [''],
      aadharno: [''],
      patientclinicidentifier: ['', Validators.required],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });
  }
  // generate password 
  passwordLenght: any = 8;
  passwordPattern: any;
  generatePassword(e) {
    if (e.checked == true) {
      this.passwordPattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,./;'[]\=-)(*&^%$#@!~`";
      this.passwordLenght = 8;
      let text = "";
      for (let i = 0; i < this.passwordLenght; i++) {
        text += this.passwordPattern.charAt(Math.floor(Math.random() * this.passwordPattern.length));
      }
      let Password = text;
      this.createpatProfile.get('password').setValue(Password);
    } else if (e.checked == false) {
      this.createpatProfile.get('password').setValue('');
    }
  }
  // clear patient form 
  clearreg() {
    this.createpatProfile = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      gender: [''],
      age: [''],
      aadharno: [''],
      patientclinicidentifier: ['', Validators.required],
      phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]],
      email: ['', [Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });
  }
  // patient reg
  firstname: any;
  clinicpatid: any;
  patregister() {
    this.loading = true;
    if (this.createpatProfile?.value.firstname.trim() == '' || this.createpatProfile?.value.firstname.trim() == null ||
      this.createpatProfile?.value.phoneno == '' || this.createpatProfile?.value.phoneno == null ||
      this.createpatProfile?.value.password == '' || this.createpatProfile?.value.password == null ||
      this.createpatProfile?.value.patientclinicidentifier.trim() == '' || this.createpatProfile?.value.patientclinicidentifier.trim() == null) {

      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
      return;
    }
    else {

      if (this.createpatProfile?.value?.email && this.createpatProfile?.value?.email != "") {
        this.loading = true;
        const roleid = 3;
        this.patientfirstname = this.createpatProfile.value.firstname
        this.patientlastname = this.createpatProfile.value.lastname
        this.patientphoneno = this.createpatProfile.value.phoneno

        this.patientnamesidenav = this.createpatProfile.value.firstname + " " + (this.createpatProfile.value.lastname == null || this.createpatProfile.value.lastname == '' ? '' : ('-' + this.createpatProfile.value.lastname)) + '-' + this.createpatProfile.value.patientclinicidentifier

        // this.patientnamesidenav = this.createpatProfile.value.firstname
        let name = this.createpatProfile.value.firstname + " " + (this.createpatProfile.value.lastname == null || this.createpatProfile.value.lastname == '' ? '' : (this.createpatProfile.value.lastname))

        this.firstname = name
        this.clinicpatid = this.createpatProfile?.value.patientclinicidentifier

        this.getinput = { fname: name, clinicpatid: this.createpatProfile?.value.patientclinicidentifier }

        this.getpatientbyregisterpatient(name)
        // this.getpatientbyregisterpatient(this.createpatProfile.value.firstname + " " + this.createpatProfile.value.lastname)

        this.authenticationService.register(this.createpatProfile.value, roleid)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              // this.createpatProfile.reset();
              this.clearreg();
              // this.getpatientslist()

              this.patclicked = {
                patfname: this.patientfirstname,
                patlname: this.patientlastname,
                patmobno: this.patientphoneno
              }

              this.Ispatregscreen = false;
              this.Isbookingscreen = true;
              // this.sidenav.close();
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            })
      }
      else {
        this.patientfirstname = this.createpatProfile.value.firstname
        this.patientlastname = this.createpatProfile.value.lastname
        this.patientphoneno = this.createpatProfile.value.phoneno


        this.patientnamesidenav = this.createpatProfile.value.firstname + " " + (this.createpatProfile.value.lastname == null || this.createpatProfile.value.lastname == '' ? '' : (this.createpatProfile.value.lastname)) + '-' + this.createpatProfile.value.patientclinicidentifier

        // this.patientnamesidenav = this.createpatProfile.value.firstname + " " + this.createpatProfile.value.lastname + "-" + this.createpatProfile.value.patientclinicidentifier
        // this.getpatientbyregisterpatient(this.createpatProfile.value.firstname)
        let name = this.createpatProfile.value.firstname + " " + (this.createpatProfile.value.lastname == null || this.createpatProfile.value.lastname == '' ? '' : (this.createpatProfile.value.lastname))
        this.getpatientbyregisterpatient(name)
        this.getinput = { fname: name, clinicpatid: this.createpatProfile?.value.patientclinicidentifier }


        this.loading = true;
        const roleid = 3;
        let payload = {
          "FirstName": this.createpatProfile.value.firstname == null ? "" : String(this.createpatProfile.value.firstname),
          "LastName": this.createpatProfile.value.lastname == null ? "" : String(this.createpatProfile.value.lastname),
          "Password": this.createpatProfile.value.password == null ? "" : String(this.createpatProfile.value.password),
          "MobileNumber": this.createpatProfile.value.phoneno == null ? "" : String(this.createpatProfile.value.phoneno),
          "RoleId": roleid,
          "Aadhaarnumber": this.createpatProfile.value.aadharno == null ? "" : String(this.createpatProfile.value.aadharno),
          "ClinicPatientId": this.createpatProfile.value.patientclinicidentifier,
          "Age": this.createpatProfile.value.age

        }
        // return;
        this.authenticationService.RegisterWithMobileNumber(payload)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              // setTimeout(() => this.formGroupDirective.resetForm(), 0);
              // this.createpatProfile.reset();
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              this.clearreg();
              // this.getpatientslist()

              this.patclicked = {
                patfname: this.patientfirstname,
                patlname: this.patientlastname,
                patmobno: this.patientphoneno
              }
              this.Ispatregscreen = false;
              this.Isbookingscreen = true;
            } else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            })
      }
    }
  }
  familytype: boolean = false;
  alreadymemb: boolean = false;
  patid: any;
  listdata2: boolean;
  dataSource2 = new MatTableDataSource([]);
  resp: any;
  regbtn: boolean = true;
  @ViewChild('uploadResultPaginator', { read: MatPaginator }) uploadResultPaginator: MatPaginator;

  // mobile numbr checks patient
  onFocusOutEvent(event: any) {
    if (event.target.value == '') {
      // alert('empty');
    }
    else {
      // alert('hi');
      this.loading = true;
      this.dataSource2 = new MatTableDataSource([]);
      this.authenticationService.patdetailsbymobno(event.target.value)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          if (!res.isError) {
            if (res.responseMessage == null) {
              this.familytype = false;
              this.alreadymemb = false
              this.regbtn = true;
            }
            else {
              this.resp = res.responseMessage;
              if (this.resp.mobile == this.createpatProfile?.value.phoneno) {
                this.familytype = true;
                this.regbtn = false;
                this.patid = this.resp.patientId;
                setTimeout(() => {
                  document.getElementById("checkscroll").scrollIntoView({ behavior: 'smooth', block: "end" });
                })
                this.dataSource2 = new MatTableDataSource(res.responseMessage.patientFamilyMemberDetails);
                setTimeout(() => {
                  this.dataSource2.paginator = this.uploadResultPaginator;
                });
                if (res.responseMessage.patientFamilyMemberDetails === null || res.responseMessage.patientFamilyMemberDetails.length === 0) {
                  this.alreadymemb = false;
                }
                else {
                  this.alreadymemb = true;
                }
              }
            }

            this.loading = false;
          } else {
            this.loading = false;
            this.familytype = false;
            this.alreadymemb = false
            this.regbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.responseData, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }
  patfamtype() {

    this.loading = true;
    if (this.createpatProfile?.value.firstname == '' || this.createpatProfile?.value.firstname == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill First name', options);
      this.loading = false;
      return;
    }
    if (this.createfamiltype?.value.relationtype == '' || this.createfamiltype?.value.relationtype == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill Relation Type', options);
      this.loading = false;
      return;
    }
    if (this.createpatProfile?.value.patientclinicidentifier == '' || this.createpatProfile?.value.patientclinicidentifier == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please Fill Clinic Patient ID', options);
      this.loading = false;
      return;
    }
    else {
      this.loading = true;
      if (!this.createpatProfile?.value.age) {
        this.createpatProfile.get('age').setValue("");
      }
      if (!this.createpatProfile?.value.lastname) {
        this.createpatProfile.get('lastname').setValue("");
      }

      if (!this.createpatProfile?.value.aadharno) {
        this.createpatProfile.get('aadharno').setValue("");
      }

      if (!this.createpatProfile?.value.firstname) {
        this.createpatProfile.get('firstname').setValue("");
      }
      if (!this.createpatProfile?.value.gender) {
        this.createpatProfile.get('gender').setValue("");
      }

      let payload = {
        "FirstName": String(this.createpatProfile?.value.firstname),
        "LastName": String(this.createpatProfile?.value.lastname),
        "RelationType": String(this.createfamiltype?.value.relationtype),
        "Profile": '',
        "PatientId": String(this.patid),
        "GenderName": String(this.createpatProfile?.value.gender),
        "Age": String(this.createpatProfile?.value.age),
        "Aadhaarnumber": String(this.createpatProfile?.value.aadharno),
        "ClinicPatientId": this.createpatProfile?.value.patientclinicidentifier
      }

      const roleid = 3;
      this._DoctorService.famtype(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.alreadymemberslist(payload.PatientId);
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.sidenav.close();
            this.ngOnInit()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            for (var prop in err.error) {
              this.toastrService.warning('', err?.error[prop], options);
            }
          })
    }
  }
  displayedColumns2: string[] = ['name', 'patientid', 'relationtype'];

  alreadymemberslist(pid) {
    this.loading = true;
    this.dataSource2 = new MatTableDataSource([]);
    this.loading = true;
    this._DoctorService.alreadymemlist(pid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.dataSource2 = new MatTableDataSource(res.responseMessage);
          this.dataSource2.paginator = this.uploadResultPaginator;
          // setTimeout(() => {
          // });
          if (res.responseMessage === null || res.responseMessage.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
          }
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }
  // loads speciality
  speciality() {
    this.loading = true;
    this._patientservice.specialitylist(this.clinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.specialityArray = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }
  // loads doctors
  // doctorslist() {
  //   this.loading = true;
  //   this._patientservice.doctorlist(this.clinicId)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.loading = false;
  //         this.filteredOptions = res.responseMessage;
  //       }
  //       else {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //       }
  //     },
  //       err => {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //       })
  // }
  // load doctor based on speciality
  Book_SelectedSpeciality;
  loaddoctorbasedonSpeciality() {
    this.selectedconsultationtype = ""
    this.selectedLocation = ""
    this.timeslots = []
    // clear previously booked appointment details if any
    this.blckbtn = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.cashpaymentform = false;
    this.freeapptform = false;
    this.insuranceform = false;
    this.cardpaymentform = false;
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.isActive('');
    this.isConsultaionselected = false;
    this.consultationTypeArrayBookappointment = []
    // ---------------------------   


    this.loading = true;
    let payload = {
      "SpecialityId": this.Book_SelectedSpeciality
    }
    this._patientservice.clinicadminDocfilterByspecility(payload)
      .pipe(first())

      // this._patientservice.doctoravailableWithSpecialityWithoutDate(payload)
      .subscribe((res: any) => {
        console.log("fefeefefefeef")
        if (!res.isError) {
          this.loading = false;
          this.filteredOptionsdoctor = res.responseMessage.doctors;
          this.Book_SelectedDocInfo = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {

        })
  }
  // load consultation type for book appointment screen

  Bookapp_consultationType() {
    this.loading = true;
    this.consultationTypeArrayBookappointment.length = 0;
    this.consultationTypeArrayBookappointmentArray.length = 0;
    // this._patientservice.getpaymentType()
    this.loading = true;
    this._patientservice.ClinicadminGetconsultationslots(this.Book_SelectedDocInfo?.doctorId)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.consultationTypeArrayBookappointmentArray = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {


          this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
            if (docContype?.status == 1) {
              docContype.loccm.map((data) => {
                if (data.isConsultationCodeMapped == true) {
                  this.isCodemap = true
                }

                if (data.isConsultationCodeMapped == true) {
                  if (data.isConsultationCodeMapped == true && data.defaultlocation == true) {
                    this.selectedLocation = data.clinicLocationMapId;
                  }
                }
                if (data.isConsultationCodeMapped == false && data.defaultlocation == false) {
                  this.selectedLocation = data.clinicLocationMapId;
                }
              })

              this.locationData = docContype.loccm;
            }
          })

          let CodemappedTrueArray = this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
            if (docContype?.status == 1) {
              return this.consultationTypeArrayBookappointmentArray.some(allContype => this.isCodemap == true && docContype.status == 1)
            }
          });

          let tempArray = [];
          for (let it of this.consultationTypeArrayBookappointmentArray) {
            CodemappedTrueArray.filter(i => {
              if (it?.consultationTypeId == i.typeId) {
                tempArray.push(it)
              }
            })
          }

          let array = tempArray;
          var unique = [];
          var distinct = [];
          for (let i = 0; i < array.length; i++) {
            if (!unique[array[i].consultationTypeId]) {
              distinct.push(array[i]);
              unique[array[i].consultationTypeId] = 1;
            }
          }

          this.consultationTypeArrayBookappointment = distinct;

          // if multiple type have na
          if (this.consultationTypeArrayBookappointment.length > 1) {
            if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
              this.isConsultaionselected = true;
            } else {
              this.isConsultaionselected = false;
            }
          } else {
            if (this.consultationTypeArrayBookappointment.length == 1) {
              this.selectedconsultationtype = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;

              if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
                this.isConsultaionselected = true;
              } else {
                this.isConsultaionselected = false;
              }

              // if only one type , it will selected that type by default

              //this.userSelectedconsultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
              // this.radioChangeForSingletype();
            }
          }

          //  console.log('type details', this.selectedLocation, this.selectedconsultationtype)
          this.loadDatesinCal();
        })
  }

  // hide/show consultation type change

  Changeconsultiontype() {
    this.SelectedSlotDet = ""
    this.slottime = ""
    this.slotimeid = ""
    this.timeslots = [];
    this.timeslots.length = 0;
    this.selectedDate = this.walkin_appoinmentdate;

    //  this.consultationTypeArrayBookappointment.map((data)=>{
    //   if(data.consultationTypeId == this.selectedconsultationtype){
    //    this.locationData = data.loccm;
    //  if(data.loccm.length >0){
    //   data.loccm.map((locdata) =>{
    //    if(locdata.defaultlocation == true){
    //    this.selectedLocation = locdata.clinicLocationMapId
    //}
    //})
    //}
    // }
    //})

    this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
      if (docContype?.status == 1) {
        docContype.loccm.map((data) => {
          if (this.selectedconsultationtype == docContype.typeId) {
            if (data.isConsultationCodeMapped == true) {

              if (data.isConsultationCodeMapped == true && data.defaultlocation == true) {
                return this.selectedLocation = data.clinicLocationMapId;
              }
            } else {
              return this.selectedLocation = data.clinicLocationMapId;
            }

          }
        })

        this.locationData = docContype.loccm;
      }
    })

    if (this.selectedconsultationtype != 102) {
      // walk in  selected na
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
      this.NextPreviousslots();
      // selecting today date in calender
      this.myHolidayFilter = (d: Date): any => {
        return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
      }
      this.selectedDate = this.walkin_appoinmentdate
      this.getBookingslots(this.walkin_appoinmentdate);
      this.getslots(this.walkin_appoinmentdate)
      // this.cleardata();      
    } else {
      // walk in not selected
      // this.notwalkin = true;
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
      this.loadmyDate();
      this.checkprofile();
    }
    // this.loadcalenderDates();

    if (this.selectedconsultationtype) {
      this.isConsultaionselected = true;
    } else {
      this.isConsultaionselected = false;
    }

  }

  onclickbacktodatechange() {
    this.Isbookingscreen = true;
    this.Ispaymentscreen = false;
    this.cashpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
    this.insuranceform = false;
    this.NextPreviousslots();
    this.freeapptform = false;
    this.cardpaymentform = false;
  }

  // changedoctor
  Book_SelectedDoctor
  Book_SelectedDocInfo;

  ChangeDoctorBookappointment() {
    this.selectedconsultationtype = ""
    this.SelectedSlotDet = ""
    this.timeslots = []
    this.selectedLocation = ""
    this.slottime = ""
    this.slotimeid = ""
    this.SelectedSlotDet = ""
    this.timeslots.length = 0;
    this.Book_SelectedDocInfo = this.Book_SelectedDoctor;
    this.loading = true;
    // load consulatation type for book appoinment screen
    this.Bookapp_consultationType();

    // load payment  for book appoinment screen
    this.loadpaymentmethods()


    this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
      if (docContype?.status == 1) {
        docContype.loccm.map((data) => {
          if (data.isConsultationCodeMapped == true) {
            this.isCodemap = true
          }

          if (data.isConsultationCodeMapped == true) {
            if (data.isConsultationCodeMapped == true && data.defaultlocation == true) {
              this.selectedLocation = data.clinicLocationMapId;
            }
          }
          if (data.isConsultationCodeMapped == false && data.defaultlocation == false) {
            this.selectedLocation = data.clinicLocationMapId;
          }
        })

        this.locationData = docContype.loccm;
      }
    })

    let CodemappedTrueArray = this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
      if (docContype?.status == 1) {
        return this.consultationTypeArrayBookappointmentArray.some(allContype => this.isCodemap == true && docContype.status == 1)
      }
    });

    let tempArray = [];
    for (let it of this.consultationTypeArrayBookappointmentArray) {
      CodemappedTrueArray.filter(i => {
        if (it?.consultationTypeId == i.typeId) {
          tempArray.push(it)
        }
      })
    }

    let array = tempArray;
    var unique = [];
    var distinct = [];
    for (let i = 0; i < array.length; i++) {
      if (!unique[array[i].consultationTypeId]) {
        distinct.push(array[i]);
        unique[array[i].consultationTypeId] = 1;
      }
    }

    this.consultationTypeArrayBookappointment = distinct;

    // if multiple type have na
    if (this.consultationTypeArrayBookappointment.length > 1) {
      if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
        this.isConsultaionselected = true;
      } else {
        this.isConsultaionselected = false;
      }
    } else {
      if (this.consultationTypeArrayBookappointment.length == 1) {
        if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
          this.isConsultaionselected = true;
        } else {
          this.isConsultaionselected = false;
        }

        // if only one type , it will selected that type by default
        this.selectedconsultationtype = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;

        //this.userSelectedconsultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
        // this.radioChangeForSingletype();
      }
    }


  }

  loadDoctorDateInCalender() {
    if (this.selectedconsultationtype != 102) {
      this.NextPreviousslots()
      // this.bookappointmentDet = doctor;
      if (this.Book_SelectedDocInfo.slotModel != null) {
        let f = new Date(this.Book_SelectedDocInfo.slotModel.slotTime.substr(0, 10));
        let a = moment(f, "MM/DD/YYYY");
        setTimeout(() => {
          this.calendar?._goToDateInView(a, 'month');
        });
        setTimeout(() => {
          this.getBookingslots(this.Book_SelectedDocInfo.slotModel.slotTime);
        })
      }

    }


  }

  // it loads slot model dates depends on api response
  getBookingslots(a) {
    this.loading = true;
    var myarray = [];
    // To make the slot date as selected;
    this.myHolidayFilter = (d: Date): any => {
      if (a) {
        if (moment(d).format('YYYY-MM-DD') >= moment(a).format('YYYY-MM-DD')) {
          myarray.push(moment(d).format('YYYY-MM-DD'));
        }
      } else {
        myarray.push(moment(d).format('YYYY-MM-DD'));
      }
    }

    setTimeout(() => {
      this.loading = true;
      let payload = {
        StartDate: myarray[0],
        EndDate: myarray[myarray.length - 1],
        ClinicId: this.Book_SelectedDocInfo.clinicId,
        DoctorId: this.Book_SelectedDocInfo.doctorId,
        // ConsultationType: this.selectedconsultationtype
        CliniclocMapid: this.selectedLocation
      }

      this._patientservice.getdateslot(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.myHolidayDates = res?.responseMessage[0]?.slotDates;
            this.myHolidayFilter = (d: Date): any => {
              return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
            }
            this.defaultSelectedSlots()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          })
    });
  }


  //default selected slots
  defaultSelectedSlots() {
    if (this.selectedconsultationtype == 102) {
      this.getslots(moment(new Date()).format('YYYY-MM-DD'))
      this.selectedDate = moment(new Date()).format('YYYY-MM-DD')
      return;
    }

    if (this.selectedconsultationtype != 102) {
      this.getslots(moment(this.myHolidayDates[0]).format('YYYY-MM-DD'))
      this.selectedDate = moment(this.myHolidayDates[0]).format('YYYY-MM-DD')
      return;
    }

  }
  disableSubmit: boolean = false;
  amountValidation(event, element) {
    if (event <= element.amountPayable) {
      this.disableSubmit = false;
    } else {
      this.disableSubmit = true;
    }
    // if(event > element?.amountPayable){
    //   return this.disableSubmit = true;
    // }else{
    //   return this.disableSubmit = false;
    // }
  }

  // get slots
  getslots(e) {
    this.slottime = ""
    this.slotimeid = ""
    this.SelectedSlotDet = ""
    this.timeslots.length = 0;
    this.loading = true;
    this.locationDate = moment(e).format('YYYY-MM-DD');
    this._patientservice.timeslot(this.Book_SelectedDocInfo.doctorId, moment(e).format('YYYY-MM-DD'), this.selectedconsultationtype, this.selectedLocation)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;

          if (this.selectedconsultationtype != 102) {
            this.timeslots = res.responseMessage;

            if (res.responseMessage.length == 0) {
              this.Noslotmsg = true;
            } else {
              this.Noslotmsg = false;
            }
          } else {
            this.timeslots = [];
            this.Noslotmsg = true;
          }
        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      });
  }

  // selected slot 
  slotid(sltId, time, data) {
    this.slottime = time;
    this.slotimeid = sltId;
    this.SelectedSlotDet = data
    this.showmsg = false;
  }
  // slots button enable/disable
  isActive(sltId) {
    return this.slotimeid === sltId;
  };
  isactiveapptlist(iapt) {
    return this.selectedtxDet?.appointmentId === iapt?.appointmentId;
  }

  // previous / next button in calender
  NextPreviousslots() {
    if (this.selectedconsultationtype != 102) {
      setTimeout(() => {
        let myarray = [];
        const prev = document.querySelector('.mat-calendar-previous-button');
        const next = document.querySelector('.mat-calendar-next-button');
        prev.addEventListener('click', () => { // Previous Button
          myarray.length = 0;
          this.myHolidayFilter = (d: Date): any => {
            myarray.push(moment(d).format('YYYY-MM-DD'))
          }
          setTimeout(() => {
            this.slotimeid = "";
            this.loading = true;
            let payload = {
              StartDate: myarray[0],
              EndDate: myarray[myarray.length - 1],
              ClinicId: this.Book_SelectedDocInfo.clinicId,
              DoctorId: this.Book_SelectedDocInfo.doctorId,
              //ConsultationType: this.selectedconsultationtype
              CliniclocMapid: this.selectedLocation
            }
            this._patientservice.getdateslot(payload)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  this.loading = false;
                  this.myHolidayDates = res?.responseMessage[0]?.slotDates;
                  this.myHolidayFilter = (d: Date): any => {
                    return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
                  }
                }
                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err.error, options);
                })

          });

        });
        next.addEventListener('click', () => { // Next Button
          myarray.length = 0;
          this.myHolidayFilter = (d: Date): any => {
            myarray.push(moment(d).format('YYYY-MM-DD'))
          }
          setTimeout(() => {
            this.slotimeid = "";
            this.loading = true;
            let payload = {
              StartDate: myarray[0],
              EndDate: myarray[myarray.length - 1],
              ClinicId: this.Book_SelectedDocInfo.clinicId,
              DoctorId: this.Book_SelectedDocInfo.doctorId,
              // ConsultationType: this.selectedconsultationtype
              CliniclocMapid: this.selectedLocation
            }

            this._patientservice.getdateslot(payload)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  this.loading = false;
                  this.myHolidayDates = res?.responseMessage[0]?.slotDates;
                  this.myHolidayFilter = (d: Date): any => {
                    return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
                  }
                }
                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
                }
              },
                err => {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err.error, options);
                })

          });
        });

      }, 150);
    }
  }

  // pay 
  // paymentUpdate() {
  //   console.log(this.payUpdateform.value)
  //   this.IsEditpopup = false;
  // }

  // book now
  // Isbookingscreen: boolean = true;
  // Ispaymentscreen: boolean = false;
  BookNow() {
    console.log("?gbrggrgrgrgg")

    if (this.patientControlsidenav.value !== "") {
      console.log("enter")
      console.log("this.dropdowmpatientid =======" + this.dropdowmpatientid)
      // walkin
      if (this.selectedconsultationtype == 102) {
        console.log("enterwalkin")

        if (this.Book_SelectedSpeciality &&
          this.Book_SelectedDocInfo &&
          this.selectedconsultationtype) {
          console.log("func01")

          if (this.dropdowmpatientid == undefined) {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Please select patient name", options);
          } else {
            console.log("func-on")

            this.Ispaymentscreen = true;
            this.Isbookingscreen = false;
            this.datechange = false;

            this.checkprofile()
          }


        }

        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please enter all the fields", options);
          this.loading = false;
          return;
        }

      } else {
        // not walk in
        console.log("not walk in")

        if (this.Book_SelectedSpeciality &&
          this.Book_SelectedDocInfo &&
          this.selectedconsultationtype &&
          this.SelectedSlotDet) {
          console.log("func02")


          if (this.dropdowmpatientid == undefined) {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Please select patient name", options);
          } else {
            console.log("func-on2")

            this.Ispaymentscreen = true;
            this.Isbookingscreen = false;
            this.datechange = true;
            this.checkprofile()
          }

        }

        else {
          console.log("validation")

          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please enter all the fields", options);
          this.loading = false;
          return;
        }
      }
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select patient name", options);
    }


    // walk in 

  }

  // PaymentScreen_CancelPay
  PaymentScreen_CancelPay() {
    this.IsBookPayment = false;
    this.Ispaymentscreen = false;
    this.Isbookingscreen = true;
  }
  paymethodlist: any = [];
  newArray: any = [];
  availablepaymethods: any;
  methodtype: any;
  cashpaymentform: boolean;
  cardpaymentform: boolean;
  freeapptform: boolean;
  insuranceform: boolean;
  imgfile: any;

  loadpaymentmethods() {
    this.loading = true;
    if (this.Book_SelectedDocInfo) {
      this.paymethodlist = [];
      this.availablepaymethods = [];
      this.newArray = [];
      this._patientservice.loadpaymentmethods()
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.paymethodlist = res.responseMessage;
            this._patientservice.activeclinicpayment(this.Book_SelectedDocInfo?.clinicId)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  if (this.selectedconsultationtype == 2) {
                    this.availablepaymethods = res.responseMessage.clinicVisitPaymentDetails;
                  } else {
                    this.availablepaymethods = res.responseMessage.onlinePaymentDetails;
                  }
                  // this.availablepaymethods = res.responseMessage.paymentDetails;
                  for (let i = 0; i < this.paymethodlist.length; i++) {
                    var ismatch = false;
                    for (let j = 0; j < this.availablepaymethods.length; j++) {
                      if (this.paymethodlist[i].paymentMethodId == this.availablepaymethods[j].paymentMethodId) {
                        ismatch = true;
                        this.paymethodlist[i].showDateInput = false;
                        this.newArray.push(this.paymethodlist[i]);
                        break;
                      }
                    }
                    if (!ismatch) {
                      this.paymethodlist[i].showDateInput = true;
                      this.paymethodlist[i].mychecked2 = false;
                      this.newArray.push(this.paymethodlist[i]);
                    }

                    //End if
                  }
                } else {
                }
              },
                err => {
                });
          } else {
          }
        },
          err => {
          });
    }
  }
  // hide/show insurance option

  onItemChange(paymethod) {
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.methodtype = paymethod.paymentMethodReferenceName;

    if (paymethod.paymentMethodReferenceName === 'razorpay') {
      this.cashpaymentform = false;
      this.cardpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'cash') {
      this.cardpaymentform = false;
      this.cashpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'free_service') {
      this.freeapptform = true;
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.insuranceform = false;
    }
    else {
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.freeapptform = false;
      this.insuranceform = true;
    }
  }

  isActivePaymentScreen(item) {
    return this.methodtype === item.paymentMethodReferenceName;
  }
  listinsuranceproviderArray: any = [];
  listInsuranceProvider() {
    this.loading = true;
    this._patientservice.getInsturanceProvider()
      .pipe(first())
      .subscribe((res: any) => {
        this.loading = false;
        this.listinsuranceproviderArray = res.responseMessage
      }, err => {
      })
  }

  // file upload for insurance
  filevalidation: boolean;
  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    this.imgfile = event.target.files[0];
    this.filevalidation = false;
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
      }
    }
  }

  pay_id: any;
  ord_id: any;
  sign: any;
  pat_id: string;
  consultationTypeText
  consFess: number;
  docid: any;
  cliname: any;
  specid: any;
  stdate: string;
  mobilenumber: any;
  resposnsedata: any;
  apptid: any;
  sloterrormsg: boolean;
  successection: boolean = false;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  displayinfo: any;
  displaytext = "";

  submitappointment(paytype) {
    // debugger;
    this.blckbtn = true;
    console.log("conformclick")
    if (this.selectedconsultationtype == 1) {
      this.consultationTypeText = 'online';
      this.displaytext = 'Video Consultation';
      this.consFess = this.Book_SelectedDocInfo.fees.domesticConsultation;
    }

    if (this.selectedconsultationtype == 102) {
      this.Book_SelectedDocInfo?.fees?.wfList.map((cwdata) => {
        if (cwdata.cliniclocationmapId == this.selectedLocation) {
          this.consFess = cwdata.walkinfee;
          this.consultationTypeText = 'walk_in';
          this.displaytext = 'Walk in';
        }
      })
    }
    if (this.selectedconsultationtype == 2) {
      this.Book_SelectedDocInfo?.fees?.cvfList.map((cvdata) => {
        if (cvdata.cliniclocationmapId == this.selectedLocation) {
          this.consultationTypeText = 'visit_to_clinic';
          this.displaytext = 'Clinic Visit';
          this.consFess = cvdata.clinicVisitFee;
        }
      })
    }

    this.docid = this.Book_SelectedDocInfo?.doctorId;
    this.cliname = this.Book_SelectedDocInfo?.clinicName;
    this.specid = this.Book_SelectedDocInfo?.specialityId;
    this.stdate = this.SelectedSlotDet?.slotTime;
    this.mobilenumber = this.bankCtrl?.value?.phoneNumber;

    let meta = this;
    // debugger;
    // insurance ,cash ,free_service

    if (this.selectedconsultationtype == 102 && this.consultationTypeText == "walk_in" && this.SelectedSlotDet == "") {
      // walkin but slot not selected

      if (paytype == "insurance") {
        // alert("walkin ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" ||
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          // this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        if (this.imgfile == undefined) {
          this.filevalidation = true;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.blckbtn = false;
          return;
        }
        this.displayinfo = {
          "displayAppointmentType": this.displaytext,
          "AppointmentType": this.consultationTypeText,
          "AppointmentDate": this.walkin_appoinmentdate,
          "time": ""
        }
        this.loading = true;
        this.pat_id = this.dropdowmpatientid;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        console.log("conformclick1")

        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsuranceinsurance.append('AppointmentDate', this.walkin_appoinmentdate);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.specid);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.patphonenum);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('CliniclocMapid', this.selectedLocation);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.blckbtn = false;

                this.cashpaymentform = false;
                this.freeapptform = false;
                this.insuranceform = false;
                this.cardpaymentform = false;

                this.Ispaymentscreen = false;
                const dt = this.maxdate.toISOString();
                setTimeout(() => {
                  this.sidenav.close();
                }, 3000)

                const sdate = this.viewTransaction.value.startdate;
                const getstdate = moment(sdate).format();
                let startdate = getstdate.substr(0, 10);

                const edate = this.viewTransaction.value.enddate;
                const getedate = moment(edate).format();
                let enddate = getedate.substr(0, 10);
                this.ngOnInit()

              });
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        this.displayinfo = {
          "displayAppointmentType": this.displaytext,
          "AppointmentType": this.consultationTypeText,
          "AppointmentDate": this.walkin_appoinmentdate,
          "time": this.SelectedSlotDet?.time
        }
        let insurancedoctorfee
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        console.log("conformclick2")

        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('AppointmentDate', this.walkin_appoinmentdate);
        formDataPaymentWalkin.append('PatientId', this.dropdowmpatientid);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.patphonenum);
        formDataPaymentWalkin.append('paymentMethod', paytype);

        formDataPaymentWalkin.append('CliniclocMapid', this.selectedLocation);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);

        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.SelectedSlotDet = "";
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              setTimeout(() => {
                this.sidenav.close();
              }, 3000)
              this.successection = true;
              this.blckbtn = false;
              this.cashpaymentform = false;
              this.freeapptform = false;
              this.insuranceform = false;
              this.cardpaymentform = false;

              this.Ispaymentscreen = false;
              this.resposnsedata = res;
              this.apptid = res.responseData;

              const sdate = this.viewTransaction.value.startdate;
              const getstdate = moment(sdate).format();
              let startdate = getstdate.substr(0, 10);

              const edate = this.viewTransaction.value.enddate;
              const getedate = moment(edate).format();
              let enddate = getedate.substr(0, 10);
              this.ngOnInit()
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    } else if (this.selectedconsultationtype == 102 && this.consultationTypeText == "walk_in" && this.SelectedSlotDet != "") { // walkin but slot selected
      // alert("walkin slot")

      if (paytype == "insurance") {
        // alert("walkin  slot ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" ||
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          // this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        if (this.imgfile == undefined) {
          this.filevalidation = true;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.blckbtn = false;
          return;
        }
        this.displayinfo = {
          "displayAppointmentType": this.displaytext,
          "AppointmentType": this.consultationTypeText,
          "AppointmentDate": this.walkin_appoinmentdate,
          "time": this.SelectedSlotDet?.time
        }
        this.loading = true;
        this.pat_id = this.dropdowmpatientid;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        console.log("conformclick3")

        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsuranceinsurance.append('AppointmentDate', this.walkin_appoinmentdate);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('CliniclocMapid', this.selectedLocation);
        formDataInsuranceinsurance.append('SpecilalityId', this.specid);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.patphonenum);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              this.SelectedSlotDet = "";
              this.successection = true;
              this.blckbtn = false;
              this.cashpaymentform = false;
              this.freeapptform = false;
              this.insuranceform = false;
              this.cardpaymentform = false;

              this.Ispaymentscreen = false;
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                const dt = this.maxdate.toISOString();
                setTimeout(() => {
                  this.sidenav.close();
                }, 3000)

                const sdate = this.viewTransaction.value.startdate;
                const getstdate = moment(sdate).format();
                let startdate = getstdate.substr(0, 10);

                const edate = this.viewTransaction.value.enddate;
                const getedate = moment(edate).format();
                let enddate = getedate.substr(0, 10);
                this.ngOnInit()

              });
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        this.displayinfo = {
          "displayAppointmentType": this.displaytext,
          "AppointmentType": this.consultationTypeText,
          "AppointmentDate": this.walkin_appoinmentdate,
          "time": this.SelectedSlotDet?.time
        }
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        console.log("conformclick4")

        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('AppointmentDate', this.walkin_appoinmentdate);
        formDataPaymentWalkin.append('PatientId', this.dropdowmpatientid);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.patphonenum);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('CliniclocMapid', this.selectedLocation);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('AppoinmentSlotid', this.slotimeid);
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);

        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.SelectedSlotDet = "";
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              this.successection = true;
              this.blckbtn = false;
              this.cashpaymentform = false;
              this.freeapptform = false;
              this.insuranceform = false;
              this.cardpaymentform = false;

              this.Ispaymentscreen = false;
              this.resposnsedata = res;
              this.apptid = res.responseData;

              setTimeout(() => {
                this.sidenav.close();
              }, 3000)
              const sdate = this.viewTransaction.value.startdate;
              const getstdate = moment(sdate).format();
              let startdate = getstdate.substr(0, 10);

              const edate = this.viewTransaction.value.enddate;
              const getedate = moment(edate).format();
              let enddate = getedate.substr(0, 10);
              this.ngOnInit()
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    }
    else { // online and offline
      // alert(" online offline")
      if (paytype == "insurance") {
        // alert(" online offline , insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" ||
          this.Insuranceform.value.insuranceNumber == null || this.Insuranceform.value.insuranceProvider == null ||
          this.Insuranceform.value.validity == null || this.Insuranceform.value.insurarname == null) {
          // this.filevalidation = true;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.blckbtn = false;
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        if (this.imgfile == undefined) {
          this.filevalidation = true;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.blckbtn = false;
          return;
        }
        this.displayinfo = {
          "displayAppointmentType": this.displaytext,
          "AppointmentType": this.consultationTypeText,
          "AppointmentDate": this.stdate,
          "time": this.SelectedSlotDet?.time
        }
        this.loading = true;
        this.pat_id = this.dropdowmpatientid;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;

        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        console.log("conformclick5")

        const formDataInsurance: FormData = new FormData();
        formDataInsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsurance.append('AppointmentDate', this.stdate);
        formDataInsurance.append('Comments', "Regularcheckup");
        formDataInsurance.append('Firstname', "");
        formDataInsurance.append('Lastname', "");
        formDataInsurance.append('CliniclocMapid', this.selectedLocation);
        formDataInsurance.append('DoctorId', this.docid);
        formDataInsurance.append('SpecilalityId', this.specid);
        formDataInsurance.append('Email', "");
        formDataInsurance.append('Mobile', this.patphonenum);
        formDataInsurance.append('PaymentMethod', "Insurance");
        formDataInsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsurance.append('BookingType', "regular");
        formDataInsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsurance.append('OrderId', this.ord_id);
        formDataInsurance.append('PaymentId', this.pay_id);
        formDataInsurance.append('Signature', this.sign);
        formDataInsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsurance.append('Cardimagepath', this.imgfile);
        formDataInsurance.append('PatientId', this.pat_id);
        // if (this.myfollowupdetails &&
        //   this.myfollowupdetails.mybookfollowup == true &&
        //   this.myfollowupdetails.followUp.parentAppointmentId) {
        //   formDataInsurance.append('followUp.ParentAppointmentId', this.myfollowupdetails.followUp.parentAppointmentId);
        // }
        this._patientservice.paymentsubmitForInsurance(formDataInsurance)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              this.SelectedSlotDet = "";
              this.successection = true;
              this.blckbtn = false;
              this.cashpaymentform = false;
              this.freeapptform = false;
              this.insuranceform = false;
              this.cardpaymentform = false;

              this.Ispaymentscreen = false;
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                const dt = this.maxdate.toISOString();
                setTimeout(() => {
                  this.sidenav.close();
                }, 3000)

                const sdate = this.viewTransaction.value.startdate;
                const getstdate = moment(sdate).format();
                let startdate = getstdate.substr(0, 10);

                const edate = this.viewTransaction.value.enddate;
                const getedate = moment(edate).format();
                let enddate = getedate.substr(0, 10);
                this.ngOnInit()

              });
            }
            else {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        // alert("online offline , cash and free")
        this.loading = true;
        this.pat_id = this.dropdowmpatientid;
        // this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        const payment = paytype;
        const aptmnt = {
          appointtype: this.consultationTypeText,
          comment: "",
          fname: "",
          lname: "",
          doctor: this.docid,
          clinic: this.cliname,
          speciality: this.specid,
          email: "",
          mobile: "",
          dateofappointment: "",
          timeslot: "",
          paymentid: ""
        }
        let parentappid = "";
        this.displayinfo = {
          "displayAppointmentType": this.displaytext,
          "AppointmentType": this.consultationTypeText,
          "AppointmentDate": this.stdate,
          "time": this.SelectedSlotDet?.time
        }
        // if (this.myfollowupdetails &&
        //   this.myfollowupdetails.mybookfollowup == true &&
        //   this.myfollowupdetails.followUp.parentAppointmentId) {
        //   parentappid = this.myfollowupdetails.followUp.parentAppointmentId
        // }

        let locationID = 1;
        console.log("conformclick6")

        this._patientservice.paymentsubmit(aptmnt, this.stdate, this.pat_id, this.slotimeid, this.pay_id, this.ord_id, this.sign, this.consFess, payment, this.patphonenum, parentappid, this.selectedLocation)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              this.SelectedSlotDet = "";
              this.successection = true;
              this.blckbtn = false;
              this.cashpaymentform = false;
              this.freeapptform = false;
              this.insuranceform = false;
              this.cardpaymentform = false;

              this.Ispaymentscreen = false;
              meta.ngZone.run(() => {
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                const dt = moment(this.maxdate).format('MM/DD/YYYY');
              });
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              setTimeout(() => {
                this.sidenav.close();
              }, 3000)
              const sdate = this.viewTransaction.value.startdate;
              const getstdate = moment(sdate).format();
              let startdate = getstdate.substr(0, 10);

              const edate = this.viewTransaction.value.enddate;
              const getedate = moment(edate).format();
              let enddate = getedate.substr(0, 10);
              this.ngOnInit()
            }
            else {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      }
    }
  }

  clearfreeapptform() {
    this.blckbtn = false;
    this.freeapptform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcashpayment() {
    this.blckbtn = false;
    this.cashpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');

  }
  clearinsurance() {
    this.blckbtn = false;
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.insuranceform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');

  }
  clearcardpayment() {
    this.blckbtn = false;
    this.cardpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    let item = [];
    this.isActive(item);
  }
  odId: any;
  skey: any;
  errormessagebox: boolean;
  clinicID: any;

  paymentId: any;
  orderId: any;
  signature: any;
  parentaId: any;
  pAId: number;
  razorinfo: any;

  initPay() {
    console.log("pay")
    this.blckbtn = true;
    if (this.selectedconsultationtype == 102) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.blckbtn = false;
      this.toastrService.warning('', "Rayzor Not Applicable for Walk-In", options);
      return;
    }
    if (this.selectedconsultationtype == 1) {
      this.consultationTypeText = 'online';
      this.consFess = this.Book_SelectedDocInfo?.fees?.domesticConsultation;
    }

    this.clinicID = this.Book_SelectedDocInfo?.clinicId;
    this.docid = this.Book_SelectedDocInfo?.doctorId;
    this.cliname = this.Book_SelectedDocInfo?.clinicName;
    this.specid = this.Book_SelectedDocInfo?.specialityId;
    this.stdate = this.SelectedSlotDet?.slotTime;
    this.mobilenumber = this.patphonenum;


    if (this.selectedconsultationtype == 1) {
      this.consultationTypeText = 'online';
      this.displaytext = 'Video Consultation';
      this.consFess = this.Book_SelectedDocInfo.fees.domesticConsultation;
    }

    if (this.selectedconsultationtype == 102) {
      this.Book_SelectedDocInfo?.fees?.wfList.map((cwdata) => {
        if (cwdata.cliniclocationmapId == this.selectedLocation) {
          this.consFess = cwdata.walkinfee;
          this.displaytext = 'Walk in';
          this.consultationTypeText = 'walk_in';
        }
      })
    }
    if (this.selectedconsultationtype == 2) {
      this.Book_SelectedDocInfo?.fees?.cvfList.map((cvdata) => {
        if (cvdata.cliniclocationmapId == this.selectedLocation) {
          this.consultationTypeText = 'visit_to_clinic';
          this.displaytext = 'Clinic Visit';
          this.consFess = cvdata.clinicVisitFee;
        }
      })
    }


    this.user_id = sessionStorage.getItem('userId');
    if (!this.slotimeid || this.slotimeid === 'undefined') {
      this.sloterrormsg = true;
      this.loading = false;
    } else {
      this.sloterrormsg = false;
    console.log("payAPI")

      this._patientservice.emailinitpay(this.consFess, this.docid, this.clinicID, this.dropdowmpatientid)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.odId = res.responseMessage;
            this.skey = res.responseData

            this.payWithRazor(this.odId, this.skey);
          }
          else {
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
            this.blckbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.blckbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }


  // Location dropdown
  ChangeLocationBookappointment(event) {
    //this.selectedLocation = event.value;
    this.timeslots = []
    this.slottime = ""
    this.slotimeid = ""
    this.SelectedSlotDet = ""
    this.Noslotmsg = true;
    this._patientservice.timeslot(this.Book_SelectedDocInfo.doctorId, this.locationDate, this.selectedconsultationtype, event.value)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;

          if (this.selectedconsultationtype != 102) {
            this.timeslots = res.responseMessage;
            if (res.responseMessage.length == 0) {
              this.Noslotmsg = true;
            } else {
              this.Noslotmsg = false;
            }

          } else {
            this.timeslots = [];
            this.Noslotmsg = true;
          }

          if (this.selectedconsultationtype != 102) {

            //if(this.selectedconsultationtype == 1){
            // this.selectedLocation = 1;
            // }

            this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');

            this.myHolidayFilter = (d: Date): any => {
              return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
            }

            this.selectedDate = this.walkin_appoinmentdate
            this.getBookingslots(this.walkin_appoinmentdate);
            this.getslots(this.walkin_appoinmentdate)

          } else {
            this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
            this.loadDoctorDateInCalender();
            this.checkprofile();
          }


        } else {
          this.loading = false;
        }
      }, err => {
        this.loading = false;
      });
  }

  loadDatesinCal() {

    if (this.consultationTypeArrayBookappointment.length == 1) {
      this.isConsultaionselected = true;
    } else {
      this.isConsultaionselected = false;
    }

    // --------------- Load current date in Calender for WalkIn Type
    if (this.selectedconsultationtype == 102) {

      this.myHolidayDates = new Date();
      this.getslots(moment(new Date()).format('YYYY-MM-DD'))
      this.selectedDate = moment(new Date()).format('YYYY-MM-DD')
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD')
      this.myHolidayFilter = (d: Date): any => {
        return moment(d).format('YYYY-MM-DD') == moment(new Date()).format('YYYY-MM-DD')
      }
      return;
    }

    if (this.selectedconsultationtype != 102) {
      //this.myHolidayDates = new Date();
      this.loadDatesforSingleType(moment(new Date()).format('YYYY-MM-DD'))
      // this.getslots(moment(this.myHolidayDates).format('YYYY-MM-DD'))
      // this.selectedDate = moment(this.myHolidayDates).format('YYYY-MM-DD')
      //this.myHolidayFilter = (d: Date): any => {
      //return moment(d).format('YYYY-MM-DD') == moment(this.myHolidayDates).format('YYYY-MM-DD')
      // }
      return;
    }
    // ----------------

  }



  loadmyDate() {
    this.loading = true;
    var dateD = new Date();
    let firstDayD;
    let lastDayD;
    if (this.selectedconsultationtype == 102) {

      firstDayD = moment(dateD).format('YYYY-MM-DD')
      lastDayD = moment(dateD).format('YYYY-MM-DD')
    }


    setTimeout(() => {
      this.loading = true;
      let payload = {
        StartDate: firstDayD,
        EndDate: lastDayD,
        ClinicId: this.Book_SelectedDocInfo.clinicId,
        DoctorId: this.Book_SelectedDocInfo.doctorId,
        // ConsultationType: this.selectedconsultationtype
        CliniclocMapid: this.selectedLocation
      }

      this._patientservice.getdateslot(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.myHolidayDates = res?.responseMessage[0]?.slotDates;
            this.myHolidayFilter = (d: Date): any => {
              return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
            }
            this.defaultSelectedSlots()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          })
    });

  }

  // it loads slot model dates depends on api response
  loadDatesforSingleType(a) {

    this.loading = true;

    var dateD = new Date();
    let firstDayD;
    let lastDayD;


    if (this.selectedconsultationtype == 102) {

      firstDayD = moment(dateD).format('YYYY-MM-DD')
      lastDayD = moment(dateD).format('YYYY-MM-DD')
    }

    if (this.selectedconsultationtype != 102) {
      var firstDay = new Date(dateD.getFullYear(), dateD.getMonth(), 1);
      var lastDay = new Date(dateD.getFullYear(), dateD.getMonth() + 1, 0);

      firstDayD = moment(dateD).format('YYYY-MM-DD')
      lastDayD = moment(lastDay).format('YYYY-MM-DD')
    }


    setTimeout(() => {
      this.loading = true;
      let payload = {
        StartDate: firstDayD,
        EndDate: lastDayD,
        ClinicId: this.Book_SelectedDocInfo.clinicId,
        DoctorId: this.Book_SelectedDocInfo.doctorId,
        // ConsultationType: this.selectedconsultationtype
        CliniclocMapid: this.selectedLocation
      }

      this._patientservice.getdateslot(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.myHolidayDates = res?.responseMessage[0]?.slotDates;
            this.myHolidayFilter = (d: Date): any => {
              return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
            }
            this.defaultSelectedSlots()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          })
    });

  }

  checkpro: any;
  checkproerror: boolean;
  messagecontentflag: any;
  navigateflag: any;

  checkprofile() {
    this._patientservice.checkprofile2(this.dropdowmpatientid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.checkpro = res.responseMessage;
          this.loading = true;
          this._patientservice.patientdetail(this.dropdowmpatientid)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                this.razorinfo = res.responseMessage;
              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
        } else {
          this.checkproerror = true;
          this.messagecontentflag = res.errorMessage;
          this.navigateflag = res.responseMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });
  }

  // for testing
  payWithRazor(oid, sk) {
    console.log("payAPI2")

    let razorpaydescription = ""
    this.pat_id = this.dropdowmpatientid;
    let meta = this
    // if(this.myfollowupdetails &&
    //   this.myfollowupdetails.mybookfollowup == true &&
    //   this.myfollowupdetails.followUp.parentAppointmentId){
    //     razorpaydescription = "Followup Fee";
    //   }else{
    //     razorpaydescription = "Consultation Fee";
    //   }
    razorpaydescription = "Consultation Fee";
    const options: any = {
      key: sk,
      amount: this.consFess * 100, // amount should be in paise format to display Rs 1255 without decimal point
      currency: 'INR',
      name: 'ClinaNG', // company name or product name
      description: razorpaydescription,  // product description
      // description: 'Consultation Fee',  // product description
      image: './assets/images/clina-blue.webp', // company logo or product image
      order_id: oid, // order_id created by you in backend
      modal: {
        // We should prevent closing of the form when esc key is pressed.
        escape: false,
      },
      notes: {
        // include notes if any
      },
      theme: {
        color: '#0c238a'
      }
    };
    options.handler = ((response, error) => {
      options.response = response;
      this.paymentId = response.razorpay_payment_id;
      this.orderId = response.razorpay_order_id;
      this.signature = response.razorpay_signature;

      if (response.razorpay_payment_id && response.razorpay_order_id && response.razorpay_signature) {
        this.loading = true;
        if (!this.slotimeid || this.slotimeid === 'undefined') {
          this.sloterrormsg = true;
          this.loading = false;
        }
        else {
          const payment = 'RazorPay';
          if (this.parentaId != 0) {
            this.pAId = this.parentaId;
          } else {
            this.pAId = 0;
          }
          const aptmnt = {
            appointtype: this.consultationTypeText,
            comment: "",
            fname: "",
            lname: "",
            doctor: this.docid,
            clinic: this.cliname,
            speciality: this.specid,
            email: "",
            mobile: "",
            dateofappointment: "",
            timeslot: "",
            paymentid: ""
          }
          let parentappid = "";
          this.displayinfo = {
            "displayAppointmentType": this.displaytext,
            "AppointmentType": this.consultationTypeText,
            "AppointmentDate": this.stdate,
            "time": this.SelectedSlotDet?.time
          }
          // if(this.myfollowupdetails &&
          //   this.myfollowupdetails.mybookfollowup == true &&
          //   this.myfollowupdetails.followUp.parentAppointmentId){
          //     parentappid = this.myfollowupdetails.followUp.parentAppointmentId     
          //   }
          let locationID = 1;
    console.log("payAPIconform")

          this._patientservice.paymentsubmit(aptmnt, this.stdate, this.pat_id, this.slotimeid, this.paymentId, this.orderId, this.signature, this.consFess, payment, this.patphonenum, parentappid, this.selectedLocation)
            .pipe(first())
            .subscribe((res: any) => {
              if (res && !res.isError) {
                this.resposnsedata = res;
                this.apptid = res.responseData;
                this.blckbtn = false;
                this.loading = false;
                this.sloterrormsg = false;
                this.SelectedSlotDet = "";

                meta.ngZone.run(() => {
                  this.successection = true;
                  this.blckbtn = false;
                  this.Ispaymentscreen = false;
                  const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                  const dt = moment(this.maxdate).format('MM/DD/YYYY');
                  // setTimeout(() => {
                  //   if (slotDate > dt) {
                  //     meta.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  //   } else {
                  //     meta.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  //   }      
                  // }, 3000);
                });
                setTimeout(() => {
                  this.sidenav.close();
                }, 3000)
                // this.sidenav.close();
                const sdate = this.viewTransaction.value.startdate;
                const getstdate = moment(sdate).format();
                let startdate = getstdate.substr(0, 10);

                const edate = this.viewTransaction.value.enddate;
                const getedate = moment(edate).format();
                let enddate = getedate.substr(0, 10);
                this.ngOnInit()
                // if (enddate && startdate) {
                //   this.getTransactionlistWithDate()
                // } else {
                //   this.ChangeConsultationTran();
                // }

                // this.sharedataService.setSuccessmsg(res.responseMessage);
              }
              else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res?.errorMessage, options);
                this.sloterrormsg = false;
                this.blckbtn = false;
                if (this.errormessagebox) {
                  this.loading = false;
                }
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            },
              err => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
                this.sloterrormsg = false;
                this.blckbtn = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
                if (this.forbiddenmessagebox) {
                  this.loading = false;
                }
              });
        }
      }
      // call your backend api to verify payment signature & capture transaction
    });
    options.prefill = {
      name: this.razorinfo.firstName,
      email: this.razorinfo.eMail,
      contact: this.razorinfo.mobileNumber
    },
      options.modal.ondismiss = (() => {
        this.blckbtn = false;
        // handle the case when user closes the form while transaction is in progress
      });
    const rzp = new this.winRef.nativeWindow.Razorpay(options);
    rzp.open();
  }
  // side window code ends
  treatmentAppointmentFields: boolean = false;
  directAppointmentFields: boolean = true;
}

export interface PeriodicElement {
  invoiceo: any;
  paymenttype: string;
  transactionid: any;
  paymentdate: any;
  amount: any;
  status: any;
  action: any;
}

export interface Bank {
  patientid: any;
  name: any;
  firstName: any;
  phoneNumber: any;
}
interface Gender {
  value: string;
}


import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminTransactionComponent } from './clinicadmin-transaction.component';

describe('ClinicadminTransactionComponent', () => {
  let component: ClinicadminTransactionComponent;
  let fixture: ComponentFixture<ClinicadminTransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminTransactionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

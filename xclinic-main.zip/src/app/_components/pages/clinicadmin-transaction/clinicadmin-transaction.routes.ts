import { RouterModule } from '@angular/router';
import { ClinicadminTransactionComponent } from '../clinicadmin-transaction/clinicadmin-transaction.component';
export const ClinicadminTransactionRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminTransactionComponent,
    }
]
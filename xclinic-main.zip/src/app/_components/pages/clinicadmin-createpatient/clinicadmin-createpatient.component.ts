import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { PatientService } from 'src/app/_services/patient.service';

@Component({
  selector: 'app-clinicadmin-createpatient',
  templateUrl: './clinicadmin-createpatient.component.html',
  styleUrls: ['./clinicadmin-createpatient.component.css']
})
export class ClinicadminCreatepatientComponent implements OnInit {
  hide = true;
  loading: boolean;
  createpatProfile: FormGroup
  minlen: any = 1;
  maxlen: any = 1;
  mandatorymobEmailfields: boolean = false;
  constructor(private _formBuilder: FormBuilder,
    private toastrService: ToastService,
    private _patientservice: PatientService,
    private authenticationService: AuthenticationService,
    public dialogRef: MatDialogRef<ClinicadminCreatepatientComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.minlen = sessionStorage.getItem("minlen");
    this.maxlen = sessionStorage.getItem("maxlen");
  }

  ngOnInit(): void {
    if (sessionStorage.getItem("clinicCountryName") == "india") {
      this.mandatorymobEmailfields = false;
      this.createpatProfile = this._formBuilder.group({
        firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
        lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
        email: ['', [Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
        password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
        phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]]
      });
    }
    else {
      this.mandatorymobEmailfields = true;
      this.createpatProfile = this._formBuilder.group({
        firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
        lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
        email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
        password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
        phoneno: ['', [Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(this.minlen), Validators.maxLength(this.maxlen)]]
      });
    }
  }
  reset() {
    this.createpatProfile.reset();
  }
  patregister() {
    if (this.createpatProfile.value.email == "" || this.createpatProfile.value.email == null && this.createpatProfile.value.phoneno) {
      if (this.createpatProfile.value.password == '' || this.createpatProfile.value.password == null || this.createpatProfile.value.password.trim() == "") {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Enter valid the Password', options);
        setTimeout(() => {
          this.toastrService.clear(), 2000
        }, 2000);
        return;
      }
      this.loading = true;
      const roleid = 3;
      let payload = {
        "FirstName": this.createpatProfile.value.firstname,
        "LastName": this.createpatProfile.value.lastname,
        "Password": this.createpatProfile.value.password,
        "MobileNumber": this.createpatProfile.value.phoneno,
        "RoleId": roleid
      }
      this.authenticationService.RegisterWithMobileNumber(payload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            this.createpatProfile.reset();
            this.dialogRef.close({ data: res });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            this.dialogRef.close({ data: err });
          });
    } else {
      if (this.createpatProfile.value.password == '' || this.createpatProfile.value.password == null || this.createpatProfile.value.password.trim() == "") {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please Enter valid the Password', options);
        setTimeout(() => {
          this.toastrService.clear(), 2000
        }, 2000);
        return;
      }
      this.loading = true;
      const roleid = 3;
      this.authenticationService.register(this.createpatProfile.value, roleid)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            this.createpatProfile.reset();
            this.dialogRef.close({ data: res });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            this.dialogRef.close({ data: err });
          });
    }
  }

}

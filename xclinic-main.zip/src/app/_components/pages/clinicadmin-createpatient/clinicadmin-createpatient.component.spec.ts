import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminCreatepatientComponent } from './clinicadmin-createpatient.component';

describe('ClinicadminCreatepatientComponent', () => {
  let component: ClinicadminCreatepatientComponent;
  let fixture: ComponentFixture<ClinicadminCreatepatientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminCreatepatientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminCreatepatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

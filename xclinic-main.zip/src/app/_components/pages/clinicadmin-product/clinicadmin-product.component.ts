import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild,ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';

export interface PeriodicElement {
  name: string;
  code: number;
  category: number;
  record: number;
  unit:string;
  action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { name: 'Rishith', code: 343822, category: 343822, record:10, unit:'Box', action:'' },
  { name: 'Rajesh', code: 343822, category: 343822, record:5, unit:'Price', action:'' },
  { name: 'Krish', code: 343822, category: 343822, record:3, unit:'Box', action:'' },
];

@Component({
  selector: 'app-clinicadmin-product',
  templateUrl: './clinicadmin-product.component.html',
  styleUrls: ['./clinicadmin-product.component.css']
})

export class ClinicadminProductComponent implements OnInit {
// ViewChild is used to access the input element.
  @ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', {static: false})InputVar: ElementRef;
  @ViewChild(MatPaginator, { static: false }) productpaginator: MatPaginator;
      
  clinicId:any;
  displayedColumns: string[] = ['name', 'code', 'category', 'record','unit', 'action', ];

  public dataSource: any = new MatTableDataSource([]);
  createproduct: FormGroup;
  total:any;
  granttotal:any;
  clinicid:any;
  chargesCategory:any;
  chargesTax:any;
  chargesUnit:any;
  addressmodel:any;
  hidediv:boolean = false;
  note:any;
  domaincurrency:any;
  productids:any;
  servid:any;
  loading:boolean;
  btnCreate:boolean;
  tableArray: any = [];
  productunitArray: any = [];
  locationarray: any = [];
  categoryarray: any = [];
  taxarray: any = [];
  public totalSize = 0;
  public pageindex = 0;
  catName:any;
  public filerpastform_pagination_show: boolean;
  listdata: boolean;

  searchstring: any;
  size: any;
  getpendingstate: any;
  filterData: boolean;
  applyfilterData: boolean = false;
  Fsearchstring:string
  public originalarray: any = [];
  filterString;
  filter: string;
  searchinput:any;
  page1:any

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router:Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('createpaginator', { static: false }) createpaginator: MatPaginator;

  ngOnInit(): void {
  this.loading = true;
  setTimeout(()=>{
   this.loading = false;
  },2000)

    this.createproduct = this._formBuilder.group({
      name: [''],
      price: [''],
      code: [''],
      unittype: [''],
      category: [''],
      reorderevel: [''],
      taxtype: [''],
      typevalue: [''],
    });

   this.btnCreate = history.state.btnAction;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('stockinwardId')) {
        this.servid = params?.get('stockinwardId');
      }
    });

  console.log(this.servid);
  
  this.domaincurrency = sessionStorage.getItem('domaincurrencydetails');
  this.clinicid = sessionStorage.getItem('clinicId');
  console.log(this.domaincurrency);

  this._DoctorService.getlocations(this.clinicid)
      .pipe(first())
      .subscribe((res: any) => {
         this.locationarray = res?.responseMessage;
        // console.log('location details',res?.responseMessage);
        },
        err => {
    });

  this._DoctorService.getproductlist(0,5)
    .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];

          this.addressmodel = res?.responseMessage;
          console.log(this.addressmodel);
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

      console.log('edit details ',history.state.stockinstatus)

      if(this.servid != undefined){
        this._DoctorService.getstockindetails(Number(this?.servid))
        .pipe(first())
        .subscribe((res: any) => {
        if (!res.isError) {
        console.log('service details',res)
        this.loading = false;
        let data = res?.responseMessage[0];

        this.createproduct.get('name').setValue(new Date(data?.stockdate));
        this.createproduct.get('price').setValue(data?.supplierId);
        this.createproduct.get('code').setValue(data?.locationid);
        this.createproduct.get('unittype').setValue(data?.referenceno);
        this.createproduct.get('reorderevel').setValue(data?.referenceno);
        this.createproduct.get('taxtype').setValue(data?.referenceno);
        this.createproduct.get('typevalue').setValue(data?.referenceno);

        this.dataSource = new MatTableDataSource(this.tableArray);
          setTimeout(() => {
          this.dataSource.paginator = this.createpaginator
        });

        }

        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
    }else{
        this.loading = false;
    }


  // Get supplier list 
  this._DoctorService.getCategorylist()
      .pipe(first())
      .subscribe((res: any) => {
         console.log(res?.responseMessage)
         this.categoryarray = res?.responseMessage;
        },
        err => {
  });

  // Get product list 
  this._DoctorService.getTaxlist()
      .pipe(first())
      .subscribe((res: any) => {
         this.taxarray = res?.responseMessage;
        },
        err => {
  });

  // Get productunit list 
  this._DoctorService.getProductunit()
      .pipe(first())
      .subscribe((res: any) => {
         this.productunitArray = res?.responseMessage;
        },
        err => {
  });

}

 selectedcategory(event){
  this.chargesCategory = event.value;
  
  this.categoryarray.map((data)=>{
    if(data.productCatagoryid == event.value){
       this.catName = data.productCatogaryName;
    }
  })
  console.log(this.catName)
    if(this.catName == "Internal"){
      this.createproduct.get('price').setValue("");
      this.createproduct.get('taxtype').setValue("");
      this.createproduct.get('typevalue').setValue("");
      this.hidediv = true;
    }else{
      this.hidediv = false;
    }
  }

  selectedtax(event){
  this.chargesTax = event.value.taxTypeId;
   console.log('product change',this.chargesTax);
  }

  selectedunittype(event){
  this.chargesUnit = event.value.productUnitid;
   console.log('product change',this.chargesUnit);
  }

  addproduct(formData: any, formDirective: FormGroupDirective){
   this.loading = true;
    console.log(this.createproduct.value)
  if(this.createproduct.value.name != '' && this.createproduct.value.code != "" && this.createproduct.value.unittype != "" && 
  this.createproduct.value.name != null && this.createproduct.value.code != null && this.createproduct.value.unittype != null
  )
  {
    let formobject ={};
    if(this.productids == undefined){
      if(this.catName == "Internal"){
        formobject = {
          "ProductName": this.createproduct.value.name,
          "Code": this.createproduct.value.code,
          "ReorderedLevel": Number(this.createproduct.value.reorderevel),
          "Unit": Number(this.createproduct.value.unittype),
          "CategoryType": Number(this.createproduct.value.category)
        } 
      }
      else{
        formobject = {
          "ProductName": this.createproduct.value.name,
          "Code": this.createproduct.value.code,
          "ReorderedLevel": Number(this.createproduct.value.reorderevel),
          "SellingPrice": Number(this.createproduct.value.price),
          "Unit": Number(this.createproduct.value.unittype),
          "CategoryType": Number(this.createproduct.value.category),
          "TaxId": Number(this.createproduct.value.taxtype),
          "Taxamount": Number(this.createproduct.value.typevalue)
        }
      }
    }

    if(this.productids != undefined){
      if(this.catName == "Internal"){
          formobject = {
          "ProductName": this.createproduct.value.name,
          "Code": this.createproduct.value.code,
          "ReorderedLevel": Number(this.createproduct.value.reorderevel),
          "Unit": Number(this.createproduct.value.unittype),
          "CategoryType": Number(this.createproduct.value.category),
          "ProductId": Number(this.productids)
        }
      } else {
        formobject = {
          "ProductName": this.createproduct.value.name,
          "Code": this.createproduct.value.code,
          "ReorderedLevel": Number(this.createproduct.value.reorderevel),
          "SellingPrice": Number(this.createproduct.value.price),
          "Unit": Number(this.createproduct.value.unittype),
          "CategoryType": Number(this.createproduct.value.category),
          "TaxId":Number(this.createproduct.value.taxtype),
          "Taxamount": Number(this.createproduct.value.typevalue),
          "ProductId": Number(this.productids)
        }
      }
    }

      this._DoctorService.createproduct(formobject,this.productids).pipe(first()).subscribe((res: any) => {
      if(!res.isError) {
      this.loading = false;
      this.addressmodel = res?.responseMessage;
          console.log(res);
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
           // this.dataSource.paginator = this.paginator
          });

           setTimeout(() => {
          this.dataSource.paginator = this.createpaginator
        });

      
      this.createproduct.reset();
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.success('', res.responseMessage, options);
      this.getproducts();
      this.clearinput(formData,formDirective);
      } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      });
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the mandatory fields', options);
    }

  }

  clearinput(formData: any, formDirective: FormGroupDirective) {
  formDirective.resetForm();
  this.createproduct.reset();
  this.createproduct.get('reorderevel').reset();
  this.createproduct.get('name').reset();
  this.createproduct.get('code').reset();
  this.createproduct.get('price').reset();
  this.productids = undefined;
  }


  getproducts(){
   this._DoctorService.getproductlist(0,5)
    .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];

          this.addressmodel = res?.responseMessage;
          console.log(res);
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

 editclick(ele){
  console.log(ele)
  this.loading = true;
     this._DoctorService.getsingleproduct(ele.productId)
    .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
        this.loading = false;

        let details = res?.responseMessage;
        console.log(res?.responseMessage);
        
        this.createproduct.get('name').setValue(details.productName);
        this.createproduct.get('price').setValue(details.sellingPrice);
        this.createproduct.get('code').setValue(details.productCode);
        this.createproduct.get('unittype').setValue(details.unitTypeId);
        this.createproduct.get('reorderevel').setValue(details.reorderedLevel);
        this.createproduct.get('category').setValue(details.categoryTypeId);
        this.productids = ele.productId;

         if(details.categoryType == "Internal"){
         this.hidediv = true;
           this.createproduct.get('taxtype').setValue("");
           this.createproduct.get('price').setValue("");
           this.createproduct.get('typevalue').setValue("");
         }else{
           this.createproduct.get('taxtype').setValue(details.taxId);
           this.createproduct.get('price').setValue(details.sellingPrice);
           this.createproduct.get('typevalue').setValue(details.taxAmount);
          this.hidediv = false;
         }

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });

  }

  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getproductlist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }

     
searchfilter() {
  const filterValue = this.searchinput;
  let searchstring = filterValue.trim()
  console.log(searchstring)
  if (searchstring) {
    this.applyfilterData = true;
  } else {
    this.applyfilterData = false;
  return;
  }
 
  this.loading = true;
  this.Fsearchstring=searchstring;
  
    this._DoctorService.productfilter(searchstring)
    .pipe(first())
    .subscribe((res: any) => {
      if (!res.isError) {
        console.log(res)
        let array = [];
        this.loading = false;
        this.dataSource = new MatTableDataSource(res?.responseMessage);
        if (this.dataSource.data.length === 0) {
          this.listdata = true;
        }
        else {
          this.listdata = false;
        }
        setTimeout(() => {
          this.totalSize = res?.pagination?.total;
          ///this.dataSource.paginator = this.createpaginator;
        });
      }
      else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        this.loading = false;
      }
    },
      err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        this.loading = false;
      });
}

     
     filterGetnext(event) {         
      this.loading = true;
      this._DoctorService.productfilterwithpageSize(this.Fsearchstring,event.pageIndex,event.pageSize)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {          
            let array = [];                    
            this.loading = false;
            for (let item of res?.responseMessage) {             
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
              this.filterData = true;
    
            }
            else {
              this.listdata = false;
              this.filterData = false;
            }
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    }

  clearfilter() {
    this.loading = true;
  this.searchinput = "";
  // this.filterData =false;
  this.applyfilterData = false;
   let searchstring = this.searchinput;
  this._DoctorService.getproductlist(0,5)
    .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          
          this.loading = false;
          let array = [];
          this.size = 5;
          this.totalSize = res.total;
          //  this.pageSize = res.pageSize;
          this.addressmodel = res?.responseMessage;
          console.log(res);
          this.dataSource = new MatTableDataSource(this.addressmodel);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
          }
          else {
            this.listdata = false;
            this.filterData = false
          }   
          setTimeout(() => {
            this.totalSize = res?.pagination.total;
            // this.pageSize = res?.pagination?.pageSize;
             //this.dataSource.paginator = this.productpaginator
            this.dataSource.paginator = this.createpaginator;
            // this.totalSize = res?.responseMessage?.pagination?.total
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  
        if (searchstring == "") {
          this.filterData = false;  
        this.listdata = false;
        }
}

}
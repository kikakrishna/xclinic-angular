import { RouterModule } from '@angular/router';
import {ClinicadminProductComponent } from './clinicadmin-product.component';
export const ClinicadminProductRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminProductComponent,
    }
]
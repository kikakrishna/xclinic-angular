import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminProductComponent } from './clinicadmin-product.component';

describe('ClinicadminProductComponent', () => {
  let component: ClinicadminProductComponent;
  let fixture: ComponentFixture<ClinicadminProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminProductComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

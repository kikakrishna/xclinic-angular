import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeleteserviceComponent } from './clinicadmin-deleteservice.component';

describe('ClinicadminDeleteserviceComponent', () => {
  let component: ClinicadminDeleteserviceComponent;
  let fixture: ComponentFixture<ClinicadminDeleteserviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeleteserviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeleteserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

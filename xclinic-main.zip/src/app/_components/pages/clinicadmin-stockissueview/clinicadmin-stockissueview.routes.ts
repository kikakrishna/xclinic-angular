import { RouterModule } from '@angular/router';
import { ClinicadminStockissueviewComponent } from './clinicadmin-stockissueview.component';
export const ClinicadminStockissueviewRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockissueviewComponent,
    }
]
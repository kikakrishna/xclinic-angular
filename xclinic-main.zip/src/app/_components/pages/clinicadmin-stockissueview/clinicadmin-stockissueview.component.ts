import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { filter, first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';



export interface PeriodicElement {
  productname: string;
  qty: number;
  unittype: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { productname: 'product 1', qty: 5, unittype: 'Box', },
  { productname: 'product 2', qty: 3, unittype: 'piece', },
  { productname: 'product 3', qty: 4, unittype: 'Box', },

];
@Component({
  selector: 'app-clinicadmin-stockissueview',
  templateUrl: './clinicadmin-stockissueview.component.html',
  styleUrls: ['./clinicadmin-stockissueview.component.css']
})
export class ClinicadminStockissueviewComponent implements OnInit {
  displayedColumns: string[] = ['productname', 'qty', 'unittype',];
  dataSource = ELEMENT_DATA;
  createstockissueview: FormGroup;

  // date = new FormControl(new Date());
  // serializedDate = new FormControl(new Date().toISOString());

  name = new FormControl('', [Validators.required,]);
  getErrorMessage() {
    if (this.name.hasError('required')) {
      return 'Please Enter Name';
    }
    return;
  }
  alert = new FormControl('', [Validators.required,]);
  getErrorMessagealert() {
    if (this.alert.hasError('required')) {
      return 'Please Enter Alert';
    }

  }

  code = new FormControl('', [Validators.required,]);
  getErrorMessagecode() {
    if (this.code.hasError('required')) {
      return 'Please Enter Code';
    }

  }

  constructor(private _formBuilder: FormBuilder,

    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router: Router) { }

  ngOnInit(): void {
    this.createstockissueview = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      refno: ['', Validators.required],
      issueto: ['', Validators.required],
      location: ['', Validators.required],
    });
  }
}

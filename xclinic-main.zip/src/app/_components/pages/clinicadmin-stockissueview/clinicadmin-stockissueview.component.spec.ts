import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockissueviewComponent } from './clinicadmin-stockissueview.component';

describe('ClinicadminStockissueviewComponent', () => {
  let component: ClinicadminStockissueviewComponent;
  let fixture: ComponentFixture<ClinicadminStockissueviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockissueviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockissueviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

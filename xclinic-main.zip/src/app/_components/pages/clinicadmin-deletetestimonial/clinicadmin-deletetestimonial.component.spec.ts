import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeletetestimonialComponent } from './clinicadmin-deletetestimonial.component';

describe('ClinicadminDeletetestimonialComponent', () => {
  let component: ClinicadminDeletetestimonialComponent;
  let fixture: ComponentFixture<ClinicadminDeletetestimonialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeletetestimonialComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeletetestimonialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDoctoreditfeeComponent } from './clinicadmin-doctoreditfee.component';

describe('ClinicadminDoctoreditfeeComponent', () => {
  let component: ClinicadminDoctoreditfeeComponent;
  let fixture: ComponentFixture<ClinicadminDoctoreditfeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDoctoreditfeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDoctoreditfeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

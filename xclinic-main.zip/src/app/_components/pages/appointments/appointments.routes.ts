import { RouterModule } from '@angular/router';
import { AppointmentsComponent } from './appointments.component';
export const AppointmentsRoutes: RouterModule[] = [
    {
        path: '',
        component: AppointmentsComponent,
    }
]
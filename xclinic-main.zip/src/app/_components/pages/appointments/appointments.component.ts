import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { DoctorService } from '../../../_services/doctor.service';
import { first } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { ToastService } from 'ng-uikit-pro-standard';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  displayedColumns: string[];
  dynamiccloumnname: any;
  public filterpast_startdate: any;
  public filterpast_enddate: any;
  public filerpastform_pagination_show: boolean;
  public dataSource: any = new MatTableDataSource<object>([]);
  Ishide: boolean = true;
  loading: boolean;
  today = new Date();
  myStartDate: any;
  myEndDate: any;
  getpendingstate: any;
  id: string;
  listdata: boolean;
  role: any;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  messagebox: boolean;
  errormessagebox: boolean;
  filter: string;
  public totalSize = 0;
  public pageindex = 0;
  public pagesize = 0;
  isShowfilter: boolean;
  isShowmsg: boolean;
  filterpast: FormGroup;
  search: FormGroup;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  todate: boolean;
  pastfiltervalue = [];
  @ViewChild('widgetsContent', { read: ElementRef }) public widgetsContent: ElementRef<any>;
  public scrollRight(): void {
    this.widgetsContent.nativeElement.scrollTo({ left: (this.widgetsContent.nativeElement.scrollLeft + 150), behavior: 'smooth' });
  }
  public scrollLeft(): void {
    this.widgetsContent.nativeElement.scrollTo({ left: (this.widgetsContent.nativeElement.scrollLeft - 150), behavior: 'smooth' });
  }
  constructor(private toastrService: ToastService, public _formBuilder: FormBuilder, private _DoctorService: DoctorService, private _Activatedroute: ActivatedRoute) {
    this.dataSource = new MatTableDataSource;
    this.filter = this._Activatedroute.snapshot.params.tId;
    if (this.filter) {
      this.appt(this.filter);
    }
    this.todate = true;
  }

  ngOnInit(): void {
    this.toastrService.clear();
    this.myStartDate = new Date();
    const today = new Date()
    this.myStartDate.setDate(today.getDate() - 1)

    this.filterpast = this._formBuilder.group({
      fromdatepicker: ['', Validators.required],
      todatepicker: ['', Validators.required]
    });
    this.search = this._formBuilder.group({
      searchvalue: ['']
    });
    this.role = sessionStorage.getItem("Role");
    console.log(this.role)
    this.dynamiccloumnname = "";
    if (sessionStorage.getItem("Role") == "doctor") {
      this.displayedColumns = ['patient', 'appid', 'date', 'time', 'consultation', 'appointmentstatus', 'action'];
      this.dynamiccloumnname = "Doctor";
      this.isShowfilter = true;
      return;
    }
    if (sessionStorage.getItem("Role") == "patient") {
      this.displayedColumns = ['appid', 'doctor', 'date', 'time', 'consultation', 'action'];
      this.dynamiccloumnname = "Patient";
      this.isShowfilter = true;
      return;
    }
    this.loading = true;
    if (this.role === "doctor") {
      let array = [];
      this.getpendingstate = this.filter;
      this._DoctorService.appointmentlist(this.filter, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          if (!res.isError) {
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
            }

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
    else if (this.role === "Admin") {
      let array = [];
      this.getpendingstate = this.filter;
      this._DoctorService.appointmentlist(this.filter, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          if (!res.isError) {
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
            }

          } else {
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
    else if (this.role === 'patient') {
      let array = [];
      this.getpendingstate = this.filter;
      this._DoctorService.appointmentlist(this.filter, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
            }
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
    else {
      let array = [];
      this.getpendingstate = this.filter;
      this._DoctorService.appointmentlist(this.filter, 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          this.loading = false;
          if (!res.isError) {
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
            }

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }
  dateenabled() {
    this.search.get('searchvalue').setValue(null);
    this.myEndDate = this.filterpast.value.fromdatepicker;
    this.filterpast.get('todatepicker').setValue('');
    if (this.myEndDate != null) {
      this.todate = false;
    } else {
      this.todate = true;
    }
  }

  clearPastForm() {
    this.filterpast.reset();
  }
  clearfilterpastPagination() {
    this.filerpastform_pagination_show = false;
  }
  datevalidation() {
    this.search.get('searchvalue').setValue(null);
    if (this.filterpast.value.fromdatepicker == null) {
      this.filterpast.controls.todatepicker.disable();
      return;
    }
    this.myEndDate = this.filterpast.value.fromdatepicker;
  }
  filterpastForm() {
    this.search.get('searchvalue').setValue(null);
    this.isShowmsg = false;
    this.dataSource = new MatTableDataSource([]);
    this.toastrService.clear();
    this.loading = true;
    let array = [];
    const fdate = this.filterpast.value.fromdatepicker;
    const getFdate = moment(fdate).format();
    let startdate = getFdate.substr(0, 19);
    this.filterpast_startdate = startdate;

    const edate = this.filterpast.value.todatepicker;
    const getEdate = moment(edate).format();
    let enddate = getEdate.substr(0, 19);
    this.filterpast_enddate = enddate;


    this.getpendingstate = 'past';
    this._DoctorService.Pastappointmentlist('Past', 0, 5, startdate, enddate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.filerpastform_pagination_show = true;
          this.totalSize = res.responseMessage.pagination.total;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          this.loading = false;
          if (this.dataSource?.data?.length === 0) {
            this.listdata = true;
            this.isShowmsg = true;

          }
          else {
            this.listdata = false;
            this.isShowmsg = false;

          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  filterString;
  searchinput
  getNext2(event: PageEvent, filter) {
    this.searchinput = ""
    console.log(event.pageIndex)
    console.log(event.pageSize)
    console.log(filter)
    this.pagesize = event.pageSize
    this.loading = true;
    let array = [];
    if (this.filterpast_startdate === undefined || this.filterpast.value.fromdatepicker == null) {
      this.filterpast_startdate = '';
    }
    if (this.filterpast_enddate === undefined || this.filterpast.value.todatepicker == null) {
      this.filterpast_enddate = '';
    }
    this._DoctorService.Pastappointmentlist('Past', event.pageIndex, event.pageSize, this.filterpast_startdate, this.filterpast_enddate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.filerpastform_pagination_show = true;
          this.totalSize = res.responseMessage.pagination.total;
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource?.data?.length === 0) {
            this.listdata = true;
            this.isShowmsg = true;
          }
          else {
            this.listdata = false;
            this.isShowmsg = false;
          }

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          this.errormessagebox = true;
          this.messagecontent = res.errorMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });
  }
  getNext(event: PageEvent, filter) {
    this.loading = true;
    let array = [];
    this.getpendingstate = filter;
    if (this.search.value.searchvalue && filter === 'past') {
      if (this.filterpast_startdate === undefined || this.filterpast.value.fromdatepicker == null) {
        this.filterpast_startdate = '';
      }
      if (this.filterpast_enddate === undefined || this.filterpast.value.todatepicker == null) {
        this.filterpast_enddate = '';
      }
      this._DoctorService.apponitmentpastfilter(this.search.value.searchvalue, filter, event.pageIndex, event.pageSize, this.filterpast_startdate, this.filterpast_enddate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.filerpastform_pagination_show = true;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            this.loading = false;
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
            }
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    } else {
      this._DoctorService.appointmentlist(filter, event.pageIndex, event.pageSize)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            this.loading = false;
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
            }
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }
  isFollowuplabelShow: boolean = true;
  appt(state: string) {
    // this.listdata = true;
    // this.filterData = true;
    this.applyfilterData = false;
    this.searchinput = ""
    this.isShowmsg = false;
    this.dataSource = new MatTableDataSource([]);
    this.loading = true;
    this.getpendingstate = state;
    if (state === 'upcoming') {
      this.isFollowuplabelShow = false;
      let array = [];
      this.getpendingstate = 'upcoming';
      this._DoctorService.appointmentlist('Upcoming', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.totalSize = res.responseMessage.pagination.total;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
              if (this.paginator) {
                this.paginator.pageIndex = 0;
              }
            }
          } else {
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    }
    else if (state === 'today') {
      this.isFollowuplabelShow = true;
      let array = [];
      this.getpendingstate = 'today';
      this._DoctorService.appointmentlist('Today', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.totalSize = res.responseMessage.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
              if (this.paginator) {
                this.paginator.pageIndex = 0;
              }
            }
          } else {
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
    else if (state === 'past') {
      this.isFollowuplabelShow = true;
      let array = [];
      this.getpendingstate = 'past';
      this._DoctorService.appointmentlist('Past', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.filerpastform_pagination_show = true;
            this.totalSize = res.responseMessage.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
              if (this.paginator) {
                this.paginator.pageIndex = 0;
              }
            }
          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
    else {
      this.isFollowuplabelShow = false;
      this.getpendingstate = 'cancelled';
      let array = [];
      this._DoctorService.appointmentlist('Cancelled', 0, 5)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.totalSize = res.responseMessage.pagination.total;
            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource?.data?.length === 0) {
              this.listdata = true;
              this.isShowmsg = true;
            }
            else {
              this.listdata = false;
              this.isShowmsg = false;
              if (this.paginator) {
                this.paginator.pageIndex = 0;
              }
            }
            this.dataSource.filterPredicate = function (data, filter: string) {
              console.log('aa', data)
              console.log('bb', filter)
            }

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }
  filterfun() {
    if (this.role == "patient") {
      this.dataSource.filterPredicate = function (data, filter: string): boolean {
        if (filter == data.appointmentId) {
          return data;
        } else if (data.doctor.toLowerCase().includes(filter.toLowerCase())) {
          return data;
        } else if (data.speciality.toLowerCase().includes(filter.toLowerCase())) {
          return data;
        } else if (data.clinicName.toLowerCase().includes(filter.toLowerCase())) {
          return data;
        } else if (data.slotTime.toLowerCase().includes(filter.toLowerCase())) {
          return data;
        } else if (data.formattedappointmentDate.toLowerCase().includes(filter.toLowerCase())) {
          return data;
        }
      };
      return;
    }
    if (this.role == "doctor") {
      return;
    }
  }
  filterData: boolean;
  applyFilter2(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.filteredData.length === 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
    }
  }
  sessionback() {
    sessionStorage.setItem('backpatadmin', 'false');
    sessionStorage.setItem('backdocadmin', 'false');
  }
  closemessagebox() {
    this.messagebox = false;
    this.errormessagebox = false;
    this.forbiddenmessagebox = false;
  }
  viewclick(state) {
    console.log(state)
    sessionStorage.setItem('appointmentstate', state);
  }
  applyfilterData: boolean = false;
  Fsearchstring: string;

  searchappoinmentfilter() {
    let searchstring = this.searchinput.trim();
    this.Fsearchstring = searchstring
    this.applyfilterData = true;
    if (searchstring.length != 0) {
      this.loading = true;
      this._DoctorService.apponitmentfilterwithpageSize(searchstring, this.getpendingstate, 0, 5)
        // this._DoctorService.apponitmentfilter(searchstring,this.getpendingstate)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            let array = [];

            this.loading = false;
            for (let item of res?.responseMessage?.appointmentList) {
              item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            setTimeout(() => {
              this.totalSize = res?.responseMessage?.pagination.total;
            });
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource.paginator) {
              this.dataSource.paginator.firstPage();
            }
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
              this.filterData = true;

            }
            else {
              this.listdata = false;
              this.filterData = false;
              // this.appointmentspaginator.pageIndex = 0;

            }
            // setTimeout(() => {
            //   this.dataSource.paginator = this.paginator
            // });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    } else {
      // alert();
      this.applyfilterData = false;
      if (this.getpendingstate == "today") {
        this.appt('today');
      }
      if (this.getpendingstate == "past") {
        this.appt('past');
      }
      if (this.getpendingstate == "upcoming") {
        this.appt('upcoming');
      }
      if (this.getpendingstate == "cancelled") {
        this.appt('cancelled');
      }
      return;
    }

  }
  // clearinput(event: Event) {
  //   const filterValue = (event.target as HTMLInputElement).value;
  //   let searchstring = filterValue.trim()
  //   if (searchstring == "") {
  //     this.applyfilterData = false;
  //     if (this.getpendingstate == "today") {
  //       this.appt('today');
  //     }
  //     if (this.getpendingstate == "past") {
  //       this.appt('past');
  //     }
  //     if (this.getpendingstate == "upcoming") {
  //       this.appt('upcoming');
  //     }
  //     if (this.getpendingstate == "cancelled") {
  //       this.appt('cancelled');
  //     }
  //     return;
  //   }
  // }
  clearfilter() {
    this.searchinput = "";
    let searchstring = this.searchinput;
    
    this.applyfilterData = false;
    if (this.getpendingstate == "today") {
      this.appt('today');
    }
    if (this.getpendingstate == "past") {
      this.appt('past');
    }
    if (this.getpendingstate == "upcoming") {
      this.appt('upcoming');
    }
    if (this.getpendingstate == "cancelled") {
      this.appt('cancelled');
    }
    if (this.applyfilterData == false) {
      this.filterData = false;
    } else {
      this.filterData = true;
    }
    return;
  }

  filterGetnext(event: PageEvent, timeframe) {
    this.getpendingstate = timeframe;
    this.loading = true;
    this._DoctorService.apponitmentfilterwithpageSize(this.Fsearchstring, timeframe, event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          let array = [];
          setTimeout(() => {
            this.totalSize = res.responseMessage.pagination.total;
          }, 100);
          this.loading = false;
          for (let item of res?.responseMessage?.appointmentList) {
            item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
            this.filterData = true;

          }
          else {
            this.listdata = false;
            this.filterData = false;
          }

        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }
}





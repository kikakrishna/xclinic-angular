import { Component, OnInit, ViewChild, ChangeDetectorRef, OnDestroy, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MediaMatcher } from '@angular/cdk/layout';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { MatSidenav } from '@angular/material/sidenav';

export interface PeriodicElement {
  name: string;
  email: string;
  phone: string;
  
  address: string;
  action:string;
  
}

const ELEMENT_DATA: PeriodicElement[] = [
  {email: 'rishith@gmail.com', name: 'Rishith', phone: '+91 9789587962',  address: 'Sathy Rd, behind Hotel Guru Amudhas, Saravanampatti,..',action:'' },
  {email: 'rajesh@gmail.com', name: 'Rajesh', phone: '+91 9789587962', address: 'Sathy Rd, behind Hotel Guru Amudhas, Saravanampatti,..',action:'' },
  {email: 'krish@gmail.com', name: 'Krish', phone:'+91 9789587962', address: 'Sathy Rd, behind Hotel Guru Amudhas, Saravanampatti,..',action:'' },
];

@Component({
  selector: 'app-clinicadmin-supplierlist',
  templateUrl: './clinicadmin-supplierlist.component.html',
  styleUrls: ['./clinicadmin-supplierlist.component.css']
})

export class ClinicadminSupplierlistComponent implements OnInit {
  displayedColumns: string[] = [ 'name','email', 'phone','address','action' ];
  dataSource:any;
  supplierstatus:any;
  addressmodel:any;
  btnAction: boolean;
  loading: boolean;
  public totalSize = 0;
  public pageindex = 0;

  public filerpastform_pagination_show: boolean;
  listdata: boolean;
  searchinput:any;
  filterData: boolean;
  applyfilterData: boolean = false;

  constructor(
  private _formBuilder: FormBuilder,
  private _DoctorService: DoctorService,
  public toastrService: ToastService, private router:Router
    ) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatPaginator, { static: false }) supplierlistpaginator: MatPaginator;
  
  ngOnInit(): void {
   this.loading = true;
   this._DoctorService.getsupplierlist(0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.responseMessage;

          console.log(array)
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  createclick(){
      this.router.navigate([`/thealth/clinicadmin/supplier/add`], { state: { supplierstatus: 'create', btnAction:true } });
  } 
  
  editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/supplier/edit/${ele.supplierId}`], { state: { supplierstatus: ele, btnAction:false } });
      }
      
  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getsupplierlist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }

clearfilter() {
        this.loading = true;
      this.searchinput = "";
      this.applyfilterData = false;
      let searchstring = this.searchinput;
      this._DoctorService.getsupplierlist(0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.responseMessage;
          this.totalSize = res.total;
          console.log(array)
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
             this.dataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      
        if (searchstring == "") {
          this.filterData = false;
        }
      
    }
      filterString;
      Fsearchstring:string;
      applyFilter2() {
   
       const filterValue = this.searchinput;
       let searchstring = filterValue.trim()
       console.log(searchstring)
       if(searchstring != "") {
       if (searchstring) {
         this.applyfilterData = true;
       } else {
         this.applyfilterData = false;
       return;
       }
      
       this.loading = true;
       this.Fsearchstring=searchstring;
       
         this._DoctorService.supplierlistfilter(searchstring)
         .pipe(first())
         .subscribe((res: any) => {
           if (!res.isError) {
             console.log(res)
             let array = [];
             this.loading = false;
             for (let item of res?.responseMessage) {
              //  item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
               array.push(item);
             }
             this.dataSource = new MatTableDataSource(array);
             if (this.dataSource.data.length === 0) {
               this.listdata = true;
             }
             else {
               this.listdata = false;
             }
             setTimeout(() => {
                this.totalSize = res?.pagination?.total;
              /// this.dataSource.paginator = this.supplierlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
             });
           }
           else {
             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
             this.toastrService.warning('', res.errorMessage, options);
             this.loading = false;
           }
         },
           err => {
             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
             this.toastrService.warning('', err?.error, options);
             this.loading = false;
           });
     }
     }

     
     filterGetnext(event) {         
      this.loading = true;
      this._DoctorService.supplierlistfilterwithpageSize(this.Fsearchstring,event.pageIndex,event.pageSize)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {          
            let array = [];                    
            this.loading = false;
            for (let item of res?.responseMessage) {             
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
              this.filterData = true;
    
            }
            else {
              this.listdata = false;
              this.filterData = false;
            }
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    }

}
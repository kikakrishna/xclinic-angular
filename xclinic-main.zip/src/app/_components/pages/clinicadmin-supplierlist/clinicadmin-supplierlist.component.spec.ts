import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminSupplierlistComponent } from './clinicadmin-supplierlist.component';

describe('ClinicadminSupplierlistComponent', () => {
  let component: ClinicadminSupplierlistComponent;
  let fixture: ComponentFixture<ClinicadminSupplierlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminSupplierlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminSupplierlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

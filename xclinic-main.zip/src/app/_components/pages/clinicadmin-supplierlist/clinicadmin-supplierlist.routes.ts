import { RouterModule } from '@angular/router';
import { ClinicadminSupplierlistComponent } from './clinicadmin-supplierlist.component';
export const ClinicadminSupplierlistRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminSupplierlistComponent,
    }
]
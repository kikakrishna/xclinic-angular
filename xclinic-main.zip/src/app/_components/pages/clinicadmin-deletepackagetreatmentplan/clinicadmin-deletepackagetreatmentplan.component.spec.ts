import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeletepackagetreatmentplanComponent } from './clinicadmin-deletepackagetreatmentplan.component';

describe('ClinicadminDeletepackagetreatmentplanComponent', () => {
  let component: ClinicadminDeletepackagetreatmentplanComponent;
  let fixture: ComponentFixture<ClinicadminDeletepackagetreatmentplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeletepackagetreatmentplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeletepackagetreatmentplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockadjustmentlistComponent } from './clinicadmin-stockadjustmentlist.component';

describe('ClinicadminStockadjustmentlistComponent', () => {
  let component: ClinicadminStockadjustmentlistComponent;
  let fixture: ComponentFixture<ClinicadminStockadjustmentlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockadjustmentlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockadjustmentlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { AfterViewInit, Component,ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';

export interface PeriodicElement {
  date: string;
  productitems: number;
  createdby: string;
  location:string;
  refno: number;
  action:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {date: '21-05-2022', productitems: 2, createdby:'Admin',  location:'location-1', refno:32422, action:'' },
  {date: '20-05-2022', productitems: 3, createdby:'Admin',  location:'location-2', refno:42423, action:'' },
  {date: '19-05-2022', productitems: 4, createdby:'Admin',  location:'location-3', refno:34234, action:'' },
];

@Component({
  selector: 'app-clinicadmin-stockadjustmentlist',
  templateUrl: './clinicadmin-stockadjustmentlist.component.html',
  styleUrls: ['./clinicadmin-stockadjustmentlist.component.css']
})

export class ClinicadminStockadjustmentlistComponent implements OnInit {
  displayedColumns: string[] = [ 'date', 'productitems','createdby','location','refno','action' ];
 // dataSource = ELEMENT_DATA;
  servicestatus:any;
  btnAction:boolean;

  public stockinArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  addressmodel:any;
  clinicId:any;
  
  public totalSize = 0;
  public pageindex = 0;

  constructor(
  private _DoctorService: DoctorService,
  private _patientservice: PatientService,
  public toastrService: ToastService,
  private _formBuilder: FormBuilder,
  private router: Router,
     public _activatedRoute: ActivatedRoute,
     public dialog: MatDialog,
    ) { }

  ngOnInit(): void {
    this.loading = true;

    this.clinicId = sessionStorage.getItem('clinicId');
    this.stockinArraydataSource.paginator = this.paginator;
    this._DoctorService.getstockadjustlist(0,5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
        let array = [];
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          console.log('stockissue list', res);

          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
            // console.log(d)
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          console.log(array)
          this.stockinArraydataSource = new MatTableDataSource(array);
     
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.stockinArraydataSource.paginator = this.paginator
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }); 
     }

  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getstockadjustlist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          for(let item of res?.responseMessage) {
            let d = new Date(item?.date);
              item.formattedappointmentDate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          this.stockinArraydataSource = new MatTableDataSource(array);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }

    createclick(){
      this.router.navigate([`/thealth/clinicadmin/stockadjustment/add`], { state: { servicestatus: 'create', btnAction:true } });
    }


    editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/stockadjustment/edit/${ele.stockadjustmentid}`], { state: { servicestatus: ele, btnAction:false } });
      }

}
import { RouterModule } from '@angular/router';
import { ClinicadminStockadjustmentlistComponent } from  './clinicadmin-stockadjustmentlist.component';
export const ClinicadminStockAdjustmentlistRoutes: RouterModule[] = [
    {
        path: '',
        component:  ClinicadminStockadjustmentlistComponent ,
    }
]
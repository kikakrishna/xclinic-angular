
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatDialog } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, ReplaySubject, Subject } from 'rxjs';
import { first, retry, take, takeUntil } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';
import { Bank } from '../clinicadmin-transaction/clinicadmin-transaction.component';
import { MatSidenav } from '@angular/material/sidenav';
import { MatCalendar } from '@angular/material/datepicker';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { WindowRefService } from 'src/app/_services/window-ref.service';

@Component({
  selector: 'app-clinicadmin-plantreatmentschedule',
  templateUrl: './clinicadmin-plantreatmentschedule.component.html',
  styleUrls: ['./clinicadmin-plantreatmentschedule.component.css']
})
export class ClinicadminPlantreatmentscheduleComponent implements OnInit {
  @ViewChild('privatUserCheckbox') privatUserCheckbox: ElementRef;
  displayedColumns: string[] = ['appointmentid', 'date', 'doctor', 'amount', 'status', 'action'];
  clinicId: any;
  loading: boolean;
  familytype: boolean = false;
  regbtn: boolean = true;
  alreadymemb: boolean = true;
  Selectedlocationdropdown: any = "";
  filteredOptions: Observable<string[]>;
  // public dataSource: any = new MatTableDataSource([]);
  // dataSource = ELEMENT_DATA;
  public dataSource: any = new MatTableDataSource([]);
  blckbtn: boolean = false;
  consultationTypeArrayBookappointment: any = [];
  consultationTypeArrayBookappointmentArray: any = [];
  specialityArray: any = [];
  locationData: any[];
  slottime: any;
  timeslots: any = [];
  locationDate: any;
  patclicked: { patfname: any, patlname: any, patmobno: any };
  selectedDate
  Noslotmsg: boolean;
  doctorlist: any = [];
  showmsg: boolean;
  isCodemap
  SelectedSlotDet
  Book_SelectedDocInfo
  walkin_appoinmentdate
  selectedconsultationtype
  isConsultaionselected: boolean = false
  myHolidayFilter: any = []
  clinicLocations: any = [];
  selectedLocation: any;
  patientfirstname: any;
  parentGroup: FormGroup;
  updateAppointment: FormGroup;
  user_id: string;
  sessionclinicId: any;
  patientlistarr: any;
  patienttrpackagemapid: any;
  appointmentarray: any = [];
  treatementAppointmentarray: any = [];
  treatmentid: any;
  viewbilling: any;
  public viewbillingdataSource: any = new MatTableDataSource([]);
  displayedColumns2: string[] = ['invoicenumber', 'appointmentdate', 'paymentdate', 'amount', 'invoicestatus', 'action'];
  CurrencyDisplay: any
  viewbillingamount: any;
  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective;
  // public dataSource: any = new MatTableDataSource([]);	
  // dataSource = ELEMENT_DATA;

  // dropdown search start
  /** list of banks */
  protected banks: Bank[] = [];

  /** control for the selected bank */
  public bankCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword */
  public bankFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanks: ReplaySubject<Bank[]> = new ReplaySubject<Bank[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;

  @ViewChild('sidenav') public sidenav: MatSidenav;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();
  // dropdown search end
  @ViewChild('calendar', { static: false }) calendar: MatCalendar<any>;
  checkpro: any;
  razorinfo: any;
  errormessagebox: boolean;
  messagecontent: any;
  checkproerror: boolean;
  messagecontentflag: any;
  navigateflag: any;
  forbiddenmessagebox: boolean;
  paymethodlist: any = [];
  availablepaymethods: any = [];
  newArray: any = [];
  slotimeid: string;
  servid: any;
  schedulebtn: boolean = false;
  treatementnoofvisits: any = [];
  visitCount: any;
  treatementAptLength: any;
  public myHolidayDates: any = [];
  clinicName: any;
  domaindetails: any;
  patienttrpackagemapidList: any;
  norecord: boolean = false;

  constructor(private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public dialog: MatDialog,
    public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private router: Router,
    public _activatedRoute: ActivatedRoute, private winRef: WindowRefService, private ngZone: NgZone) { }

  ngOnInit(): void {
    this.createpatProfile = this._formBuilder.group({
      treatmentname: ['', [Validators.required]],
      amount: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      noofvisit: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    });
    this.updateAppointment = this._formBuilder.group({
      dateofappointment: ['', Validators.required],
      timeslot: [''],
      slots: this._formBuilder.array([])
    });

    this.Insuranceform = this._formBuilder.group({
      appointtype: ['online'],
      insuranceNumber: ['', [Validators.required]],
      insuranceProvider: ['', [Validators.required]],
      validity: ['', [Validators.required]],
      insurarname: ['', [Validators.required]],
    });

    this.loading = true;
    setTimeout(() => {
      this.loading = false;
    }, 2000)
    // load the initial bank list
    this.filteredBanks.next(this.banks.slice());


    this.clinicId = sessionStorage.getItem('clinicId');
    this.clinicName = this._patientservice.Domdetails.responseMessage.clinicName
    this.domaindetails = this._patientservice.Domdetails.responseMessage;
    console.log(this.domaindetails)
    // console.log(this._patientservice.Domdetails.responseMessage.clinicName)
    // side window code
    this.speciality();
    this.myHolidayFilter = (d: Date): any => {
      return false;
    }
    this.parentGroup = this._formBuilder.group({
      'radio-group1': [''],
    });
    // this.getpatientslist();
    // this.loadpaymentmethods()
    this.listInsuranceProvider()
    this.user_id = sessionStorage.getItem('userId');
    this.getClinicLocations();
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('id')) {
        this.servid = params?.get('id');
      }
    })

    //console.log(this._DoctorService.planTreatmentDetails(this?.servid))
    this.getpackageTreatment();
    this.loadScript()
  }
  noofvisits: any = []
  getpackageTreatment() {
    console.log(this.servid)
    this._DoctorService.planTreatmentDetails(this.servid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appointmentarray = res?.responseMessage[0]
          this.treatementAppointmentarray = res?.responseMessage[0]?.treatementAppointment
          let array = []
          for (let item of this.treatementAppointmentarray) {
            let d = new Date(item?.date);
            item.date = moment(d).format('MMM DD,y',);
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          this.treatementnoofvisits = res?.responseMessage[0]?.totalNoofVisits
          this.treatementAptLength = this.treatementAppointmentarray.length
          console.log(this.treatementAppointmentarray.length)
          this.visitCount = this.appointmentarray?.totalNoofVisits - this.treatementAptLength;
          this.pat_id = res?.responseMessage[0]?.patientId
          if (this.appointmentarray?.totalNoofVisits > this.treatementAppointmentarray.length) {
            this.schedulebtn = true;
          } else {
            this.schedulebtn = false;
          }

          if (this.treatementAptLength > 0) {
            this.norecord = false;
          } else {
            this.norecord = true;
          }
          // get visit & count based on isinvoicegenerated == false
          res?.responseMessage[0]?.treatmentlist.filter(item => {
            if (item.isinvoicegenerated == false) {
              // this.visitCount = item.visits - this.treatementAptLength;
              this.consFess = item.amount;
              this.patienttrpackagemapidList = item.patienttrpackagemapid
            } else {

            }
          })
          console.log(JSON.stringify(this.visitCount));

          this.noofvisits = [];
          for (let i = 0; i < this.visitCount; i++) {
              let newName = {
                id:i.toString(),
                name:"Tony"
              };
              this.noofvisits.push(newName);
          }
          console.log(this.noofvisits)
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  // load checkout script
  public loadScript() {
    // alert('in')      
    var isFound = false;
    var scripts = document.getElementsByTagName("script")
    for (var i = 0; i < scripts.length; ++i) {
      if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
        isFound = true;
      }
    }

    if (!isFound) {
      var dynamicScripts = ["https://checkout.razorpay.com/v1/checkout.js"];
      for (var i = 0; i < dynamicScripts.length; i++) {
        let node = document.createElement('script');
        node.src = dynamicScripts[i];
        node.type = 'text/javascript';
        node.async = false;
        node.charset = 'utf-8';
        document.getElementsByTagName('head')[0].appendChild(node);
      }
    }
  }


  counter(i: number): Array<number> {
    return new Array(i);
  }
  dividerhide: boolean = false;
  viewsummary: boolean = true;
  Packagetreatment: boolean = true;
  bookappointmenth3: boolean = false;
  accordionscreen: boolean = false;
  tablescreen: boolean = true;
  plantreatmentschedule() {
    this.loading = true;
    this.loading = false;
    this.tablescreen = false;
    this.accordionscreen = true;
    this.bookappointmenth3 = true;
    this.Packagetreatment = false;
    this.viewsummary = false;
    this.dividerhide = true;
    this.loadpaymentmethods()
  }
  visitfield: boolean = false;
  yesscreen: boolean = true;
  aa: FormGroup;
  sameDoctor: any = [
    { 'name': 'Yes', 'value': 1 },
    { 'name': 'No', 'value': 2 }
  ]
  default_sameDoctor: any = 1;
  // radioChange(event) {
  //   console.log(event)
  //   if(event.value == 1) {
  //     this.yesscreen = true;
  //     this.visitfield = false;
  //     this.default_sameDoctor
  //   } else {
  //     this.yesscreen = true;
  //     this.visitfield = false;
  //   }
  // }
  yesclick(value) {
    this.default_sameDoctor = value
    this.yesscreen = true;
    this.visitfield = false;
    this.clearArray()
  }
  noscreen: boolean = true;
  noclick(value) {
    this.default_sameDoctor = value
    console.log(this.sameDoctor)
    this.yesscreen = false;
    this.visitfield = true;
    this.timeslots = [];
    this.clearArray()
  }
  cancelclick() {
    this.dividerhide = false;
    this.bookappointmenth3 = false;
    this.tablescreen = true;
    this.viewsummary = true;
    this.Packagetreatment = true;
    this.accordionscreen = false;
    this.selectedLocation = ""
    this.Book_SelectedDoctor = ""
    this.selectedconsultationtype = ""
    this.Book_SelectedSpeciality = ""
    this.visitSlots = []
    this.completeVisitTime = []
    this.selectedDateArray = []
    this.selectedDoctorArray = []
  }
  viewsummaryclick() {
    this.router.navigate([`/thealth/clinicadmin/packagetreatmentsummary/${this?.servid}`]);
  }

  createpatProfile: FormGroup
  edittreatment() {
    this.sidenav.open();
    this.loading = true;
    this.createpatProfile.reset();
    this._DoctorService.planTreatmentDetails(this?.servid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appointmentarray = res?.responseMessage[0]
          this.createpatProfile.get('treatmentname').setValue(this.appointmentarray.treatmentName);
          this.createpatProfile.get('noofvisit').setValue(this.appointmentarray.totalNoofVisits);
          this.createpatProfile.get('amount').setValue(this.appointmentarray.totalAmount);
          this.treatmentid = this.appointmentarray.patienttrpackagemapid
          setTimeout(() => {

          });
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  reset() {
    // this.createpatProfile.reset();
    this.sidenav.close();
  }

  billingtable: boolean = false;
  viewbillingpopup() {
    this.billingtable = true;

    // get billing
    this.loading = true;
    this._DoctorService.getviewbillinglist(this?.servid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.viewbilling = res?.responseMessage?.treatmentViewInvoiceModel
          this.viewbillingamount = res?.responseMessage
          let array = []
          for (let item of this.viewbilling) {
            if (item?.appointmentDate != null) {
              let d = new Date(item?.appointmentDate);
              item.appointmentDate = moment(d).format('MMM DD,y',);
            } else {
              item.appointmentDate = '-'
            }

            if (item?.paymentDate != null) {
              let d = new Date(item?.paymentDate);
              item.paymentDate = moment(d).format('MMM DD,y',);
            } else {
              item.paymentDate = '-'
            }
            array.push(item);
          }
          this.viewbillingdataSource = new MatTableDataSource(array);
          console.log(this.viewbilling)
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  speciality() {
    this.loading = true;
    this._patientservice.specialitylist(this.clinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.specialityArray = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }
  Book_SelectedSpeciality;
  spePayload: any;
  diffSpecialityArray: any = [];
  diffDoctorArray: any = [];
  diffLocationArray: any = [];
  clearArray() {
    this.diffConsultationTypeArray = []
    this.diffDoctorArray = []
    this.diffLocationArray = []
    this.diffSpecialityArray = []
    this.visitSlots = []
    this.completeVisitTime = []
    this.selectedDateArray = []
    this.selectedDoctorArray = []
    this.selectedLocation = ""
    this.Book_SelectedDoctor = ""
    this.selectedconsultationtype = ""
    this.Book_SelectedSpeciality = ""
    this.updateAppointment.reset()
  }
  loaddoctorbasedonSpeciality(visit?) {

    // clear previously booked appointment details if any
    this.blckbtn = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
    // empty
    // this.selectedconsultationtype = ''
    // this.Book_SelectedDoctor = ''
    // this.selectedLocation = ''
    // this.updateAppointment.get('dateofappointment').setValue('')
    // this.timeslots = []
    // this.visitSlots = []
    // ---------------------------   
    // this.clearArray()
    this.loading = true;
    let payload = {
      "SpecialityId": this.Book_SelectedSpeciality
    }
    console.log(visit)
    if (this.default_sameDoctor == 2) {
      // this.diffSpecialityArray.push(this.Book_SelectedSpeciality)
      this.diffSpecialityArray[visit] = this.Book_SelectedSpeciality
    }
    console.log(this.diffSpecialityArray)
    console.log(this.default_sameDoctor)
    this._patientservice.clinicadminDocfilterByspecility(payload)
      // this._patientservice.doctoravailableWithSpecialityWithoutDate(payload)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.filteredOptions = res.responseMessage.doctors;
          // this.Book_SelectedDocInfo = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {

        })
  }

  // slots button enable/disable
  isActive(sltId) {
    return this.slotimeid === sltId;
  }

  Bookapp_consultationType() {
    this.loading = true;
    this.consultationTypeArrayBookappointment.length = 0;
    this.consultationTypeArrayBookappointmentArray.length = 0;
    // this._patientservice.getpaymentType()
    this._patientservice.ClinicadminGetconsultationslots(this.Book_SelectedDocInfo?.doctorId)
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.consultationTypeArrayBookappointmentArray = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        }, () => {


          this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
            if (docContype?.status == 1) {
              docContype.loccm.map((data) => {
                if (data.isConsultationCodeMapped == true) {
                  this.isCodemap = true
                }

                if (data.isConsultationCodeMapped == true) {
                  if (data.isConsultationCodeMapped == true && data.defaultlocation == true) {
                    this.selectedLocation = data.clinicLocationMapId;
                  }
                }
                if (data.isConsultationCodeMapped == false && data.defaultlocation == false) {
                  this.selectedLocation = data.clinicLocationMapId;
                }
              })

              this.locationData = docContype.loccm;
            }
          })

          let CodemappedTrueArray = this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
            if (docContype?.status == 1) {
              return this.consultationTypeArrayBookappointmentArray.some(allContype => this.isCodemap == true && docContype.status == 1)
            }
          });

          let tempArray = [];
          for (let it of this.consultationTypeArrayBookappointmentArray) {
            CodemappedTrueArray.filter(i => {
              if (it?.consultationTypeId == i.typeId) {
                tempArray.push(it)
              }
            })
          }

          let array = tempArray;
          var unique = [];
          var distinct = [];
          for (let i = 0; i < array.length; i++) {
            if (!unique[array[i].consultationTypeId]) {
              distinct.push(array[i]);
              unique[array[i].consultationTypeId] = 1;
            }
          }
          let sampleArray = []
          for (let i of distinct) {
            if (i.consultationTypeId != 102) {
              sampleArray.push(i)
            }
          }
          console.log(sampleArray)
          this.consultationTypeArrayBookappointment = sampleArray;

          // if multiple type have na
          if (this.consultationTypeArrayBookappointment.length > 1) {
            if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
              this.isConsultaionselected = true;
            } else {
              this.isConsultaionselected = false;
            }
          } else {
            if (this.consultationTypeArrayBookappointment.length == 1) {
              // this.selectedconsultationtype = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;

              if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
                this.isConsultaionselected = true;
              } else {
                this.isConsultaionselected = false;
              }

              // if only one type , it will selected that type by default

              //this.userSelectedconsultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
              // this.radioChangeForSingletype();
            }
          }

          //  console.log('type details', this.selectedLocation, this.selectedconsultationtype)
          // this.loadDatesinCal();
        })
  }
  diffConsultationTypeArray: any = []
  Changeconsultiontype(visit?) {
    this.SelectedSlotDet = ""
    // this.selectedLocation = ""
    this.timeslots.length = 0;
    console.log(this.selectedLocation)
    // empty
    // this.selectedconsultationtype = ''
    // this.Book_SelectedDoctor = ''
    // this.selectedLocation = ''
    // this.updateAppointment.get('dateofappointment').setValue('')
    // this.timeslots = []
    // this.visitSlots = []

    this.selectedDate = this.walkin_appoinmentdate;
    if (this.default_sameDoctor == 2) {
      // this.spePayload = {
      //   "SpecialityId": this.Book_SelectedSpeciality
      // }
      if (this.selectedconsultationtype == 1) {
        this.consultationTypeText = 'online';
      }
      if (this.selectedconsultationtype == 2) {
        this.consultationTypeText = 'visit_to_clinic';
      }
      this.diffConsultationTypeArray[visit] = this.consultationTypeText
      this.diffLocationArray[visit] = this.selectedLocation
      console.log(this.diffLocationArray)
    }
    console.log(this.diffConsultationTypeArray)
    console.log(this.default_sameDoctor)
    this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
      if (docContype?.status == 1) {
        docContype.loccm.map((data) => {
          if (this.selectedconsultationtype == docContype.typeId) {
            if (data.isConsultationCodeMapped == true) {
              if (data.isConsultationCodeMapped == true && data.defaultlocation == true) {
                return this.selectedLocation = data.clinicLocationMapId;
              }
            } else {
              return this.selectedLocation = data.clinicLocationMapId;
            }
          }
        })

        this.locationData = docContype.loccm;
      }
    })
    console.log(this.selectedconsultationtype)
    if (this.selectedconsultationtype != 102) {
      // walk in  selected na
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');

      // selecting today date in calender
      this.myHolidayFilter = (d: Date): any => {
        return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
      }
      this.selectedDate = this.walkin_appoinmentdate
      // this.getBookingslots(this.walkin_appoinmentdate);
      // this.getslots(this.walkin_appoinmentdate)
      // this.cleardata();      
    } else {
      // walk in not selected
      // this.notwalkin = true;
      this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
      // this.loadmyDate();
      // this.checkprofile();
    }
    // this.loadcalenderDates();

    if (this.selectedconsultationtype) {
      this.isConsultaionselected = true;
    } else {
      this.isConsultaionselected = false;
    }
    this.dateSlots()
    // this.checkprofile();
  }
  checkprofile() {
    // this.pat_id = this.appointmentarray?.patientId;
    this._patientservice.checkprofile2(this.pat_id)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.checkpro = res.responseMessage;
          this.loading = true;
          this._patientservice.patientdetail(this.pat_id)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                this.loading = false;
                this.razorinfo = res.responseMessage;
                console.log(this.razorinfo)
              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
        } else {
          this.checkproerror = true;
          this.messagecontentflag = res.errorMessage;
          this.navigateflag = res.responseMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });
  }

  loadpaymentmethods() {
    this.newArray = []
    this.paymethodlist.length = 0;
    this._patientservice.loadpaymentmethods()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res);
        if (!res.isError) {
          this.loading = false;
          this.paymethodlist = res.responseMessage;
          console.log(res.responseMessage)
          this._patientservice.activeclinicpayment(this.clinicId)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                console.log(res);
                if (this.selectedconsultationtype == 2) {
                  this.availablepaymethods = res.responseMessage.clinicVisitPaymentDetails;
                } else {
                  this.availablepaymethods = res.responseMessage.onlinePaymentDetails;
                }
                console.log(this.availablepaymethods);
                // this.availablepaymethods = res.responseMessage.paymentDetails;
                for (let i = 0; i < this.paymethodlist.length; i++) {
                  var ismatch = false;
                  for (let j = 0; j < this.availablepaymethods.length; j++) {
                    if (this.paymethodlist[i].paymentMethodId == this.availablepaymethods[j].paymentMethodId) {
                      ismatch = true;
                      this.paymethodlist[i].showDateInput = false;
                      this.newArray.push(this.paymethodlist[i]);
                      break;
                    }
                  }
                  if (!ismatch) {
                    this.paymethodlist[i].showDateInput = true;
                    this.paymethodlist[i].mychecked2 = false;
                    this.newArray.push(this.paymethodlist[i]);
                  }

                  //End if
                }
                console.log(this.newArray)
              } else {
                console.log('error');
              }
            },
              err => {
                console.log('error2');
              });
        } else {
          console.log('error');
        }
      },
        err => {
          console.log('error2');
        });
  }

  // changedoctor
  Book_SelectedDoctor
  // Book_SelectedDocInfo;
  selectedDoctorArray :any = []
  ChangeDoctorBookappointment(visit?) {
    this.SelectedSlotDet = ""
    this.Book_SelectedDocInfo = this.Book_SelectedDoctor;
    this.selectedconsultationtype = ""
    // empty
    // this.selectedconsultationtype = ''
    // this.Book_SelectedDoctor = ''
    // this.selectedLocation = ''
    // this.updateAppointment.get('dateofappointment').setValue('')
    // this.timeslots = []
    // this.visitSlots = []
    // load consulatation type for book appoinment screen
    this.Bookapp_consultationType();
    // load payment  for book appoinment screen
    // this.loadpaymentmethods()
    if (this.default_sameDoctor == 2) {
      // this.spePayload = {
      //   "SpecialityId": this.Book_SelectedSpeciality
      // }
      this.diffDoctorArray[visit] = this.Book_SelectedDocInfo.doctorId
      this.selectedDoctorArray[visit] = this.Book_SelectedDocInfo.doctorName
      this.completeVisitTime[visit] = undefined
      this.visitSlots[visit] = undefined
    }
    console.log(this.diffDoctorArray)
    console.log(this.default_sameDoctor)

    this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
      if (docContype?.status == 1) {
        docContype.loccm.map((data) => {
          if (data.isConsultationCodeMapped == true) {
            this.isCodemap = true
          }

          if (data.isConsultationCodeMapped == true) {
            if (data.isConsultationCodeMapped == true && data.defaultlocation == true) {
              // this.selectedLocation = data.clinicLocationMapId;
            }
          }
          if (data.isConsultationCodeMapped == false && data.defaultlocation == false) {
            // this.selectedLocation = data.clinicLocationMapId;
          }
        })

        this.locationData = docContype.loccm;
      }
    })

    let CodemappedTrueArray = this.Book_SelectedDocInfo?.doctorConsultationType.filter(docContype => {
      if (docContype?.status == 1) {
        return this.consultationTypeArrayBookappointmentArray.some(allContype => this.isCodemap == true && docContype.status == 1)
      }
    });

    let tempArray = [];
    for (let it of this.consultationTypeArrayBookappointmentArray) {
      CodemappedTrueArray.filter(i => {
        if (it?.consultationTypeId == i.typeId) {
          tempArray.push(it)
        }
      })
    }
    console.log(tempArray)
    let array = tempArray;
    var unique = [];
    var distinct = [];
    for (let i = 0; i < array.length; i++) {
      if (!unique[array[i].consultationTypeId]) {
        distinct.push(array[i]);
        unique[array[i].consultationTypeId] = 1;
      }
    }
    console.log(distinct)
    let sample = []
    // for (let it of distinct) {
    //   if(it.)
    // }
    this.consultationTypeArrayBookappointment = distinct;
    console.log(this.consultationTypeArrayBookappointment)
    // if multiple type have na
    if (this.consultationTypeArrayBookappointment.length > 1) {
      if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
        this.isConsultaionselected = true;
      } else {
        this.isConsultaionselected = false;
      }
    } else {
      if (this.consultationTypeArrayBookappointment.length == 1) {
        if (this.selectedconsultationtype == 2 || this.selectedconsultationtype == 102) {
          this.isConsultaionselected = true;
        } else {
          this.isConsultaionselected = false;
        }

        // if only one type , it will selected that type by default
        // this.selectedconsultationtype = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;

        //this.userSelectedconsultationType = this.consultationTypeArrayBookappointment[0]?.consultationTypeId;
        // this.radioChangeForSingletype();
      }
    }


  }

  visitSlots: any = []
  completeVisitArray: any = [];
  completeVisit: boolean = false;
  currentVisit: any;
  completeVisitTime: any = []
  // selected slot 
  slotid(slt, visit) {
    // this.slottime = time;
    console.log(slt)
    this.slotimeid = slt.appointmentslotId;
    // this.SelectedSlotDet = data
    this.showmsg = false;
    this.visitSlots[visit] = slt.appointmentslotId
    this.completeVisitTime[visit] = slt.time;
    this.completeVisitArray[visit] = true
    console.log(this.visitSlots)
    console.log(visit)
    console.log(this.completeVisitTime[visit])
  }
  // Location dropdown
  ChangeLocationBookappointment(event, visit) {
    //this.selectedLocation = event.value;
    console.log(event)
    this.Noslotmsg = true;
    // empty
    // this.updateAppointment.get('dateofappointment').setValue('')
    // this.timeslots = []
    // this.visitSlots = []
    if (this.default_sameDoctor == 2) {
      // this.spePayload = {
      //   "SpecialityId": this.Book_SelectedSpeciality
      // }
      this.diffLocationArray[visit] = this.selectedLocation
    }
    console.log(this.diffLocationArray)
    console.log(this.default_sameDoctor)
    this.dateSlots()
    // this._patientservice.timeslot(this.Book_SelectedDocInfo.doctorId, this.locationDate, this.selectedconsultationtype, event.value)
    //   .pipe(first())
    //   .subscribe((res: any) => {
    //     if (!res.isError) {
    //       this.loading = false;
    //       console.log(this.selectedconsultationtype)
    //       if (this.selectedconsultationtype != 102) {
    //         this.timeslots = res.responseMessage;
    //         if (res.responseMessage.length == 0) {
    //           this.Noslotmsg = true;
    //         } else {
    //           this.Noslotmsg = false;
    //         }
    //       } else {
    //         this.timeslots = [];
    //         this.Noslotmsg = true;
    //       }

    //       if (this.selectedconsultationtype != 102) {
    //         this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
    //         this.myHolidayFilter = (d: Date): any => {
    //           return moment(d).format('YYYY-MM-DD') == moment(this.walkin_appoinmentdate).format('YYYY-MM-DD')
    //         }

    //         this.selectedDate = this.walkin_appoinmentdate
    //         // this.getBookingslots(this.walkin_appoinmentdate);
    //         // this.getslots(this.walkin_appoinmentdate)

    //       } else {
    //         this.walkin_appoinmentdate = moment(new Date()).format('YYYY-MM-DD');
    //         // this.loadDoctorDateInCalender();
    //         this.checkprofile();
    //       }
    //       this.dateSlots()

    //     } else {
    //       this.loading = false;
    //     }
    //   }, err => {
    //     this.loading = false;
    //   });
  }

  // getpatientslist() {
  //   this.loading = true;
  //   this._patientservice.getpatients()
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.loading = false;
  //         for (let item of res.responseMessage) {
  //           item.name = item.firstName + ' ' + item.lastName + '-' + item.clinicPatientId;
  //         }
  //         this.patientlistarr = res.responseMessage
  //         this.banks = this.patientlistarr;
  //         this.filteredBanks.next(this.banks.slice());
  //         if (this.patclicked) {
  //           const getchergeid3 = this.patientlistarr.findIndex(x => {
  //             if (x.firstName == this.patclicked.patfname && x.phoneNumber == this.patclicked.patmobno) {
  //               return x;
  //             }
  //           });
  //           this.bankCtrl.setValue(this.banks[getchergeid3]);
  //         }
  //       }
  //       else {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res.errorMessage, options);
  //       }
  //     },
  //       err => {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', err?.error, options);
  //       })
  // }


  listinsuranceproviderArray: any = [];
  listInsuranceProvider() {
    this.loading = true;
    this._patientservice.getInsturanceProvider()
      .pipe(first())
      .subscribe((res: any) => {
        this.loading = false;
        this.listinsuranceproviderArray = res.responseMessage
      }, err => {
      })
  }

  getClinicLocations() {
    // Get clinic locations
    this.loading = true;
    this.sessionclinicId = sessionStorage.getItem('clinicId');
    this._DoctorService.getclinicLocations(this.sessionclinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.clinicLocations = res.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }

  updatetreatment(createpatProfile, formDirective: FormGroupDirective) {
    if
      (
      this.createpatProfile?.value.noofvisit == '' || this.createpatProfile?.value.noofvisit == null
      // this.createTreatment?.value.amount == '' || this.createTreatment?.value.amount == null ||
      // this.createTreatment?.value.code == '' || this.createTreatment?.value.code == null
    ) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
    }
    else {
      this.loading = true;
      let payload = {
        // "TreatmentName": this.createpatProfile.value.treatmentname,
        "Visits": this.createpatProfile.value.noofvisit,
        // "Amounts": this.createpatProfile.value.amount,
        "patienttrpackagemapid": this.treatmentid
      }

      console.log(this.treatmentid)
      this._DoctorService.updateTreatmentById(payload, this.patienttrpackagemapid)
        .pipe(first())
        .subscribe((res: any) => {
          // console.log(res)
          if (!res.isError) {
            this.loading = false;
            setTimeout(() => {

            });
            this.sidenav.close();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            // this.sidenav.close();
            this.ngOnInit()
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            // console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }
  noslotmsg: boolean = false;
  stdate: any;
  selectedDateArray: any = []
  getslot(e, visit) {
    this.loading = true;
    this.timeslots = [];
    // this.sloterrormsg = false;
    const sdate = this.updateAppointment.value.dateofappointment;
    // console.log(sdate)
    let d = new Date(this.updateAppointment.value.dateofappointment);
    this.selectedDateArray[visit] =  moment(d).format('MMM DD,y',);
    console.log(this.selectedDateArray)
    this.completeVisitTime[visit] = undefined
    this.visitSlots[visit] = undefined
    // this.visitSlots.splice(visit, 1);
    const dobdate = moment(sdate).format();
    this.stdate = dobdate.substr(0, 19);
    console.log(dobdate)
    this._patientservice
      .timeslot(
        this.Book_SelectedDocInfo?.doctorId, dobdate, this.selectedconsultationtype, this.selectedLocation
      )
      .pipe(first())
      .subscribe(
        (res: any) => {
          if (!res.isError) {
            this.loading = false;
            if (res.responseMessage.length === 0) {
              this.noslotmsg = true;
            } else {
              this.noslotmsg = false;
              this.timeslots = res.responseMessage;
            }
          } else {
            this.loading = false;
            this.errormessagebox = true;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
        (err) => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.messagecontent = err.error;
        }
      );
  }
  payload: any;
  maxdate: any;
  dateSlots() {
    console.log('log')
    this.loading = true;
    this.payload = {
      StartDate: moment(this.maxdate).format('YYYY-MM-DD'),
      EndDate: moment(this.maxdate).add(365, 'days').format('YYYY-MM-DD'),
      ClinicId: this.clinicId,
      DoctorId: this.Book_SelectedDocInfo?.doctorId,
      ConsultationType: this.selectedconsultationtype,
      CliniclocMapid: this.selectedLocation
    }
    this.myHolidayDates.length = 0;
    this._patientservice.getdateslot(this.payload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.myHolidayDates = res?.responseMessage[0]?.slotDates;
          console.log(res?.responseMessage[0]?.slotDates)
          if (res?.responseMessage[0]?.slotDates.length == 0) {
            this.noslotmsg = true;
          } else {
            this.noslotmsg = false;
          }
          // this.isDateOpened = true;
          this.myHolidayFilter = (d: Date): any => {
            return this.myHolidayDates.find(x => moment(x).format('MM/DD/YYYY') == moment(d).format('MM/DD/YYYY'));
          }
          this.loading = false;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        })
  }
  ClosedDatePicker() {
    // this.isDateOpened = false;
  }
  OpenDatePicker() {
  }
  clearSlots(i) {
    // this.timeslots = []
    this.timeslots = []
    this.updateAppointment.get('dateofappointment').setValue('')
    this.updateAppointment.reset()
    if (this.default_sameDoctor == 2) {
      this.selectedLocation = ""
      this.Book_SelectedDoctor = ""
      this.selectedconsultationtype = ""
      this.Book_SelectedSpeciality = ""
    }
  }

  consultationTypeText: any;
  consFess: any;
  sloterrormsg: boolean = false;
  Insuranceform: FormGroup;
  pat_id: string;
  ord_id: any;
  sign: any;
  parentaId: any;
  mobilenumber: any;
  docid: any;
  cliname: any;
  specid: any;
  odId: any;
  skey: any;
  paymentId: any;
  orderId: any;
  signature: any;
  razorpaymentform: boolean;
  pay_id: any;
  // razorpaymentform: boolean;
  activepaymethod: any;
  // availablepaymethods: any;
  freeapptform: boolean;
  insuranceform: boolean;
  clinicID: any;
  doctorimage: any;
  docimage: any;
  cashpaymentform: boolean;
  apptid: any;
  successection: boolean;
  paymentsection: boolean;
  resposnsedata: any;
  methodtype: any;
  searchspecial: any;
  searchdoc: any;
  searchdocspecial: any;
  searchddates: any;
  searchdoctordates: any;
  consultationType: any;
  pageCheck: any;
  consultationType_walkin = "";
  walkin_appoinmentDate;
  disabledIswalkin: boolean = false;
  cardpaymentform: boolean;
  onItemChange(paymethod) {
    console.log(paymethod)
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.methodtype = paymethod.paymentMethodReferenceName;

    if (paymethod.paymentMethodReferenceName === 'razorpay') {
      this.cashpaymentform = false;
      this.cardpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'cash') {
      this.cardpaymentform = false;
      this.cashpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'free_service') {
      this.freeapptform = true;
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.insuranceform = false;
    }
    else {
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.freeapptform = false;
      this.insuranceform = true;
    }
  }

  isActivepayment(item) {
    return this.methodtype === item.paymentMethodReferenceName;
  }
  imgfile: any;
  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    console.log(file)
    this.imgfile = event.target.files[0];
    console.log(this.imgfile)
    this.filevalidation = false;
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
      }
    }
  }
  clearfreeapptform() {
    this.blckbtn = false;
    this.freeapptform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcashpayment() {
    this.blckbtn = false;
    this.cashpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearinsurance() {
    this.blckbtn = false;
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.insuranceform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcardpayment() {
    this.blckbtn = false;
    this.cardpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    let item = [];
    this.isActive(item);
  }
  filevalidation: boolean;
  locationId: any;
  submitTreatmentForm(methodtype, updateAppointment, formDirective: FormGroupDirective) {
    console.log(this.methodtype)
    console.log(this.updateAppointment)
    // const sdate = this.updateAppointment.value.dateofappointment;
    // const dobdate = moment(sdate).format();
    // this.stdate = dobdate.substr(0, 19);
    console.log(this.stdate)
    console.log(this.visitSlots)
    if (this.default_sameDoctor == 2) {
      this.docid = JSON.stringify(this.diffDoctorArray);
      this.specid = JSON.stringify(this.diffSpecialityArray);
      this.locationId = JSON.stringify(this.diffLocationArray);
      this.consultationTypeText = JSON.stringify(this.diffConsultationTypeArray);
    } else {
      if (this.selectedconsultationtype == 1) {
        this.consultationTypeText = 'online';
        // this.consFess = this.appointmentarray.amount;
      }
      if (this.selectedconsultationtype == 2) {
        this.consultationTypeText = 'visit_to_clinic';
        // this.consFess = this.appointmentarray.amount;
      }
      if (this.Book_SelectedDocInfo) {
        this.docid = this.Book_SelectedDocInfo.doctorId;
      }
      this.specid = this.Book_SelectedSpeciality;
      this.locationId = this.selectedLocation;
      this.consultationTypeText = this.consultationTypeText;
    }
    console.log(this.locationId)
    let meta = this
    console.log(this.visitCount)
    console.log(this.visitSlots.length)
    if (this.visitCount == this.visitSlots.length) {
      let value = this.visitSlots.filter(x => x != undefined && x != null)
      console.log(value)
      console.log(value.length)
      if(value.length != this.visitCount) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please complete all the visits and schedule appointments', options);
        return;
      }

      if (methodtype == "insurance") {
        // alert(" online offline , insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined) {
          this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.appointmentarray?.patientId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsurance: FormData = new FormData();
        formDataInsurance.append('AppointmentType', this.consultationTypeText);
        // formDataInsurance.append('AppointmentDate', this.stdate);
        formDataInsurance.append('Comments', "Regularcheckup");
        formDataInsurance.append('Firstname', "");
        formDataInsurance.append('Lastname', "");
        formDataInsurance.append('PatientId', this.pat_id);
        formDataInsurance.append('DoctorId', this.docid);
        formDataInsurance.append('SpecilalityId', this.specid);
        formDataInsurance.append('ClinicName', this.clinicName);
        formDataInsurance.append('Mobile', this.appointmentarray?.phonenumber);
        formDataInsurance.append('PaymentMethod', "Insurance");
        // formDataInsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsurance.append('BookingType', "regular");
        // formDataInsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsurance.append('CliniclocMapid', this.locationId);
        formDataInsurance.append('OrderId', this.ord_id);
        formDataInsurance.append('PaymentId', this.pay_id);
        // formDataInsurance.append('Signature', this.sign);
        formDataInsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsurance.append('Cardimagepath', this.imgfile);
        formDataInsurance.append('SlotId', JSON.stringify(this.visitSlots));
        formDataInsurance.append('patienttrpackagemapid', this.patienttrpackagemapidList);

        if (this.default_sameDoctor == 2) {
          this._DoctorService.planTreatmentScheduleMultidoctor(formDataInsurance)
            .pipe(first())
            .subscribe((res: any) => {
              console.log(res);
              if (!res.isError) {
                console.log(res);
                this.resposnsedata = res;
                this.apptid = res.responseData;
                this.sloterrormsg = false;
                this.loading = false;
                this.mobilenumber = "";
                // this.SelectedSlotDet = "";
                meta.ngZone.run(() => {
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res?.responseMessage, options);
                });
                this.cancelclick()
                this.getpackageTreatment()
              }
              else {
                this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.sloterrormsg = false;
              }
            },
              err => {
                this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);
                this.loading = false;
                this.sloterrormsg = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
              });
        } else {
          this._DoctorService.planTreatmentSchedule(formDataInsurance)
            .pipe(first())
            .subscribe((res: any) => {
              console.log(res);
              if (!res.isError) {
                console.log(res);
                this.resposnsedata = res;
                this.apptid = res.responseData;
                this.sloterrormsg = false;
                this.loading = false;
                this.mobilenumber = "";
                // this.SelectedSlotDet = "";
                meta.ngZone.run(() => {
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res?.responseMessage, options);
                });
                this.cancelclick()
                this.getpackageTreatment()
              }
              else {
                this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.sloterrormsg = false;
              }
            },
              err => {
                this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err.error, options);
                this.loading = false;
                this.sloterrormsg = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
              });
        }

      } else {
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('PatientId', this.appointmentarray?.patientId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.clinicName);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.appointmentarray?.phonenumber);
        formDataPaymentWalkin.append('paymentMethod', this.methodtype);
        formDataPaymentWalkin.append('BookingType', 'regular');
        formDataPaymentWalkin.append('OrderId', '');
        formDataPaymentWalkin.append('PaymentId', '');
        formDataPaymentWalkin.append('SlotId', JSON.stringify(this.visitSlots));
        formDataPaymentWalkin.append('CliniclocMapid', this.locationId);
        formDataPaymentWalkin.append('patienttrpackagemapid', this.patienttrpackagemapidList);
        console.log(formDataPaymentWalkin)
        // return
        if (this.default_sameDoctor == 2) {
          this._DoctorService.planTreatmentScheduleMultidoctor(formDataPaymentWalkin)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                console.log(res)
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                this.cancelclick()
                this.getpackageTreatment()
              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res?.errorMessage, options);
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            })
        } else {
          this._DoctorService.planTreatmentSchedule(formDataPaymentWalkin)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                console.log(res)
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                this.cancelclick()
                this.getpackageTreatment()
              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res?.errorMessage, options);
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            })
        }
      }
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please complete all the visits and schedule appointments', options);
    }
  }
  initPay() {
    this.checkprofile()
    this.blckbtn = true;
    if (this.consultationType_walkin == "102") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.blckbtn = false;
      this.toastrService.warning('', "Rayzor Not Applicable for Walk-In", options);
      return;
    }
    if (this.default_sameDoctor == 2) {
      this.docid = JSON.stringify(this.diffDoctorArray);
      this.specid = JSON.stringify(this.diffSpecialityArray);
      this.locationId = JSON.stringify(this.diffLocationArray);
      this.consultationTypeText = JSON.stringify(this.diffConsultationTypeArray);
    } else {
      if (this.selectedconsultationtype == 1) {
        this.consultationTypeText = 'online';
        // this.consFess = this.appointmentarray.amount;
      }
      if (this.selectedconsultationtype == 2) {
        this.consultationTypeText = 'visit_to_clinic';
        // this.consFess = this.appointmentarray.amount;
      }
      this.docid = this.Book_SelectedDocInfo.doctorId;
      this.specid = this.Book_SelectedSpeciality;
      this.locationId = this.selectedLocation;
      this.consultationTypeText = this.consultationTypeText
    }
    this.user_id = this.appointmentarray?.patientId;;
    console.log(this.consFess)
    // console.log('pay details... ', this.consFess, this.docid, this.clinicID, this.user_id, "*******", this.slotimeid)
    if (this.visitCount == this.visitSlots.length) {
      let value = this.visitSlots.filter(x => x != undefined && x != null)
      console.log(value)
      console.log(value.length)
      if(value.length != this.visitCount) {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', 'Please complete all the visits and schedule appointments', options);
        return;
      }
      console.log(value)
      if (!this.slotimeid || this.slotimeid === 'undefined') {
        this.sloterrormsg = true;
        this.loading = false;
      } else {
        this.sloterrormsg = false;
        this._patientservice.emailinitpay(this.consFess, this.Book_SelectedDocInfo.doctorId, this.clinicID, this.user_id)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              this.odId = res.responseMessage;
              this.skey = res.responseData
              this.blckbtn = false;
              this.payWithRazor(this.odId, this.skey);
            }
            else {
              this.errormessagebox = true;
              this.blckbtn = false;
              this.messagecontent = res.errorMessage;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      }
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please complete all the visits and schedule appointments', options);
    }
  }
  pAId: number;
  payWithRazor(oid, sk) {
    console.log(this.consultationTypeText);
    let razorpaydescription = ""
    this.pat_id = this.appointmentarray?.patientId;
    let meta = this
    razorpaydescription = "Consultation Fee";
    // this.consFess = this.appointmentarray.totalAmount
    console.log(this.consFess)
    const options: any = {
      key: sk,
      amount: this.consFess * 100, // amount should be in paise format to display Rs 1255 without decimal point
      currency: 'INR',
      name: 'ClinaNG', // company name or product name
      description: razorpaydescription,  // product description
      // description: 'Consultation Fee',  // product description
      image: './assets/images/clina-blue.webp', // company logo or product image
      order_id: oid, // order_id created by you in backend
      modal: {
        // We should prevent closing of the form when esc key is pressed.
        escape: false,
      },
      notes: {
        // include notes if any
      },
      theme: {
        color: '#0c238a'
      }
    };
    console.log(options)
    options.handler = ((response, error) => {
      options.response = response;
      this.paymentId = response.razorpay_payment_id;
      this.orderId = response.razorpay_order_id;
      this.signature = response.razorpay_signature;

      if (response.razorpay_payment_id && response.razorpay_order_id && response.razorpay_signature) {
        this.loading = true;
        if (!this.slotimeid || this.slotimeid === 'undefined') {
          this.sloterrormsg = true;
          this.loading = false;
        }
        else {
          const payment = 'RazorPay';
          if (this.parentaId != 0) {
            this.pAId = this.parentaId;
          } else {
            this.pAId = 0;
          }
          // const aptmnt = {
          //   appointtype: this.consultationTypeText,
          //   comment: "",
          //   fname: "",
          //   lname: "",
          //   doctor: this.docid,
          //   clinic: this.cliname,
          //   speciality: this.specid,
          //   email: "",
          //   mobile: "",
          //   dateofappointment: "",
          //   timeslot: "",
          //   paymentid: ""
          // }
          const formDataPayment: FormData = new FormData();
          formDataPayment.append('AppointmentType', this.consultationTypeText);
          formDataPayment.append('PatientId', this.appointmentarray?.patientId);
          formDataPayment.append('DoctorId', this.docid);
          formDataPayment.append('ClinicName', this.clinicName);
          formDataPayment.append('SpecilalityId', this.specid);
          formDataPayment.append('Mobile', this.appointmentarray?.phonenumber);
          formDataPayment.append('paymentMethod', this.methodtype);
          formDataPayment.append('BookingType', "regular");
          formDataPayment.append('OrderId', this.orderId);
          formDataPayment.append('PaymentId', this.paymentId);
          formDataPayment.append('Signature', this.signature);
          formDataPayment.append('SlotId', JSON.stringify(this.visitSlots));
          formDataPayment.append('CliniclocMapid', this.locationId);
          formDataPayment.append('patienttrpackagemapid', this.patienttrpackagemapidList);
          console.log(JSON.stringify(formDataPayment))
          // if (this.myfollowupdetails &&
          //   this.myfollowupdetails.mybookfollowup == true &&
          //   this.myfollowupdetails.followUp.parentAppointmentId) {
          //   parentappid = this.myfollowupdetails.followUp.parentAppointmentId
          // }
          // return
          if (this.default_sameDoctor == 2) {
            this._DoctorService.planTreatmentScheduleMultidoctor(formDataPayment)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res);
                if (res && !res.isError) {
                  this.resposnsedata = res;
                  this.apptid = res.responseData;
                  this.loading = false;
                  this.sloterrormsg = false;
                  meta.ngZone.run(() => {
                    this.successection = true;
                    this.paymentsection = false;
                    this.blckbtn = false;
                  });
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res?.responseMessage, options);
                  this.cancelclick()
                  this.getpackageTreatment()
                }
                else {
                  this.blckbtn = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res?.errorMessage, options);
                  this.sloterrormsg = false;
                  if (this.errormessagebox) {
                    this.loading = false;
                  }
                  this.errormessagebox = true;
                  this.messagecontent = res.errorMessage;
                }
              },
                err => {
                  this.blckbtn = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                  this.sloterrormsg = false;
                  this.forbiddenmessagebox = true;
                  this.messagecontent = err.error;
                  if (this.forbiddenmessagebox) {
                    this.loading = false;
                  }
                });
          } else {
            this._DoctorService.planTreatmentSchedule(formDataPayment)
              .pipe(first())
              .subscribe((res: any) => {
                console.log(res);
                if (res && !res.isError) {
                  this.resposnsedata = res;
                  this.apptid = res.responseData;
                  this.loading = false;
                  this.sloterrormsg = false;
                  // meta.ngZone.run(() => {
                  //   this.successection = true;
                  //   this.paymentsection = false;
                  // });
                  meta.ngZone.run(() => {
                    this.successection = true;
                    this.paymentsection = false;
                    const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                    const dt = moment(this.maxdate).format('MM/DD/YYYY');
                    this.blckbtn = false;
                  });
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.success('', res?.responseMessage, options);
                  this.cancelclick()
                  this.getpackageTreatment()
                }
                else {
                  this.blckbtn = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res?.errorMessage, options);
                  this.sloterrormsg = false;
                  if (this.errormessagebox) {
                    this.loading = false;
                  }
                  this.errormessagebox = true;
                  this.messagecontent = res.errorMessage;
                }
              },
                err => {
                  this.blckbtn = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', err?.error, options);
                  this.sloterrormsg = false;
                  this.forbiddenmessagebox = true;
                  this.messagecontent = err.error;
                  if (this.forbiddenmessagebox) {
                    this.loading = false;
                  }
                });
          }
        }
      }
      // call your backend api to verify payment signature & capture transaction
    });
    options.prefill = {
      name: this.razorinfo.firstName,
      email: this.razorinfo.eMail,
      contact: this.razorinfo.mobileNumber
    },
      options.modal.ondismiss = (() => {
        // handle the case when user closes the form while transaction is in progress
      });
    console.log(options);

    const rzp = new this.winRef.nativeWindow.Razorpay(options);
    rzp.open();
  }

  previewclick(ele) {
    this.router.navigate([`/thealth/clinicadmin/transactioninvoice/${ele.billAppointmentMapId}`]);
  }
  viewclick(ele) {
    this.router.navigate([`/thealth/clinicadmin/appointments/${ele.type}/${ele.appointmentId}`]);
  }

}

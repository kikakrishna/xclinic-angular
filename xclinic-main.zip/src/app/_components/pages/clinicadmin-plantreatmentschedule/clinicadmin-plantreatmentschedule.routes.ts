import { RouterModule } from '@angular/router';
import { ClinicadminPlantreatmentscheduleComponent  } from './clinicadmin-plantreatmentschedule.component';
export const ClinicadminPlantreatmentscheduleRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminPlantreatmentscheduleComponent ,
    }
]

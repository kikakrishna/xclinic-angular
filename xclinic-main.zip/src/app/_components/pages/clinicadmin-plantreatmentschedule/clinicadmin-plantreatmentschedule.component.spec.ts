import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminPlantreatmentscheduleComponent } from './clinicadmin-plantreatmentschedule.component';

describe('ClinicadminPlantreatmentscheduleComponent', () => {
  let component: ClinicadminPlantreatmentscheduleComponent;
  let fixture: ComponentFixture<ClinicadminPlantreatmentscheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminPlantreatmentscheduleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminPlantreatmentscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';

@Component({
  selector: 'app-clinicadmin-deleteslider',
  templateUrl: './clinicadmin-deleteslider.component.html',
  styleUrls: ['./clinicadmin-deleteslider.component.css']
})
export class ClinicadminDeletesliderComponent implements OnInit {
  sliderDelete: boolean = false;
  constructor(private _formBuilder: FormBuilder,
    private _DoctorService: DoctorService,
    public dialogRef: MatDialogRef<ClinicadminDeletesliderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    }

  ngOnInit(): void {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  yessliders() {
  console.log(this.data)
    this._DoctorService
      .deleteslider(this.data)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.dialogRef.close({ data: res });
        } else {
          this.dialogRef.close({ data: res });
        }
      },
      err => {
          this.dialogRef.close({ data: err });
      });
  }

}

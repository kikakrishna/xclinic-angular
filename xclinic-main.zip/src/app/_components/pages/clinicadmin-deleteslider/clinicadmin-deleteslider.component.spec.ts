import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeletesliderComponent } from './clinicadmin-deleteslider.component';

describe('ClinicadminDeletesliderComponent', () => {
  let component: ClinicadminDeletesliderComponent;
  let fixture: ComponentFixture<ClinicadminDeletesliderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeletesliderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeletesliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

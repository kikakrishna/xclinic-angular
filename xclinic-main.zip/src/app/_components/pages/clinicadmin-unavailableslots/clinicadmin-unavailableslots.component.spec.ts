import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminUnavailableslotsComponent } from './clinicadmin-unavailableslots.component';

describe('ClinicadminUnavailableslotsComponent', () => {
  let component: ClinicadminUnavailableslotsComponent;
  let fixture: ComponentFixture<ClinicadminUnavailableslotsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminUnavailableslotsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminUnavailableslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

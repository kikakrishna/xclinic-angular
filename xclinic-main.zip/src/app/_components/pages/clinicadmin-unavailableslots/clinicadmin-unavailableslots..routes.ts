import { RouterModule } from '@angular/router';
import { ClinicadminUnavailableslotsComponent } from './clinicadmin-unavailableslots.component';
export const DoctorUnavailableslotsRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminUnavailableslotsComponent,
    }
]
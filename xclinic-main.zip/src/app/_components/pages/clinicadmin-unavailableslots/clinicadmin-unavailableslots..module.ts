import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import {
  MatMomentDateModule,
  MomentDateAdapter,
  MAT_MOMENT_DATE_FORMATS,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter';
import { MatDialogModule } from '@angular/material/dialog';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { DoctorUnavailableslotsRoutes } from './clinicadmin-unavailableslots..routes';
import { DoctorMarkavailabilityComponent } from '../doctor-markavailability/doctor-markavailability.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MY_DATE_FORMATS } from './my-date-formats';
import { ToastModule } from 'ng-uikit-pro-standard';
import { ClinicadminUnavailableslotsComponent } from './clinicadmin-unavailableslots.component';
import { ClinicadminMarkunavailabilityComponent } from '../clinicadmin-markunavailability/clinicadmin-markunavailability.component';

@NgModule({  
  declarations: [ClinicadminUnavailableslotsComponent,ClinicadminMarkunavailabilityComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(DoctorUnavailableslotsRoutes),
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    MatSelectModule,
    MatDatepickerModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatCheckboxModule,
    MatRadioModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  entryComponents: [ClinicadminMarkunavailabilityComponent],
  exports: [ClinicadminUnavailableslotsComponent],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { strict: true } },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },    
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },
    ]
})
export class ClinicadminUnavailableslotsModule { }

import { Component, OnInit, ViewChild ,OnDestroy} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { DoctorService } from '../../../_services/doctor.service';
import { first } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { ActivatedRoute } from '@angular/router';
import { ClinicadminMarkunavailabilityComponent } from '../clinicadmin-markunavailability/clinicadmin-markunavailability.component';
import { PatientService } from 'src/app/_services/patient.service';
@Component({
  selector: 'app-clinicadmin-unavailableslots',
  templateUrl: './clinicadmin-unavailableslots.component.html',
  styleUrls: ['./clinicadmin-unavailableslots.component.css']
})
export class ClinicadminUnavailableslotsComponent implements OnInit,OnDestroy {
  unavaliableDateslots_displayedColumns: string[] = ['date', 'days', 'clinic'];
  unavaliableTimeslots_displayedColumns: string[] = ['slot','consultancystatus','status'];
  unavaliableDateslots_dataSource: any = new MatTableDataSource<object>([]);
  unavaliableTimeslots_dataSource: any = new MatTableDataSource<object>([]);
  public clinicname: any = [];
  UnavailViewslots: FormGroup;
  lstsdate: any;
  lstedate: any;
  weekdays: any = []
  loading:boolean;
  myStartDate: any;
  myEndDate: any;
  getslotlistTempData: any = {};
  getselectedSlotlistTempData: any;
  selecteddate: any;
  Doctorid:any;
  selectedDoctor:any;
  appoinmenttype:any = [];
  chgconsultantiontypevar=0;
  clinicLocations: any = [];
  clinicId: any;
  videostatus: any;
  mappedLocation: any;
  @ViewChild('paginator', { read: MatPaginator }) paginator: MatPaginator;
  @ViewChild('paginator2', { read: MatPaginator }) paginator2: MatPaginator;
  constructor(public _activatedRoute:ActivatedRoute,public _formBuilder: FormBuilder, 
    public _patientservice:PatientService,
    public _DoctorService: DoctorService,
    public dialog: MatDialog,
    private toastrService: ToastService) {
    this.unavaliableDateslots_dataSource = new MatTableDataSource
    this.unavaliableTimeslots_dataSource = new MatTableDataSource
    this.UnavailViewslots = this._formBuilder.group({
      clinicname: [''],
      startdate: ['', Validators.required],
      enddate: ['', Validators.required],
      location: ['']
    });
  }
  ngOnInit(): void {
    this.selectedDoctor = JSON.parse(sessionStorage.getItem("selecteddoctor"));
    this.loading = true;
    this.videostatus = sessionStorage.getItem('videostatus');
    this._activatedRoute.paramMap.subscribe(params => {
      this.Doctorid = +params.get('doctorid');
    });
    this.myStartDate = new Date();
    this.UnavailViewslots.controls.enddate.disable();
    this.unavaliableDateslots_dataSource.paginator = this.paginator;
    this.unavaliableTimeslots_dataSource.paginator = this.paginator2;
    this._DoctorService.getcliniclist()
      .pipe(first())
      .subscribe((res: any) => {

        if (!res.isError) {
          this.loading = false;
          this.clinicname = res.responseMessage;
          this.UnavailViewslots.get('clinicname').setValue(res.responseMessage[0].clinicId);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });

      // this._DoctorService.getappoinmenttype()
      this._patientservice.getpaymentType_Notwalkin()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.appoinmenttype.length =0;
          this.loading = false;          
          res.responseMessage.push({appointmentTypeId:0,appointmentTypeName:"Both",appoinmentlabel:"Both"});                    
          for(let i of res.responseMessage){
            if(i.appointmentTypeName == "Video Consultation"){
              i.appoinmentlabel = "Video"
            }
            if(i.appointmentTypeName == "Clinic Visit"){
              i.appoinmentlabel = "Clinic Visit"
            }
          }          
          this.appoinmenttype = res?.responseMessage;
        
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
      this.getClinicLocations();
  }
  getClinicLocations(){      
    // Get clinic locations
    this.clinicId = sessionStorage.getItem('clinicId');
    this._DoctorService.getclinicLocations(this.clinicId)
    .pipe(first())
    .subscribe((res: any) => {
      if(!res.isError){
        console.log(res)
        this.clinicLocations = res.responseMessage;
        console.log(this.clinicLocations)
      }
      else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
      }
    }, err => {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', err?.error, options);
    })
}
  dateenabled() {
    this.UnavailViewslots.controls.enddate.reset();
    if (this.UnavailViewslots.value.startdate != "") {
      this.UnavailViewslots.controls.enddate.enable();
    }
  }
  datevalidation() {
    if (this.UnavailViewslots.value.startdate == "") {
      this.UnavailViewslots.controls.enddate.disable();
      return;
    }
    this.myEndDate = this.UnavailViewslots.value.startdate;
  }

  statchanged(sId, slotstate) {
    this.loading = true;
    this._DoctorService.slotchangestate(sId, slotstate)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);     
          // this.getslotlistTemp();
          this.Changeconsultationtype()
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // this.getslotlistTemp();
          this.Changeconsultationtype()
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  getselectedSlotlist2(data) {
    if (data) {
      var array = [];
      for(let item of data?.slots){
        item.clinicName = data.clinicName;
        item.clinicId = data.clinicId;
        array.push(item);
      }
      this.unavaliableTimeslots_dataSource = new MatTableDataSource(array);
      this.getselectedSlotlistTempData = data;
      setTimeout(() => {
        this.unavaliableTimeslots_dataSource.paginator = this.paginator2
        if (this.unavaliableTimeslots_dataSource.paginator) {
          this.unavaliableTimeslots_dataSource.paginator.firstPage();
        }   
      });
      this.selecteddate = data.date;
      this.chgconsultantiontypevar=0;       
    }
  }
  getselectedSlotlist(data) {
    if (data) {
      var array = [];
      for(let item of data?.slots){
        item.clinicName = data.clinicName;
        item.clinicId = data.clinicId;
        array.push(item);
      }
      this.unavaliableTimeslots_dataSource = new MatTableDataSource(array);
      this.getselectedSlotlistTempData = data;
      setTimeout(() => {
        this.unavaliableTimeslots_dataSource.paginator = this.paginator2
      });
      this.selecteddate = data.date;
    }
  }
  getRecord(sdata){
    return this.selecteddate === sdata;
  }
  getslotlist() {    
    this.chgconsultantiontypevar=0;    
    let array = [];
    this.loading = true;
    const listsdate = this.UnavailViewslots.value.startdate;
    const getstdate = moment(listsdate).format();
    this.lstsdate = getstdate.substr(0, 19);
    const listedate = this.UnavailViewslots.value.enddate;
    const getedate = moment(listedate).format();
    this.lstedate = getedate.substr(0, 19);
    this.getslotlistTempData.startdate = this.lstsdate;
    this.getslotlistTempData.enddate = this.lstedate;
    this.getslotlistTempData.clinicname = this.UnavailViewslots.value;
    if(this.UnavailViewslots.value.location == "") {
      // this.setcliniclocationDefault();
      this.mappedLocation = "";
    } else {
      this.mappedLocation = this.UnavailViewslots.value.location;
    }
    this._DoctorService.addslotlist2(this.lstsdate, this.lstedate, this.UnavailViewslots.value,this.Doctorid, this.mappedLocation)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let item of res?.responseMessage[0]?.byDate) {
            item.formatedDate = moment(item?.date).format('ll');     
            array.push(item)
          }
          this.unavaliableDateslots_dataSource = new MatTableDataSource(array);
          
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.unavaliableDateslots_dataSource.paginator = this.paginator);
      })
  }
  getslotlistTemp() {
    this.loading = true;
    let array = [];
    this.unavaliableDateslots_dataSource.length = 0;
    this._DoctorService.addslotlist2(this.getslotlistTempData?.startdate, this.getslotlistTempData?.enddate, this.getslotlistTempData?.clinicname,this.Doctorid, this.mappedLocation)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let item of res?.responseMessage[0]?.byDate) {
            item.formatedDate = moment(item?.date).format('ll');     
            array.push(item)
          }
          this.unavaliableDateslots_dataSource = new MatTableDataSource(res?.responseMessage[0]?.byDate);
          console.log(res?.responseMessage[0]?.byDate, "***SLOTS **")
          if (res?.responseMessage[0]?.byDate?.length == 0) {
            console.log("NO slot data");
            this.selecteddate = '';
            this.unavaliableTimeslots_dataSource = new MatTableDataSource<object>([]);
            return;
          }
          for (let items of res?.responseMessage[0]?.byDate) {
            if (items?.date === this.getselectedSlotlistTempData?.date) {
              if (items?.slots?.length != 0) {
                this.getselectedSlotlist(items);
              }
            }
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.unavaliableDateslots_dataSource.paginator = this.paginator);
      })
  }
  markunavailablity() {
    const dialogRef = this.dialog.open(ClinicadminMarkunavailabilityComponent, {
      width: '100%',
      data:this.Doctorid
    });
  }
  setchoosedoc:boolean;
  setchoosendoctor(){
    this.setchoosedoc = true;
  }
  ngOnDestroy(){    
  }
  Changeconsultationtype(){
    if(!this.getslotlistTempData?.startdate || !this.getslotlistTempData?.enddate || !this.getslotlistTempData.clinicname || !this.getselectedSlotlistTempData){
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Select Date", options);
      return;
    }

    this.loading = true;
    let array = [];
    // this.unavaliableDateslots_dataSource.length = 0;
    this._DoctorService.addslotlistConsultationtypeforclinicadmin(this.selecteddate,this.selecteddate,this.getslotlistTempData?.clinicname,this.Doctorid,this.chgconsultantiontypevar)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let item of res?.responseMessage[0]?.byDate) {
            item.formatedDate = moment(item?.date).format('ll');     
            array.push(item)
          }
          // this.unavaliableDateslots_dataSource = new MatTableDataSource(res?.responseMessage[0]?.byDate);
          console.log(res?.responseMessage[0]?.byDate, "***SLOTS **")
          if (res?.responseMessage[0]?.byDate?.length == 0) {
            console.log("NO slot data");
             this.selecteddate = '';
            this.unavaliableTimeslots_dataSource = new MatTableDataSource<object>([]);
            return;
          }
          for (let items of res?.responseMessage[0]?.byDate) {
            if (items?.date === this.getselectedSlotlistTempData?.date) {
              if (items?.slots?.length != 0) {
                this.getselectedSlotlist(items);
              }
            }
          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
      .add(() => {
        setTimeout(() => this.unavaliableDateslots_dataSource.paginator = this.paginator);
      })    
      }
}

import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { PatientService } from 'src/app/_services/patient.service';
import { ShareDataService } from 'src/app/_services/sharedata.service';
import { WindowRefService } from 'src/app/_services/window-ref.service';
declare var $: any;
@Component({
  selector: 'app-clinic-admin-bookingdetail',
  templateUrl: './clinic-admin-bookingdetail.component.html',
  styleUrls: ['./clinic-admin-bookingdetail.component.css']
})
export class ClinicAdminBookingdetailComponent implements OnInit {
  loading: boolean;
  paymethodlist: any = [];
  cardpaymentform: boolean;
  Insuranceform: FormGroup;
  user_id: string;
  pat_id: string;
  ord_id: any;
  sign: any;
  parentaId: any;
  pAId: number;
  slotimeid: any;
  sloterrormsg: boolean;
  maxdate = new Date();
  stdate: string;
  blckbtn:boolean = false;
  forbiddenmessagebox: boolean;
  messagecontent: any;
  pay_id: any;
  consFess: number;
  checkproerror: boolean;
  messagecontentflag: any;
  navigateflag: any;
  errormessagebox: boolean;
  mobilenumber: any;
  razorinfo: any;
  checkpro: any;
  masteruser_id: string;
  docdetails: any;
  docdClinicVisit: any;
  followupdetails = null;
  myfollowupdetails: any = ""
  apptdetails: any = "";
  patdetails: any;
  patLocaDetail: any;
  finalFee: any;
  clinicID: any;
  doctorimage: any;
  docimage: any;
  cashpaymentform: boolean;
  docid: any;
  cliname: any;
  specid: any;
  odId: any;
  skey: any;
  paymentId: any;
  orderId: any;
  signature: any;
  razorpaymentform: boolean;
  activepaymethod: any;
  availablepaymethods: any;
  freeapptform: boolean;
  insuranceform: boolean;
  newArray: any = [];
  apptid: any;
  successection: boolean;
  paymentsection: boolean;
  resposnsedata: any;
  methodtype: any;
  searchspecial: any;
  searchdoc: any;
  searchdocspecial: any;
  searchddates: any;
  searchdoctordates: any;
  parentGroup: FormGroup;
  consultationType: any;
  pageCheck: any;
  consultationType_walkin = "";
  walkin_appoinmentDate;
  selectedconsultationtype;
  disabledIswalkin: boolean = false;
  constructor(private _formBuilder: FormBuilder, private _patientservice: PatientService, private ngZone: NgZone,
    private toastrService: ToastService, private router: Router,
    private sharedataService: ShareDataService,
    private winRef: WindowRefService,) { }

  ngOnInit(): void {
     this.loadScript();
    this.Insuranceform = this._formBuilder.group({
      appointtype: ['online'],
      insuranceNumber: ['', [Validators.required]],
      insuranceProvider: ['', [Validators.required]],
      validity: ['', [Validators.required]],
      insurarname: ['', [Validators.required]],
    });

    this.parentGroup = this._formBuilder.group({
      'radio-group1': [''],
    });

    this.successection = false;
    this.paymentsection = true;
    //console.log("///////////////////////////////",this.sharedataService?.finalFee)
    this.docdetails = this.sharedataService?.clinicadminDoctordetails;
    this.apptdetails = this.sharedataService?.clinicadminAppointmentdetails;
    this.docdClinicVisit =this.sharedataService?.clinicadminDoctordetails?.fees?.cvfList;

    this.patdetails = this.sharedataService?.clinicadminPatientdetails;
    this.patLocaDetail = this.sharedataService?.locMapid;
    this.finalFee = this.sharedataService?.finalFee;

    this.clinicID = this.docdetails?.clinicId;
    this.stdate = this.apptdetails?.slotTime;
    this.slotimeid = this.apptdetails?.appointmentslotId;
    // this.consFess = this.docdetails?.doctorFee;
    this.docid = this.docdetails?.doctorId;
    this.cliname = this.docdetails?.clinicName;
    this.specid = this.docdetails?.specialityId;
    this.doctorimage = this.docdetails?.doctorProfileURL;
    if (this.doctorimage != 'null' || this.doctorimage != '') {
      this.docimage = this.doctorimage;
    }
    else {
      this.docimage = "./assets/images/noimage.webp"
    }
    this.cardpaymentform = false;
    this.cashpaymentform = false;
    this.freeapptform = false;
    this.insuranceform = false;
    this.user_id = sessionStorage.getItem('userId');
    this.masteruser_id = sessionStorage.getItem('masteruserId');

    $('.payment-methods input:radio').change(function () {
      // Only remove the class in the specific `box` that contains the radio
      $('label.highlight').removeClass('highlight');
      $(this).closest('.row').addClass('highlight');
    });
    
    if (this.apptdetails?.userSelectedconsultationType == 1) {
      this.selectedconsultationtype = 'online';
      this.consFess = this.docdetails.fees.domesticConsultation;
    }
     if (this.apptdetails?.userSelectedconsultationType == 102) {
      this.docdetails?.fees?.wfList.map((cwdata) =>{
         if(cwdata.cliniclocationmapId == this.patLocaDetail){
            this.selectedconsultationtype = 'walk_in';
            this.consFess = cwdata.walkinfee;
            this.consultationType_walkin = this.apptdetails?.consultationtype;
         }
      })
    }
    if (this.apptdetails?.userSelectedconsultationType == 2) {
      this.docdetails?.fees?.cvfList.map((cvdata) =>{
         if(cvdata.cliniclocationmapId == this.patLocaDetail){
            this.selectedconsultationtype = 'visit_to_clinic';
            this.consFess = cvdata.clinicVisitFee;
         }
      })
    }

    // else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 2) {
     // this.selectedconsultationtype = 'walk_in';
     // this.consFess = this.docdetails?.fees?.wfList[1].walkinfee;
     // this.consultationType_walkin = this.apptdetails?.consultationtype;
    //} 

    //else if (this.apptdetails?.userSelectedconsultationType == 2 && this.patLocaDetail == 1) {
     // this.selectedconsultationtype = 'visit_to_clinic';
     // this.consFess = this.docdetails?.fees?.cvfList[0].clinicVisitFee;
     // } 
    else {
     // this.selectedconsultationtype = 'visit_to_clinic';
     // this.consFess = this.docdetails?.fees?.cvfList[1].clinicVisitFee;
    }


    if (this.apptdetails?.userSelectedconsultationType == 102) {
      // alert("walkin")
      this.disabledIswalkin = false;
    } else {
      // alert("not walkin")
      this.disabledIswalkin = true;
    }
    this.loadpaymentmethods()
    this._patientservice.checkprofile2(this.patdetails.userId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.checkpro = res.responseMessage;
          this.loading = true;
          console.log(this.patdetails.userId, "******")
          this._patientservice.patientdetail(this.patdetails.userId)
            .pipe(first())
            .subscribe((res: any) => {
              console.log('Raor response..... ', res)
              if (!res.isError) {
                this.loading = false;
                this.razorinfo = res.responseMessage;
                // this.mobilenumber = res?.responseMessage?.mobileNumber
                this.mobilenumber = sessionStorage.getItem("mobilenumber")

              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
                this.loading = false;
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            }, err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
        } else {
          this.checkproerror = true;
          this.messagecontentflag = res.errorMessage;
          this.navigateflag = res.responseMessage;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.forbiddenmessagebox = true;
          this.messagecontent = err.error;
        });

    this.listInsuranceProvider();
  }

  // load checkout script
  public loadScript() {        
    var isFound = false;
    var scripts = document.getElementsByTagName("script")
    for (var i = 0; i < scripts.length; ++i) {
        if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
            isFound = true;
        }
    }

    if (!isFound) {
        var dynamicScripts = ["https://checkout.razorpay.com/v1/checkout.js"];
        for (var i = 0; i < dynamicScripts.length; i++) {
            let node = document.createElement('script');
            node.src = dynamicScripts [i];
            node.type = 'text/javascript';
            node.async = false;
            node.charset = 'utf-8';
            document.getElementsByTagName('head')[0].appendChild(node);
        }
    }
}

  loadpaymentmethods() {
    this.paymethodlist.length = 0;
    this._patientservice.loadpaymentmethods()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res);
        if (!res.isError) {
          this.loading = false;
          this.paymethodlist = res.responseMessage;
          console.log(res.responseMessage)
          this._patientservice.activeclinicpayment(this.docdetails?.clinicId)
            .pipe(first())
            .subscribe((res: any) => {
              if (!res.isError) {
                console.log(res);
                if (this.apptdetails.consultationtype == 2) {
                  this.availablepaymethods = res.responseMessage.clinicVisitPaymentDetails;
                } else {
                  this.availablepaymethods = res.responseMessage.onlinePaymentDetails;
                }
                console.log(this.availablepaymethods);
                // this.availablepaymethods = res.responseMessage.paymentDetails;
                for (let i = 0; i < this.paymethodlist.length; i++) {
                  var ismatch = false;
                  for (let j = 0; j < this.availablepaymethods.length; j++) {
                    if (this.paymethodlist[i].paymentMethodId == this.availablepaymethods[j].paymentMethodId) {
                      ismatch = true;
                      this.paymethodlist[i].showDateInput = false;
                      this.newArray.push(this.paymethodlist[i]);
                      break;
                    }
                  }
                  if (!ismatch) {
                    this.paymethodlist[i].showDateInput = true;
                    this.paymethodlist[i].mychecked2 = false;
                    this.newArray.push(this.paymethodlist[i]);
                  }

                  //End if
                }
                console.log(this.newArray)
              } else {
                console.log('error');
              }
            },
              err => {
                console.log('error2');
              });
        } else {
          console.log('error');
        }
      },
        err => {
          console.log('error2');
        });
  }


  onItemChange(paymethod) {
    console.log(paymethod)
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.methodtype = paymethod.paymentMethodReferenceName;

    if (paymethod.paymentMethodReferenceName === 'razorpay') {
      this.cashpaymentform = false;
      this.cardpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'cash') {
      this.cardpaymentform = false;
      this.cashpaymentform = true;
      this.freeapptform = false;
      this.insuranceform = false;
    }
    else if (paymethod.paymentMethodReferenceName === 'free_service') {
      this.freeapptform = true;
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.insuranceform = false;
    }
    else {
      this.cardpaymentform = false;
      this.cashpaymentform = false;
      this.freeapptform = false;
      this.insuranceform = true;
    }
  }


  isActive(item) {
    return this.methodtype === item.paymentMethodReferenceName;
  }


  imgfile: any;
  uploadFile(event) {
    let reader = new FileReader(); // HTML5 FileReader API
    let file = event.target.files[0];
    console.log(file)
    this.imgfile = event.target.files[0];
    console.log(this.imgfile)
    this.filevalidation = false;
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
      }
    }
  }
  clearfreeapptform() {
  this.blckbtn = false;
    this.freeapptform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcashpayment() {
  this.blckbtn = false;
    this.cashpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearinsurance() {
  this.blckbtn = false;
    this.Insuranceform.reset();
    this.imgfile = undefined;
    this.insuranceform = false;
    this.parentGroup.controls['radio-group1'].reset();
    this.isActive('');
  }
  clearcardpayment() {
  this.blckbtn = false;
    this.cardpaymentform = false;
    this.parentGroup.controls['radio-group1'].reset();
    let item = [];
    this.isActive(item);
  }
  filevalidation: boolean;
  consultationTypeText

  submitappointment(paytype) {
   this.blckbtn = true;
    if (this.apptdetails?.userSelectedconsultationType == 1) {
      this.consultationTypeText = 'online';
      this.consFess = this.docdetails.fees.domesticConsultation;
    } 

if (this.apptdetails?.userSelectedconsultationType == 102) {
      this.docdetails?.fees?.wfList.map((cwdata) =>{
         if(cwdata.cliniclocationmapId == this.patLocaDetail){
            this.consultationTypeText = 'walk_in';
            this.consFess = cwdata.walkinfee;
         }
      })
    }
     if (this.apptdetails?.userSelectedconsultationType == 2) {
      this.docdetails?.fees?.cvfList.map((cvdata) =>{
         if(cvdata.cliniclocationmapId == this.patLocaDetail){
            this.consultationTypeText = 'visit_to_clinic';
            this.consFess = cvdata.clinicVisitFee;
         }
      })
    }


  //  else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 1) {
    //  this.consultationTypeText = 'walk_in';
      //this.consFess = this.docdetails?.fees?.wfList[0].walkinfee;
    //} else if (this.apptdetails?.userSelectedconsultationType == 102 && this.patLocaDetail == 2) {
      //this.consultationTypeText = 'walk_in';
      //this.consFess = this.docdetails?.fees?.wfList[1].walkinfee;
    //} else if (this.apptdetails?.userSelectedconsultationType == 2 && this.patLocaDetail == 1) {
      //this.consultationTypeText = 'visit_to_clinic';
      //this.consFess = this.docdetails?.fees?.cvfList[0].clinicVisitFee;
   // }
    // else {
      //this.consultationTypeText = 'visit_to_clinic';
      //this.consFess = this.docdetails?.fees?.cvfList[1].clinicVisitFee;
    //}

    this.docid = this.docdetails?.doctorId;
    this.cliname = this.docdetails?.clinicName;
    this.specid = this.docdetails?.specialityId;
    this.mobilenumber = this.patdetails?.mobileNumber;

    let meta = this
    if (this.apptdetails?.userSelectedconsultationType == 102 && this.consultationTypeText == "walk_in" && this.apptdetails?.IsWalkselectedtype == "no_slot_walkin") { 
      if (paytype == "insurance") {
        // alert("walkin ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined) {
          this.filevalidation = true;
          this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsuranceinsurance.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.specid);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.mobilenumber);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('CliniclocMapid', this.patLocaDetail);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.paymentsection = false;
                this.blckbtn = false;
                const dt = this.maxdate.toISOString();                
                setTimeout(() => {
                  if (this.stdate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        let insurancedoctorfee
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataPaymentWalkin.append('PatientId', this.patdetails?.userId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.mobilenumber);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);
        formDataPaymentWalkin.append('CliniclocMapid', this.patLocaDetail);
        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              // this.SelectedSlotDet = "";
              this.apptid = res.responseData;
              this.successection = true;
              this.paymentsection = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const dt = this.maxdate.toISOString();   
              this.blckbtn = false;             
              setTimeout(() => {
                if (this.stdate > dt) {
                  this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                } else {
                  this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                }
              }, 2000);
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    } else if (this.apptdetails?.userSelectedconsultationType == 102 && this.consultationTypeText == "walk_in" && this.apptdetails?.IsWalkselectedtype == "slot_walkin") { 
      if (paytype == "insurance") {
        // alert("walkin  slot ,insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined) {
          this.filevalidation = true;
             this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        const formDataInsuranceinsurance: FormData = new FormData();
        formDataInsuranceinsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsuranceinsurance.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataInsuranceinsurance.append('Comments', "Regularcheckup");
        formDataInsuranceinsurance.append('Firstname', "");
        formDataInsuranceinsurance.append('Lastname', "");
        formDataInsuranceinsurance.append('DoctorId', this.docid);
        formDataInsuranceinsurance.append('SpecilalityId', this.specid);
        formDataInsuranceinsurance.append('Email', "");
        formDataInsuranceinsurance.append('Mobile', this.mobilenumber);
        formDataInsuranceinsurance.append('PaymentMethod', "Insurance");
        formDataInsuranceinsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsuranceinsurance.append('BookingType', "regular");
        formDataInsuranceinsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsuranceinsurance.append('CliniclocMapid', this.patLocaDetail);
        formDataInsuranceinsurance.append('OrderId', this.ord_id);
        formDataInsuranceinsurance.append('PaymentId', this.pay_id);
        formDataInsuranceinsurance.append('Signature', this.sign);
        formDataInsuranceinsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsuranceinsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsuranceinsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsuranceinsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsuranceinsurance.append('Cardimagepath', this.imgfile);
        formDataInsuranceinsurance.append('PatientId', this.pat_id);
        this._patientservice.paymentsubmit_WalkIn(formDataInsuranceinsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              this.successection = true;
              this.paymentsection = false;
              this.blckbtn = false;
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";                
                const dt = this.maxdate.toISOString();                
                setTimeout(() => {
                  if (this.stdate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess
        // alert("walkin ,cash free")
        const formDataPaymentWalkin: FormData = new FormData();
        formDataPaymentWalkin.append('AppointmentType', this.consultationTypeText);
        formDataPaymentWalkin.append('AppointmentDate', this.apptdetails?.slotTime);
        formDataPaymentWalkin.append('PatientId', this.patdetails?.userId);
        formDataPaymentWalkin.append('DoctorId', this.docid);
        formDataPaymentWalkin.append('ClinicName', this.cliname);
        formDataPaymentWalkin.append('SpecilalityId', this.specid);
        formDataPaymentWalkin.append('Mobile', this.mobilenumber);
        formDataPaymentWalkin.append('paymentMethod', paytype);
        formDataPaymentWalkin.append('BookingType', "regular");
        formDataPaymentWalkin.append('AppoinmentSlotid', this.slotimeid);
        formDataPaymentWalkin.append('DoctorFee', insurancedoctorfee);
        formDataPaymentWalkin.append('CliniclocMapid', this.patLocaDetail);
        this._patientservice.paymentsubmit_WalkIn(formDataPaymentWalkin)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              // this.SelectedSlotDet = "";   
              this.apptid = res.responseData;           
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
              const dt = this.maxdate.toISOString();    
              this.successection = true;
              this.paymentsection = false;
              this.blckbtn = false;            
              setTimeout(() => {
                if (this.stdate > dt) {
                  this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                } else {
                  this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                }
              }, 2000);
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
            });
      }
    }
    else { 
      if (paytype == "insurance") {
        // alert(" online offline , insurance")
        if (this.Insuranceform.value.insuranceNumber == "" || this.Insuranceform.value.insuranceProvider == "" ||
          this.Insuranceform.value.validity == "" || this.Insuranceform.value.insurarname == "" || this.imgfile == undefined) {
          this.filevalidation = true;
             this.blckbtn = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please Fill all Mandatory Fields", options);
          return;
        }
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        console.log(this.Insuranceform.value)
        let insurancedoctorfee;
        insurancedoctorfee = this.consFess.toString()
        const formDataInsurance: FormData = new FormData();
        formDataInsurance.append('AppointmentType', this.consultationTypeText);
        formDataInsurance.append('AppointmentDate', this.stdate);
        formDataInsurance.append('Comments', "Regularcheckup");
        formDataInsurance.append('Firstname', "");
        formDataInsurance.append('Lastname', "");
        formDataInsurance.append('DoctorId', this.docid);
        formDataInsurance.append('SpecilalityId', this.specid);
        formDataInsurance.append('Email', "");
        formDataInsurance.append('Mobile', this.mobilenumber);
        formDataInsurance.append('PaymentMethod', "Insurance");
        formDataInsurance.append('AppoinmentSlotid', this.slotimeid);
        formDataInsurance.append('BookingType', "regular");
        formDataInsurance.append('DoctorFee', insurancedoctorfee);
        formDataInsurance.append('CliniclocMapid', this.patLocaDetail);
        formDataInsurance.append('OrderId', this.ord_id);
        formDataInsurance.append('PaymentId', this.pay_id);
        formDataInsurance.append('Signature', this.sign);
        formDataInsurance.append('InsuranceproviderProviderid', this.Insuranceform.value.insuranceProvider);
        formDataInsurance.append('Insurerid', this.Insuranceform.value.insuranceNumber);
        formDataInsurance.append('Insurername', this.Insuranceform.value.insurarname);
        formDataInsurance.append('Validity', this.Insuranceform.value.validity.toISOString());
        formDataInsurance.append('Cardimagepath', this.imgfile);
        formDataInsurance.append('PatientId', this.pat_id);

        this._patientservice.paymentsubmitForInsurance(formDataInsurance)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.success('', res?.responseMessage, options);
                // this.followupdetails = "";
                this._patientservice.Followupdoctordetails = "";
                this.successection = true;
                this.paymentsection = false;
                this.blckbtn = false;
                const dt = this.maxdate.toISOString();                
                setTimeout(() => {
                  if (this.stdate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);

              });
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
      } else {
        // alert("online offline , cash and free")
        this.loading = true;
        this.pat_id = this.patdetails?.userId;
        this.pay_id = null;
        this.ord_id = null;
        this.sign = null;
        const payment = paytype;
        const aptmnt = {
          appointtype: this.consultationTypeText,
          comment: "",
          fname: "",
          lname: "",
          doctor: this.docid,
          clinic: this.cliname,
          speciality: this.specid,
          email: "",
          mobile: "",
          dateofappointment: "",
          timeslot: "",
          paymentid: ""
        }
        let parentappid = "";
        this._patientservice.paymentsubmit(aptmnt, this.stdate, this.pat_id, this.slotimeid, this.pay_id, this.ord_id, this.sign, this.consFess, payment, this.mobilenumber, parentappid,this.patLocaDetail)
          .pipe(first())
          .subscribe((res: any) => {
            console.log(res);
            if (!res.isError) {
              console.log(res);
              this.resposnsedata = res;
              this.apptid = res.responseData;
              this.sloterrormsg = false;
              this.loading = false;
              this.mobilenumber = "";
              // this.SelectedSlotDet = "";
              meta.ngZone.run(() => {
                this.successection = true;
                this.paymentsection = false;
                const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                // const dt = moment(this.maxdate).format('MM/DD/YYYY');
                const dt = this.maxdate.toISOString();  
                this.blckbtn = false;              
                setTimeout(() => {
                  if (this.stdate > dt) {
                    this.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                  } else {
                    this.router.navigate(['/thealth/clinicadmin/appointments/today'])
                  }
                }, 2000);
              });
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res.responseMessage, options);
            }
            else {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              this.loading = false;
              this.sloterrormsg = false;
            }
          },
            err => {
               this.blckbtn = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err.error, options);
              this.loading = false;
              this.sloterrormsg = false;
              this.forbiddenmessagebox = true;
              this.messagecontent = err.error;
            });
          }
        }
      }

  listinsuranceproviderArray: any = [];
  listInsuranceProvider() {
    this._patientservice.getInsturanceProvider()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        this.listinsuranceproviderArray = res.responseMessage
      }, err => {
      })
  }

  initPay() {
  this.blckbtn = true;
    if (this.consultationType_walkin == "102") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
         this.blckbtn = false;
      this.toastrService.warning('', "Rayzor Not Applicable for Walk-In", options);
      return;
    }
    if (this.apptdetails?.userSelectedconsultationType == 1) {
      this.consultationTypeText = 'online';
      // this.consFess = this.docdetails.fees?.domesticConsultation;
    }
    if (this.apptdetails?.userSelectedconsultationType == 102) {
      this.consultationTypeText = 'walk_in';
      // this.consFess = this.docdetails.fees?.walkInFee;
    }
    if (this.apptdetails?.userSelectedconsultationType == 2) {
      this.consultationTypeText = 'visit_to_clinic';
      // this.consFess = this.docdetails.fees?.clinicVisitConsultationFee;
    }

    this.user_id = sessionStorage.getItem('userId');
    console.log('pay details... ',this.consFess, this.docid, this.clinicID, this.user_id, "*******", this.slotimeid)
    if (!this.slotimeid || this.slotimeid === 'undefined') {
      this.sloterrormsg = true;
      this.loading = false;
    } else {
      this.sloterrormsg = false;
      this._patientservice.emailinitpay(this.consFess, this.docid, this.clinicID, this.user_id)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res);
          if (!res.isError) {
            this.odId = res.responseMessage;
            this.skey = res.responseData
            this.blckbtn = false;
            this.payWithRazor(this.odId, this.skey);
          }
          else {
            this.errormessagebox = true;
               this.blckbtn = false;
            this.messagecontent = res.errorMessage;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
             this.blckbtn = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
            this.forbiddenmessagebox = true;
            this.messagecontent = err.error;
          });
    }
  }
  cleardata() {
    this.apptdetails = ""
    this.consultationType_walkin = ""
  }
  // for testing
  payWithRazor(oid, sk) {
    console.log(this.consultationTypeText);
    let razorpaydescription = ""
    this.pat_id = this.patdetails.userId;
    let meta = this
    if (this.myfollowupdetails &&
      this.myfollowupdetails.mybookfollowup == true &&
      this.myfollowupdetails.followUp.parentAppointmentId) {
      razorpaydescription = "Followup Fee";
    } else {
      razorpaydescription = "Consultation Fee";
    }
    const options: any = {
      key: sk,
      amount: this.consFess * 100, // amount should be in paise format to display Rs 1255 without decimal point
      currency: 'INR',
      name: 'ClinaNG', // company name or product name
      description: razorpaydescription,  // product description
      // description: 'Consultation Fee',  // product description
      image: './assets/images/clina-blue.webp', // company logo or product image
      order_id: oid, // order_id created by you in backend
      modal: {
        // We should prevent closing of the form when esc key is pressed.
        escape: false,
      },
      notes: {
        // include notes if any
      },
      theme: {
        color: '#0c238a'
      }
    };
    console.log(options)
    options.handler = ((response, error) => {
      options.response = response;
      this.paymentId = response.razorpay_payment_id;
      this.orderId = response.razorpay_order_id;
      this.signature = response.razorpay_signature;

      if (response.razorpay_payment_id && response.razorpay_order_id && response.razorpay_signature) {
        this.loading = true;
        if (!this.slotimeid || this.slotimeid === 'undefined') {
          this.sloterrormsg = true;
          this.loading = false;
        }
        else {
          const payment = 'RazorPay';
          if (this.parentaId != 0) {
            this.pAId = this.parentaId;
          } else {
            this.pAId = 0;
          }
          const aptmnt = {
            appointtype: this.consultationTypeText,
            comment: "",
            fname: "",
            lname: "",
            doctor: this.docid,
            clinic: this.cliname,
            speciality: this.specid,
            email: "",
            mobile: "",
            dateofappointment: "",
            timeslot: "",
            paymentid: ""
          }
          let parentappid = "";
          if (this.myfollowupdetails &&
            this.myfollowupdetails.mybookfollowup == true &&
            this.myfollowupdetails.followUp.parentAppointmentId) {
            parentappid = this.myfollowupdetails.followUp.parentAppointmentId
          }
          this._patientservice.paymentsubmit(aptmnt, this.stdate, this.pat_id, this.slotimeid, this.paymentId, this.orderId, this.signature, this.consFess, payment, this.mobilenumber, parentappid, this.patLocaDetail)
            .pipe(first())
            .subscribe((res: any) => {
              console.log(res);
              if (res && !res.isError) {
                this.resposnsedata = res;
                this.apptid = res.responseData;
                this.loading = false;
                this.sloterrormsg = false;
                this.followupdetails = "";
                this.sharedataService.reschefollowdetails = "";
                this.sharedataService.followupdet = "";
                this._patientservice.Followupdoctordetails = "";
                this.myfollowupdetails = ""
                sessionStorage.removeItem("followupdetails");
                this.sharedataService.rescheduledocdetails('');
                this.sharedataService.searchdats = "";
                this.sharedataService.searchdates('');
                this.sharedataService.searchspeciality = '';
                this.sharedataService.searchspecial('');
                this.sharedataService.searchdoctor = '';
                this.sharedataService.searchdoc('');
                this.sharedataService.docspeciality = "";
                this.sharedataService.searchdocspeciality('');
                this.sharedataService.docdate = "";
                this.sharedataService.searchdocdate('');
                this.sharedataService.docspecdate = "";
                this.sharedataService.searchdocspecdate('');
                this.sharedataService.specdate = '';
                this.sharedataService.searchspecdate('');
                this.sharedataService.ResheclinicadminAppointmentdetails = ""
                this.sharedataService.ResheclinicadminDoctordetails = ""
                this.sharedataService.ResheclinicadminPatientdetails = ""
                this.sharedataService.clinicadminconsulatationType = "";
                this.consultationType_walkin = "";
                sessionStorage.removeItem("specialityId")
                // meta.ngZone.run(() => {
                //   this.successection = true;
                //   this.paymentsection = false;
                // });

                meta.ngZone.run(() => {
                  this.successection = true;
                  this.paymentsection = false;
                  const slotDate = moment(this.stdate).format('MM/DD/YYYY');
                  const dt = moment(this.maxdate).format('MM/DD/YYYY');
                  this.blckbtn = false;
                  setTimeout(() => {
                    if (slotDate > dt) {
                      meta.router.navigate(['/thealth/clinicadmin/appointments/upcoming']);
                    } else {
                      meta.router.navigate(['/thealth/clinicadmin/appointments/today'])
                    }
                  }, 3000);
                });

                this.sharedataService.setSuccessmsg(res.responseMessage);
              }
              else {
                 this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res?.errorMessage, options);
                this.sloterrormsg = false;
                if (this.errormessagebox) {
                  this.loading = false;
                }
                this.errormessagebox = true;
                this.messagecontent = res.errorMessage;
              }
            },
              err => {
                 this.blckbtn = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
                this.sloterrormsg = false;
                this.forbiddenmessagebox = true;
                this.messagecontent = err.error;
                if (this.forbiddenmessagebox) {
                  this.loading = false;
                }
              });
        }
      }
      // call your backend api to verify payment signature & capture transaction
    });
    options.prefill = {
      name: this.razorinfo.firstName,
      email: this.razorinfo.eMail,
      contact: this.razorinfo.mobileNumber
    },
      options.modal.ondismiss = (() => {
        // handle the case when user closes the form while transaction is in progress
      });
    const rzp = new this.winRef.nativeWindow.Razorpay(options);
    rzp.open();
  }

  changeDateFunction(docdetails) {
    this.sharedataService.ResheclinicadminAppointmentdetails = this.apptdetails;
    this.sharedataService.ResheclinicadminDoctordetails = docdetails;
    this.sharedataService.ResheclinicadminPatientdetails = this.patdetails;
    this.sharedataService.Resheclinicadminwalkinconsultation = this.consultationType_walkin
    // this.consultationType_walkin = this.sharedataService?.clinicadminconsulatationType;
    
    this.sharedataService.locMapid = this.patLocaDetail;

    this.sharedataService.clinicadminconsulatationType = "";
    console.log(this.patdetails["patient_params"])
    sessionStorage.setItem('changedate','yes')

    this.router.navigate(['/thealth/clinicadmin/patients/bookappointment', this.patdetails["patient_params"]]);
  }
  ngOnDestroy() {
    this.pageCheck = "bookingdetail";
    this.cleardata()
  }
}

import { RouterModule } from '@angular/router';
import { ClinicAdminBookingdetailComponent } from './clinic-admin-bookingdetail.component';
export const ClinicadminBookingRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicAdminBookingdetailComponent,
    }
]

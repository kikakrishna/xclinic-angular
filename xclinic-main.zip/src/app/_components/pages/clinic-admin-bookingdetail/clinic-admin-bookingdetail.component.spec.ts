import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicAdminBookingdetailComponent } from './clinic-admin-bookingdetail.component';

describe('ClinicAdminBookingdetailComponent', () => {
  let component: ClinicAdminBookingdetailComponent;
  let fixture: ComponentFixture<ClinicAdminBookingdetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicAdminBookingdetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicAdminBookingdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

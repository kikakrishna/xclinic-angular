import { SelectionModel } from '@angular/cdk/collections';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSidenav } from '@angular/material/sidenav';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { element } from '../doctor-vitalgroup/doctor-vitalgroup.component';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
// import { Meta } from '@angular/platform-browser';

@Component({
  selector: 'app-clinicadmin-createvitalgroup',
  templateUrl: './clinicadmin-createvitalgroup.component.html',
  styleUrls: ['./clinicadmin-createvitalgroup.component.css']
})
export class ClinicadminCreatevitalgroupComponent implements OnInit {
  opened: boolean;
  CreatevitalgrpForm: FormGroup;
  EditvitalgrpForm: FormGroup;
  displayedColumns: string[] = ['select', 'vitals', 'unit'];
  CreatevitaldisplayedColumns: string[] = ['vitals', 'unit'];
  public dataSource: any = new MatTableDataSource<object>([]);
  selection = new SelectionModel(true, []);
  totalCal = 0;
  loading: boolean;
  vitalgroupList: any = [];
  EditvitalgroupList: any = [];
  selectedEdit: any = [];
  VitalgroupId
  editedOrder: any;
  updateVitalData: any = [];
  @ViewChild('sidenav') public sidenav: MatSidenav;
  @ViewChild('tableid') tableid!: MatTable<string>;


  constructor(public _patientservice: PatientService,
    public _formBuilder: FormBuilder,
    public _DoctorService: DoctorService,
    public toastrService: ToastService,
    public dialog: MatDialog) {

  }
  ngOnInit(): void {
    this.CreatevitalgrpForm = this._formBuilder.group({
      vitalgrpname: ['', Validators.required]
    });
    this.EditvitalgrpForm = this._formBuilder.group({
      editvital: ['', Validators.required]
    });
    this.GetVitalGroupList()
  }
  // dropTable(event: CdkDragDrop<string[]>) {
  //   const prevIndex = this.dataSource.findIndex((d) => d === event.item.data);
  //   moveItemInArray(this.dataSource, prevIndex, event.currentIndex);
  //   this.tableid.renderRows();
  // }


  dropTable(event: CdkDragDrop<string[]>) {
    console.log(event)
    const prevIndex = this.dataSource.findIndex((d) => d === event.item.data);
    moveItemInArray(this.dataSource, prevIndex, event.currentIndex);
    let index = this.dataSource.findIndex(x => x.vitalid === event.item.data.vitalid);
    console.log(prevIndex);
    console.log(index);
    // console.log(this.dataSource.length);
    console.log(event.currentIndex,'currindex');
    if(prevIndex > event.currentIndex) {
      console.log('up')
      this.dataSource.forEach((element,arrayindex)=>{
        element.orderid = arrayindex + 1;
        // if(arrayindex > index && this.dataSource.length != element.orderid) {
        //   let current = this.dataSource.length -1;
        //   console.log(current, 'yjgj')
        //   element.orderid += 1;
        // }
        // else if(arrayindex === index) {
        //   element.orderid = index + 1;
        //   console.log('1st yjgj')
        // }
      })
    } 
    else {
      console.log('down')
      this.dataSource.forEach((element,arrayindex)=>{
        console.log(arrayindex == element.orderid)
        // if(arrayindex < event.currentIndex && element.orderid != 1) {
            element.orderid = arrayindex + 1;
        // }
      })
    }
    // if(prevIndex < event.currentIndex) {
    //   this.dataSource.forEach((element,arrayindex)=>{
    //   console.log(element)
    //   console.log(arrayindex)
    //   console.log(index)
    //   if(arrayindex > index) {
    //     element.orderid += 1;
    //   }
    //   else if(arrayindex === index) {
    //     element.orderid = index + 1;
    //   }

    //   })
    // } else {
    //   console.log(event.currentIndex)
    // }
    // if()
    console.log(this.dataSource);
    this.tableid.renderRows();
  }

  dragMoved(event: CdkDragDrop<number[]>) {
    console.log(event)
  }

  // CreateVitalGroup
  CreateVitalGroup() {
    console.log(this.CreatevitalgrpForm.value.vitalgrpname)
    if (this.CreatevitalgrpForm.invalid || this.CreatevitalgrpForm.value.vitalgrpname.trim() =="") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter vital groupname", options);
      return;
    } else {
      this.loading = true;
      let payload = {
        "groupname": this.CreatevitalgrpForm.value.vitalgrpname
      }
      this.loading = true;
      this._DoctorService.CreateVitalGroup(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res?.responseMessage, options);
            this.CreatevitalgrpForm.reset();
            this.GetVitalGroupList()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res?.errorMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
    }
  }
  GetVitalGroupList() {
    this.loading = true;
    this.vitalgroupList.length = 0;
    this._DoctorService.GetVitalGroup()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          this.vitalgroupList = res?.responseMessage;
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })

  }
  GetSystemVitalList(data) {
    this.loading = true;
    // this.GetVitalGroupList()
    console.log(data)
    this.VitalgroupId = data;
    this._DoctorService.GetVitalGroupbyid(this.VitalgroupId?.vitalgroupid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          this.EditvitalgrpForm.get('editvital').setValue(res?.responseMessage?.vitalgroupname);
          this.dataSource = res?.responseMessage?.vitals;
          this.selection = new SelectionModel(true, [
            ...this.dataSource.filter(row => row.ismapped == true)
          ]);
          console.log(this.selection)

          this.selectedEdit.length = 0

          this.selection['_selection'].forEach(element => {
            console.log(element)
            // this.selectedEdit.push(element.vitalid)
            this.selectedEdit.push({vitalid:element.vitalid,orderid: element.orderid})
            console.log(this.selectedEdit)
          });
          console.log(this.selectedEdit)
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })

  }

  toggleSelection(row: element): void {
    this.selectedEdit.length = 0;
    this.selection.toggle(row);
    console.log(this.selection['_selection'])
    this.selection['_selection'].forEach(element => {
      console.log(element)
      this.selectedEdit.push({vitalid:element.vitalid,orderid: element.orderid})
    });
    console.log(this.selectedEdit)
  }

  editSubmit() {
    console.log(this.EditvitalgrpForm.value.editvital)
    if (this.EditvitalgrpForm.value.editvital.trim() == '' || this.EditvitalgrpForm.value.editvital == null) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Enter the Vital Group Name", options);
      return;
    }
    if (this.selectedEdit.length == 0) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select system vitals", options);
      return;
    }
    else {
      console.log(this.VitalgroupId)
      console.log(this.VitalgroupId?.vitalgroupid)
      let payload = {
        "vitalgroupid": this.VitalgroupId?.vitalgroupid,
        "vitalgroupname": this.EditvitalgrpForm.value.editvital,
        "vitaldetailsModels": this.selectedEdit
      }
      // console.log(this.dataSource)
      // console.log(this.updateVitalData);
      // this.dataSource.forEach(element => {
      //   console.log(element);
      //   this.selectedEdit.push({vitalid:element.vitalid,orderid:element.orderid});
      // })
      // console.log(this.updateVitalData);
      // let payload = {
      //     "vitalgroupid": this.editedOrder?.vitalgroupid,
      //     "vitalgroupname": this.editedOrder?.vitalgroupname,
      //     "vitaldetailsModels": this.updateVitalData
      // }
      console.log(payload)
      // return;
      console.log(this.selectedEdit)
      this.loading = true;
      this._DoctorService.UpdateVitalGroupbyid(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res?.responseMessage, options);
            this.sidenav.close();
            this.CreatevitalgrpForm.reset();
            this.GetVitalGroupList()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res?.responseMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
    }
  }

  editorderSubmit() {
    this.updateVitalData = [];
    console.log(this.updateVitalData)
    // console.log(this.EditvitalgrpForm.value.editvital)
    // if (this.EditvitalgrpForm.value.editvital.trim() == '' || this.EditvitalgrpForm.value.editvital == null) {
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', "Please Enter the Vital Group Name", options);
    //   return;
    // }
    // if (this.updateVitalData.length == 0) {
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', "Please select system vitals", options);
    //   return;
    // }
    // else {
      // console.log(this.editedOrder)
      // console.log(this.VitalgroupId?.vitalgroupid)
      // let payload = {
      //   "vitalgroupid": this.VitalgroupId?.vitalgroupid,
      //   "vitalgroupname": this.EditvitalgrpForm.value.editvital,
      //   "vitaldetailsModels": this.selectedEdit
      // }
      console.log(this.dataSource)
      console.log(this.updateVitalData);
      this.dataSource.forEach(element => {
        console.log(element);
        this.updateVitalData.push({orderid:element.orderid, vitalid:element.vitalid});
      })
      console.log(this.updateVitalData);
      let payload = {
          "vitalgroupid": this.editedOrder?.vitalgroupid,
          "vitaldetailsModels": this.updateVitalData
      }
      console.log(payload)
      this.loading = true;
      this._DoctorService.UpdateVitalGroupbyorder(payload)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res?.responseMessage, options);
            this.sidenav.close();
            this.CreatevitalgrpForm.reset();
            this.GetVitalGroupList()
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res?.responseMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
    // }
  }
  openEditorder: boolean = false;
  editordername;
  editorderdet;
  editorder(item) {
    this.editorderdet = item;
    this.editordername=""
    this.openEditorder = true;
    this.opened = true;
    console.log(item)    
    this.editedOrder = item;
    this.editordername=item?.groupname
    // this.EditvitalgrpForm.get('editvital').setValue(item?.groupname);    
    for(let i of item?.systemvitals){
      i.ismapped = true;
    }
    this.dataSource = item?.systemvitals;
    this.selection = new SelectionModel(true, [
      ...this.dataSource.filter(row => row.ismapped == true)
    ]);
    console.log(this.selection)

    this.selectedEdit.length = 0

    this.selection['_selection'].forEach(element => {
      console.log(element)
      this.selectedEdit.push(element.vitalid)
    });
    console.log(this.selectedEdit)
  }
  // submiteditOrder(){
  //   console.log(this.editorderdet)
  //   let array=[];
  //   this.editorderdet.systemvitals.forEach(element => {
  //     console.log(element)
  //     array.push( {
  //       "vitalid": element.vitalid,
  //       "orderid": element.orderid
  //     })
  //   });
  //   let payload={
  //     "vitalgroupid": this.editorderdet?.vitalgroupid,
  //     "vitaldetailsModels":array
  //   }
  //   console.log(payload);
  //   return;
  //   this.loading = true;
  //   this._DoctorService.EditorderVitalGroup(payload)
  //     .pipe(first())
  //     .subscribe((res: any) => {
  //       if (!res.isError) {
  //         this.loading = false;
  //         console.log(res)
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.success('', res?.responseMessage, options);
  //         this.sidenav.close();
  //         this.CreatevitalgrpForm.reset();
  //         this.GetVitalGroupList()
  //       }
  //       else {
  //         this.loading = false;
  //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //         this.toastrService.warning('', res?.responseMessage, options);
  //       }
  //     }, err => {
  //       this.loading = false;
  //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //       this.toastrService.warning('', err?.error, options);
  //     })
  // }
  vitalgroupSidescreenopen() {
    // alert("open")
  }
  vitalgroupSidescreenclose() {
    // alert("clse")
    this.openEditorder = false;
  }
}

import { RouterModule } from '@angular/router';
import { ClinicadminCreatevitalgroupComponent } from './clinicadmin-createvitalgroup.component';

export const ClinicadminCreatevitalgroupRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminCreatevitalgroupComponent,
    }
]
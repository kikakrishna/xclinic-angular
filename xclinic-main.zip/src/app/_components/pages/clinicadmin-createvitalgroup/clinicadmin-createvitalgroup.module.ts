import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClinicadminCreatevitalgroupComponent } from './clinicadmin-createvitalgroup.component';
import { ClinicadminCreatevitalgroupRoutes } from './clinicadmin-createvitalgroup.routes';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSidenavModule } from '@angular/material/sidenav';
import {MatTableModule} from '@angular/material/table';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatIconModule } from '@angular/material/icon';




@NgModule({
  declarations: [ClinicadminCreatevitalgroupComponent],
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSidenavModule,
    MatTableModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    DragDropModule,
    RouterModule.forChild(ClinicadminCreatevitalgroupRoutes),
  ],
  exports: [ClinicadminCreatevitalgroupComponent],
})
export class ClinicadminCreatevitalgroupModule { }

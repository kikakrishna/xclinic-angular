import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminCreatevitalgroupComponent } from './clinicadmin-createvitalgroup.component';

describe('ClinicadminCreatevitalgroupComponent', () => {
  let component: ClinicadminCreatevitalgroupComponent;
  let fixture: ComponentFixture<ClinicadminCreatevitalgroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminCreatevitalgroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminCreatevitalgroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

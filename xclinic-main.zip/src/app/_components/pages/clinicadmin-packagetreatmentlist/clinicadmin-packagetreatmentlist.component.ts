import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';

export interface PeriodicElement {
  treatmentid: number;
  treatmentname: string;
  patient: string;
  noofvisits: string;
  amount: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { treatmentid: 12345, treatmentname: 'Root Canal', patient: 'Dr.Nelson DM', noofvisits: '5', amount: '3000', action: '' },
];
@Component({
  selector: 'app-clinicadmin-packagetreatmentlist',
  templateUrl: './clinicadmin-packagetreatmentlist.component.html',
  styleUrls: ['./clinicadmin-packagetreatmentlist.component.css']
})
export class ClinicadminPackagetreatmentlistComponent implements OnInit {
  displayedColumns: string[] = ['patient', 'treatmentid', 'treatmentname', 'noofvisits', 'amount', 'action'];
  // dataSource = ELEMENT_DATA;

  servicestatus: any;
  btnAction: boolean;
  getpendingstate: any;
  public dataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  public filerpastform_pagination_show: boolean;
  loading: boolean;
  addressmodel: any;
  clinicId: any;
  listdata: boolean;
  Fsearchstring: string;
  filterData: boolean;
  public searchinput = "";
  applyfilterData: boolean = false;
  public totalSize = 0;
  public pageindex = 0;


  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private router: Router,
    public _activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.loading = true;

    this.clinicId = sessionStorage.getItem('clinicId');
    this.dataSource.paginator = this.paginator;
    this._DoctorService.getpackagetreatmentlist(0, 5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          let array = [];
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);

          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator

          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }


  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getpackagetreatmentlist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  // createclick(){
  //   this.router.navigate([`/thealth/clinicadmin//add`], { state: { servicestatus: 'create', btnAction:true } });
  // }


  // editclick(ele){
  // this.router.navigate([`/thealth/clinicadmin//edit/${ele.}`], { state: { servicestatus: ele, btnAction:false } });
  //   }

  //reset
  clearfilter() {
    this.loading = true;
    this.searchinput = "";
    let searchstring = this.searchinput;
    this.applyfilterData = false;
    this._DoctorService.getpackagetreatmentlist(0, 5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          let array = [];
          this.addressmodel = res?.responseMessage;
          this.totalSize = res.total;
          for (let item of res?.responseMessage) {
            array.push(item);

          }

          console.log(array)
          this.dataSource = new MatTableDataSource(array);

          setTimeout(() => {
            this.totalSize = res?.pagination.total;
            this.dataSource.paginator = this.paginator
            this.paginator.pageSize = 0
          });

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    if (searchstring == "") {
      this.filterData = false;
    }
  }
  filterstring

  applyFilter2() {

    const filterValue = this.searchinput;
    let searchstring = filterValue.trim()
    console.log(searchstring)
    if (searchstring != "") {
      if (searchstring) {
        this.applyfilterData = true;
      } else {
        this.applyfilterData = false;
        return;
      }
      this.loading = true;
      this.Fsearchstring = searchstring;
      console.log(filterValue.trim().toLowerCase(), this.getpendingstate, 0, 5)
      this._DoctorService.treatmentlistfilter(searchstring,)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            console.log(res)
            let array = [];
            this.loading = false;
            for (let item of res?.responseMessage) {
              //  item.formattedappointmentDate = moment(item?.appointmentDate).format('ll');
              array.push(item);
            }
            this.dataSource = new MatTableDataSource(array);
            if (this.dataSource.data.length === 0) {
              this.listdata = true;
            }
            else {
              this.listdata = false;
            }
            setTimeout(() => {
              this.totalSize = res?.pagination?.total;
              this.paginator.pageIndex = 0;
              this.paginator.pageSize = 0;
              // this.dataSource.paginator = this.stockinlistpaginator
              //  this.totalSize = res?.responseMessage?.pagination?.total
            });
          }
          else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            this.loading = false;
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
            this.loading = false;
          });
    }
  }
  treatmentlistfilterwithpageSize
  filterGetnext(event) {
    this.loading = true;
    this._DoctorService.treatmentlistfilterwithpageSize(this.Fsearchstring, event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          let array = [];
          this.loading = false;
          for (let item of res?.responseMessage) {
            let d = new Date(item?.date);
            item.formattedappointmentDate = moment(d).format('ll');
            array.push(item);
          }
          this.dataSource = new MatTableDataSource(array);
          if (this.dataSource.data.length === 0) {
            this.listdata = true;
            this.filterData = true;

          }
          else {
            this.listdata = false;
            this.filterData = false;
          }

        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.loading = false;
        });
  }

  editclick(ele) {
    this.router.navigate([`/thealth/clinicadmin/plantreatmentschedule/${ele.patienttrpackagemapid}`], { state: { stockinstatus: ele, btnAction: false } });
  }
}



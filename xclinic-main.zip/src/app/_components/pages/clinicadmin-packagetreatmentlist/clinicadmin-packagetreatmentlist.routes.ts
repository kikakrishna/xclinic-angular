import { RouterModule } from '@angular/router';
import { ClinicadminPackagetreatmentlistComponent  } from './clinicadmin-packagetreatmentlist.component';
export const ClinicadminPackagetreatmentlistRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminPackagetreatmentlistComponent ,
    }
]
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminPackagetreatmentlistComponent } from './clinicadmin-packagetreatmentlist.component';

describe('ClinicadminPackagetreatmentlistComponent', () => {
  let component: ClinicadminPackagetreatmentlistComponent;
  let fixture: ComponentFixture<ClinicadminPackagetreatmentlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminPackagetreatmentlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminPackagetreatmentlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

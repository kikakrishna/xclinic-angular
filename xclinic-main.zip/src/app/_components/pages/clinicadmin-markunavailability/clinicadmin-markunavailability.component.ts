import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DoctorService } from '../../../_services/doctor.service';
import { first } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import * as moment from 'moment';
import { MatRadioChange } from '@angular/material/radio';
import { ToastService } from 'ng-uikit-pro-standard';
import { PatientService } from 'src/app/_services/patient.service';
@Component({
  selector: 'app-clinicadmin-markunavailability',
  templateUrl: './clinicadmin-markunavailability.component.html',
  styleUrls: ['./clinicadmin-markunavailability.component.css']
})
export class ClinicadminMarkunavailabilityComponent implements OnInit {
  unavaliableslots_dataSource;
  loading: boolean;
  public clinicname: any = [];
  Viewslots: FormGroup;
  lstsdate: any;
  public arr2: any = []
  lstedate: any;
  stdate: any;
  etdate: any;
  dayslot: any[] = [];
  slotid: any[] = [];
  enableslotbutton: boolean;
  buttonslot: any;
  myStartDate: any;
  myEndDate: any;
  public weekdays: any = [];
  nolist: boolean;
  timeslot: boolean;
  doctorid: any;
  selectedDoctor:any;
  appoinmenttype:any=[];
  isDoubletype:boolean= false;  
  clinicLocations: any = [];
  clinicId: any;
  enableLocation: boolean = false;
  defaultClinic: any;
  clinicLocationmapId: any;
  singletype: any;
  constructor(public _formBuilder: FormBuilder,
    public _patientservice:PatientService, public _DoctorService: DoctorService,
    private dialog: MatDialogRef<ClinicadminMarkunavailabilityComponent>,
    private toastrService: ToastService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.enableslotbutton = false;
    this.Viewslots = this._formBuilder.group({
      clinicname: [''],
      startdate: ['', Validators.required],
      enddate: ['', Validators.required],
      consultationtyperdbtn:['', Validators.required],
      filtslot: ['all'],
      location: [''],
    });
    this.doctorid = this.data;
    console.log(this.doctorid)
  }
  ngOnInit(): void {
    this.selectedDoctor = JSON.parse(sessionStorage.getItem("selecteddoctor"));
    this.loading = true;
    this.myStartDate = new Date();
    this.Viewslots.controls.enddate.disable();
    this.getdaylist()
    this._DoctorService.getcliniclist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.clinicname = res.responseMessage;
          this.Viewslots.get('clinicname').setValue(res.responseMessage[0].clinicId);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
      // this._DoctorService.getappoinmenttype()
      this._patientservice.getpaymentType_Notwalkin()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for(let i of res.responseMessage){
            if(i.appointmentTypeName == "Video Consultation"){
              i.appoinmentlabel = "Video"
            }
            if(i.appointmentTypeName == "Clinic Visit"){
              i.appoinmentlabel = "Clinic Visit"
            }
          }
          console.log(res.responseMessage)          
          this.appoinmenttype = res?.responseMessage;          
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
      this._DoctorService.viewprofile(this.selectedDoctor.doctorId)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        // enable and disable section for consulation type
        // console.log(this.selectedDoctor)
        let ctypearray = [];
        res?.responseMessage?.doctorConsultationType.forEach(element => {
          console.log(element)
          if (element.status == 1 && element?.consultationType != "Walk-In" && element?.typeId != 102) {
            ctypearray.push(element);
          }
        });
        // console.log(ctypearray)
        // console.log(this.appoinmenttype)
        if (ctypearray.length == 2) {
          this.isDoubletype = true;
          this.Viewslots.get('consultationtyperdbtn').setValue(this.appoinmenttype[0]?.appointmentTypeId);
        }
        if (ctypearray.length == 1) {
          this.appoinmenttype.forEach(apptype => {
            if(apptype.appointmentTypeName == ctypearray[0].consultationType){
              this.singletype = apptype.appointmentTypeName;
              this.Viewslots.get('consultationtyperdbtn').setValue(apptype.appointmentTypeId);
              if(this.Viewslots.value.consultationtyperdbtn == 2){
                this.enableLocation = true;
              }
              this.isDoubletype = false;
            }
          });
          // console.log(ctypearray)
        }
      })
      this.getClinicLocations();
  }
  getClinicLocations(){      
      // Get clinic locations
      this.clinicId = sessionStorage.getItem('clinicId');
      this._DoctorService.getclinicLocations(this.clinicId)
      .pipe(first())
      .subscribe((res: any) => {
        if(!res.isError){
          console.log(res)
          this.clinicLocations = res.responseMessage;
          console.log(this.clinicLocations)
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  changeType(event){
    console.log(event);
    if(event.value == 2){
      this.enableLocation = true;
      // this.Viewslots.get('location').addValidators(Validators.required);   
      this.Viewslots.controls['location'].setValidators([Validators.required]);    
    } else {
      this.enableLocation = false;
      this.Viewslots.controls["location"].clearValidators();
    }
  }
  resetall() {
    this.buttonslot.length = 0;
    this.buttonslot = false;
    this.Viewslots.reset();
  }
  satdate() {
    const sdate = this.Viewslots.value.startdate;
    const getstdate = moment(sdate).format();
    this.stdate = getstdate.substr(0, 19);
  }
  slotchange(daysid, event) {
    if (event.checked) {
      this.dayslot.push(daysid);
      if (this.dayslot.length > 0) {
      } else {
      }
    } else {
      const index = this.dayslot.indexOf(daysid);
      this.dayslot.splice(index, 1);
    }
  }
  endate() {
    const edate = this.Viewslots.value.enddate;
    const getedate = moment(edate).format();
    this.etdate = getedate.substr(0, 19);
  }
  check(data) {
    data.active = !data.active
  }
  click(user) {
    if (user.active == true) {
      this.arr2.push(user.slotId)
    } else {
      this.arr2.splice(this.arr2.findIndex(a => a.slotId === user.slotId), 1)
    }
    user.active = !user.active
    this.c1(this.arr2);
    if (this.arr2.length > 0) {
      this.timeslot = false;
    } else {
      this.timeslot = true;
    }
  }
  c1(value) {
    console.log(this.arr2)
  }
  setcliniclocationDefault() {
    // set defaut location map if type is video consultation
    this.getClinicLocations();
    console.log(this.Viewslots.value.consultationtyperdbtn);
    console.log(this.Viewslots.value.location);
    if(this.Viewslots.value.consultationtyperdbtn == 1) {
      console.log(this.clinicLocations);
      this.clinicLocations.forEach(element => {
        if(element.defaultclinic == true) {
          this.Viewslots.get('location').setValue(element.clinicLocationMapId);
        }
      });
    }
  }
  gettimeslot() {
    this.loading = true;
    var array = [];
    const weekdaystring = this.dayslot.toString();
    this.setcliniclocationDefault();
    console.log(this.Viewslots.value)
    this._DoctorService.timeslot2consultaiontype(this.stdate, this.etdate, weekdaystring, this.Viewslots.value, this.doctorid,this.Viewslots.value.consultationtyperdbtn)
      .pipe(first())
      .subscribe((res: any) => {
        this.loading = false;
        if (!res.isError) {
          for (var obj of res?.responseMessage[0]?.byDate) {
            for (let item of obj?.slots) {
              item['active'] = true
            }
            array.push(obj)
          }
          this.buttonslot = array;
          if (this.buttonslot.length === 0) {
            this.nolist = true;
          } else {
            this.nolist = false;
          }
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
          this.dayslot = [];
        });
  }
  getdaylist() {
    this.loading = true;
    this._DoctorService.getweekdays()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.weekdays = res.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  radioChange($event: MatRadioChange) {
    const radiovalue = $event.value
    if (radiovalue === 'selected') {
      this.enableslotbutton = true;
    } else {
      this.enableslotbutton = false;
    }
  }
  consultationChange($event, index) {
    console.log($event, index);
    if($event.value){
      this.buttonslot = [];
    }
  }
  selectslot(slotId, fulvalue, event) {
    if (event.checked) {
      this.slotid.push(slotId);
      if (this.slotid.length > 0) {
      } else {
      }
    } else {
      const indexslot = this.slotid.indexOf(slotId);
      this.slotid.splice(indexslot, 1);
    }
  }
  dateenabled() {
    this.Viewslots.controls.enddate.reset();
    if (this.Viewslots.value.startdate != "") {
      this.Viewslots.controls.enddate.enable();
    }
  }
  datevalidation() {
    if (this.Viewslots.value.startdate == "") {
      this.Viewslots.controls.enddate.disable();
      return;
    }
    this.myEndDate = this.Viewslots.value.startdate;
  }
  createunavailslot(formData: any, formDirective: FormGroupDirective) {
    console.log(this.buttonslot, "RAm")
    console.log(this.stdate)
    console.log(this.etdate)
    console.log(this.dayslot)
    console.log(this.arr2)
    console.log(this.Viewslots.value)
    console.log(this.doctorid)
    this.loading = true;
    // set cliniclocation from defaultlocation true
    // this.setcliniclocationDefault();
    if (this.Viewslots.value.filtslot === "selected") {
      // choosen selected 
      if (this.arr2.length === 0) {
        this.loading = false;
        this.timeslot = true;
        const options = { opacity: 1 };
        this.toastrService.warning('', "Please Select Timeslot", options);
        return;
        // choosen selected ,but slots not selected        
      } else {
        this.timeslot = false;
        //  only slot are selected
        this._DoctorService.unavailabilityupdate2(
          this.stdate, this.etdate, this.dayslot, this.arr2, this.Viewslots.value, this.doctorid,this.Viewslots.value.consultationtyperdbtn)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              const options = { opacity: 1 };
              this.toastrService.success('', res.responseMessage, options);
              this.dialog.close();
            } else {
              this.loading = false;
              const options = { opacity: 1 };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1 };
              this.toastrService.warning('', err.error, options);
            });
      }
    }
    else {
      // choose all
      this.timeslot = false;
      this._DoctorService.unavailabilityupdate2(
        this.stdate, this.etdate, this.dayslot, this.arr2, this.Viewslots.value, this.doctorid,this.Viewslots.value.consultationtyperdbtn)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.dialog.close();
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          });
    }
  }
  resetform(formData: any, formDirective: FormGroupDirective) {
    formDirective.resetForm();
    this.Viewslots.reset();
    this.dayslot = [];
    this.buttonslot = [];
    this.ngOnInit();
    this.enableLocation = false;
  }
}


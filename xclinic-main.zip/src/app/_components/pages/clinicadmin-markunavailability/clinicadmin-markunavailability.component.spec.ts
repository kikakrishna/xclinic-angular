import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminMarkunavailabilityComponent } from './clinicadmin-markunavailability.component';

describe('ClinicadminMarkunavailabilityComponent', () => {
  let component: ClinicadminMarkunavailabilityComponent;
  let fixture: ComponentFixture<ClinicadminMarkunavailabilityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminMarkunavailabilityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminMarkunavailabilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

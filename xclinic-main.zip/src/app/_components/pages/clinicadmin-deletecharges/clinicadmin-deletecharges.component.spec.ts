import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDeletechargesComponent } from './clinicadmin-deletecharges.component';

describe('ClinicadminDeletechargesComponent', () => {
  let component: ClinicadminDeletechargesComponent;
  let fixture: ComponentFixture<ClinicadminDeletechargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDeletechargesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDeletechargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

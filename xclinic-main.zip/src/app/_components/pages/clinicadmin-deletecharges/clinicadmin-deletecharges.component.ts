import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';

@Component({
  selector: 'app-clinicadmin-deletecharges',
  templateUrl: './clinicadmin-deletecharges.component.html',
  styleUrls: ['./clinicadmin-deletecharges.component.css']
})
export class ClinicadminDeletechargesComponent implements OnInit {

  constructor(private _formBuilder: FormBuilder,
    private _DoctorService: DoctorService,
    public dialogRef: MatDialogRef<ClinicadminDeletechargesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  deletefile() {
    console.log(this.data)
    this._DoctorService
      .deletecharge(this.data)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.dialogRef.close({ data: res });
        } else {
          this.dialogRef.close({ data: res });
        }
      },
        err => {
          this.dialogRef.close({ data: err });
        });
  }

}

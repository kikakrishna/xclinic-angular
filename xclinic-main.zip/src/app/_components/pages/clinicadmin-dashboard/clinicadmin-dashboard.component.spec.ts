import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDashboardComponent } from './clinicadmin-dashboard.component';

describe('ClinicadminDashboardComponent', () => {
  let component: ClinicadminDashboardComponent;
  let fixture: ComponentFixture<ClinicadminDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { CalendarOptions, } from '@fullcalendar/angular';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import * as moment from 'moment';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminCalenderappointmentpopupComponent } from '../clinicadmin-calenderappointmentpopup/clinicadmin-calenderappointmentpopup.component';
import taLocale from '@fullcalendar/core/locales/ta-in';
import enLocale from '@fullcalendar/core/locales/en-gb';
import arLocale from '@fullcalendar/core/locales/ar';

@Component({
  selector: 'app-clinicadmin-dashboard',
  templateUrl: './clinicadmin-dashboard.component.html',
  styleUrls: ['./clinicadmin-dashboard.component.css']
})
export class ClinicadminDashboardComponent implements OnInit {
  public calendarOptions: CalendarOptions = {
    initialView: 'dayGridDay',
    defaultAllDay: true,
    expandRows: true,
    displayEventTime: true,
    firstDay: 1,
    headerToolbar: {
      left: 'prev,next',
      center: 'title',
      right: 'dayGridMonth,dayGridWeek,dayGridDay'
    },
  };
  doctorlist: any = [];
  Calender_data: any = [];
  doctorDashboardItem: any = [];
  fullname: string = "";
  clinicadminForm: FormGroup;
  current_date: any;
  apt_date: any;
  timeFrame: string;
  maxdate: any;
  siteLocale: any;
  language: string;
  loading: boolean;
  languageList = [
    { code: 'en', label: 'English' },
    { code: 'ta', label: 'Tamil' }
  ];
  eventClassNames: any;
  constructor(public _patientservice: PatientService,
    public _formBuilder: FormBuilder,
    public _DoctorService: DoctorService,
    public toastrService: ToastService,
    public dialog: MatDialog) {
    let sessionLang = sessionStorage.getItem('sitelanguage');
    if (sessionLang == null) {
      this.siteLocale = 'en';
    } else {
      this.siteLocale = sessionLang;
    }
  }

  ngOnInit(): void {
    this.loading = true;
    this.maxdate = new Date();
    this.fullname = sessionStorage.getItem("userName") + " " + sessionStorage.getItem("lastName");
    this.clinicadminForm = this._formBuilder.group({
      doctorid: ['', Validators.required]
    });

    this.language = sessionStorage.getItem('sitelanguage');
    if (this.language != null && this.language === 'ta') {
      this.calendarOptions = {
        initialView: 'dayGridDay',
        locales: [taLocale],
        locale: this.siteLocale,
        defaultAllDay: true,
        expandRows: true,
        displayEventTime: true,
        firstDay: 1,
        headerToolbar: {
          left: 'prev,next',
          center: 'title',
          right: 'dayGridDay,dayGridWeek,dayGridMonth'
        }
      };
    }else if (this.language != null && this.language === 'ar') {
      this.calendarOptions = {
        initialView: 'dayGridDay',
        locales: [arLocale],
        locale: this.siteLocale,
        defaultAllDay: true,
        expandRows: true,
        displayEventTime: true,
        firstDay: 1,
        headerToolbar: {
          left: 'prev,next',
          center: 'title',
          right: 'dayGridMonth,dayGridWeek,dayGridDay'
        }
      };
    }
     else {
      this.calendarOptions = {
        initialView: 'dayGridDay',
        locales: [enLocale],
        locale: this.siteLocale,
        defaultAllDay: true,
        expandRows: true,
        displayEventTime: true,
        firstDay: 1,
        headerToolbar: {
          left: 'prev,next',
          center: 'title',
          right: 'dayGridDay,dayGridWeek,dayGridMonth'
        },
        
      };
    }

    this.Calender_data.length = 0;
    this.doctorlist.length = 0;
    this._patientservice.getalldocdrop()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          if (res?.responseMessage?.length != 0) {
            this.loading = false;
            this.doctorlist = res?.responseMessage;
            this.clinicadminForm.get('doctorid').setValue(res?.responseMessage[0]?.doctorId);
            this._DoctorService.getadmindocdashboard(res?.responseMessage[0]?.doctorId)
              .pipe(first())
              .subscribe((res: any) => {
                if (!res.isError) {
                  this.loading = false;
                  this.doctorDashboardItem = res?.responseMessage;
                  for (let items of res?.responseMessage?.doctorCalender) {
                    // get timeframe based on date
                    this.current_date = moment(this.maxdate).format('L');
                    this.apt_date = moment(items?.appointmentDate).format('L');
                    if (this.current_date <= this.apt_date) {
                      this.timeFrame = 'upcoming';
                    }
                    if (this.current_date >= this.apt_date) {
                      this.timeFrame = 'past';
                    }
                    if (this.current_date == this.apt_date) {
                      this.timeFrame = 'today';
                    }

                    if(items?.consultationTypeName == 'Video Consultation'){
                      this.eventClassNames = 'Onlineconsultation';
                    } 
                    if(items?.consultationTypeName == 'Clinic Visit') {
                      this.eventClassNames = 'Offlineconsultation';
                    }   
                    if (items?.consultationTypeName == 'Walk-In') {
                      this.eventClassNames = 'Walkinconsultation';
                    }     
                    // End
                    let title
                    if (items?.patientFirstName && items?.slotTime) {
                      title = items?.patientFirstName + " " + items?.slotTime;
                    } else {
                      title = items?.patientFirstName;
                    }
                    console.log(items?.locationmodel?.locationName)
                    const dashval = {
                      title: title,
                      date: items?.appointmentDate,
                      time: items?.slotTime,
                      speciality: items?.speciality,
                      start: items?.appointmentDate,
                      "appid": items?.appointmentId,
                      "titlename": items?.patientName,
                      color: '#F39200',
                      timeFrame: this.timeFrame,
                      paymentType: items?.consultationTypeName,
                      classNames: this.eventClassNames,
                      location: items?.locationmodel?.locationName
                    }
                    this.Calender_data.push(dashval);
                  }
                  this.calendarOptions.events = this.Calender_data;
                  this.calendarOptions.eventClick = (e) => {
                    const payload = {
                      "title": e.event._def.extendedProps.titlename,
                      "date": e.event.start,
                      "slottime": e.event._def.extendedProps.time,
                      "speciality": e.event._def.extendedProps.speciality,
                      "appid": e.event._def.extendedProps.appid,
                      "timeFrame": e.event._def.extendedProps.timeFrame,
                      "paymentType": e.event._def.extendedProps.paymentType,
                      "location": e.event._def.extendedProps.location
                    }
                    const dialogRef = this.dialog.open(ClinicadminCalenderappointmentpopupComponent, {
                      panelClass: 'calendarwrapper',
                      data: payload

                    });
                    dialogRef.afterClosed().subscribe(result => {
                      if (result) {
                        if (!result.data.isError) {
                        }
                      }
                    });
                  }
                }
                else {
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res?.errorMessage, options);
                }
              }, err => {
                this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', err?.error, options);
              })
          } else {
            this.loading = false;
          }
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }

  Changedoctor() {
    this.eventClassNames =""
    this.loading = true;
    this.language = sessionStorage.getItem('sitelanguage');
    if (this.language != null && this.language === 'ta') {
      this.calendarOptions = {
        initialView: 'dayGridDay',
        locales: [taLocale],
        locale: this.siteLocale,
        defaultAllDay: true,
        expandRows: true,
        displayEventTime: true,
        firstDay: 1,
        headerToolbar: {
          left: 'prev,next',
          center: 'title',
          right: 'dayGridDay,dayGridWeek,dayGridMonth'
        }
      };
    } else {
      this.calendarOptions = {
        initialView: 'dayGridDay',
        locales: [enLocale],
        locale: this.siteLocale,
        defaultAllDay: true,
        expandRows: true,
        displayEventTime: true,
        firstDay: 1,
        headerToolbar: {
          left: 'prev,next',
          center: 'title',
          right: 'dayGridDay,dayGridWeek,dayGridMonth'
        },
      };
    }
    let Mycalender_data = [];
    this.doctorDashboardItem.length = 0;
    this._DoctorService.getadmindocdashboard(this.clinicadminForm.value.doctorid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.doctorDashboardItem = res?.responseMessage;
          for (let items of res?.responseMessage?.doctorCalender) {
            // get timeframe based on date
            this.current_date = moment(this.maxdate).format('L');
            this.apt_date = moment(items?.appointmentDate).format('L');
            if (this.current_date <= this.apt_date) {
              this.timeFrame = 'upcoming';
            }
            if (this.current_date >= this.apt_date) {
              this.timeFrame = 'past';
            }
            if (this.current_date == this.apt_date) {
              this.timeFrame = 'today';
            }
            if(items?.consultationTypeName == 'Video Consultation'){
              this.eventClassNames = 'Onlineconsultation';
            } 
            if(items?.consultationTypeName == 'Clinic Visit') {
              this.eventClassNames = 'Offlineconsultation';
            }
            if (items?.consultationTypeName == 'Walk-In') {
              this.eventClassNames = 'Walkinconsultation';
            }
            let title
            if (items?.patientFirstName && items?.slotTime) {
              title = items?.patientFirstName + " " + items?.slotTime;
            } else {
              title = items?.patientFirstName;
            }
            const dashval = {
              title: title,
              date: items?.appointmentDate,
              time: items?.slotTime,
              speciality: items?.speciality,
              start: items?.appointmentDate,
              "appid": items?.appointmentId,
              "titlename": items?.patientName,
              color: '#F39200',
              timeFrame: this.timeFrame,
              paymentType: items?.consultationTypeName,
              classNames: this.eventClassNames,
              location: items?.locationmodel?.locationName
            }
            Mycalender_data.push(dashval);
          }
          this.calendarOptions.events = Mycalender_data;
          
          this.calendarOptions.eventClick = (e) => {
            const payload = {
              "title": e.event._def.extendedProps.titlename,
              "date": e.event.start,
              "slottime": e.event._def.extendedProps.time,
              "speciality": e.event._def.extendedProps.speciality,
              "appid": e.event._def.extendedProps.appid,
              "timeFrame": e.event._def.extendedProps.timeFrame,
              "paymentType": e.event._def.extendedProps.paymentType,
              "location": e.event._def.extendedProps.location
            }
            const dialogRef = this.dialog.open(ClinicadminCalenderappointmentpopupComponent, {
              panelClass: 'calendarwrapper',
              data: payload

            });
            dialogRef.afterClosed().subscribe(result => {
              if (result) {
                if (!result.data.isError) {
                }
              }
            });
          }
          setTimeout(() => {
            this.calendarOptions.events = Mycalender_data;
          }, 1000)

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
}

import { RouterModule } from '@angular/router';
import { ClinicadminDashboardComponent } from './clinicadmin-dashboard.component';
export const ClinicadminDashboardRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminDashboardComponent,
    }
]
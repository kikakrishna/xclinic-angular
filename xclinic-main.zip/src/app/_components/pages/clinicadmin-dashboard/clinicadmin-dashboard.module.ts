import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ClinicadminDashboardComponent } from './clinicadmin-dashboard.component';
import { ClinicadminDashboardRoutes } from './clinicadmin-dashboard.routes';
import { MatDialogModule } from '@angular/material/dialog';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MY_DATE_FORMATS } from '../appointments/my-date-formats';
import { ClinicadminCalenderappointmentpopupComponent } from '../clinicadmin-calenderappointmentpopup/clinicadmin-calenderappointmentpopup.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
FullCalendarModule.registerPlugins([ // register FullCalendar plugins
  dayGridPlugin,
]);
@NgModule({
  declarations: [ClinicadminDashboardComponent,ClinicadminCalenderappointmentpopupComponent],
  imports: [
    RouterModule.forChild(ClinicadminDashboardRoutes),
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatCardModule,
    MatButtonModule,
    MatDividerModule,
    FullCalendarModule,    
    MatSelectModule,
    MatInputModule,
    MatDialogModule,
    MatDatepickerModule
  ],
  entryComponents:[
    ClinicadminCalenderappointmentpopupComponent
  ],
  exports: [ClinicadminDashboardComponent],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },

  ]
})
export class ClinicadminDashboardModule { }

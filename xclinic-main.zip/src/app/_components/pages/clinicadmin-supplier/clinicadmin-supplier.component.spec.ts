import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminSupplierComponent } from './clinicadmin-supplier.component';

describe('ClinicadminSupplierComponent', () => {
  let component: ClinicadminSupplierComponent;
  let fixture: ComponentFixture<ClinicadminSupplierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminSupplierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminSupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

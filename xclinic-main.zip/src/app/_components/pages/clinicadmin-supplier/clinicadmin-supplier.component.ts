import { Component, OnInit, ViewChild, ChangeDetectorRef, OnDestroy, ElementRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MediaMatcher } from '@angular/cdk/layout';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { MatSidenav } from '@angular/material/sidenav';

@Component({
  selector: 'app-clinicadmin-supplier',
  templateUrl: './clinicadmin-supplier.component.html',
  styleUrls: ['./clinicadmin-supplier.component.css']
})

export class ClinicadminSupplierComponent implements OnInit {
  loading:boolean;
  createsupplier: FormGroup;
  paymentmodetoppings = new FormControl();
  supplierid:any;
  servid:any;
  btnCreate:any;
  validatemyemail: boolean;

  constructor(
    private _formBuilder: FormBuilder,
    private _DoctorService: DoctorService,
    public _activatedRoute: ActivatedRoute,
    public toastrService: ToastService, private router:Router
    ) { 
    }

  ngOnInit(): void {
  this.loading = true;
  
  this.createsupplier = this._formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      //email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      phone: ['', Validators.required],
      address: [''],
      street: [''],
      city: [''],
      state: [''],
      country: [''],
      pincode: [''],
    });

    this.btnCreate = history.state.btnAction;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('supplierId')) {
        this.servid = params?.get('supplierId');
      }
    })

       if(this.servid != undefined){
        this._DoctorService.getsupplierdetails(Number(this?.servid))
        .pipe(first())
        .subscribe((res: any) => {
        if (!res.isError) {
        this.loading = false;
        let data = res?.responseMessage;

        this.createsupplier.get('name').setValue(data?.name);
        this.createsupplier.get('email').setValue(data?.email);
        this.createsupplier.get('phone').setValue(data?.mobileno);
        this.createsupplier.get('address').setValue(data?.address);
        this.createsupplier.get('street').setValue(data?.street);
        this.createsupplier.get('city').setValue(data?.city);
        this.createsupplier.get('state').setValue(data?.state);
        this.createsupplier.get('country').setValue(data?.country);
        this.createsupplier.get('pincode').setValue(data?.pincode);
        this.supplierid = Number(this?.servid);
        
        }
        else {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', res.errorMessage, options);
        }
        },
        err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
        });
        
    }else{
        this.loading = false;
    }
  }

  save(event) {
    const regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (regularExpression.test(String(event.target.value).toLowerCase())) {
      this.validatemyemail = true
    }
    else {
      this.validatemyemail = false;
    }
  }

  addsupplier(formData: any, formDirective: FormGroupDirective){
  this.loading = true;

    if (this.validatemyemail == false) {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Invalid Email Address', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);
      return;
    }

    if(this.createsupplier.value.name == "" || this.createsupplier.value.email == "" ||
      this.createsupplier.value.phone == "") {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Enter all the Manditory Fileds', options);
      setTimeout(() => {
        this.toastrService.clear(), 2000
      }, 2000);
      return;
    }

  let formobject = {};
  if(this.createsupplier.value.name != "" && this.createsupplier.value.email && this.createsupplier.value.phone) {
    if(!this.btnCreate && this.supplierid != undefined) {
    formobject = { 
    "ClinicsupplierId": this.supplierid,
    "Name": this.createsupplier.value.name,
    "Email": this.createsupplier.value.email,
    "Mobileno": this.createsupplier.value.phone,
    "Address": this.createsupplier.value.address,
    "Street": this.createsupplier.value.street,
    "City":this.createsupplier.value.city,
    "State": this.createsupplier.value.state,
    "Country": this.createsupplier.value.country,
    "Pincode": this.createsupplier.value.pincode
    }
    }

    if(this.btnCreate) {
    formobject = { "Name": this.createsupplier.value.name,
    "Email": this.createsupplier.value.email,
    "Mobileno": this.createsupplier.value.phone,
    "Address": this.createsupplier.value.address,
    "Street": this.createsupplier.value.street,
    "City":this.createsupplier.value.city,
    "State": this.createsupplier.value.state,
    "Country": this.createsupplier.value.country,
    "Pincode": this.createsupplier.value.pincode
    }
    }

    this._DoctorService.createsupplierdata(formobject, this.supplierid)
      .pipe(first())
          .subscribe((res: any) => {
              if(!res.isError) { 
                    this.loading = false;
                    formDirective.resetForm();
                    this.createsupplier.reset();
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.success('', res.responseMessage, options);
                    setTimeout(()=>{this.router.navigate(['/thealth/clinicadmin/supplier'])},2000);

              }else{
                  this.loading = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', res.errorMessage, options);
            }
      });
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please fill all the mandatory fields", options);
    }
  }
 
}
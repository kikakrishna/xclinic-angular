import { RouterModule } from '@angular/router';
import {ClinicadminSupplierComponent } from './clinicadmin-supplier.component';
export const ClinicadminSupplierRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminSupplierComponent,
    }
]
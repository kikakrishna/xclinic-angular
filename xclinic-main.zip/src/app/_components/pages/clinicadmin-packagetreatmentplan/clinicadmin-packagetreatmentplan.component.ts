import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';
import { ClinicadminDeletepackagetreatmentplanComponent } from '../clinicadmin-deletepackagetreatmentplan/clinicadmin-deletepackagetreatmentplan.component';
import { MatDialog } from '@angular/material/dialog';
export interface PeriodicElement {
  treatmentname: string;
  code: number;
  category: number;
  record: number;
  unit: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { treatmentname: 'Root Canal', code: 5, category: 343822, record: 10, unit: '2000', action: '' },
  { treatmentname: 'Root Canal', code: 4, category: 343822, record: 10, unit: '2000', action: '' },
];

@Component({
  selector: 'app-clinicadmin-packagetreatmentplan',
  templateUrl: './clinicadmin-packagetreatmentplan.component.html',
  styleUrls: ['./clinicadmin-packagetreatmentplan.component.css']
})

export class ClinicadminPackagetreatmentplanComponent implements OnInit {
  // ViewChild is used to access the input element.
  @ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', { static: false }) InputVar: ElementRef;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  clinicId: any;
  displayedColumns: string[] = ['treatmentname', 'code', 'unit', 'action',];
  // dataSource = ELEMENT_DATA;
  public dataSource: any = new MatTableDataSource([]);
  addressmodel: any;
  createTreatment: FormGroup
  loading: boolean;
  chargesTax: any;
  public details: any = [];
  tableArray: any = [];
  productunitArray: any = [];
  locationarray: any = [];
  categoryarray: any = [];
  taxarray: any = [];
  public totalSize = 0;
  public pageindex = 0;
  treatmentids: any;
  searchstring: any;
  size: any;
  listdata: boolean;
  getpendingstate: any;
  filterData: boolean;
  applyfilterData: boolean = false;
  Fsearchstring: string
  public originalarray: any = [];
  filterString;
  filter: string;
  searchinput: any;
  page1: any;
  savebutton: boolean = true;
  updatebutton: boolean = false;
  treatmentpackageId: any;
  TreatmentpackageId: any;
  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
    private _formBuilder: FormBuilder,
    private router: Router,
    public _activatedRoute: ActivatedRoute,
    public dialog: MatDialog
  ) { }




  ngOnInit(): void {
    this.createTreatment = this._formBuilder.group({
      code: [''],
      amount: ['', [Validators.pattern('^[0-9]*$')]],
      treatmentname: [''],
      noofvisit: [''],
      taxtype: [''],
      typevalue: [''],
    });
    this.loading = true;
    this.clinicId = sessionStorage.getItem('clinicId');
    this.dataSource.paginator = this.paginator;
    this._DoctorService.getPackagetreatmentplan(0, 5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          let array = [];
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
            this.dataSource.paginator = this.paginator
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
    this._DoctorService.getTaxlist()
      .pipe(first())
      .subscribe((res: any) => {
        this.taxarray = res?.responseMessage;
      },
        err => {
        });

  }
  selectedtax(event) {
    this.chargesTax = event.value.taxTypeId;
  }
  treatment_payload: any
  addtreatment(formData: any, formDirective: FormGroupDirective) {
    this.loading = true;
    console.log(this.createTreatment.value)

    if (this.createTreatment.value.treatmentname != '' && this.createTreatment.value.noofvisit != "" && this.createTreatment.value.amount != "" && this.createTreatment.value.code != "" && 
      this.createTreatment.value.treatmentname != null && this.createTreatment.value.noofvisit != null && this.createTreatment.value.amount != null && this.createTreatment.value.code != null
    ) {
      if(this.createTreatment.value.taxtype != '' && this.createTreatment.value.taxtype != null &&
      this.createTreatment.value.typevalue != '' && this.createTreatment.value.typevalue != null) {
        this.treatment_payload = {
          "TreatmentName": this.createTreatment.value.treatmentname,
          "Visits": this.createTreatment.value.noofvisit,
          "Amounts": this.createTreatment.value.amount,
          "Code": this.createTreatment.value.code,
          "TaxId": this.createTreatment.value.taxtype,
          "Taxamount": this.createTreatment.value.typevalue,
        }
      } else{
        this.treatment_payload = {
          "TreatmentName": this.createTreatment.value.treatmentname,
          "Visits": this.createTreatment.value.noofvisit,
          "Amounts": this.createTreatment.value.amount,
          "Code": this.createTreatment.value.code,
        }
      }
      console.log(this.treatment_payload)
      // return
      this._DoctorService.createtreatment(this.treatment_payload)
        .pipe(first()).subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            this.addressmodel = res?.responseMessage;
            console.log(res);
            // this.dataSource = new MatTableDataSource(this.addressmodel);

            setTimeout(() => {
              // this.dataSource.paginator = this.stockinlistpaginator
              this.totalSize = res?.pagination?.total;
            });


            // this.createpatProfile.reset();
            this.ngOnInit();
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);


          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        });

    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the mandatory fields', options);
    }
  }

  cancel() {
    this.createTreatment.reset();
    this.savebutton = true;
    this.updatebutton = false;
  }
  editclick(ele) {
    this.updatebutton = true;
    this.savebutton = false;
    this.loading = true;
    this._DoctorService.getTreatmentUserById(ele.treatmentpackageId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.details = res?.responseMessage[0];
          this.createTreatment.get('treatmentname').setValue(this.details.treatementName);
          this.createTreatment.get('noofvisit').setValue(this.details.visits);
          this.createTreatment.get('amount').setValue(this.details.amount);
          this.createTreatment.get('code').setValue(this.details.code);
          this.createTreatment.get('taxtype').setValue(this.details.taxid);
          this.createTreatment.get('typevalue').setValue(this.details.taxamount);
          this.treatmentids = ele.treatmentpackageId;
          this.TreatmentpackageId = this.details.treatmentpackageId;
          // this.userId = this.details.userId
          console.log(this.details)
          console.log(this.details.treatmentpackageId)
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  getNext(event) {
    this.loading = true;
    let array = [];
    this._DoctorService.getPackagetreatmentplan(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  deleteclick(deldata) {
    const dialogRef = this.dialog.open(ClinicadminDeletepackagetreatmentplanComponent, {
      panelClass: 'deletewrapper',
      data: deldata.treatmentpackageId
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        console.log(res)
        if (!res.data.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.data.responseMessage, options);
          this.packagetreatmentplan(Event);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.data.errorMessage, options);
        }
      }
    },
      err => {
        console.log('alert')
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }


  packagetreatmentplan(event) {
    this._DoctorService.getPackagetreatmentplan(0, 5)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.dataSource = new MatTableDataSource(this.addressmodel);
          setTimeout(() => {
            this.totalSize = res?.pagination?.total;
          });
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }



  UpdateUser(formDirective: FormGroupDirective) {
    console.log("vengatttt" + this.createTreatment?.value.treatmentname.trim() == '' || this.createTreatment?.value.treatmentname.trim() == null)
    if
      (this.createTreatment?.value.treatmentname.trim() == '' || this.createTreatment?.value.treatmentname.trim() == null ||
      this.createTreatment?.value.noofvisit== '' || this.createTreatment?.value.noofvisit == null ||
      this.createTreatment?.value.amount == '' || this.createTreatment?.value.amount == null ||
      this.createTreatment?.value.code == '' || this.createTreatment?.value.code == null
    ) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
      
    }
   else {
      this.loading = true;

      let payload = {
        "TreatmentName": this.createTreatment.value.treatmentname,
        "Visits": this.createTreatment.value.noofvisit,
        "Amounts": this.createTreatment.value.amount,
        "Code": this.createTreatment.value.code,
        "TreatmentpackageId":this.TreatmentpackageId,
        "TaxId": this.createTreatment.value.taxtype,
        "Taxamount": this.createTreatment.value.typevalue,
      }

      console.log("jhhfsdgg" + payload)
      this._DoctorService.updateUserById(payload, this.treatmentpackageId)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            setTimeout(() => {
              // this.dataSource.paginator = this.stockinlistpaginator
              this.totalSize = res?.pagination?.total;
            });
            this.createTreatment.reset();
            this.savebutton=true;
            this.updatebutton=false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            // this.sidenav.close();
            this.ngOnInit()
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

}
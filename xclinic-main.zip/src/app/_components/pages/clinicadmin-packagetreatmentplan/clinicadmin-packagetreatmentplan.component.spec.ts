import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminPackagetreatmentplanComponent } from './clinicadmin-packagetreatmentplan.component';

describe('ClinicadminPackagetreatmentplanComponent', () => {
  let component: ClinicadminPackagetreatmentplanComponent;
  let fixture: ComponentFixture<ClinicadminPackagetreatmentplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminPackagetreatmentplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminPackagetreatmentplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

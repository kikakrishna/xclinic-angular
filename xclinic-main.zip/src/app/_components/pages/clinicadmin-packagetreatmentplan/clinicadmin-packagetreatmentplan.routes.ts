import { RouterModule } from '@angular/router';
import { ClinicadminPackagetreatmentplanComponent } from './clinicadmin-packagetreatmentplan.component';
export const ClinicadminPackagetreatmentplanRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminPackagetreatmentplanComponent,
    }
]
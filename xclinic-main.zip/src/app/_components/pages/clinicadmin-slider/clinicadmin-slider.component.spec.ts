import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminSliderComponent } from './clinicadmin-slider.component';

describe('ClinicadminSliderComponent', () => {
  let component: ClinicadminSliderComponent;
  let fixture: ComponentFixture<ClinicadminSliderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminSliderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild,ElementRef } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { FormBuilder, FormControl, FormGroup, Validators,FormGroupDirective} from '@angular/forms';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDeletesliderComponent } from '../clinicadmin-deleteslider/clinicadmin-deleteslider.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-clinicadmin-slider',
  templateUrl: './clinicadmin-slider.component.html',
  styleUrls: ['./clinicadmin-slider.component.css']
})

export class ClinicadminSliderComponent implements OnInit {
// ViewChild is used to access the input element.
  @ViewChild("myButton", { static: false }) myButton: ElementRef;
  @ViewChild('takeInput', {static: false})InputVar: ElementRef;
      
  clinicId:any;
  displayedColumns: string[] = ['title', 'action'];
  public sliderArraydataSource: any = new MatTableDataSource([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  loading:boolean;
  imgfileWeb: any;
  imgfileonupdateWeb: boolean = false;
  imgerrorWeb: any;

  imgfileRes: any;
  imgfileonupdateRes: boolean = false;
  imgerrorRes: any;
  addressmodel: any;
  createslider: FormGroup;
  constructor(
    private _DoctorService: DoctorService,
    private _patientservice: PatientService,
    public toastrService: ToastService,
     private _formBuilder: FormBuilder,
    private router: Router,
    public dialog: MatDialog,
    ) { }


  ngOnInit(): void {
    this.loading = true;

     this.createslider = this._formBuilder.group({
      title: ['', Validators.required],
    });

    this.clinicId = sessionStorage.getItem('clinicId');
     this.sliderArraydataSource.paginator = this.paginator;
    this._DoctorService.getSliderslist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.sliderArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  createclick(){
      this.router.navigate([`/thealth/clinicadmin/services/add`], { state: { servicestatus: 'create', btnAction:true } });
  }

  editclick(ele){
    this.router.navigate([`/thealth/clinicadmin/services/edit/${ele.clinicserviceid}`], { state: { servicestatus: ele, btnAction:false } });
      }


  deleteclick(deldata) {
  this.loading = false;
  const dialogRef = this.dialog.open(ClinicadminDeletesliderComponent, {
  panelClass: 'deletewrapper',
  data: deldata.clinicSliderImageId
  });
  dialogRef.afterClosed().subscribe(res => {
  if (res) {
  if (!res.data.isError) {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.success('', res.data.responseMessage, options);
    this.sliderslist();
  } else {
    this.loading = false;
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', res.data.errorMessage, options);
  }
  }
  },
  err => {
  this.loading = false;
  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  this.toastrService.warning('', err?.error, options);
  });
  }

  sliderslist() {
    this._DoctorService.getSliderslist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.addressmodel = res?.responseMessage;
          this.sliderArraydataSource = new MatTableDataSource(this.addressmodel);
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

	uploadWebimage(event, DocSignFile) {
    let fileExt = event.target.files[0].type.split('/')[1]
    let fileSize = event.target.files[0].size;
    console.log(event.target,fileSize)
    if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || fileExt === 'webp') {
      if (1000 <= fileSize ) {
        this.imgerrorWeb = false;
        let reader = new FileReader(); // HTML5 FileReader API
        let file = event.target.files[0];
        this.imgfileWeb = event.target.files[0];
        this.imgfileonupdateWeb = false;
        console.log('this is image', this.imgfileWeb)
        if (event.target.files && event.target.files[0]) {
          reader.readAsDataURL(file);
        }
      }
      else {
        DocSignFile.value = ''
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Plesae upload an image above 20kb", options);
      }
    }
    else {
      DocSignFile.value = ''
      this.imgerrorWeb = "Only jpg, jpeg, png file format is accepted"
    }

	}

	uploadResponimage(event, DocSignFileRes) {
  let fileExt = event.target.files[0].type.split('/')[1]
    let fileSize = event.target.files[0].size;
    if (fileExt === 'jpg' || fileExt === 'jpeg' || fileExt === 'png' || fileExt === 'webp') {
      if (1000 <= fileSize ) {
        this.imgerrorRes = false;
        let reader = new FileReader(); // HTML5 FileReader API
        let file = event.target.files[0];
        this.imgfileRes = event.target.files[0];
        this.imgfileonupdateRes = false;
        console.log('this is image', this.imgfileWeb)
        if (event.target.files && event.target.files[0]) {
          reader.readAsDataURL(file);
        }
      }
      else {
        DocSignFileRes.value = ''
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Plesae upload an image above 20kb", options);
      }
    }
    else {
      DocSignFileRes.value = ''
      this.imgerrorRes = "Only jpg, jpeg, png file format is accepted"
    }
	}

	createSlider(formData: any, formDirective: FormGroupDirective){

  this.loading = true;

  if(this.createslider.value.title == '' || this.createslider.value.title == null){
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.loading = false;
    this.toastrService.warning('', "Enter all the Mandatory Fields", options);
        return;
    }

    if(this.imgfileWeb?.name == '' || this.imgfileWeb?.name == null || this.imgfileWeb?.name == undefined){
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please upload an Slider Banner Web Image", options);
    }

    if(this.imgfileRes?.name == '' || this.imgfileRes?.name == null || this.imgfileRes?.name == undefined){
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please upload Slider Banner Responsive Image", options);
    }


    if(this.imgfileWeb?.name != '' && this.imgfileRes?.name != '' && this.imgfileWeb?.name != undefined && this.imgfileRes?.name != undefined){
          this._DoctorService.createsliderdata(this.createslider, this.imgfileWeb,this.imgfileRes)
          .pipe(first())
          .subscribe((res: any) => {
          if (!res.isError) {
          console.log(res)
          if(!res.isError) {   
          console.log('updated data', res) 

          this.loading = false;
          formDirective.resetForm();
          this.InputVar.nativeElement.value = "";
          this.myButton.nativeElement.value = "";
          this.createslider.reset(); 
          this.imgfileWeb=null; 
          this.imgfileonupdateWeb = false; 
          this.imgfileRes=null; 
          this.imgfileonupdateRes = false; 

          this.sliderslist();             
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          this.loading = false;
          }

          }
          });
    }

	}

  sliderReset(formData: any, formDirective: FormGroupDirective)
  {
  formDirective.resetForm();
  this.InputVar.nativeElement.value = "";
  this.myButton.nativeElement.value = "";
  this.createslider.reset(); 
  this.imgfileWeb=null; 
  this.imgfileonupdateWeb = false; 
  this.imgfileRes=null; 
  this.imgfileonupdateRes = false; 
  }




}

import { RouterModule } from '@angular/router';
import { ClinicadminSliderComponent } from './clinicadmin-slider.component';
export const ClinicadminSliderRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminSliderComponent,
    }
]
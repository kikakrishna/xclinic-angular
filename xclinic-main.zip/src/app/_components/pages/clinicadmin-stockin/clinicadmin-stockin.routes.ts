import { RouterModule } from '@angular/router';
import { ClinicadminStockinComponent } from './clinicadmin-stockin.component';
export const ClinicadminStockinRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminStockinComponent,
    }
]
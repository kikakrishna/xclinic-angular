import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import * as moment from 'moment';

export interface PeriodicElement {
  productname: string;
  qty: string;
  unittype: string;
  unitcost: string;
  subtotal: string;
  action: string;

}
const ELEMENT_DATA: PeriodicElement[] = [
  { productname: 'Product 1', qty: '2', unittype: 'Box', unitcost: '100', subtotal: '200', action: '' },
  { productname: 'Product 2', qty: '3', unittype: 'Piece', unitcost: '50', subtotal: '150', action: '' },
  { productname: 'Product 3', qty: '4', unittype: 'Box', unitcost: '10', subtotal: '40', action: '' },

];
@Component({
  selector: 'app-clinicadmin-stockin',
  templateUrl: './clinicadmin-stockin.component.html',
  styleUrls: ['./clinicadmin-stockin.component.css']
})
export class ClinicadminStockinComponent implements OnInit {
  displayedColumns: string[] = ['productname', 'qty', 'unittype', 'unitcost', 'subtotal', 'action'];
  public dataSource: any = new MatTableDataSource([]);
  createstockin: FormGroup;
  total: any;
  subtotal: any;
  granttotal: any;
  clinicid: any;
  chargesProduct: any;
  note: any;
  domaincurrency: any;
  servid: any;
  loading: boolean;
  btnCreate: boolean;
  tableArray: any = [];
  inwardArray: any = [];
  locationarray: any = [];
  supplierarray: any = [];
  productarray: any = [];
  tableinwardArray: any = [];
  maxDate: any;
  unitType: any;

  constructor(
    private _formBuilder: FormBuilder,
    public _activatedRoute: ActivatedRoute,
    private _DoctorService: DoctorService,
    public toastrService: ToastService, private router: Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('createpaginator', { read: MatPaginator }) createpaginator: MatPaginator;

  ngOnInit(): void {
    this.loading = true;
    setTimeout(() => {
      this.loading = false;
    }, 2000)

    console.log(this.maxDate)
    this.maxDate = new Date();
    // this.maxDate = moment(this.maxDate)
    this.createstockin = this._formBuilder.group({
      stockdate: [''],
      stockproduct: [''],
      stocksupplier: [''],
      stockqty: [''],
      stocklocation: [''],
      stockunit: [''],
      stockrefno: [''],
    });

    this.btnCreate = true;
    this._activatedRoute.paramMap.subscribe(params => {
      if(params?.get('stockinwardId')) {
        this.servid = params?.get('stockinwardId');
        this.btnCreate = false;
      }
    })

    console.log(this.servid);
    this.domaincurrency = sessionStorage.getItem('domaincurrencydetails');
    this.clinicid = sessionStorage.getItem('clinicId');

    this._DoctorService.getlocations(this.clinicid)
      .pipe(first())
      .subscribe((res: any) => {
        this.locationarray = res?.responseMessage;
        // console.log('location details',res?.responseMessage);
      },
        err => {
        });

    console.log('edit details ', history.state.stockinstatus)

    if(this.servid != undefined) {
        this._DoctorService.getstockindetails(Number(this?.servid))
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              console.log('stockin details', res)
              this.loading = false;
              let data = res?.responseMessage[0];

              const d = new Date(data?.stockdate) 
              let newdatevalue = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString();

              this.createstockin.get('stockdate').setValue(newdatevalue);

              this.createstockin.get('stocksupplier').setValue(data?.supplierId);
              this.createstockin.get('stocklocation').setValue(data?.clinicLocationId);
              this.createstockin.get('stockrefno').setValue(data?.referenceno);
              this.granttotal = data?.totalAmount;
              this.note = data?.notes;
              data?.productStockList.map((datas, key) => {
                this.tableArray.push(
                  {
                    "id": key,
                    //"productname": data?.productStockList,
                    "productname": datas?.productName,
                    "productdate": data?.stockdate,
                    "supplier": data?.supplierName,
                    "location": data?.clinicLocationId,
                    "refno": data?.referenceno,
                    "qty": datas.quantity,
                    "unitcost": datas?.unitCost,
                    "unittype": datas?.unitType,
                    "subtotal": Number(datas?.subTotal).toFixed(2),
                  })
              })

              this.dataSource = new MatTableDataSource(this.tableArray);
              setTimeout(() => {
                this.dataSource.paginator = this.createpaginator
              });


            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
            }
          },
            err => {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', err?.error, options);
            });
    } else {
      this.loading = false;
    }

    // Get supplier list 
    this._DoctorService.getSupplierlist()
      .pipe(first())
      .subscribe((res: any) => {
        this.supplierarray = res?.responseMessage;
        console.log('supplier details', res?.responseMessage);
      },
        err => {
        });

    // Get product list 
    console.log(this.btnCreate)
    if (this.btnCreate == true) {
      this._DoctorService.getProductlist()
        .pipe(first())
        .subscribe((res: any) => {
          this.productarray = res?.responseMessage;
          console.log('product details', res?.responseMessage);
        },
          err => {
          });
    }

    setTimeout(() => this.dataSource.paginator = this.createpaginator);
    this.dataSource.paginator = this.paginator;
  }

  selectedproduct(event) {
    this.chargesProduct = event.value.productName;
    this.unitType = event.value.unitType;
    console.log('product change', this.chargesProduct, event.value.productId);
  }

  calculation(event) {
    // console.log('calculationevent',event);
    let sumtotal = Number(event.stockqty) * Number(event.stockunit)
    this.total = sumtotal;
  }

  getTotalCost() {
    let granttotal = this.tableArray.map(t => Number(t.subtotal)).reduce((acc, value) => acc + value, 0);
    this.granttotal = granttotal;
    return this.tableArray.map(t => Number(t.subtotal)).reduce((acc, value) => acc + value, 0);
  }

  addstock(formData: any, formDirective: FormGroupDirective) {
    //console.log(this.createstockin.value)
    //this.calculation(this.createstockin.value);
    if (this.createstockin.value.stockdate != '' && this.createstockin.value.stocklocation != ""  && this.createstockin.value.stocksupplier != "") {
      if (this.createstockin.value.stockproduct != '' && this.createstockin.value.stockqty != "" && this.createstockin.value.stockunit != "") {
        let sumtotal = Number(this.createstockin.value.stockqty) * Number(this.createstockin.value.stockunit)
        this.subtotal = sumtotal;

        let count = 0;
        if (this.tableArray.length == 0) {
          count = 0;
        } else {
          count = this.tableArray.length + 1;
        }

        this.createstockin.value.stockproduct.productId
        // console.log('cehfdefe')
        // console.log(this.dataSource.filteredData)
        // let Check = this.dataSource.filteredData.find(x => x.productId == this.createstockin.value.stockproduct.productId)
        // console.log(Check, 'check')


        this.tableArray.push(
          {
            "id": count,
            "productid": this.createstockin.value.stockproduct.productId,
            "productname": this.chargesProduct,
            "productdate": this.createstockin.value.stockdate,
            "supplier": this.createstockin.value.stocksupplier,
            "location": this.createstockin.value.stocklocation,
            "refno": this.createstockin.value.stockrefno,
            "qty": this.createstockin.value.stockqty,
            "unitcost": this.createstockin.value.stockunit,
            "unittype": this.unitType,
            "subtotal": Number(this.subtotal).toFixed(2),
          })

        this.inwardArray.push(
          {
            "Productid": this.createstockin.value.stockproduct.productId,
            "Quantity": Number(this.createstockin.value.stockqty),
            "Unitcost": Number(this.createstockin.value.stockunit),
            "Subtotal": Number(this.subtotal)
          })

        this.dataSource = new MatTableDataSource(this.tableArray);
        setTimeout(() => {
          this.dataSource.paginator = this.createpaginator
        });
        this.clearinput(formData, formDirective);
      }
    }
    else {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill all the mandatory fields', options);
    }
  }

  clearinput(formData: any, formDirective: FormGroupDirective) {
    // formDirective.resetForm();
    // this.createstockin.reset();

    // this.createstockin.controls['stockproduct','stockqty','stockunit'].reset();
    this.createstockin.get('stockproduct').reset();
    this.createstockin.get('stockqty').reset();
    this.createstockin.get('stockunit').reset();
    this.createstockin.value.stockproduct = "";
  }

  modelChangeQty(data, element) {
    if (data != '') {
      let sumtotal = Number(data) * Number(element.unitcost)
      this.subtotal = sumtotal;
      const idx = this.dataSource.data.findIndex((x) => x.id == element.id);
      this.dataSource.data[idx].subtotal = Number(this.subtotal).toFixed(2);
    }
  }

  modelChangeCost(data, element) {
    if (data != '') {
      let sumtotal = Number(element.qty) * Number(data);
      this.subtotal = sumtotal;
      const idx = this.dataSource.data.findIndex((x) => x.id == element.id);
      this.dataSource.data[idx].subtotal = Number(this.subtotal).toFixed(2);
    }
  }
  getstockform() {
    this.loading = true;
    console.log(this.note, this.createstockin.value, this.inwardArray, this.granttotal);
    // product array from DataTable 
    this.tableinwardArray = [] 
    for (let tableData in this.dataSource.filteredData) {
      console.log(this.dataSource.filteredData[tableData].qty)
      console.log(Number(this.dataSource.filteredData[tableData].subtotal))
      this.tableinwardArray.push({
        "Productid": this.dataSource.filteredData[tableData].productid,
        "Quantity": Number(this.dataSource.filteredData[tableData].qty),
        "Unitcost": Number(this.dataSource.filteredData[tableData].unitcost),
        "Subtotal": Number(this.dataSource.filteredData[tableData].subtotal)
      })
    }
    console.log(this.tableinwardArray)
    let formobject = {
      "Date": moment(this.createstockin.value.stockdate).format(),
      "Reference": this.createstockin.value.stockrefno,
      "Cliniclocationmapid": this.createstockin.value.stocklocation,
      "Notes": this.note,
      "SupplierId": this.createstockin.value.stocksupplier,
      "Amount": this.granttotal,
      "Productinward": this.tableinwardArray
    }
    // return
    this._DoctorService.createstockindata(formobject)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res);
          this.loading = false;
          this.createstockin.reset();
          this.note = "";
          this.tableArray = [];
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          setTimeout(() => { this.router.navigate(['/thealth/clinicadmin/stockinlist']) }, 2000);

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      });
  }

  deletecharges(data) {
    // const filteredtabl3 = 
    let a = this.tableArray.filter((item) => item.id !== data.id);
    this.dataSource = new MatTableDataSource(a);
    this.tableArray = a;
    this.dataSource.paginator = this.paginator
  }

}
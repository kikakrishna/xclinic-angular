import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminStockinComponent } from './clinicadmin-stockin.component';

describe('ClinicadminStockinComponent', () => {
  let component: ClinicadminStockinComponent;
  let fixture: ComponentFixture<ClinicadminStockinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminStockinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminStockinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminDoctortreatmentComponent } from './clinicadmin-doctortreatment.component';

describe('ClinicadminDoctortreatmentComponent', () => {
  let component: ClinicadminDoctortreatmentComponent;
  let fixture: ComponentFixture<ClinicadminDoctortreatmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminDoctortreatmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminDoctortreatmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

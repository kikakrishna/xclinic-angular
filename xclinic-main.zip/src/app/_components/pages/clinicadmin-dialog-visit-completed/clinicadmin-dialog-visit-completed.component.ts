import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-clinicadmin-dialog-visit-completed',
  templateUrl: './clinicadmin-dialog-visit-completed.component.html',
  styleUrls: ['./clinicadmin-dialog-visit-completed.component.css']
})
export class ClinicadminDialogVisitCompletedComponent implements OnInit {

 
  constructor(public dialogRef: MatDialogRef<ClinicadminDialogVisitCompletedComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  conform(){
    this.dialogRef.close({data:"conform"});

  }
}


import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { first } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';

@Component({
  selector: 'app-clinicadmin-cancel',
  templateUrl: './clinicadmin-cancel.component.html',
  styleUrls: ['./clinicadmin-cancel.component.css']
})
export class ClinicadminCancelComponent implements OnInit {
  Appointmentcancel: FormGroup;
  loading:boolean;
  constructor(private _formBuilder: FormBuilder,
    private _DoctorService: DoctorService,
    public dialogRef: MatDialogRef<ClinicadminCancelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  ngOnInit(): void {
    this.Appointmentcancel = this._formBuilder.group({
    });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  apptcancel() {
    this.loading = true;
    this._DoctorService.cancelapt(this.Appointmentcancel.value, this.data)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.dialogRef.close({ data: res });
        } else {
          this.loading = false;
          this.dialogRef.close({ data: res });
        }
      },
        err => {
          this.loading = false;
          this.dialogRef.close({ data: err });
        });
  }
}
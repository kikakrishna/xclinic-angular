import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminAddslotsComponent } from './clinicadmin-addslots.component';

describe('ClinicadminAddslotsComponent', () => {
  let component: ClinicadminAddslotsComponent;
  let fixture: ComponentFixture<ClinicadminAddslotsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminAddslotsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminAddslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

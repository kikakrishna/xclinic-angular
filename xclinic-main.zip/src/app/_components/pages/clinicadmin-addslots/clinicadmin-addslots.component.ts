import { Component, Inject, OnInit } from '@angular/core';
import { DoctorService } from '../../../_services/doctor.service';
import { first } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import * as moment from 'moment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
import { PatientService } from 'src/app/_services/patient.service';
import { ClinicadminDialogconformmanageslsotComponent } from '../clinicadmin-dialogconformmanageslsot/clinicadmin-dialogconformmanageslsot.component';
@Component({
  selector: 'app-clinicadmin-addslots',
  templateUrl: './clinicadmin-addslots.component.html',
  styleUrls: ['./clinicadmin-addslots.component.css']
})
export class ClinicadminAddslotsComponent implements OnInit {
  AddSlot: FormGroup;
  loading: boolean;
  listSlot: FormGroup;
  stdate: any;
  eddate: any;
  timeenable: boolean;
  stime: any;
  uId: string;
  date: any;
  etime: any;
  timevalid: boolean;
  dayslot: any = [];
  dayslot2: any = [];
  weekdays: any = []
  public clinicname: any = [];
  public appoinmenttype: any = [];
  myStartDate: any = new Date();
  myEndDate: any;
  minmessage: boolean;
  doctorid: any;
  selectedDoctor: any;
  isDoubletype: boolean = false;
  viewprofileArray: any = [];
  clinicLocations: any = [];
  clinicId: any;
  enableLocation: boolean = false;
  defaultClinic: any;
  clinicLocationmapId: any;
  singletype: any;
  constructor(public _formBuilder: FormBuilder,
    public _DoctorService: DoctorService,
    public _patientservice: PatientService,
    public matdialog: MatDialog,
    private dialog: MatDialogRef<ClinicadminAddslotsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private toastrService: ToastService) {
    this.AddSlot = this._formBuilder.group({
      clinicname: ['', Validators.required],
      startdate: ['', Validators.required],
      enddate: ['', Validators.required],
      starttime: ['', Validators.required],
      endtime: ['', Validators.required],
      time: ['', [Validators.required, Validators.pattern("^[0-9]{1,3}$")]],
      Consultationtype: ['', Validators.required],
      location: [''],
    });
    this.listSlot = this._formBuilder.group({
      clinicname: [''],
      startdate: ['', Validators.required],
      enddate: ['', Validators.required]
    });
    this.doctorid = this.data;
  }

  ngOnInit(): void {
    this.selectedDoctor = JSON.parse(sessionStorage.getItem("selecteddoctor"));
    this.AddSlot.controls.enddate.disable();
    this.date = new Date().toISOString().substr(0, 10);
    this.uId = sessionStorage.getItem('userId');
    this.getdaylist();
    this._DoctorService.getcliniclist()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.clinicname = res.responseMessage;
          this.AddSlot.get('clinicname').setValue(res.responseMessage[0].clinicId);
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });

    // this._DoctorService.getappoinmenttype()
    this._patientservice.getpaymentType_Notwalkin()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          for (let i of res.responseMessage) {
            if (i.appointmentTypeName == "Video Consultation") {
              i.appoinmentlabel = "Video"
            }
            if (i.appointmentTypeName == "Clinic Visit") {
              i.appoinmentlabel = "Clinic Visit"
            }
          }
          this.appoinmenttype = res?.responseMessage

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
    this._DoctorService.viewprofile(this.selectedDoctor.doctorId)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        // enable and disable section for consulation type
        // console.log(this.selectedDoctor)
        let ctypearray = [];
        this.viewprofileArray = res?.responseMessage
        res?.responseMessage?.doctorConsultationType.forEach(element => {
          console.log(element)
          if (element.status == 1 && element?.typeId != 102) {
            console.log(element, "__")
            ctypearray.push(element);
          }
        });
        console.log(ctypearray)
        // console.log(this.appoinmenttype)
        if (ctypearray.length == 2) {
          this.isDoubletype = true;
          this.AddSlot.get('Consultationtype').setValue(this.appoinmenttype[0]?.appointmentTypeId);
        }
        if (ctypearray.length == 1) {
          this.appoinmenttype.forEach(apptype => {
            if (apptype.appointmentTypeName == ctypearray[0].consultationType) {
              this.singletype = apptype.appointmentTypeName;
              this.AddSlot.get('Consultationtype').setValue(apptype.appointmentTypeId);
              console.log(this.AddSlot.value.Consultationtype)
              if(this.AddSlot.value.Consultationtype == 2){
                this.enableLocation = true;
              }
              this.isDoubletype = false;
            }
          });
          // console.log(ctypearray)
        }
      })

      this.getClinicLocations();
  }

  getClinicLocations(){
     // Get clinic locations
     this.clinicId = sessionStorage.getItem('clinicId');
     console.log(this.clinicId);
     this._DoctorService.getclinicLocations(this.clinicId)
     .pipe(first())
     .subscribe((res: any) => {
       if(!res.isError){
         console.log(res)
         this.clinicLocations = res.responseMessage;
         console.log(this.clinicLocations)
       }
       else {
         this.loading = false;
         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
         this.toastrService.warning('', res.errorMessage, options);
       }
     }, err => {
       this.loading = false;
       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
       this.toastrService.warning('', err?.error, options);
     })
  }
  changeType(event){
    console.log(event);
    if(event.value == 2){
      this.enableLocation = true;
      this.AddSlot.controls['location'].setValidators([Validators.required]);    
    } else {
      this.enableLocation = false;
      this.AddSlot.controls["location"].clearValidators();
    }
  }
  dateenabled() {
    this.AddSlot.controls.enddate.reset();
    if (this.AddSlot.value.startdate != "") {
      this.AddSlot.controls.enddate.enable();
    }
  }
  datevalidation() {
    if (this.AddSlot.value.startdate == "") {
      this.AddSlot.controls.enddate.disable();
      return;
    }
    this.myEndDate = this.AddSlot.value.startdate;
  }
  satdate() {
    const sdate = this.AddSlot.value.startdate;
    const constdate = moment(sdate).format();
    this.stdate = constdate.substr(0, 19);
  }
  getdaylist() {
    this.loading = true;
    this._DoctorService.getweekdays()
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          this.weekdays = res.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      });
  }
  slotchange(daysid, event) {
    if (event.checked) {
      this.dayslot.push(daysid);
      if (this.dayslot.length > 0) {
      } else {
      }
    } else {
      const index = this.dayslot.indexOf(daysid);
      this.dayslot.splice(index, 1);
    }
  }
  slotchange2(data, event) {
    if (event.checked) {
      this.dayslot2.push(data);
      if (this.dayslot2.length > 0) {
      } else {
      }
    } else {
      const index = this.dayslot2.indexOf(data?.slotdayId);
      this.dayslot2.splice(index, 1);
    }
  }
  edate() {
    const edate = this.AddSlot.value.enddate;
    const coneddate = moment(edate).format();
    this.eddate = coneddate.substr(0, 19);
    if (this.eddate >= this.stdate) {
      this.timeenable = false;
    } else {
      this.timeenable = true;
    }
  }

  setstTime(event) {
    const starttime = event;
    const st = moment(starttime, ["h:mm A"]).format("HH:mm:ss");
    this.stime = this.date + 'T' + st;
    this.AddSlot?.controls?.time?.reset();
    if (this.stime > this.etime) {
      this.timevalid = true;
    } else {
      this.timevalid = false;
    }
  }
  setedTime(event) {
    const endtime = event;
    const et = moment(endtime, ["h:mm A"]).format("HH:mm:ss");
    this.etime = this.date + 'T' + et;
    this.AddSlot?.controls?.time?.reset();
    if (this.stime > this.etime) {
      this.timevalid = true;
    } else {
      this.timevalid = false;
    }
   
  }

  timevalidation(event) {
    var diff = Date.parse(this.etime) - Date.parse(this.stime);
    var msec = diff
    var mm = Math.floor(msec / 60000);
    if (this.AddSlot.value.time <= mm) {
      this.minmessage = false;
    } else {
      this.minmessage = true;
    }
  }
  array: any = [];
  createdocslot(formData: any, formDirective: FormGroupDirective) {
    console.log(this.AddSlot.value.Consultationtype)
    console.log(this.viewprofileArray.doctorConsultationType)

    // Set default clinic location if consultation type is video
    this.getClinicLocations();
    console.log(this.AddSlot.value.Consultationtype);
    console.log(this.AddSlot.value.location);
    if(this.AddSlot.value.time == 0) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('',"Please enter valid duration", options);
      return;
    }
    if(this.AddSlot.value.Consultationtype != 1) {
      console.log(this.AddSlot.value)
      this.clinicLocationmapId = this.AddSlot.value.location;
    }
    else {
      console.log(this.clinicLocations);
      this.clinicLocations.forEach(element => {
        if(element.defaultclinic == true) {
          this.clinicLocationmapId = element.clinicLocationMapId;
        }
      });
    }

    for (let i of this.viewprofileArray.doctorConsultationType) {
      // console.log(i)
      if (i?.typeId == this.AddSlot?.value?.Consultationtype &&
        i?.consultationType != "Walk-In" &&
        i?.status == "1") {
          this.array = (i?.loccm).filter(loc => loc.clinicLocationMapId === this.clinicLocationmapId)
          console.log(this.array)
          this.array.map((getData)=>{
          if(getData.isConsultationCodeMapped== false) {
          //if(this.array.isConsultationCodeMapped== false) {
            console.log(i)
            const dialogRef = this.matdialog.open(ClinicadminDialogconformmanageslsotComponent, {
              panelClass: 'deletewrapper',
              width: '300px'
            });
            dialogRef.afterClosed().subscribe(res => {
              if (res) {
                console.log(res)
                if (!res.data.isError) {
                  if (res?.data == "conform") {
                    this.aution();               
                    return;
                  }
                  if (res?.data == "no") {                
                    return;
                  }
                }
              }
            })
            return;
          } else {
            this.aution(); 
            return;
          }
        })
      } 
    }
  }
  aution() {
    this.loading = true;
    this.toastrService.clear();
    this._DoctorService.createslot(
      this.stdate, this.eddate, this.stime, this.etime, this.doctorid, this.dayslot, this.AddSlot.value.time, this.AddSlot.value, this.AddSlot.value.Consultationtype, this.clinicLocationmapId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          this.AddSlot.reset();
          this.dialog.close("slotcreated");
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err.error, options);
        });
  }
  resetForm(formData: any, formDirective: FormGroupDirective) {
    this.AddSlot.reset();
    this.listSlot.reset();
    formDirective.resetForm();
    this.dayslot = [];
    this.getdaylist();
    this.ngOnInit();
    this.enableLocation = false;
  }
}


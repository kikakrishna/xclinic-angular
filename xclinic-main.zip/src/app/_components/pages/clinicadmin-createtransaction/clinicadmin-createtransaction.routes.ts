import { RouterModule } from '@angular/router';
import { ClinicadminCreatetransactionComponent } from './clinicadmin-createtransaction.component';
export const ClinicadminCreateTransactionRoutes: RouterModule[] = [
    {
        path: '',
        component: ClinicadminCreatetransactionComponent,
    }
]
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicadminCreatetransactionComponent } from './clinicadmin-createtransaction.component';

describe('ClinicadminCreatetransactionComponent', () => {
  let component: ClinicadminCreatetransactionComponent;
  let fixture: ComponentFixture<ClinicadminCreatetransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClinicadminCreatetransactionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicadminCreatetransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatRadioChange } from '@angular/material/radio';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'ng-uikit-pro-standard';
import { ReplaySubject, Subject } from 'rxjs';
import { first, take, takeUntil } from 'rxjs/operators';
import { DoctorService } from 'src/app/_services/doctor.service';
import { PatientService } from 'src/app/_services/patient.service';
import { Bank } from '../clinicadmin-transaction/clinicadmin-transaction.component';

@Component({
  selector: 'app-clinicadmin-createtransaction',
  templateUrl: './clinicadmin-createtransaction.component.html',
  styleUrls: ['./clinicadmin-createtransaction.component.css']
})
export class ClinicadminCreatetransactionComponent implements OnInit, AfterViewInit, OnDestroy {
  public dataSource: any = new MatTableDataSource([]);
  displayedColumns: string[] = ['chargesname', 'qty', 'amount', 'discount', 'Tax', 'total', 'action'];
  chargeslist: any = [];
  productchargeslist: any = [];
  discountlist: any = [];
  discountlistpro: any = [];
  loading: boolean = false;
  IseditDiscount: boolean = false;

  BalanceAmount: Number
  discountAmount: Number;
  actualqty:any;
  actualprice:any;
  actualproductamount:any;
  discountpro:any;
  totalpro:any;
  discountInputdatapro:any;
  chargesInputproduct:any;
  actualTaxamountpro:any;
  productresp:any = [];
  addDetailsproduct:any = {};
  ISdiscountInputdatapro:boolean = false;
  modelPDiscountType: any;
  // start
  /** list of banks */
  protected banks: Bank[] = []

  /** control for the selected bank */
  public bankCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword */
  public bankFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanks: ReplaySubject<Bank[]> = new ReplaySubject<Bank[]>(1);

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;

  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();

  billid_edit = ""
  Iseditbill: boolean = false;
  saveid: any;
  cur_label: any = ""

  // createpaginator
  // end
  constructor(private _patientservice: PatientService,
    public toastrService: ToastService,
    public _DoctorService: DoctorService,
    public router: Router,
    public _activatedRoute: ActivatedRoute,
    public _formBuilder: FormBuilder) {
    this._activatedRoute.paramMap.subscribe(params => {
      if (params?.get('bill_appointment_map_id')) {
        this.billid_edit = params?.get('bill_appointment_map_id');

      }
    })

  }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('createpaginator', { read: MatPaginator }) createpaginator: MatPaginator;
  rbtnarray: any = [];
  selectedTxdet;
  ngOnInit(): void {
    this.selectedTxdet = JSON.parse(sessionStorage.getItem("SessionselectedTxdet"))
    console.log(this.selectedTxdet)
    this.getCharges();
    this.getChargesproduct();
    this.getDiscount();
    // this.tableArray = [{ "id": 1, "chargesName": "Clinic Visit", "description": "desc", "discount": "100" },
    // { "id": 2, "chargesName": "other charge", "description": "test", "discount": "300" }]
    // console.log(this.tableArray)
    // this.dataSource = new MatTableDataSource(this.tableArray);
    setTimeout(() => this.dataSource.paginator = this.createpaginator);
    this.dataSource.paginator = this.paginator

    console.log(this.dataSource)
    this.rbtnarray = ["Amount", "Precentage"]
    // this.getTotalCost();


    // set initial selection
    this.bankCtrl.setValue(this.banks[10]);

    // load the initial bank list
    this.filteredBanks.next(this.banks.slice());

    // listen for search field value changes
    this.bankFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterBanks();
      });

    // edit screen changes
    this.GetInvoiceBillMapid()
  }

  modelChangeQty(data,element){
    console.log('modelChangeQty', data, Number(this.actualprice))
    if(data != null){
    let newamount = (Number(data) * Number(this.actualprice));
    this.actualproductamount = newamount;
    }
    }

  modelChangePrice(data,element){
    if(data != null ){
    let newamount = (Number(data) * Number(this.actualqty));
    this.actualproductamount = newamount;
    this.actualprice = Number(data);
    }
    }  

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  // edit screen changes
  Loadupdatedetails;
  GetInvoiceBillMapid() {
    if (this.billid_edit) {
      this.loading = true;
      this._DoctorService.GetInvoiceBillMapid(this.billid_edit)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false;
            console.log(res)
            this.Loadupdatedetails = res
            let count = 0;
            for (let item of res.responseMessage.billViewModel.listbillItems) {
              console.log(item)
              count++;
              this.tableArray.push(
                {
                  "id": count,
                  "ChargeName": item.chargesname,
                  "ChargeDescription": item.description,
                  "Amount": item.amount,
                  "Discount": item.discount,
                  "Qty": item.quantity,
                  "gst": item.taxAmount,
                  "Total": item?.total,
                  "TaxId": item.taxId,
                  "TaxAmount": item.taxAmount,
                  "TaxName": '',
                  "BillClinicChargesMapId": item?.bill_cliniccharges_map_id,
                  "DiscountType": item?.discountTypeId,
                  "ClinicCodeId": '',
                  "selecteddiscounttype": ''
                })
              console.log(item)
            }
            console.log(this.tableArray)
            this.dataSource = new MatTableDataSource(this.tableArray);
            setTimeout(() => {
              this.dataSource.paginator = this.createpaginator
            });
            this.Iseditbill = true;
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res?.errorMessage, options);
          }
        }, err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
    }
  }


  // getcharges
  getCharges() {
    this.loading = false;
    this._DoctorService.getchargesForCreatebill()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.loading = false;
          this.chargeslist = res?.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }

  // getcharges
  getChargesproduct() {
    this.loading = false;
    this._DoctorService.getchargesForCreatebillproduct()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log('productchargeslist',res)
          this.loading = false;
          this.productchargeslist = res?.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }

  

  // getDiscount
  getDiscount() {
    this.loading = false;
    this._DoctorService.getDiscounttype()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res)
          this.loading = false;
          this.discountlist = res?.responseMessage;
          this.discountlistpro = res?.responseMessage;
        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  showtextbox:boolean=false;
  Copyactualamount;
  selectedcharge() {
    console.log(this.chargesInput);
    // if(this.chargesInput == "115"){
    //   this.showtextbox = true;
    // }else{
    //   this.showtextbox = false;
    // }
    this.loading = true;
    this._DoctorService.Code_Description(this.chargesInput)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          if(res?.responseMessage[0].clinicChargeName == "Remaining Charges"){
            this.showtextbox = true;
          }else{
            this.showtextbox = false;
          }
          for (let i of res.responseMessage) {
            i.name = i.description + "-" + i.codeId
          }
          this.banks = res.responseMessage;
          this.actualamount = res.responseMessage[0].amount;
          //this.actualproductamount = res.responseMessage[0].amount;
          //this.actualprice = res.responseMessage[0].amount;
          this.Copyactualamount = this.actualamount;
          this.actualTaxamount = res.responseMessage[0].taxAmount
          this.filteredBanks.next(this.banks.slice());
          // this.bankCtrl.setValue(this.banks);
          this.bankCtrl.setValue(res?.responseMessage[0]);
          this.cur_label = res?.responseMessage[0]?.currencyDetails

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
    // this.chargesInput = e;
  }

    selectedchargeproduct() {
    console.log(this.chargesInputproduct);
    // if(this.chargesInput == "115"){
    //   this.showtextbox = true;
    // }else{
    //   this.showtextbox = false;
    // }
    this.loading = true;
    this._DoctorService.Code_Description(this.chargesInputproduct)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          console.log(res)
          if(res?.responseMessage[0].clinicChargeName == "Remaining Charges"){
            this.showtextbox = true;
          }else{
            this.showtextbox = false;
          }
          for (let i of res.responseMessage) {
            i.name = i.description + "-" + i.codeId
          }
          this.productresp = res.responseMessage;
          this.actualproductamount = res.responseMessage[0].amount;
          this.actualprice = res.responseMessage[0].amount;
          this.Copyactualamount = this.actualproductamount;
          this.actualTaxamountpro = res.responseMessage[0].taxAmount;
          this.cur_label = res?.responseMessage[0]?.currencyDetails
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
    // this.chargesInput = e;
  }

  selectedDescription() {
    console.log(this.bankCtrl.value)
    this.cur_label = this.bankCtrl?.value?.currencyDetails
    this.actualamount = this.bankCtrl?.value?.amount;
    this.actualTaxamount = this.bankCtrl?.value?.taxAmount;
    console.log(this.actualTaxamount)
  }
  actualamount: any;
  actualTaxamount: any;
  chargesInput;
  discountInputdata
  tableArray: any = [];
  clearinput() {
    this.chargesInput = "";
    this.modelDiscountType = ""
    this.discountInputdata = ""
    this.addDetails = {}
    this.filteredBanks.next([].slice());
    this.bankCtrl.setValue([]);
    this.actualamount = 0;
    this.actualTaxamount = 0;
    this.cur_label = "";

    this.chargesInputproduct = "";
    this.modelPDiscountType = "";
    this.discountInputdatapro = "";
    this.addDetailsproduct = {};
    this.actualproductamount = 0;
    this.actualTaxamountpro = 0;
    this.actualprice = "";
    this.actualqty = undefined;
  }
  addDetails: any = {}
  ISdiscountInputdata: boolean = false;
  selectedradiobtn;

  radioChange(i,name) {
    console.log('service', i)
    this.selectedradiobtn = i;
    if(name == 'service'){
      this.calculation();
    }
  }

  radioChangepro(i,name) {
    console.log('product', i)
    this.selectedradiobtn = i;

    if(name == 'product'){
      this.calculationproduct();
    } 
  }
  
  modelDiscountType
  discount;
  total;
  calculation() {
    console.log(this.selectedradiobtn)
    if (this.selectedradiobtn != undefined) {
      if (this.selectedradiobtn['discountTypeName'] == "Percentage") {
        this.ISdiscountInputdata = false;
        this.discount = Number(this.actualamount) * Number(this.discountInputdata) / 100;
        let tot_amt_afterdiscount = Number(this.actualamount) - Number(this.discount);
        let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamount) / 100);
        this.total = bal_amt_withtax;
      }
      if (this.selectedradiobtn['discountTypeName'] == "Amount") {
        this.ISdiscountInputdata = false;
        this.discount = Number(this.discountInputdata);
        let tot_amt_afterdiscount = Number(this.actualamount) - Number(this.discount);
        let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamount) / 100);
        this.total = bal_amt_withtax;
        
      }
    }

    else {
      this.discount = 0;
      let tot_amt_afterdiscount = Number(this.actualamount) - Number(this.discount);
      let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamount) / 100)
      this.total = bal_amt_withtax;
    }
    console.log(this.discount)
    console.log(this.total)
    console.log(this.actualTaxamount)
  }


  calculationproduct() {
    console.log(this.selectedradiobtn)
    if (this.selectedradiobtn != undefined) {
      if (this.selectedradiobtn['discountTypeName'] == "Percentage") {
        this.ISdiscountInputdatapro = false;
        this.discountpro = Number(this.actualproductamount) * Number(this.discountInputdatapro) / 100;
        let tot_amt_afterdiscount = Number(this.actualproductamount) - Number(this.discountpro);
        let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamountpro) / 100);
        this.totalpro = bal_amt_withtax;
        console.log(this.discountpro)
        console.log(this.totalpro)
      }
      if (this.selectedradiobtn['discountTypeName'] == "Amount") {
        this.ISdiscountInputdatapro = false;
        this.discountpro = Number(this.discountInputdatapro);
        let tot_amt_afterdiscount = Number(this.actualproductamount) - Number(this.discountpro);
        let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamountpro) / 100);
        this.totalpro = bal_amt_withtax;
      }
    }

    else {
      this.discountpro = 0;
      let tot_amt_afterdiscount = Number(this.actualproductamount) - Number(this.discountpro);
      let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamountpro) / 100)
      this.totalpro = bal_amt_withtax;
    }
  }
  

  filterData: Boolean = false;
  discountStatus: boolean = false;
  add() {   
    console.log(this.getTotalCost()) 
    console.log(this.modelDiscountType)
    console.log(this.discountInputdata)
    if (this.actualamount == 0 || this.actualamount == "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select description", options)
      return;
    }    

    // if(this.actualamount > this.Copyactualamount){
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', "actual amount should not exceed", options)
    //   return;
    // }
     else {
        if(this.discountInputdata === "" ||this.discountInputdata == undefined) {
          this.discountStatus = false
        } else {
          this.discountStatus = true
        }

        if(this.modelDiscountType != undefined && this.modelDiscountType != "" && this.discountStatus != true){
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Please enter the discount value", options)
          return
        } 

        this.showtextbox = false;
        // if (this.selectedradiobtn != undefined) {
        //   this.calculation();
        // }
        // else {
        //   // this.discount = 0;
        //   // this.total = 0;
        // }
        this.calculation();
        this.addDetails = this?.bankCtrl?.value;
        this.addDetails.amount = this.actualamount;
        console.log(this.addDetails)
        console.log(this.actualamount)

        let count = 0;
        if (this.tableArray.length == 0) {
          count = 0;
        } else {
          count = this.tableArray.length + 1;
        }
        this.tableArray.push(
          {
            "id": count,
            "ChargeName": this.addDetails?.clinicChargeName,
            "ChargeDescription": this.addDetails?.description,
            "Amount": this.addDetails?.amount,
            "Qty":1,
            "Discount": Number(this.discount).toFixed(2),
            "gst": this.addDetails?.taxAmount,
            "Total": Number(this.total).toFixed(2),
            "TaxId": this.addDetails?.taxId,
            "TaxAmount": this.addDetails?.taxAmount,
            "TaxName": this.addDetails?.taxTypeName,
            "BillClinicChargesMapId": 0,
            "DiscountType": this.selectedradiobtn?.discountTypeId,
            "ClinicCodeId": this.addDetails?.clinicCodesId,
            "selecteddiscounttype": this.selectedradiobtn
          })

        this.dataSource = new MatTableDataSource(this.tableArray);
        setTimeout(() => {
          this.dataSource.paginator = this.createpaginator
        });
        if (this.tableArray.length == 0) {
          this.filterData = false;
        } else {
          this.filterData = true;
        }
        // this.TransactiondataSource.paginator = this.txpaginator

        console.log(this.tableArray)
        this.clearinput();
      }
  }
  discountProductStatus: boolean = false;
  addproduct() {   
    console.log(this.actualproductamount) 
    if(this.actualqty == 0 || this.actualqty == undefined) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter the quantity", options)
      return;
    }
    // console.log(this.actualqty)
    // debugger
    console.log(this.modelPDiscountType) 
    console.log(this.discountInputdatapro) 
    if (this.actualproductamount == 0 || this.actualproductamount == "") {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select price", options)
      return;
    }
    else {
      if(this.discountInputdatapro === "" || this.discountInputdatapro == undefined) {
        this.discountProductStatus = false
      } else {
        this.discountProductStatus = true
      }

      if(this.modelPDiscountType != undefined && this.modelPDiscountType != "" && this.discountProductStatus != true){
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please enter the discount value", options)
        return
      } 

      this.showtextbox = false;
      this.calculationproduct(); 

      this.addDetailsproduct = this?.productresp[0];
      this.addDetailsproduct.amount = this.actualproductamount;

      console.log(this.addDetailsproduct); 
    
      let count = 0;
      if (this.tableArray.length == 0) {
        count = 0;
      } else {
        count = this.tableArray.length + 1;
      }
      this.tableArray.push(
        {
          "id": count,
          "ChargeName": this.addDetailsproduct?.clinicChargeName,
          "ChargeDescription": this.addDetailsproduct?.description,
          "Amount": this.addDetailsproduct?.amount,
          "Discount": Number(this.discountpro).toFixed(2),
          "gst": this.addDetailsproduct?.taxAmount,
          "Qty": this.actualqty,
          "Total": Number(this.totalpro).toFixed(2),
          "TaxId": this.addDetailsproduct?.taxId,
          "TaxAmount": this.addDetailsproduct?.taxAmount,
          "TaxName": this.addDetailsproduct?.taxTypeName,
          "BillClinicChargesMapId": 0,
          "DiscountType": this.selectedradiobtn?.discountTypeId,
          "ClinicCodeId": this.addDetailsproduct?.clinicCodesId,
          "selecteddiscounttype": this.selectedradiobtn
        })

      this.dataSource = new MatTableDataSource(this.tableArray);
      setTimeout(() => {
        this.dataSource.paginator = this.createpaginator
      });
      if (this.tableArray.length == 0) {
        this.filterData = false;
      } else {
        this.filterData = true;
      }

      // this.TransactiondataSource.paginator = this.txpaginator

      console.log(this.tableArray)
      this.clearinput();
    }
  }


  deletetable(data) {
    // const filteredtabl3 = 
    let a = this.tableArray.filter((item) => item.id !== data.id);
    this.dataSource = new MatTableDataSource(a);
    this.tableArray = a;
    this.dataSource.paginator = this.paginator

  }
  editDetails;
  editmodelDiscountType;
  editdiscountInputdata;
  editselectedradiobtn
  edit(item) {
    console.log(item);
    this.editDetails = item;
    this.editmodelDiscountType = item?.selecteddiscounttype?.discountTypeId;
    this.editdiscountInputdata = item?.Discount;
    this.IseditDiscount = true;
    console.log(this.editdiscountInputdata)
  }
  editradioChange(i) {
    console.log(i)
    this.editselectedradiobtn = i;
    this.editcalculation();
  }
  // editmodelDiscountType
  editdiscount;
  edittotal;
  editcalculation() {
    console.log(this.editselectedradiobtn)
    console.log(this.editmodelDiscountType)
    if (this.editselectedradiobtn?.discountTypeName == "Percentage" || this.editmodelDiscountType == "95") {

      // this.discount = Number(this.actualamount) * Number(this.discountInputdata) / 100;

      this.editdiscount = Number(this.editDetails?.Amount) * Number(this.editdiscountInputdata) / 100;
      let tot_amt_afterdiscount = Number(this.editDetails?.Amount) - Number(this.editdiscount);
      let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.editDetails?.TaxAmount) / 100);
      this.edittotal = bal_amt_withtax;
      // this.edittotal = (Number(this.editDetails?.Amount) - Number(this.editdiscount) + ( Number(this.editDetails?.Amount) * Number(this.editDetails?.TaxAmount)/100 ))
      // this.editdiscount = (Number(this.editDetails?.Amount) * Number(this.editdiscountInputdata)) / 100;
      // this.edittotal = (Number(this.editDetails?.Amount) - Number(this.editdiscount) + ( Number(this.editDetails?.Amount) * Number(this.editDetails?.TaxAmount)/100 ))

      // console.log(this.editdiscount)

      // this.discount = (Number(this.actualamount) * Number(this.discountInputdata)) / 100;
      // let tot_amt_afterdiscount = Number(this.actualamount) - Number(this.discount);
      // let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.actualTaxamount)/100 );
      // this.total = bal_amt_withtax;


      // this.edittotal = (Number(this.editDetails?.Amount) - Number(this.editdiscount) + Number(this.editDetails?.TaxAmount))
      //  sample ( Number(this.actualamount) * Number(this.actualTaxamount)/100 )
      console.log(this.editdiscountInputdata)
      console.log(this.edittotal)
    }
    if (this.editselectedradiobtn?.discountTypeName == "Amount" || this.editmodelDiscountType == "94") {
      this.editdiscount = Number(this.editdiscountInputdata);
      let tot_amt_afterdiscount = Number(this.editDetails?.Amount) - Number(this.editdiscount);
      let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.editDetails?.TaxAmount) / 100);
      this.edittotal = bal_amt_withtax;
      // this.edittotal = (Number(this.editDetails?.Amount) - Number(this.editdiscountInputdata) + ( Number(this.editDetails?.Amount) * Number(this.editDetails?.TaxAmount)/100 ))

      // this.editdiscount = Number(this.editdiscountInputdata);
      // this.edittotal = (Number(this.editDetails?.Amount) - Number(this.editdiscountInputdata) + ( Number(this.editDetails?.Amount) * Number(this.editDetails?.TaxAmount)/100 ))

      // this.editdiscount = Number(this.editDetails?.Amount) * Number(this.editdiscountInputdata) / 100;
      // let tot_amt_afterdiscount = Number(this.editDetails?.Amount) - Number(this.editdiscount);
      // let bal_amt_withtax = Number(tot_amt_afterdiscount) + (Number(tot_amt_afterdiscount) * Number(this.editDetails?.TaxAmount)/100 );
      // this.edittotal = bal_amt_withtax;

    }
    console.log(this.editdiscount)
    console.log(this.edittotal)
    console.log(this.editDetails?.Amount)
  }
  saveEdit() {
    this.editcalculation()
    if (this.editmodelDiscountType) {
      console.log(this.editdiscountInputdata)
      console.log(this.editdiscount)
      console.log(this.edittotal)
      console.log(this.editDetails?.Amount);
      console.log(this.editDetails)
      // this.IseditDiscount = false;

      //find  obj to  edit
      console.log(this.tableArray)
      let objIndex = this.tableArray.findIndex((obj => obj.id == this.editDetails?.id));
      this.tableArray[objIndex].Discount = Number(this.editdiscount).toFixed(2)
      this.tableArray[objIndex].Total = Number(this.edittotal).toFixed(2)
      this.tableArray[objIndex].selecteddiscounttype = this.editselectedradiobtn;
      this.dataSource = new MatTableDataSource(this.tableArray);
      this.dataSource.paginator = this.paginator
      this.IseditDiscount = false;
    }
    else {
      this.IseditDiscount = false;
    }

  }
  popupsave() {
    this.IseditDiscount = false;

  }
  popupcancel() {
    this.IseditDiscount = false;
  }
  submitGenInvoiceSave() {
    // alert("Save")
    if (this.tableArray.length == 0) {
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please Add Service to  Generate Invoice", options);
      return;
    } else {
      
      if (this.saveid === undefined) {
        // generate bill before save
        let beforesaveGeneBillarray: any = [];
        for (let i of this.tableArray) {
          console.log(i)
          let objpayload = {
            "ClinicCodeId": i.ClinicCodeId,
            "Amount": i.Amount,
            "Discount": i.Discount,
            "DiscountType": i?.selecteddiscounttype?.discountTypeId,
            "Total": i.Total,
            "TaxId": i.TaxId,
            "Quantity": i.Qty,
            "TaxAmount": i.TaxAmount
          }
          beforesaveGeneBillarray.push(objpayload)
        }
        let payload = {
          "bGenerateInvoice": true,
          "TotalAmount": this.getTotalCost(),
          "chargeModel": beforesaveGeneBillarray
        }
        console.log(this.getTotalCost())
        console.log(this.selectedTxdet.appointmentId, beforesaveGeneBillarray)
        // return;
        console.log(beforesaveGeneBillarray)
        this.loading = true;
        this._DoctorService.CreateBill(this.selectedTxdet.appointmentId, payload)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              console.log(res)
              this.saveid = res.responseData
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res?.responseMessage, options);
              // this._DoctorService.reloadtx_det = this.selectedTxdet;
              this.router.navigate(['/thealth/clinicadmin/transaction/']);
              // sessionStorage.removeItem("selectedTxdet")             
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res?.errorMessage, options);
            }
          }, err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
      } 
      // else {
      //   // after save
      //   this._DoctorService.GenerateInvoice(this.saveid.split('-')[0])
      //     .pipe(first())
      //     .subscribe((res: any) => {
      //       if (!res.isError) {
      //         this.loading = false;
      //         console.log(res)
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.success('', res?.responseMessage, options);
      //         this.router.navigate(['/thealth/clinicadmin/transaction/']);
      //       }
      //       else {
      //         this.loading = false;
      //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //         this.toastrService.warning('', res?.errorMessage, options);
      //       }
      //     }, err => {
      //       this.loading = false;
      //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //       this.toastrService.warning('', err?.error, options);
      //     })
      // }
    }
  }

  submitGenInvoiceUpdate() {
    // alert("update")
    if (this.selectedTxdet?.bill_appointment_map_id != undefined && this.tableArray.length != 0 || this.saveid) {
      // alert("one")    
      this.loading = true;
      if (this.saveid === undefined) {        
        // for update invoice
        // this._DoctorService.GenerateInvoice(this.selectedTxdet?.bill_appointment_map_id)
        this.Issubmit = true;
        console.log(this.billid_edit)
        let array: any = [];
        for (let i of this.tableArray) {
          console.log(i)
          let payload;
          if (i.BillClinicChargesMapId == 0) {
            // new
            payload = {
              "ChargeName": i.ChargeName,
              "ChargeDescription": i.ChargeDescription,
              "Amount": i.Amount,
              "Discount": i.Discount,
              "Total": i.Total,
              "TaxId": i.TaxId,
              "TaxAmount": i.TaxAmount,
              "Quantity": i.Qty,
              "TaxName": i.TaxName,
              "BillClinicChargesMapId": 0,
              "DiscountType": 0,
              "ClinicCodeId": i.ClinicCodeId
            }
          } else {
            // old
            payload = {
              // "ChargeName": i.ChargeName,
              // "ChargeDescription": i.ChargeDescription,
              "Amount": i.Amount,
              "Discount": i.Discount,
              // "Total": i.Total,
              // "TaxId": i.TaxId,
              // "TaxAmount": i.TaxAmount,
              // "TaxName": i.TaxName,
              "BillClinicChargesMapId": i.BillClinicChargesMapId,
              "DiscountType": i.DiscountType,
              "Total": i.Total
            }
          }
          array.push(payload)
        }
        console.log(array)


        this._DoctorService.Updatebill2(this.selectedTxdet?.bill_appointment_map_id, array)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false;
              console.log(res)
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.success('', res?.responseMessage, options);
              // this._DoctorService.reloadtx_det = this.selectedTxdet;
              this.router.navigate(['/thealth/clinicadmin/transaction/']);
              // sessionStorage.removeItem("selectedTxdet")             

              // this.router.navigate(['/thealth/clinicadmin/transaction/']);
            }
            else {
              this.loading = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res?.errorMessage, options);
            }
          }, err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
      }
    }
    else{
      this.loading = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please add service or product to genrate invoice", options);
    }
  }


  // submitGenerateInvoice() {
  //   console.log(this.saveid)
  //   if (this.selectedTxdet?.bill_appointment_map_id != undefined && this.tableArray.length != 0 || this.saveid) {
  //     // alert("one")    
  //     this.loading = true;
  //     if (this.saveid === undefined) {
  //       alert(1)
  //       return;
  //       // for update invoice
  //       // this._DoctorService.GenerateInvoice(this.selectedTxdet?.bill_appointment_map_id)
  //       this.Issubmit = true;
  //       console.log(this.billid_edit)
  //       let array: any = [];
  //       for (let i of this.tableArray) {
  //         console.log(i)
  //         let payload;
  //         if (i.BillClinicChargesMapId == 0) {
  //           // new
  //           payload = {
  //             "ChargeName": i.ChargeName,
  //             "ChargeDescription": i.ChargeDescription,
  //             "Amount": i.Amount,
  //             "Discount": i.Discount,
  //             "Total": i.Total,
  //             "TaxId": i.TaxId,
  //             "TaxAmount": i.TaxAmount,
  //             "TaxName": i.TaxName,
  //             "BillClinicChargesMapId": 0,
  //             "DiscountType": 0,
  //             "ClinicCodeId": i.ClinicCodeId
  //           }
  //         } else {
  //           // old
  //           payload = {
  //             // "ChargeName": i.ChargeName,
  //             // "ChargeDescription": i.ChargeDescription,
  //             "Amount": i.Amount,
  //             "Discount": i.Discount,
  //             // "Total": i.Total,
  //             // "TaxId": i.TaxId,
  //             // "TaxAmount": i.TaxAmount,
  //             // "TaxName": i.TaxName,
  //             "BillClinicChargesMapId": i.BillClinicChargesMapId,
  //             "DiscountType": i.DiscountType,
  //             "Total": i.Total
  //           }
  //         }
  //         array.push(payload)
  //       }
  //       console.log(array)


  //       this._DoctorService.Updatebill2(this.selectedTxdet?.bill_appointment_map_id, array)
  //         .pipe(first())
  //         .subscribe((res: any) => {
  //           if (!res.isError) {
  //             this.loading = false;
  //             console.log(res)
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.success('', res?.responseMessage, options);
  //             this.router.navigate(['/thealth/clinicadmin/transaction/']);
  //           }
  //           else {
  //             this.loading = false;
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.warning('', res?.errorMessage, options);
  //           }
  //         }, err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //         })
  //     }
  //     else {
  //       alert(2)
  //       return;
  //       // after save
  //       this._DoctorService.GenerateInvoice(this.saveid.split('-')[0])
  //         .pipe(first())
  //         .subscribe((res: any) => {
  //           if (!res.isError) {
  //             this.loading = false;
  //             console.log(res)
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.success('', res?.responseMessage, options);
  //             this.router.navigate(['/thealth/clinicadmin/transaction/']);
  //           }
  //           else {
  //             this.loading = false;
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.warning('', res?.errorMessage, options);
  //           }
  //         }, err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //         })
  //     }
  //   } else {
  //     alert(3)
  //       return;
  //     // if (this.tableArray.length == 0) {
  //     //   this.loading = false;
  //     //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     //   this.toastrService.warning('', "Please Add Charges to  Generate Invoice", options);
  //     //   return;
  //     // } else {

  //     //   alert("generatebill")
  //     //   return;
  //     //   // generate bill before save
  //     //   let beforesaveGeneBillarray: any = [];
  //     //   for (let i of this.tableArray) {
  //     //     console.log(i)
  //     //     let objpayload = {
  //     //       "ClinicCodeId": i.ClinicCodeId,
  //     //       "Amount": i.Amount,
  //     //       "Discount": i.Discount,
  //     //       "DiscountType": i?.selecteddiscounttype?.discountTypeId,
  //     //       "Total": i.Total,
  //     //       "TaxId": i.TaxId,
  //     //       "TaxAmount": i.TaxAmount
  //     //     }
  //     //     beforesaveGeneBillarray.push(objpayload)
  //     //   }
  //     //   let payload = {
  //     //     "bGenerateInvoice": true,
  //     //     "TotalAmount": this.getTotalCost(),
  //     //     "chargeModel": beforesaveGeneBillarray
  //     //   }
  //     //   console.log(this.getTotalCost())
  //     //   console.log(this.selectedTxdet.appointmentId, beforesaveGeneBillarray)
  //     //   // return;
  //     //   console.log(beforesaveGeneBillarray)
  //     //   this.loading = true;
  //     //   this._DoctorService.CreateBill(this.selectedTxdet.appointmentId, payload)
  //     //     .pipe(first())
  //     //     .subscribe((res: any) => {
  //     //       if (!res.isError) {
  //     //         this.loading = false;
  //     //         console.log(res)
  //     //         this.saveid = res.responseData
  //     //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     //         this.toastrService.success('', res?.responseMessage, options);
  //     //         this._DoctorService.reloadtx_det = this.selectedTxdet;
  //     //         this.router.navigate(['/thealth/clinicadmin/transaction/']);
  //     //         sessionStorage.removeItem("selectedTxdet")

  //     //       }
  //     //       else {
  //     //         this.loading = false;
  //     //         const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     //         this.toastrService.warning('', res?.errorMessage, options);
  //     //       }
  //     //     }, err => {
  //     //       this.loading = false;
  //     //       const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     //       this.toastrService.warning('', err?.error, options);
  //     //     })
  //     // }
  //   }


  // }
  // submitGenerateInvoice() {
  //   console.log(this.saveid)
  //   if (this.selectedTxdet?.bill_appointment_map_id != undefined && this.tableArray.length != 0 || this.saveid) {
  //     // alert("one")    
  //     this.loading = true;
  //     if (this.saveid === undefined) {
  //       this._DoctorService.GenerateInvoice(this.selectedTxdet?.bill_appointment_map_id)
  //         .pipe(first())
  //         .subscribe((res: any) => {
  //           if (!res.isError) {
  //             this.loading = false;
  //             console.log(res)
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.success('', res?.responseMessage, options);
  //           }
  //           else {
  //             this.loading = false;
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.warning('', res?.errorMessage, options);
  //           }
  //         }, err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //         })
  //     }
  //     else {
  //       this._DoctorService.GenerateInvoice(this.saveid)
  //         .pipe(first())
  //         .subscribe((res: any) => {
  //           if (!res.isError) {
  //             this.loading = false;
  //             console.log(res)
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.success('', res?.responseMessage, options);
  //           }
  //           else {
  //             this.loading = false;
  //             const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //             this.toastrService.warning('', res?.errorMessage, options);
  //           }
  //         }, err => {
  //           this.loading = false;
  //           const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //           this.toastrService.warning('', err?.error, options);
  //         })
  //     }
  //   } else {
  //     this.loading = false;
  //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  //     this.toastrService.warning('', "Please Save Transaction before Generate Invoice", options);
  //     return;
  //   }


  // }
  Issubmit: Boolean = false;
  submitCreatebill() {
    this.Issubmit = true;
    let array: any = [];
    // for (let i of this.tableArray) {
    //   console.log(i)
    //   let payload = {
    //     "ClinicCodeId": i.ClinicCodeId,
    //     "Amount": i.Amount,
    //     "Discount": i.Discount,
    //     "DiscountType": i?.selecteddiscounttype?.discountTypeId,
    //     "Total": i.Total,
    //     "TaxId": i.TaxId,
    //     "TaxAmount": i.TaxAmount       
    //   }

    //   // let payload = {
    //   //   "ChargeName": i.ChargeName,
    //   //   "ChargeDescription": i.ChargeDescription,
    //   //   "Amount": i.Amount,
    //   //   "Discount": i.Discount,
    //   //   "Total": i.Total,
    //   //   "TaxId": i.TaxId,
    //   //   "TaxAmount": i.TaxAmount,
    //   //   "TaxName": i.TaxName,
    //   //   "BillClinicChargesMapId": 0,
    //   //   "DiscountType": i?.selecteddiscounttype?.discountTypeId,
    //   //   "ClinicCodeId": i.ClinicCodeId
    //   // }
    //   array.push(payload)
    // }
    for (let i of this.tableArray) {
      console.log(i)
      let objpayload = {
        "ClinicCodeId": i.ClinicCodeId,
        "Amount": i.Amount,
        "Discount": i.Discount,
        "DiscountType": i?.selecteddiscounttype?.discountTypeId,
        "Total": i.Total,
        "TaxId": i.TaxId,
        "TaxAmount": i.TaxAmount
      }
      array.push(objpayload)
    }
    let payload = {
      "bGenerateInvoice": false,
      "TotalAmount": this.getTotalCost(),
      "chargeModel": array
    }
    console.log(this.getTotalCost())
    console.log(this.selectedTxdet.appointmentId, array)
    // return;
    console.log(array)
    this.loading = true;
    this._DoctorService.CreateBill(this.selectedTxdet.appointmentId, payload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.Issubmit = false;
          console.log(res)
          this.saveid = res.responseData
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res?.responseMessage, options);
          // this._DoctorService.reloadtx_det = this.selectedTxdet;
          this.router.navigate(['/thealth/clinicadmin/transaction/']);
          // sessionStorage.removeItem("selectedTxdet")

        }
        else {
          this.loading = false;
          this.Issubmit = false;

          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        this.Issubmit = false;

        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  submitUpdatebill() {
    console.log(this.Loadupdatedetails?.responseMessage)

    // sessionStorage.removeItem("selectedTxdet")
    this.Issubmit = true;
    console.log(this.billid_edit)
    let array: any = [];
    for (let i of this.tableArray) {
      console.log(i)
      let payload;
      if (i.BillClinicChargesMapId == 0) {
        // new
        payload = {
          "ChargeName": i.ChargeName,
          "ChargeDescription": i.ChargeDescription,
          "Amount": i.Amount,
          "Discount": i.Discount,
          "Total": i.Total,
          "TaxId": i.TaxId,
          "TaxAmount": i.TaxAmount,
          "TaxName": i.TaxName,
          "BillClinicChargesMapId": 0,
          "DiscountType": 0,
          "ClinicCodeId": i.ClinicCodeId
        }
      } else {
        // old
        payload = {
          // "ChargeName": i.ChargeName,
          // "ChargeDescription": i.ChargeDescription,
          "Amount": i.Amount,
          "Discount": i.Discount,
          // "Total": i.Total,
          // "TaxId": i.TaxId,
          // "TaxAmount": i.TaxAmount,
          // "TaxName": i.TaxName,
          "BillClinicChargesMapId": i.BillClinicChargesMapId,
          "DiscountType": i.DiscountType,
          "Total": i.Total
        }
      }
      array.push(payload)
    }
    console.log(array)
    // return;
    this.loading = true;
    this._DoctorService.Updatebill(this.billid_edit, array)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.Issubmit = false;
          console.log(res)
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res?.responseMessage, options);
          // this._DoctorService.reloadtx_det = this.selectedTxdet;
          this.router.navigate(['/thealth/clinicadmin/transaction/']);
          // sessionStorage.removeItem("selectedTxdet") 
          // this._DoctorService.reloadtx_det = this.Loadupdatedetails?.responseMessage;
          // this.router.navigate(['/thealth/clinicadmin/transaction/']);
        }
        else {
          this.loading = false;
          this.Issubmit = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res?.errorMessage, options);
        }
      }, err => {
        this.loading = false;
        this.Issubmit = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', err?.error, options);
      })
  }
  getTotalCost() {
    return this.tableArray.map(t => Number(t.Total)).reduce((acc, value) => acc + value, 0);
  }

  goback(){
    this.router.navigate(['/thealth/clinicadmin/transaction/']);
  }
  
  ngAfterViewInit() {
    this.setInitialValue();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  /**
   * Sets the initial value after the filteredBanks are loaded initially
   */
  protected setInitialValue() {
    this.filteredBanks
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        // this.singleSelect.compareWith = (a: Bank, b: Bank) => a && b && a.id === b.id;
        this.singleSelect.compareWith = (a: Bank2, b: Bank2) => a && b && a.clinicChargesId === b.clinicChargesId;
      });
  }

  protected filterBanks() {
    if (!this.banks) {
      return;
    }
    // get the search keyword
    let search = this.bankFilterCtrl.value;
    if (!search) {
      this.filteredBanks.next(this.banks.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanks.next(
      this.banks.filter(bank => bank.name.toLowerCase().indexOf(search) > -1)
    );
  }


}

export interface Bank2 {
  clinicChargesId: any;
  status: any;
  chargeName: any;
}

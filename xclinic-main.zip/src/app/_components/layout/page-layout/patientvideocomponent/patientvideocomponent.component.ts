import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientvideocomponent',
  templateUrl: './patientvideocomponent.component.html',
  styleUrls: ['./patientvideocomponent.component.css']
})
export class PatientvideocomponentComponent implements OnInit {
  role: string;
  patientcontentsection: boolean;
  commoncontentsection: boolean;
  
  constructor() { }

  ngOnInit(): void {
    this.role = sessionStorage.getItem('Role');
    if(this.role === 'patient'){
      this.patientcontentsection = true;
      this.commoncontentsection = false;
    }
    else{
      this.patientcontentsection = false;
      this.commoncontentsection = true;
    }
  }

}

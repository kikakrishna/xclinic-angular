import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientvideocomponentComponent } from './patientvideocomponent.component';

describe('PatientvideocomponentComponent', () => {
  let component: PatientvideocomponentComponent;
  let fixture: ComponentFixture<PatientvideocomponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientvideocomponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientvideocomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

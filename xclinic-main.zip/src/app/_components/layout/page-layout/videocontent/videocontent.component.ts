import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-videocontent',
  templateUrl: './videocontent.component.html',
  styleUrls: ['./videocontent.component.css']
})
export class VideocontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

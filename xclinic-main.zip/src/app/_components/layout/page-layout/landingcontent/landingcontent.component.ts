import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landingcontent',
  templateUrl: './landingcontent.component.html',
  styleUrls: ['./landingcontent.component.css']
})
export class LandingcontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

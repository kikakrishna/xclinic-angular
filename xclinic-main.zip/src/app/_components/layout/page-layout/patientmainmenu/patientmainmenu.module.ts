import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatListModule } from '@angular/material/list';
import { RouterModule } from '@angular/router';
import { PatientmainmenuComponent } from './patientmainmenu.component';
import { MatCardModule } from '@angular/material/card';


@NgModule({
  declarations: [PatientmainmenuComponent],
  imports: [
    CommonModule,
    MatListModule,
    RouterModule,
    MatCardModule
  ],
  exports: [PatientmainmenuComponent]
})
export class PatientmainmenuModule { }

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientmainmenuComponent } from './patientmainmenu.component';

describe('PatientmainmenuComponent', () => {
  let component: PatientmainmenuComponent;
  let fixture: ComponentFixture<PatientmainmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientmainmenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientmainmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

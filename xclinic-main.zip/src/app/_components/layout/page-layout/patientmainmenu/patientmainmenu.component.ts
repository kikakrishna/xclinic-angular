import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientmainmenu',
  templateUrl: './patientmainmenu.component.html',
  styleUrls: ['./patientmainmenu.component.css']
})
export class PatientmainmenuComponent implements OnInit {
  currentrole: string;
  imageURL: string;

  constructor() { }

  ngOnInit(): void {
    this.currentrole =  sessionStorage.getItem('userName');
    const url = sessionStorage.getItem('profile');
    if( url != 'null'){
      this.imageURL = url;
    }
    else{
      this.imageURL = "../assets/images/noimage.webp";
    }
  }

}

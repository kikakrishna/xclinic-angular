import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientfooterComponent } from './patientfooter.component';

describe('PatientfooterComponent', () => {
  let component: PatientfooterComponent;
  let fixture: ComponentFixture<PatientfooterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientfooterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

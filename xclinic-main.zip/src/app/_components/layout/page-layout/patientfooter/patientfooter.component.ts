import { Component, OnInit } from '@angular/core';
import { PatientService } from '../../../../_services/patient.service';
import { first } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-patientfooter',
  templateUrl: './patientfooter.component.html',
  styleUrls: ['./patientfooter.component.css']
})
export class PatientfooterComponent implements OnInit {
  cliniclogo: any;
  clinicdetails: any;
  subscription: any;
  footerContentKinetics: boolean = false;
  isCliniclogo: boolean;
  isImgLoaded: boolean = false;
  addressmodel: any;
  cliniclocation: any;

  constructor(private _patientservice: PatientService, private router: Router) { }
  ngOnInit(): void {
  // this.subscription = this._patientservice.details.subscribe(res => {
  //     console.log('footersec1')
  //     if(!res.isError){
  //       console.log( res.responseMessage,'footer')
  //       this.cliniclogo = res.responseMessage.logoURL;
  //       this.clinicdetails = res.responseMessage;
  //     }
  //   });
    console.log(this._patientservice.Domdetails)
    this.cliniclogo = this._patientservice.Domdetails.responseMessage.logoURL;
    this.clinicdetails = this._patientservice.Domdetails.responseMessage;
    this.addressmodel = this.clinicdetails.clinicAddressModel

    for(let i=0;i<this.addressmodel.length;i++){
      if(this.addressmodel[i].defaultclinic == true){
        this.cliniclocation = this.addressmodel[i]
      }
    }

    if (window.location.hostname) {
      const subdomain = window.location.hostname.split(".")[0];
      if (subdomain == "kindkinetics" || subdomain == "xclinic"){
        this.footerContentKinetics = true;
      } else {
        this.footerContentKinetics = false;
      }
    }
  }
  // ngOnDestroy() {
  //   this.subscription.unsubscribe();
  // }

}

import { ShareDataService } from './../../../../_services/sharedata.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../../../_services/authentication.service';
import {
  MatDialog,
} from '@angular/material/dialog';
import { ChangepasswordComponent } from '../../../pages/changepassword/changepassword.component';
import { ChangepatientComponent } from '../../../../_components/pages/changepatient/changepatient.component';
import { DoctorService } from '../../../../_services/doctor.service';
import { first } from 'rxjs/operators';
import { PatientService } from 'src/app/_services/patient.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  role: string;
  lastname: string;
  profileImg: any;
  user_id: string;
  listfamily: any;
  familylist: boolean;
  siteLanguage: string;
  siteLocale: string;
  langurl: string = "";
  language: string;  
  cliniclogo: any;
  famguid: string;
  isCliniclogo:boolean;
  menusection: boolean = false;
  constructor(private authenticationService: AuthenticationService,
     private shareDataService: ShareDataService,
      public _DoctorService: DoctorService,
      public _patientservice: PatientService,
    public dialog: MatDialog,
     private route: ActivatedRoute,
      private router: Router) { }

  languageList = [
    { code: 'en', label: 'English' },
    { code: 'ta', label: 'தமிழ்' },
    { code: 'mal', label: 'മലയാളം' },
    { code: 'vie', label: 'Tiếng Việt' },
    { code: 'ar', label: 'عربى' }
  ];

  ngOnInit(): void {
    this.famguid = sessionStorage.getItem('familyMemberGuid');
    this.user_id = sessionStorage.getItem('masteruserId');
    this.role = sessionStorage.getItem('Role');
    this._DoctorService.currentrole = sessionStorage.getItem('userName');
    this.lastname = sessionStorage.getItem('lastName');
    this._patientservice.domaindetail()
    .pipe(first())
    .subscribe((resdomain: any) => {
      if (!resdomain.isError) {
        console.log(resdomain)
        sessionStorage.setItem("cliniclogo",resdomain.responseMessage.logoURL)
      }
    });
    setInterval(()=>{
      if(sessionStorage.getItem('cliniclogo') != null){
        this.cliniclogo = sessionStorage.getItem('cliniclogo');
        this.isCliniclogo = true;
      }
      this.profileImg = sessionStorage.getItem('profile');
      if (this.profileImg != 'null') {
        this.profileImg = this.profileImg;
      } else {
        this.profileImg = './assets/images/noimage.webp';
      }
    },2000)
    
    if(this.role === 'patient'){
      this.familymemberlist();
    }
    this.siteLanguage = this.languageList[0].label;
    this.siteLocale = window.location.pathname.split('/')[1];    
    if(this.siteLocale && this.siteLocale != "#"){
      this.siteLanguage = this.languageList.find(f => f.code === this.siteLocale)?.label;
    }
  }
  reloadprofilepic(){
    this.profileImg = sessionStorage.getItem('profile');
    if (this.profileImg != 'null') {
      this.profileImg = this.profileImg;
    } else {
      this.profileImg = './assets/images/noimage.webp';
    }
    if(this.role == "clinicadmin"){
      this.profileImg = './assets/images/noimage.webp';
    }
  }
  reloadname(){
  }
  changeLang(lang: string) {
    this.langurl = this.route.snapshot['_routerState'].url

    if (lang === 'mal') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'mal')
    }
    else if (lang === 'ta') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'ta')
    }
    else if (lang === 'vie') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'vie')
    }
    else if (lang === 'ar') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'ar')
    }
    else {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'en')
    }
    sessionStorage.setItem('sitelanguage',lang);
    }
    
  headerClick() {
    this.shareDataService.setdoctorbooking(undefined);
    let currentRoute = this.router.url.split('/');
    let currentRouteIndex = currentRoute.findIndex(
      (i) => (i == 'doctor-appointmentcall')
    );
    if (currentRouteIndex && currentRouteIndex > -1) {
      this.shareDataService.headerClick();
    } else {
      currentRouteIndex = currentRoute.findIndex(
        (i) => (i == 'patient-appointmentcall')
      );
      if (currentRouteIndex && currentRouteIndex > -1) {
        this.shareDataService.headerClick();
      }
    }
  }
  
changepatientcheck(){
  let pdata = sessionStorage.getItem("changepatient");  
  if(this.role === 'patient'){
    if(pdata == "true"){
      this.familylist  = true;
    }
    if(pdata == "false"){
      this.familylist  = false;
    }    
  }
}
  familymemberlist() {
    this._DoctorService
      .familylist(this.user_id)
      .pipe(first())
      .subscribe(
        (res: any) => {          
          if (!res.isError) {
            if(res?.responseMessage?.length != 0)
            {
              this.familylist = true;
              sessionStorage.setItem("changepatient","true")
            }
            if(res?.responseMessage?.length == 0)
            {
              this.familylist = false;
              sessionStorage.setItem("changepatient","false")
            }
          }
          else{
            
          }  
        },
        (err) => {
        }
      );
  }

  logout() {
    this.headerClick();
    this.authenticationService.logOut();
    if(this.role === 'doctor' || this.role === 'clinicadmin') {
      this.router.navigate(['/doctor']);
    } else {
      this.router.navigate(['']);
    }
  }

  opendialogpassword() {
    const dialogRef = this.dialog.open(ChangepasswordComponent, {
      panelClass: 'changepassword-dialog',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log(result)
        if (!result.data.isError) {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        }
      }
    });
  }

  opendialogpatient() {
    const dialogRef = this.dialog.open(ChangepatientComponent, {
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '100%',
      width: '100%',
      panelClass: 'loginfamily-dialog',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
      }
    });
  }

  openmenu() {
    this.menusection = !this.menusection;
  }

  closemenu() {
    this.menusection = false;
  }
  
}

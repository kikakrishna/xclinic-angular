import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { PatientLoginComponent } from 'src/app/_components/auth/patient-login/patient-login.component';
import { ChangepasswordComponent } from 'src/app/_components/pages/changepassword/changepassword.component';
import { ChangepatientComponent } from 'src/app/_components/pages/changepatient/changepatient.component';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { DoctorService } from 'src/app/_services/doctor.service';
import { ShareDataService } from 'src/app/_services/sharedata.service';
import { PatientService } from '../../../../_services/patient.service';

@Component({
  selector: 'app-patientheader',
  templateUrl: './patientheader.component.html',
  styleUrls: ['./patientheader.component.css']
})
export class PatientheaderComponent implements OnInit {
  role: string;
  lastname: string;
  profileImg: any;
  user_id: string;
  listfamily: any;
  familylist: boolean;
  siteLanguage: string;
  siteLocale: string;
  langurl: string = "";
  language: string;
  cliniclogo: any;
  famguid: string;
  isCliniclogo: boolean;
  patientheader: boolean;
  commonheader: boolean;
  currentuser: string;
  bookappointmentlogin: boolean;
  bookappointment: boolean;
  signinuser: boolean;
  signupbtn: boolean;
  username: string;
  currentUser2: any;
  curLang: any;
  domainname: any;
  menuStatus: any;
  constructor(private authenticationService: AuthenticationService, private shareDataService: ShareDataService, public _DoctorService: DoctorService,
    public dialog: MatDialog, private route: ActivatedRoute, private router: Router, private _patientservice: PatientService,) {

    this.shareDataService.appointmentEventEmit.subscribe(name => {
      this.username = name;
    })
    this.authenticationService.currentUser.subscribe(value => {
      this.currentUser2 = value;
      if (this.currentUser2 != null) {
        this.signinuser = true;
        this.signupbtn = false;
        this.username = sessionStorage.getItem('userName');
      }
      else {
        this.signinuser = false;
        this.signupbtn = true;
      }
    });
  }

  languageList = [
    { code: 'en', label: 'English' },
    { code: 'ta', label: 'தமிழ்' },
    { code: 'mal', label: 'മലയാളം' },
    { code: 'vie', label: 'Tiếng Việt' },
    { code: 'ar', label: 'عربى' },
    { code: 'hi', label: 'हिंदी' },
  ];

  isImgLoaded: boolean = false;

  ngOnInit(): void {
    this.curLang = sessionStorage.getItem('currentLang')
    // this._patientservice.domaindetail()
    //   .pipe(first())
    //   .subscribe((res: any) => {
    //     if (!res.isError) {
    //       sessionStorage.setItem('clinicId', res.responseMessage.clinicId);
    //       this.cliniclogo = res.responseMessage.logoURL;
    //       sessionStorage.setItem('clinicId', res.responseMessage.clinicId);
    //       if( this.cliniclogo) {
    //         this.isImgLoaded = true;
    //       }
    //     }
    //   });
    // this.cliniclogo = sessionStorage.getItem('cliniclogo');
    console.log(this._patientservice.Domdetails)
    this.cliniclogo = this._patientservice.Domdetails.responseMessage.logoURL;
    // this.cliniclogo = sessionStorage.getItem('cliniclogo2');
    this.menuStatus = this._patientservice.Domdetails.responseMessage.clinicUiFeatureMap;
    console.log(this.menuStatus)
    console.log(this.cliniclogo)
    if (this.cliniclogo) {
      this.isImgLoaded = true;
    }

    this.famguid = sessionStorage.getItem('familyMemberGuid');
    this.user_id = sessionStorage.getItem('masteruserId');
    this.currentuser = sessionStorage.getItem('currentUser');
    this.username = sessionStorage.getItem('userName');
    if (this.currentuser === null) {
      this.bookappointmentlogin = true;
      this.bookappointment = false;
    }
    else {
      this.bookappointment = true;
      this.bookappointmentlogin = false;
    }
    this.role = sessionStorage.getItem('Role');
    if (this.role === null) {
      this.signupbtn = true;
      this.signinuser = false;
    }
    else {
      this.signupbtn = false;
      this.signinuser = true;
    }
    this._DoctorService.currentrole = sessionStorage.getItem('userName');
    this.lastname = sessionStorage.getItem('lastName');
    setInterval(() => {
      this.profileImg = sessionStorage.getItem('profile');
      if (this.profileImg != 'null') {
        this.profileImg = this.profileImg;
      } else {
        this.profileImg = './assets/images/noimage.webp';
      }
    }, 2000)

    const subdomain = window.location.hostname.split(".")[0];
    this.domainname = subdomain;
    
    if (this.role === 'patient') {
      this.familymemberlist();
    }

    this.siteLanguage = this.languageList[0].label;
    this.siteLocale = window.location.pathname.split('/')[1];
    if (this.siteLocale && this.siteLocale != "#") {
      this.siteLanguage = this.languageList.find(f => f.code === this.siteLocale)?.label;
    }
  }
  reloadprofilepic() {
    this.profileImg = sessionStorage.getItem('profile');
    if (this.profileImg != 'null') {
      this.profileImg = this.profileImg;
    } else {
      this.profileImg = './assets/images/noimage.webp';
    }
    if (this.role == "clinicadmin") {
      this.profileImg = './assets/images/noimage.webp';
    }
  }
  reloadname() {

  }
  changeLang(lang: string) {
    this.langurl = this.route.snapshot['_routerState'].url

    if (lang === 'mal') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'mal')
    }
    else if (lang === 'ta') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'ta')
    }
    else if (lang === 'vie') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'vie')
    }
    else if (lang === 'ar') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'ar')
    }
    else if (lang === 'hi') {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'hi')
    }
    else {
      this.siteLanguage = this.languageList.find(f => f.code === lang).label;
      sessionStorage.setItem("currentLang", 'en')
    }
    sessionStorage.setItem('sitelanguage', lang);
  }
  headerClick() {
    this.shareDataService.setdoctorbooking(undefined);
    let currentRoute = this.router.url.split('/');
    let currentRouteIndex = currentRoute.findIndex(
      (i) => (i == 'doctor-appointmentcall')
    );
    if (currentRouteIndex && currentRouteIndex > -1) {
      this.shareDataService.headerClick();
    } else {
      currentRouteIndex = currentRoute.findIndex(
        (i) => (i == 'patient-appointmentcall')
      );
      if (currentRouteIndex && currentRouteIndex > -1) {
        this.shareDataService.headerClick();
      } else {
        currentRouteIndex = currentRoute.findIndex(
          (i) => (i == 'consultationcall')
        );
        if (currentRouteIndex && currentRouteIndex > -1) {
          this.shareDataService.headerClick();
        }
      }
    }
  }
  applehomeclick() {
    const subdomain = window.location.hostname.split(".")[0];
    this.domainname = subdomain;
    console.log(this.domainname)
    if (this.domainname == 'appledental') {
      const url = 'https://www.appledentalcare4u.com/';
      window.location.href = url;
    }
  }
  changepatientcheck() {
    let pdata = sessionStorage.getItem("changepatient");
    if (this.role === 'patient') {
      if (pdata == "true") {
        this.familylist = true;
      }
      if (pdata == "false") {
        this.familylist = false;
      }
    }
  }
  familymemberlist() {
    this._DoctorService
      .familylist(this.user_id)
      .pipe(first())
      .subscribe(
        (res: any) => {
          if (!res.isError) {

          }
          else {

          }
        },
        (err) => {

        }
      );
  }
  logout() {
    this.headerClick();
    this.authenticationService.logOut();
    this.router.navigate(['']);
  }
  opendialogpassword() {
    const dialogRef = this.dialog.open(ChangepasswordComponent, {
      panelClass: 'changepassword-dialog',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (!result.data.isError) {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        }
      }
    });
  }
  opendialogpatient() {
    const dialogRef = this.dialog.open(ChangepatientComponent, {
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '100%',
      width: '100%',
      panelClass: 'changefamily-dialog',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
      }
    });
  }
  signinopen(event) {
    const dialogRef = this.dialog.open(PatientLoginComponent, {
      width: '100%',
      panelClass: 'patlogin-dialog',
      autoFocus: false,
      maxHeight: '80vh',
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (!result.data.isError) {
        } else {
        }
      }
    });
  }
}

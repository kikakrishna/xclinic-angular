import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientheaderComponent } from './patientheader.component';
import { MatMenuModule} from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { ChangepasswordComponent } from '../../../pages/changepassword/changepassword.component';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ChangepatientComponent } from '../../../../_components/pages/changepatient/changepatient.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';

@NgModule({
  declarations: [PatientheaderComponent, ChangepasswordComponent, ChangepatientComponent],
  imports: [
    CommonModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    RouterModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule
  ],
  entryComponents: [
    ChangepasswordComponent,
    ChangepatientComponent
  ],
  exports: [
    PatientheaderComponent,
  ]
})
export class PatientheaderModule { }

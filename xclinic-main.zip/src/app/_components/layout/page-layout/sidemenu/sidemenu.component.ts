import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../../../_services/authentication.service';

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})
export class SidemenuComponent implements OnInit {
  userRole:any;
  currentrole: string;
  imageURL: string;
  activerou: boolean;
  
  constructor(private authenticationService: AuthenticationService,private activeroute: ActivatedRoute, private route:Router) { 
    this.userRole = sessionStorage.getItem("Role");
  }

  ngOnInit() {
    console.log(this.userRole);
    
    this.currentrole =  sessionStorage.getItem('userName');
    const url = sessionStorage.getItem('profile');
    if( url != 'null'){
      this.imageURL = url;
    }
    else{
      this.imageURL = "../assets/images/noimage.webp";
    }
  }

}
